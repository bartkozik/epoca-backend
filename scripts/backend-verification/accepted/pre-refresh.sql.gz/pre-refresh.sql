--
-- PostgreSQL database dump
--

-- Dumped from database version 13.4
-- Dumped by pg_dump version 13.4

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: quartz; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA quartz;


--
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA public;


--
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


--
-- Name: set_work_unit_client_id_from_project(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.set_work_unit_client_id_from_project() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
    derived_client_id UUID;
BEGIN
    SELECT project.client_id INTO derived_client_id
    FROM public.project
    WHERE project.id = NEW.project_id;

    IF FOUND THEN
        NEW.client_id := derived_client_id;
    END IF;

    RETURN NEW;
END;
$$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: client; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.client (
    id uuid NOT NULL,
    name text NOT NULL,
    color text NOT NULL,
    organization_id uuid NOT NULL,
    created_at timestamp with time zone NOT NULL,
    created_by uuid NOT NULL,
    modified_at timestamp with time zone NOT NULL,
    modified_by uuid NOT NULL,
    archived_at timestamp with time zone,
    archived_by uuid,
    logo text NOT NULL,
    type text NOT NULL,
    texture text NOT NULL
);


--
-- Name: flyway_schema_history; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.flyway_schema_history (
    installed_rank integer NOT NULL,
    version character varying(50),
    description character varying(200) NOT NULL,
    type character varying(20) NOT NULL,
    script character varying(1000) NOT NULL,
    checksum integer,
    installed_by character varying(100) NOT NULL,
    installed_on timestamp without time zone DEFAULT now() NOT NULL,
    execution_time integer NOT NULL,
    success boolean NOT NULL
);


--
-- Name: invitation; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.invitation (
    id uuid NOT NULL,
    identity_value text NOT NULL,
    identity_type text NOT NULL,
    roles text[] NOT NULL,
    expire_at timestamp without time zone,
    accept_at timestamp without time zone,
    reject_at timestamp without time zone,
    organization_id uuid NOT NULL,
    created_at timestamp without time zone NOT NULL,
    created_by uuid NOT NULL,
    modified_at timestamp without time zone NOT NULL,
    modified_by uuid NOT NULL,
    archived_at timestamp without time zone
);


--
-- Name: mail_history; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.mail_history (
    mail_uuid uuid NOT NULL,
    mail_type text NOT NULL,
    email text NOT NULL,
    created timestamp without time zone,
    api_success timestamp without time zone,
    delivered timestamp without time zone,
    clicked timestamp without time zone,
    opened timestamp without time zone
);


--
-- Name: organization; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.organization (
    id uuid NOT NULL,
    name text NOT NULL,
    slug text NOT NULL,
    created_at timestamp with time zone NOT NULL,
    created_by uuid NOT NULL,
    modified_at timestamp with time zone NOT NULL,
    modified_by uuid NOT NULL,
    archived_at timestamp with time zone
);


--
-- Name: organization_user; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.organization_user (
    organization_id uuid NOT NULL,
    user_id uuid NOT NULL,
    roles text[] NOT NULL,
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    archived_at timestamp with time zone
);


--
-- Name: project; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.project (
    id uuid NOT NULL,
    name text NOT NULL,
    description text,
    organization_id uuid NOT NULL,
    client_id uuid NOT NULL,
    created_at timestamp with time zone NOT NULL,
    created_by uuid NOT NULL,
    modified_at timestamp with time zone NOT NULL,
    modified_by uuid NOT NULL,
    archived_at timestamp with time zone,
    archived_by uuid
);


--
-- Name: project_user; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.project_user (
    id uuid NOT NULL,
    project_id uuid NOT NULL,
    user_id uuid NOT NULL,
    role text NOT NULL,
    created_at timestamp with time zone NOT NULL,
    archived_at timestamp with time zone
);


--
-- Name: quartz_blob_triggers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.quartz_blob_triggers (
    sched_name character varying(120) NOT NULL,
    trigger_name character varying(200) NOT NULL,
    trigger_group character varying(200) NOT NULL,
    blob_data bytea
);


--
-- Name: quartz_calendars; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.quartz_calendars (
    sched_name character varying(120) NOT NULL,
    calendar_name character varying(200) NOT NULL,
    calendar bytea NOT NULL
);


--
-- Name: quartz_cron_triggers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.quartz_cron_triggers (
    sched_name character varying(120) NOT NULL,
    trigger_name character varying(200) NOT NULL,
    trigger_group character varying(200) NOT NULL,
    cron_expression character varying(120) NOT NULL,
    time_zone_id character varying(80)
);


--
-- Name: quartz_fired_triggers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.quartz_fired_triggers (
    sched_name character varying(120) NOT NULL,
    entry_id character varying(95) NOT NULL,
    trigger_name character varying(200) NOT NULL,
    trigger_group character varying(200) NOT NULL,
    instance_name character varying(200) NOT NULL,
    fired_time bigint NOT NULL,
    sched_time bigint NOT NULL,
    priority integer NOT NULL,
    state character varying(16) NOT NULL,
    job_name character varying(200),
    job_group character varying(200),
    is_nonconcurrent boolean,
    requests_recovery boolean
);


--
-- Name: quartz_job_details; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.quartz_job_details (
    sched_name character varying(120) NOT NULL,
    job_name character varying(200) NOT NULL,
    job_group character varying(200) NOT NULL,
    description character varying(250),
    job_class_name character varying(250) NOT NULL,
    is_durable boolean NOT NULL,
    is_nonconcurrent boolean NOT NULL,
    is_update_data boolean NOT NULL,
    requests_recovery boolean NOT NULL,
    job_data bytea
);


--
-- Name: quartz_locks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.quartz_locks (
    sched_name character varying(120) NOT NULL,
    lock_name character varying(40) NOT NULL
);


--
-- Name: quartz_paused_trigger_grps; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.quartz_paused_trigger_grps (
    sched_name character varying(120) NOT NULL,
    trigger_group character varying(200) NOT NULL
);


--
-- Name: quartz_scheduler_state; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.quartz_scheduler_state (
    sched_name character varying(120) NOT NULL,
    instance_name character varying(200) NOT NULL,
    last_checkin_time bigint NOT NULL,
    checkin_interval bigint NOT NULL
);


--
-- Name: quartz_simple_triggers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.quartz_simple_triggers (
    sched_name character varying(120) NOT NULL,
    trigger_name character varying(200) NOT NULL,
    trigger_group character varying(200) NOT NULL,
    repeat_count bigint NOT NULL,
    repeat_interval bigint NOT NULL,
    times_triggered bigint NOT NULL
);


--
-- Name: quartz_simprop_triggers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.quartz_simprop_triggers (
    sched_name character varying(120) NOT NULL,
    trigger_name character varying(200) NOT NULL,
    trigger_group character varying(200) NOT NULL,
    str_prop_1 character varying(512),
    str_prop_2 character varying(512),
    str_prop_3 character varying(512),
    int_prop_1 integer,
    int_prop_2 integer,
    long_prop_1 bigint,
    long_prop_2 bigint,
    dec_prop_1 numeric(13,4),
    dec_prop_2 numeric(13,4),
    bool_prop_1 boolean,
    bool_prop_2 boolean
);


--
-- Name: quartz_triggers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.quartz_triggers (
    sched_name character varying(120) NOT NULL,
    trigger_name character varying(200) NOT NULL,
    trigger_group character varying(200) NOT NULL,
    job_name character varying(200) NOT NULL,
    job_group character varying(200) NOT NULL,
    description character varying(250),
    next_fire_time bigint,
    prev_fire_time bigint,
    priority integer,
    trigger_state character varying(16) NOT NULL,
    trigger_type character varying(8) NOT NULL,
    start_time bigint NOT NULL,
    end_time bigint,
    calendar_name character varying(200),
    misfire_instr smallint,
    job_data bytea
);


--
-- Name: refresh_token; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.refresh_token (
    user_id uuid NOT NULL,
    device_id text NOT NULL,
    user_agent text,
    value text NOT NULL,
    authed_by uuid[] NOT NULL,
    last_authed_at timestamp without time zone NOT NULL,
    created_at timestamp without time zone NOT NULL,
    expired_at timestamp without time zone
);


--
-- Name: saml_config; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.saml_config (
    organization_id uuid NOT NULL,
    idp_cert text NOT NULL,
    idp_entity_id text NOT NULL,
    idp_sso_url text NOT NULL,
    lang_code text NOT NULL,
    validity_duration interval NOT NULL,
    allow_account_init boolean NOT NULL,
    is_enabled boolean NOT NULL,
    created_at timestamp with time zone NOT NULL
);


--
-- Name: saml_request; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.saml_request (
    id text NOT NULL,
    one_time_token uuid,
    user_id uuid,
    used boolean NOT NULL,
    created_at timestamp with time zone NOT NULL
);


--
-- Name: sendgrid_mail_event; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sendgrid_mail_event (
    mail_uuid uuid NOT NULL,
    environment text NOT NULL,
    email text NOT NULL,
    event text,
    ip text,
    mc_stats text,
    phase_id text,
    send_at bigint,
    sg_content_type text,
    sg_event_id text,
    sg_message_id text,
    sg_template_id text,
    sg_template_name text,
    singlesend_id text,
    singlesend_name text,
    template_hash text,
    template_id text,
    template_version_id text,
    "timestamp" bigint,
    useragent text,
    processed boolean,
    reason text
);


--
-- Name: user; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."user" (
    id uuid NOT NULL,
    first_name text NOT NULL,
    last_name text NOT NULL,
    avatar text,
    color text,
    is_super_admin boolean NOT NULL,
    created_at timestamp with time zone NOT NULL,
    modified_at timestamp with time zone NOT NULL,
    archived_at timestamp with time zone
);


--
-- Name: user_identity; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_identity (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    type text NOT NULL,
    value text NOT NULL,
    main boolean NOT NULL,
    device_id text,
    confirmed boolean NOT NULL,
    confirmation_code text,
    created_at timestamp without time zone NOT NULL
);


--
-- Name: user_login_token; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_login_token (
    id uuid NOT NULL,
    user_identity_id uuid NOT NULL,
    login_token text NOT NULL,
    valid_to timestamp without time zone
);


--
-- Name: user_password; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_password (
    user_identity_id uuid NOT NULL,
    password text NOT NULL
);


--
-- Name: work_unit; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.work_unit (
    id uuid NOT NULL,
    organization_id uuid NOT NULL,
    user_id uuid NOT NULL,
    project_id uuid NOT NULL,
    date date NOT NULL,
    duration interval NOT NULL,
    description text NOT NULL,
    created_at timestamp with time zone NOT NULL,
    modified_at timestamp with time zone NOT NULL,
    archived_at timestamp with time zone,
    task_id text,
    client_id uuid NOT NULL,
    state text NOT NULL,
    entry_type text DEFAULT 'Worklog'::text NOT NULL,
    CONSTRAINT work_unit_entry_type_check CHECK ((entry_type = ANY (ARRAY['Worklog'::text, 'Note'::text]))),
    CONSTRAINT work_unit_entry_type_duration_check CHECK ((((entry_type = 'Worklog'::text) AND (duration >= '00:00:01'::interval)) OR ((entry_type = 'Note'::text) AND (duration = '00:00:00'::interval))))
);


--
-- Name: work_unit_idempotency; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.work_unit_idempotency (
    claim_id uuid NOT NULL,
    organization_id uuid NOT NULL,
    actor_id uuid NOT NULL,
    idempotency_key uuid NOT NULL,
    operation text NOT NULL,
    target_work_unit_id uuid,
    fingerprint_version integer NOT NULL,
    canonical_request jsonb,
    fingerprint text NOT NULL,
    state text NOT NULL,
    outcome_status integer,
    outcome_body jsonb,
    result_work_unit_id uuid,
    created_at timestamp with time zone NOT NULL,
    response_expires_at timestamp with time zone,
    CONSTRAINT work_unit_idempotency_command_target_check CHECK ((((operation = 'Create'::text) AND (target_work_unit_id IS NULL)) OR ((operation = 'Update'::text) AND (target_work_unit_id IS NOT NULL)))),
    CONSTRAINT work_unit_idempotency_operation_check CHECK ((operation = ANY (ARRAY['Create'::text, 'Update'::text]))),
    CONSTRAINT work_unit_idempotency_state_check CHECK ((state = ANY (ARRAY['Processing'::text, 'Completed'::text, 'Tombstone'::text]))),
    CONSTRAINT work_unit_idempotency_terminal_check CHECK ((((state = 'Processing'::text) AND (outcome_status IS NULL) AND (outcome_body IS NULL) AND (result_work_unit_id IS NULL) AND (response_expires_at IS NULL)) OR ((state = 'Completed'::text) AND (outcome_status IS NOT NULL) AND (outcome_body IS NOT NULL) AND (response_expires_at IS NOT NULL)) OR ((state = 'Tombstone'::text) AND (outcome_status IS NOT NULL) AND (outcome_body IS NULL) AND (canonical_request IS NULL) AND (response_expires_at IS NOT NULL))))
);


--
-- Name: work_unit_order; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.work_unit_order (
    organization_id uuid NOT NULL,
    user_id uuid NOT NULL,
    date date NOT NULL,
    work_unit_ids uuid[] NOT NULL
);


--
-- Name: work_unit_pm_classification; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.work_unit_pm_classification (
    work_unit_id uuid NOT NULL,
    pm_project_id uuid,
    pm_task_id text,
    version bigint NOT NULL,
    last_changed_by uuid NOT NULL,
    last_changed_at timestamp with time zone NOT NULL,
    CONSTRAINT work_unit_pm_classification_version_check CHECK ((version > 0)),
    CONSTRAINT work_unit_pm_task_id_valid CHECK (((pm_task_id IS NULL) OR ((btrim(pm_task_id) <> ''::text) AND (char_length(pm_task_id) <= 255))))
);


--
-- Name: work_unit_pm_classification_history; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.work_unit_pm_classification_history (
    id uuid NOT NULL,
    work_unit_id uuid NOT NULL,
    version bigint NOT NULL,
    operation text NOT NULL,
    actor_id uuid NOT NULL,
    actor_display_name text NOT NULL,
    changed_at timestamp with time zone NOT NULL,
    before_pm_project_id uuid,
    before_pm_project_name text,
    before_pm_client_id uuid,
    before_pm_client_name text,
    before_pm_task_id text,
    after_pm_project_id uuid,
    after_pm_project_name text,
    after_pm_client_id uuid,
    after_pm_client_name text,
    after_pm_task_id text,
    CONSTRAINT work_unit_pm_classification_history_after_pm_task_id_valid CHECK (((after_pm_task_id IS NULL) OR ((btrim(after_pm_task_id) <> ''::text) AND (char_length(after_pm_task_id) <= 255)))),
    CONSTRAINT work_unit_pm_classification_history_before_pm_task_id_valid CHECK (((before_pm_task_id IS NULL) OR ((btrim(before_pm_task_id) <> ''::text) AND (char_length(before_pm_task_id) <= 255)))),
    CONSTRAINT work_unit_pm_classification_history_operation_check CHECK ((operation = ANY (ARRAY['Replace'::text, 'Clear'::text]))),
    CONSTRAINT work_unit_pm_classification_history_version_check CHECK ((version > 0))
);


--
-- Data for Name: client; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.client (id, name, color, organization_id, created_at, created_by, modified_at, modified_by, archived_at, archived_by, logo, type, texture) FROM stdin;
9baaa280-6dca-51c5-85f7-99b7fd05e701	Atelier Operations	#5B5BD6	62445afe-3364-5e78-b55e-fb5429807a47	2026-02-13 00:01:00+00	bc1ce6aa-f011-56ab-9e10-492c111f50ba	2026-02-13 00:01:00+00	bc1ce6aa-f011-56ab-9e10-492c111f50ba	\N	\N		Internal	
d677a650-2c23-5c0c-9f53-920636bd318e	Época Labs	#2E90FA	62445afe-3364-5e78-b55e-fb5429807a47	2026-02-13 00:02:00+00	bc1ce6aa-f011-56ab-9e10-492c111f50ba	2026-02-13 00:02:00+00	bc1ce6aa-f011-56ab-9e10-492c111f50ba	\N	\N		Internal	
79d55734-27e3-5dd0-bf06-6726f0eba8b3	Northstar Health	#12B76A	62445afe-3364-5e78-b55e-fb5429807a47	2026-02-13 00:03:00+00	bc1ce6aa-f011-56ab-9e10-492c111f50ba	2026-02-13 00:03:00+00	bc1ce6aa-f011-56ab-9e10-492c111f50ba	\N	\N		External	
3030e191-44de-5909-b035-5fe3679b482a	Lumen Retail	#F79009	62445afe-3364-5e78-b55e-fb5429807a47	2026-02-13 00:04:00+00	bc1ce6aa-f011-56ab-9e10-492c111f50ba	2026-02-13 00:04:00+00	bc1ce6aa-f011-56ab-9e10-492c111f50ba	\N	\N		External	
eba17d28-b076-534c-918a-dca0a5be8fab	Verdant Mobility	#06AED4	62445afe-3364-5e78-b55e-fb5429807a47	2026-02-13 00:05:00+00	bc1ce6aa-f011-56ab-9e10-492c111f50ba	2026-02-13 00:05:00+00	bc1ce6aa-f011-56ab-9e10-492c111f50ba	\N	\N		External	
f4c5b0e8-5503-5a50-8487-4ae103b885f2	Harbor Finance	#7A5AF8	62445afe-3364-5e78-b55e-fb5429807a47	2026-02-13 00:06:00+00	bc1ce6aa-f011-56ab-9e10-492c111f50ba	2026-02-13 00:06:00+00	bc1ce6aa-f011-56ab-9e10-492c111f50ba	\N	\N		External	
a9e0bb14-488c-5643-96ca-5848796322a3	Aurora Learning	#EE46BC	62445afe-3364-5e78-b55e-fb5429807a47	2026-02-13 00:07:00+00	bc1ce6aa-f011-56ab-9e10-492c111f50ba	2026-02-13 00:07:00+00	bc1ce6aa-f011-56ab-9e10-492c111f50ba	\N	\N		External	
e7e99ce4-232e-5ade-abb1-0966c94d952e	Pulse Commerce	#F04438	62445afe-3364-5e78-b55e-fb5429807a47	2026-02-13 00:08:00+00	bc1ce6aa-f011-56ab-9e10-492c111f50ba	2026-02-13 00:08:00+00	bc1ce6aa-f011-56ab-9e10-492c111f50ba	\N	\N		External	
141122b1-9a71-570d-a44c-efc88209be99	Orbit Logistics	#667085	62445afe-3364-5e78-b55e-fb5429807a47	2026-02-13 00:09:00+00	bc1ce6aa-f011-56ab-9e10-492c111f50ba	2026-07-13 00:00:00+00	bc1ce6aa-f011-56ab-9e10-492c111f50ba	2026-07-13 00:00:00+00	bc1ce6aa-f011-56ab-9e10-492c111f50ba		External	
498db7da-8df6-5797-90f5-e34933a83972	Ember Hospitality	#B54708	62445afe-3364-5e78-b55e-fb5429807a47	2026-02-13 00:10:00+00	bc1ce6aa-f011-56ab-9e10-492c111f50ba	2026-07-13 00:00:00+00	bc1ce6aa-f011-56ab-9e10-492c111f50ba	2026-07-13 00:00:00+00	bc1ce6aa-f011-56ab-9e10-492c111f50ba		External	
\.


--
-- Data for Name: flyway_schema_history; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.flyway_schema_history (installed_rank, version, description, type, script, checksum, installed_by, installed_on, execution_time, success) FROM stdin;
0	\N	<< Flyway Schema Creation >>	SCHEMA	"quartz"	\N	postgres	2026-08-12 15:23:50.298167	0	t
1	1	user	SQL	V1__user.sql	-1567996275	postgres	2026-08-12 15:23:50.304828	7	t
2	2	organization	SQL	V2__organization.sql	826719244	postgres	2026-08-12 15:23:50.315811	3	t
3	3	client	SQL	V3__client.sql	-739817190	postgres	2026-08-12 15:23:50.321579	1	t
4	4	mail	SQL	V4__mail.sql	-1188858876	postgres	2026-08-12 15:23:50.325111	2	t
5	5	refresh token	SQL	V5__refresh_token.sql	681046707	postgres	2026-08-12 15:23:50.329325	1	t
6	6	project	SQL	V6__project.sql	979613496	postgres	2026-08-12 15:23:50.332377	2	t
7	7	add logo to client	SQL	V7__add_logo_to_client.sql	1819409206	postgres	2026-08-12 15:23:50.336593	1	t
8	8	work unit	SQL	V8__work_unit.sql	-1231120825	postgres	2026-08-12 15:23:50.339131	1	t
9	9	add task id to work unit	SQL	V9__add_task_id_to_work_unit.sql	289589848	postgres	2026-08-12 15:23:50.342261	0	t
10	10	saml config	SQL	V10__saml_config.sql	1259928605	postgres	2026-08-12 15:23:50.344737	2	t
11	11	add role to client	SQL	V11__add_role_to_client.sql	-636722096	postgres	2026-08-12 15:23:50.349369	0	t
12	12	add client id to work unit	SQL	V12__add_client_id_to_work_unit.sql	-129459335	postgres	2026-08-12 15:23:50.351641	1	t
13	13	work unit state	SQL	V13__work_unit_state.sql	1324311047	postgres	2026-08-12 15:23:50.354935	0	t
14	14	add texture client	SQL	V14__add_texture_client.sql	-189016165	postgres	2026-08-12 15:23:50.357051	0	t
15	15	add id organization user	SQL	V15__add_id_organization_user.sql	-1614887485	postgres	2026-08-12 15:23:50.359426	275	t
16	16	work unit order	SQL	V16__work_unit_order.sql	-1298079313	postgres	2026-08-12 15:23:50.637512	1	t
17	17	updated template db version	SQL	V17__updated_template_db_version.sql	632295822	postgres	2026-08-12 15:23:50.645206	27	t
18	18	add missing foreign keys	SQL	V18__add_missing_foreign_keys.sql	422071501	postgres	2026-08-12 15:23:50.677038	3	t
19	19	derive work unit client id from project	SQL	V19__derive_work_unit_client_id_from_project.sql	-2016685051	postgres	2026-08-12 15:23:50.682734	2	t
20	20	add work unit idempotency	SQL	V20__add_work_unit_idempotency.sql	35355711	postgres	2026-08-12 15:23:50.688197	2	t
21	21	add work unit entry type	SQL	V21__add_work_unit_entry_type.sql	-327069890	postgres	2026-08-12 15:23:50.692977	2	t
22	22	add work unit corrections	SQL	V22__add_work_unit_corrections.sql	928587633	postgres	2026-08-12 15:23:50.697611	8	t
23	23	migrate work unit corrections to pm classification	SQL	V23__migrate_work_unit_corrections_to_pm_classification.sql	459476547	postgres	2026-08-12 15:23:50.709428	8	t
24	\N	add work unit effective project index	SQL	R__add_work_unit_effective_project_index.sql	-1032247368	postgres	2026-08-12 15:23:50.719703	0	t
\.


--
-- Data for Name: invitation; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.invitation (id, identity_value, identity_type, roles, expire_at, accept_at, reject_at, organization_id, created_at, created_by, modified_at, modified_by, archived_at) FROM stdin;
\.


--
-- Data for Name: mail_history; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.mail_history (mail_uuid, mail_type, email, created, api_success, delivered, clicked, opened) FROM stdin;
\.


--
-- Data for Name: organization; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.organization (id, name, slug, created_at, created_by, modified_at, modified_by, archived_at) FROM stdin;
62445afe-3364-5e78-b55e-fb5429807a47	Iterators Testing	iteratorstesting	2026-02-13 00:01:00+00	bc1ce6aa-f011-56ab-9e10-492c111f50ba	2026-02-13 00:01:00+00	bc1ce6aa-f011-56ab-9e10-492c111f50ba	\N
\.


--
-- Data for Name: organization_user; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.organization_user (organization_id, user_id, roles, id, archived_at) FROM stdin;
62445afe-3364-5e78-b55e-fb5429807a47	bc1ce6aa-f011-56ab-9e10-492c111f50ba	{Owner}	7fb14237-9b39-5ba7-9eb9-5af326eec768	\N
62445afe-3364-5e78-b55e-fb5429807a47	bb6bdf69-6501-5ad2-9a1b-0148f459d5f3	{Manager}	01f6875b-9578-5e54-9ab5-ee7264b1d07d	\N
62445afe-3364-5e78-b55e-fb5429807a47	6503790e-ec8d-5c9c-a6f9-20766eed6fb4	{Owner}	71e05f52-3d4b-5098-b2f1-ea4c421a3e83	\N
62445afe-3364-5e78-b55e-fb5429807a47	de529b34-39ac-5368-86e8-1d1076117642	{Manager}	b8b994cb-9791-5346-b890-b6ec0c0ec038	\N
62445afe-3364-5e78-b55e-fb5429807a47	75243589-322b-5eea-941f-54c424751a23	{Employee}	1ed87280-98ae-5e4d-88ca-fa0e6d193a9c	\N
62445afe-3364-5e78-b55e-fb5429807a47	3c3001bd-6e38-504d-9b49-01d36a027754	{Employee}	2e372c71-aab9-5383-b423-34d68540aad1	\N
62445afe-3364-5e78-b55e-fb5429807a47	69b673aa-8141-5faa-8677-2839e80e1d78	{Employee}	cedf5a33-282b-5cc2-ad28-e598bb64b6c2	\N
62445afe-3364-5e78-b55e-fb5429807a47	44d6afb5-6765-5cc4-b4c9-a8877761b0ca	{Employee}	4c9b4ef6-fe94-55ff-a3b0-2c9b86e6d450	\N
62445afe-3364-5e78-b55e-fb5429807a47	636cb5b4-a95e-5d50-b513-6871826ee53f	{Employee}	d366c9ef-e84c-55dc-911f-2ae842a7fe39	\N
62445afe-3364-5e78-b55e-fb5429807a47	cbe7100e-7e0b-5f30-9fec-aca7c60cad25	{Employee}	6928d1a6-bd1c-589b-9900-0169eefecf73	\N
62445afe-3364-5e78-b55e-fb5429807a47	0f2178f1-017b-5762-b9fd-a197cb6cce9c	{Employee}	438cb82c-2855-589d-bed6-671610958139	\N
62445afe-3364-5e78-b55e-fb5429807a47	68e81bc4-dc44-5a60-b522-6f6909339289	{Employee}	382aabef-af8f-5e53-b314-ef1d84eba7d6	\N
62445afe-3364-5e78-b55e-fb5429807a47	b47a0c61-e4a8-5afd-b215-61150a1e3066	{Employee}	f96f7378-b388-5407-8f3f-3eedd94d0e40	\N
62445afe-3364-5e78-b55e-fb5429807a47	97447306-b2af-5ad3-a0bb-ab876cfe713a	{Employee}	609562a7-6273-5a8d-90d6-a8653d6d63bb	\N
62445afe-3364-5e78-b55e-fb5429807a47	36904740-e579-521d-8461-726ccb5f1806	{Employee}	1fe79507-744b-5e46-8161-118c2768e885	\N
62445afe-3364-5e78-b55e-fb5429807a47	1f95823c-e9b9-5334-8f67-669822d8bd9f	{Employee}	be3fa750-d249-5b3f-b5f4-2062cf2a7a6e	\N
62445afe-3364-5e78-b55e-fb5429807a47	9a22f385-4227-5e99-8f8b-5d66bc7315a3	{Employee}	475e483b-8409-586d-bd36-016174a6dd83	\N
62445afe-3364-5e78-b55e-fb5429807a47	3681b9d5-7732-52da-b97e-97efdcf08fd9	{Employee}	2634d84c-63aa-5fd1-a4e3-d552e58a98c6	\N
62445afe-3364-5e78-b55e-fb5429807a47	fe59379a-ab41-581e-8b2e-24d95eb4cee8	{Employee}	2d885608-e1f7-55bd-8858-cf20e977f2c0	\N
62445afe-3364-5e78-b55e-fb5429807a47	5c8e49c9-c065-5bc8-a57a-0a69e1a89a5e	{Employee}	72aad6d1-06a1-5df2-8969-ff0ef4cb12d7	\N
62445afe-3364-5e78-b55e-fb5429807a47	18664d65-3906-58e7-91fd-d67ffedd1b64	{Employee}	2bea5b5c-6cb0-5fa0-a97e-e774b576dc29	\N
62445afe-3364-5e78-b55e-fb5429807a47	2d40ec7a-98f2-5e42-84d6-c8bafec1e0b2	{Employee}	fcf70038-716a-5079-bfd1-8ce460965457	\N
62445afe-3364-5e78-b55e-fb5429807a47	8e9f41ef-4f61-5811-a73e-3a8bfbf74881	{Employee}	830f0594-ce35-5afa-87fe-bd4dea38fd26	\N
62445afe-3364-5e78-b55e-fb5429807a47	3d0cfe6d-2c3e-5102-a541-f86e8aef695d	{Employee}	bb0bf31e-e98f-51f2-be23-b8d30d4b282e	\N
62445afe-3364-5e78-b55e-fb5429807a47	372b5e87-7bf3-5e30-98c4-56a4c19d17fa	{Employee}	33beb656-69af-5621-8add-b65a6e1dd3e0	\N
62445afe-3364-5e78-b55e-fb5429807a47	e5222c33-013c-5ba6-9bcb-a11c7a43cbf0	{Employee}	dbd88767-3899-5d3f-b283-ef3b272c23fc	\N
62445afe-3364-5e78-b55e-fb5429807a47	8205f025-5eee-5f16-9e8e-b6a44f2a90e7	{External}	64951558-8fdb-5295-a7c7-2276d9a98e93	\N
62445afe-3364-5e78-b55e-fb5429807a47	6657781f-74d0-50d8-8f90-7c701d622872	{External}	fffc3d4a-7b22-5758-a017-9de8684dfc3b	\N
62445afe-3364-5e78-b55e-fb5429807a47	1bfc7228-78d0-5a5c-8562-deb1f1a7b28f	{External}	57af87dc-5e4d-5741-84b6-3ff02ae67ef2	\N
62445afe-3364-5e78-b55e-fb5429807a47	f3048101-4480-533e-896e-9295fb7f01d5	{External}	2fa17de6-c4f4-5619-9da5-a2f95b428974	\N
\.


--
-- Data for Name: project; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.project (id, name, description, organization_id, client_id, created_at, created_by, modified_at, modified_by, archived_at, archived_by) FROM stdin;
eb73aa6c-87aa-532d-8b94-109b8b863733	Design System Evolution	Evolves shared design-system foundations, accessible components, and contribution workflows for product teams.	62445afe-3364-5e78-b55e-fb5429807a47	9baaa280-6dca-51c5-85f7-99b7fd05e701	2026-02-23 00:02:00+00	bc1ce6aa-f011-56ab-9e10-492c111f50ba	2026-02-23 00:02:00+00	bc1ce6aa-f011-56ab-9e10-492c111f50ba	\N	\N
f04245fa-9e0e-5905-80fa-524e9f1e172f	Delivery Operations Hub	Coordinates delivery planning, staffing, risks, and operational handoffs across active engagements.	62445afe-3364-5e78-b55e-fb5429807a47	9baaa280-6dca-51c5-85f7-99b7fd05e701	2026-02-23 00:01:00+00	bc1ce6aa-f011-56ab-9e10-492c111f50ba	2026-02-23 00:01:00+00	bc1ce6aa-f011-56ab-9e10-492c111f50ba	\N	\N
67164958-1bad-5a9c-8d3a-7c4f7dfb7282	Reporting Sandbox	Provides a safe reporting workspace for prototyping metrics, dashboards, and decision-ready exports.	62445afe-3364-5e78-b55e-fb5429807a47	d677a650-2c23-5c0c-9f53-920636bd318e	2026-02-23 00:04:00+00	bc1ce6aa-f011-56ab-9e10-492c111f50ba	2026-02-23 00:04:00+00	bc1ce6aa-f011-56ab-9e10-492c111f50ba	\N	\N
b8cd683c-fe4d-538c-bdaf-68c28e1e14ef	Time Intelligence	Improves time tracking with dependable entry workflows, actionable trends, and capacity insights.	62445afe-3364-5e78-b55e-fb5429807a47	d677a650-2c23-5c0c-9f53-920636bd318e	2026-02-23 00:03:00+00	bc1ce6aa-f011-56ab-9e10-492c111f50ba	2026-02-23 00:03:00+00	bc1ce6aa-f011-56ab-9e10-492c111f50ba	\N	\N
e7ea37c3-9fe3-5010-bb38-8c7330ef5bdc	Care Analytics	Turns clinical and operational data into clear analytics for care quality and service planning.	62445afe-3364-5e78-b55e-fb5429807a47	79d55734-27e3-5dd0-bf06-6726f0eba8b3	2026-02-23 00:06:00+00	bc1ce6aa-f011-56ab-9e10-492c111f50ba	2026-02-23 00:06:00+00	bc1ce6aa-f011-56ab-9e10-492c111f50ba	\N	\N
9406b74a-6b7a-578b-8fbd-958684d93780	Patient Portal	Delivers a secure health portal where patients can manage appointments, messages, and care information.	62445afe-3364-5e78-b55e-fb5429807a47	79d55734-27e3-5dd0-bf06-6726f0eba8b3	2026-02-23 00:05:00+00	bc1ce6aa-f011-56ab-9e10-492c111f50ba	2026-02-23 00:05:00+00	bc1ce6aa-f011-56ab-9e10-492c111f50ba	\N	\N
06f6bf38-0173-52de-aa5b-77d565741cb1	Retail Insights	Combines retail performance data into practical business intelligence for merchandising and store teams.	62445afe-3364-5e78-b55e-fb5429807a47	3030e191-44de-5909-b035-5fe3679b482a	2026-02-23 00:08:00+00	bc1ce6aa-f011-56ab-9e10-492c111f50ba	2026-02-23 00:08:00+00	bc1ce6aa-f011-56ab-9e10-492c111f50ba	\N	\N
a7906be2-315f-5b5e-b344-ac119fd04d1a	Omnichannel Checkout	Unifies checkout journeys across web, mobile, and stores with consistent payment and fulfillment options.	62445afe-3364-5e78-b55e-fb5429807a47	3030e191-44de-5909-b035-5fe3679b482a	2026-02-23 00:07:00+00	bc1ce6aa-f011-56ab-9e10-492c111f50ba	2026-02-23 00:07:00+00	bc1ce6aa-f011-56ab-9e10-492c111f50ba	\N	\N
613fe369-ab85-5812-9136-0d147b91706d	Mobility Discovery	Explores customer needs and viable concepts for the next generation of connected mobility services.	62445afe-3364-5e78-b55e-fb5429807a47	eba17d28-b076-534c-918a-dca0a5be8fab	2026-02-23 00:10:00+00	bc1ce6aa-f011-56ab-9e10-492c111f50ba	2026-07-13 00:00:00+00	bc1ce6aa-f011-56ab-9e10-492c111f50ba	2026-07-13 00:00:00+00	bc1ce6aa-f011-56ab-9e10-492c111f50ba
6dfe9630-59ce-507d-81a0-2f94cb54247f	Fleet Companion	Supports drivers and fleet operators with a focused mobility app for vehicles, trips, and service needs.	62445afe-3364-5e78-b55e-fb5429807a47	eba17d28-b076-534c-918a-dca0a5be8fab	2026-02-23 00:09:00+00	bc1ce6aa-f011-56ab-9e10-492c111f50ba	2026-02-23 00:09:00+00	bc1ce6aa-f011-56ab-9e10-492c111f50ba	\N	\N
f07ee933-bae1-5f0f-9e95-6c303aba6f5d	Open Banking Integration	Connects regulated banking providers through resilient consent, account, and transaction integration flows.	62445afe-3364-5e78-b55e-fb5429807a47	f4c5b0e8-5503-5a50-8487-4ae103b885f2	2026-02-23 00:12:00+00	bc1ce6aa-f011-56ab-9e10-492c111f50ba	2026-02-23 00:12:00+00	bc1ce6aa-f011-56ab-9e10-492c111f50ba	\N	\N
35f8aab0-9932-515e-80cc-e8fa82f9c650	Risk Dashboard	Surfaces portfolio exposure, control signals, and emerging financial risks in one auditable dashboard.	62445afe-3364-5e78-b55e-fb5429807a47	f4c5b0e8-5503-5a50-8487-4ae103b885f2	2026-02-23 00:11:00+00	bc1ce6aa-f011-56ab-9e10-492c111f50ba	2026-02-23 00:11:00+00	bc1ce6aa-f011-56ab-9e10-492c111f50ba	\N	\N
1146e928-4d82-581f-84f2-b8c9b6c83378	Learning Experience	Creates an engaging learning experience for discovering content, tracking progress, and supporting instructors.	62445afe-3364-5e78-b55e-fb5429807a47	a9e0bb14-488c-5643-96ca-5848796322a3	2026-02-23 00:13:00+00	bc1ce6aa-f011-56ab-9e10-492c111f50ba	2026-02-23 00:13:00+00	bc1ce6aa-f011-56ab-9e10-492c111f50ba	\N	\N
04500693-9e94-55cd-a8ad-c3627d2dac80	Commerce Growth	Tests and scales commerce growth opportunities across acquisition, conversion, retention, and lifecycle messaging.	62445afe-3364-5e78-b55e-fb5429807a47	e7e99ce4-232e-5ade-abb1-0966c94d952e	2026-02-23 00:14:00+00	bc1ce6aa-f011-56ab-9e10-492c111f50ba	2026-02-23 00:14:00+00	bc1ce6aa-f011-56ab-9e10-492c111f50ba	\N	\N
3d5d3faf-2bbd-5bca-ac00-1c6056bf7ca6	Dispatch Optimizer	Optimizes logistics dispatch decisions using route constraints, shipment priorities, and live operating conditions.	62445afe-3364-5e78-b55e-fb5429807a47	141122b1-9a71-570d-a44c-efc88209be99	2026-02-23 00:15:00+00	bc1ce6aa-f011-56ab-9e10-492c111f50ba	2026-07-13 00:00:00+00	bc1ce6aa-f011-56ab-9e10-492c111f50ba	2026-07-13 00:00:00+00	bc1ce6aa-f011-56ab-9e10-492c111f50ba
6f343524-7197-5868-bc07-4ca1a311dc9e	Guest Journey	Maps and improves the hospitality journey from reservation and arrival through the post-stay relationship.	62445afe-3364-5e78-b55e-fb5429807a47	498db7da-8df6-5797-90f5-e34933a83972	2026-02-23 00:16:00+00	bc1ce6aa-f011-56ab-9e10-492c111f50ba	2026-07-13 00:00:00+00	bc1ce6aa-f011-56ab-9e10-492c111f50ba	2026-07-13 00:00:00+00	bc1ce6aa-f011-56ab-9e10-492c111f50ba
\.


--
-- Data for Name: project_user; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.project_user (id, project_id, user_id, role, created_at, archived_at) FROM stdin;
34bcc74e-b9dd-53ee-928c-f826c562961c	04500693-9e94-55cd-a8ad-c3627d2dac80	b47a0c61-e4a8-5afd-b215-61150a1e3066	Member	2026-03-05 14:13:00+00	\N
f5e8308b-f58e-5af9-af94-4fa39649aeaf	04500693-9e94-55cd-a8ad-c3627d2dac80	1f95823c-e9b9-5334-8f67-669822d8bd9f	Owner	2026-03-05 14:16:00+00	\N
5a32e486-e187-5f9d-9e3d-96e7068119ff	04500693-9e94-55cd-a8ad-c3627d2dac80	e5222c33-013c-5ba6-9bcb-a11c7a43cbf0	Member	2026-03-05 14:26:00+00	\N
0998eeed-ddf8-5c1b-a3b8-96a242cc818a	04500693-9e94-55cd-a8ad-c3627d2dac80	75243589-322b-5eea-941f-54c424751a23	Member	2026-03-05 14:05:00+00	\N
d1f79428-0ba1-50c7-9736-cd97b5e3b4e8	04500693-9e94-55cd-a8ad-c3627d2dac80	3c3001bd-6e38-504d-9b49-01d36a027754	Member	2026-03-05 14:06:00+00	\N
40c1c56f-b0b2-5351-b165-ba326b4cd36a	06f6bf38-0173-52de-aa5b-77d565741cb1	44d6afb5-6765-5cc4-b4c9-a8877761b0ca	Member	2026-03-05 08:08:00+00	\N
a9378f2c-854d-579e-9ee1-887f5b68e77c	06f6bf38-0173-52de-aa5b-77d565741cb1	cbe7100e-7e0b-5f30-9fec-aca7c60cad25	Owner	2026-03-05 08:10:00+00	\N
d189b60d-1618-5085-ab75-3e3beee0c671	06f6bf38-0173-52de-aa5b-77d565741cb1	18664d65-3906-58e7-91fd-d67ffedd1b64	Member	2026-03-05 08:21:00+00	\N
cb8732f6-f13b-5e23-bba2-8b3b4ca42b1e	06f6bf38-0173-52de-aa5b-77d565741cb1	f3048101-4480-533e-896e-9295fb7f01d5	Member	2026-03-05 08:30:00+00	\N
819fb37c-d03d-5bbf-90ec-43057c9e267a	06f6bf38-0173-52de-aa5b-77d565741cb1	75243589-322b-5eea-941f-54c424751a23	Member	2026-03-05 08:05:00+00	\N
3ae6f39a-7e37-5bff-934d-da82b4ab388b	1146e928-4d82-581f-84f2-b8c9b6c83378	68e81bc4-dc44-5a60-b522-6f6909339289	Member	2026-03-05 13:12:00+00	\N
ff38b54b-4b1d-5add-a463-fc4a44e48a62	1146e928-4d82-581f-84f2-b8c9b6c83378	36904740-e579-521d-8461-726ccb5f1806	Owner	2026-03-05 13:15:00+00	\N
76c89696-8875-5259-a270-616ddbc11371	1146e928-4d82-581f-84f2-b8c9b6c83378	372b5e87-7bf3-5e30-98c4-56a4c19d17fa	Member	2026-03-05 13:25:00+00	\N
af1a0d07-80f0-510c-86c7-b70f4af4b2c4	1146e928-4d82-581f-84f2-b8c9b6c83378	b47a0c61-e4a8-5afd-b215-61150a1e3066	Member	2026-03-05 13:13:00+00	\N
d16ffb31-5b72-5897-b493-7556b86d9f3f	1146e928-4d82-581f-84f2-b8c9b6c83378	97447306-b2af-5ad3-a0bb-ab876cfe713a	Member	2026-03-05 13:14:00+00	\N
975e0f8f-0707-5e2b-9fdd-1877dc842505	1146e928-4d82-581f-84f2-b8c9b6c83378	1f95823c-e9b9-5334-8f67-669822d8bd9f	Member	2026-03-05 13:16:00+00	\N
5757932e-2c6d-59ff-a3c4-296eb3a8bfc4	1146e928-4d82-581f-84f2-b8c9b6c83378	9a22f385-4227-5e99-8f8b-5d66bc7315a3	Member	2026-03-05 13:17:00+00	\N
411f8cf1-d72d-547e-bcde-38be6cbfda09	35f8aab0-9932-515e-80cc-e8fa82f9c650	cbe7100e-7e0b-5f30-9fec-aca7c60cad25	Member	2026-03-05 11:10:00+00	\N
0d39f7b8-1097-5224-be36-77c1636f7ac3	35f8aab0-9932-515e-80cc-e8fa82f9c650	b47a0c61-e4a8-5afd-b215-61150a1e3066	Owner	2026-03-05 11:13:00+00	\N
4ace2f5c-b715-5f52-9e75-ee66c5520825	35f8aab0-9932-515e-80cc-e8fa82f9c650	8e9f41ef-4f61-5811-a73e-3a8bfbf74881	Member	2026-03-05 11:23:00+00	\N
391c685a-fff6-5a7d-aff0-5d0852f889ba	35f8aab0-9932-515e-80cc-e8fa82f9c650	75243589-322b-5eea-941f-54c424751a23	Member	2026-03-05 11:05:00+00	\N
eff136cc-a85f-52a4-bb38-74128d7511d2	35f8aab0-9932-515e-80cc-e8fa82f9c650	3c3001bd-6e38-504d-9b49-01d36a027754	Member	2026-03-05 11:06:00+00	\N
33ccf0db-3d6b-5d7f-a60c-e5c9f4d9709c	35f8aab0-9932-515e-80cc-e8fa82f9c650	69b673aa-8141-5faa-8677-2839e80e1d78	Member	2026-03-05 11:07:00+00	\N
70e3c319-aef8-5f8b-aa45-d680db4f60e0	3d5d3faf-2bbd-5bca-ac00-1c6056bf7ca6	9a22f385-4227-5e99-8f8b-5d66bc7315a3	Owner	2026-03-05 15:17:00+00	2026-07-13 00:00:00+00
31403c8b-ce5b-5ef8-8623-af5feafcb788	3d5d3faf-2bbd-5bca-ac00-1c6056bf7ca6	18664d65-3906-58e7-91fd-d67ffedd1b64	Member	2026-03-05 15:21:00+00	2026-07-13 00:00:00+00
9075cf09-262c-5f41-b5c8-5032c4bd0fa0	3d5d3faf-2bbd-5bca-ac00-1c6056bf7ca6	2d40ec7a-98f2-5e42-84d6-c8bafec1e0b2	Member	2026-03-05 15:22:00+00	2026-07-13 00:00:00+00
4dae9d8c-5b9d-5524-ab76-6c10e7f9d7ca	3d5d3faf-2bbd-5bca-ac00-1c6056bf7ca6	8e9f41ef-4f61-5811-a73e-3a8bfbf74881	Member	2026-03-05 15:23:00+00	2026-07-13 00:00:00+00
ecb9d6a1-742c-547b-90f0-d620f59ced8b	3d5d3faf-2bbd-5bca-ac00-1c6056bf7ca6	3d0cfe6d-2c3e-5102-a541-f86e8aef695d	Member	2026-03-05 15:24:00+00	2026-07-13 00:00:00+00
96bb6b78-288d-5f5a-8765-8e64081b5371	3d5d3faf-2bbd-5bca-ac00-1c6056bf7ca6	372b5e87-7bf3-5e30-98c4-56a4c19d17fa	Member	2026-03-05 15:25:00+00	2026-07-13 00:00:00+00
5168395e-dbf8-50d2-a4e9-e23f31776ff7	613fe369-ab85-5812-9136-0d147b91706d	68e81bc4-dc44-5a60-b522-6f6909339289	Owner	2026-03-05 10:12:00+00	2026-07-13 00:00:00+00
f398df67-460f-5a0f-a650-9e7319e02ad6	613fe369-ab85-5812-9136-0d147b91706d	97447306-b2af-5ad3-a0bb-ab876cfe713a	Member	2026-03-05 10:14:00+00	2026-07-13 00:00:00+00
fc520326-d9e3-5b89-9677-c28cee8516ff	613fe369-ab85-5812-9136-0d147b91706d	36904740-e579-521d-8461-726ccb5f1806	Member	2026-03-05 10:15:00+00	2026-07-13 00:00:00+00
d571d8c3-b0a2-560e-93ee-0d94d2e14cc1	613fe369-ab85-5812-9136-0d147b91706d	1f95823c-e9b9-5334-8f67-669822d8bd9f	Member	2026-03-05 10:16:00+00	2026-07-13 00:00:00+00
8379ee24-a436-5c4f-b6cd-43fae7692892	67164958-1bad-5a9c-8d3a-7c4f7dfb7282	de529b34-39ac-5368-86e8-1d1076117642	Member	2026-03-05 04:04:00+00	\N
ed47e55c-f2a8-599b-a408-bb0965699c70	67164958-1bad-5a9c-8d3a-7c4f7dfb7282	3c3001bd-6e38-504d-9b49-01d36a027754	Owner	2026-03-05 04:06:00+00	\N
eda0c3a4-216f-547b-a142-651470f8ce50	67164958-1bad-5a9c-8d3a-7c4f7dfb7282	9a22f385-4227-5e99-8f8b-5d66bc7315a3	Member	2026-03-05 04:17:00+00	\N
b5347560-efd5-55f3-b738-70ac8629861c	67164958-1bad-5a9c-8d3a-7c4f7dfb7282	3681b9d5-7732-52da-b97e-97efdcf08fd9	Member	2026-03-05 04:18:00+00	\N
a3c9dab6-2589-53b1-92e7-fdc24eafb918	67164958-1bad-5a9c-8d3a-7c4f7dfb7282	fe59379a-ab41-581e-8b2e-24d95eb4cee8	Member	2026-03-05 04:19:00+00	\N
374afda1-7e1f-5d69-b799-c1b94222c6d4	6dfe9630-59ce-507d-81a0-2f94cb54247f	636cb5b4-a95e-5d50-b513-6871826ee53f	Member	2026-03-05 09:09:00+00	\N
69b98f71-b512-5660-a5d2-98a4858c4b57	6dfe9630-59ce-507d-81a0-2f94cb54247f	0f2178f1-017b-5762-b9fd-a197cb6cce9c	Owner	2026-03-05 09:11:00+00	\N
20896818-8bf1-58dd-8079-fc8a130f72ae	6dfe9630-59ce-507d-81a0-2f94cb54247f	2d40ec7a-98f2-5e42-84d6-c8bafec1e0b2	Member	2026-03-05 09:22:00+00	\N
95e057ba-0821-5ddd-8783-c22abc1d6cbc	6dfe9630-59ce-507d-81a0-2f94cb54247f	372b5e87-7bf3-5e30-98c4-56a4c19d17fa	Member	2026-03-05 09:25:00+00	\N
3f07fdb0-65c2-552a-ab2e-977d11785fd0	6dfe9630-59ce-507d-81a0-2f94cb54247f	e5222c33-013c-5ba6-9bcb-a11c7a43cbf0	Member	2026-03-05 09:26:00+00	\N
c5c815f7-5682-593b-8662-16e7686aa759	6dfe9630-59ce-507d-81a0-2f94cb54247f	75243589-322b-5eea-941f-54c424751a23	Member	2026-03-05 09:05:00+00	\N
b66555f1-4a2d-5821-856e-fec36eac502d	6dfe9630-59ce-507d-81a0-2f94cb54247f	3c3001bd-6e38-504d-9b49-01d36a027754	Member	2026-03-05 09:06:00+00	\N
ec0ff665-a053-5f81-b3b7-951206bdc96a	6dfe9630-59ce-507d-81a0-2f94cb54247f	69b673aa-8141-5faa-8677-2839e80e1d78	Member	2026-03-05 09:07:00+00	\N
32b24be8-2d14-57e9-a091-7823f5d084eb	6f343524-7197-5868-bc07-4ca1a311dc9e	3681b9d5-7732-52da-b97e-97efdcf08fd9	Owner	2026-03-05 16:18:00+00	2026-07-13 00:00:00+00
d67180c2-b20b-585c-a0b9-d656b6c0f6ef	6f343524-7197-5868-bc07-4ca1a311dc9e	cbe7100e-7e0b-5f30-9fec-aca7c60cad25	Member	2026-03-05 16:10:00+00	2026-07-13 00:00:00+00
832a719e-eb2b-5aea-b7a6-a5261f02ab0b	6f343524-7197-5868-bc07-4ca1a311dc9e	0f2178f1-017b-5762-b9fd-a197cb6cce9c	Member	2026-03-05 16:11:00+00	2026-07-13 00:00:00+00
3c9da540-987a-5e58-aae7-1a98e5b9b323	9406b74a-6b7a-578b-8fbd-958684d93780	69b673aa-8141-5faa-8677-2839e80e1d78	Owner	2026-03-05 05:07:00+00	\N
d261ba24-745b-529b-b292-5874db1198f2	9406b74a-6b7a-578b-8fbd-958684d93780	3681b9d5-7732-52da-b97e-97efdcf08fd9	Member	2026-03-05 05:18:00+00	\N
6e62c7a4-81ac-5135-a300-9184c2ed1a27	9406b74a-6b7a-578b-8fbd-958684d93780	8205f025-5eee-5f16-9e8e-b6a44f2a90e7	Member	2026-03-05 05:27:00+00	\N
1f804a7c-8663-51c3-a2fa-5fa25f15c26f	9406b74a-6b7a-578b-8fbd-958684d93780	75243589-322b-5eea-941f-54c424751a23	Member	2026-03-05 05:05:00+00	\N
9f34aed6-3604-5627-9fe0-19fa3a95ca7e	9406b74a-6b7a-578b-8fbd-958684d93780	44d6afb5-6765-5cc4-b4c9-a8877761b0ca	Member	2026-03-05 05:08:00+00	\N
571fc03f-4d4b-56a2-b478-4185a8d6223d	9406b74a-6b7a-578b-8fbd-958684d93780	636cb5b4-a95e-5d50-b513-6871826ee53f	Member	2026-03-05 05:09:00+00	\N
4b659187-9eaa-58f9-beb7-1e69bf461eff	9406b74a-6b7a-578b-8fbd-958684d93780	cbe7100e-7e0b-5f30-9fec-aca7c60cad25	Member	2026-03-05 05:10:00+00	\N
ce0577d6-5c0b-5ed4-8819-bf9496017d38	9406b74a-6b7a-578b-8fbd-958684d93780	0f2178f1-017b-5762-b9fd-a197cb6cce9c	Member	2026-03-05 05:11:00+00	\N
0f5ca1ae-93ad-5c3b-8dee-c095a6f653ed	9406b74a-6b7a-578b-8fbd-958684d93780	68e81bc4-dc44-5a60-b522-6f6909339289	Member	2026-03-05 05:12:00+00	\N
6d21b0dc-34c8-5066-a650-33e7371f4dab	9406b74a-6b7a-578b-8fbd-958684d93780	b47a0c61-e4a8-5afd-b215-61150a1e3066	Member	2026-03-05 05:13:00+00	\N
7aab6ea0-c06c-53b4-a9fa-d1faee7a3a1e	9406b74a-6b7a-578b-8fbd-958684d93780	97447306-b2af-5ad3-a0bb-ab876cfe713a	Member	2026-03-05 05:14:00+00	\N
9513c693-cb8f-5fac-90b5-950dea267341	9406b74a-6b7a-578b-8fbd-958684d93780	36904740-e579-521d-8461-726ccb5f1806	Member	2026-03-05 05:15:00+00	\N
43dc8511-f48b-5d0e-ae75-352dcccbf880	a7906be2-315f-5b5e-b344-ac119fd04d1a	5c8e49c9-c065-5bc8-a57a-0a69e1a89a5e	Member	2026-03-05 07:20:00+00	\N
4b6e1eeb-446f-5262-a4a9-20f1d95a893a	a7906be2-315f-5b5e-b344-ac119fd04d1a	1bfc7228-78d0-5a5c-8562-deb1f1a7b28f	Member	2026-03-05 07:29:00+00	\N
fb389224-cb3c-50af-adc7-58ac9f08ba3e	a7906be2-315f-5b5e-b344-ac119fd04d1a	69b673aa-8141-5faa-8677-2839e80e1d78	Member	2026-03-05 07:07:00+00	\N
fe95634d-6b41-54fa-b0d8-2ad8aaea88bc	a7906be2-315f-5b5e-b344-ac119fd04d1a	636cb5b4-a95e-5d50-b513-6871826ee53f	Owner	2026-03-05 07:09:00+00	\N
27fbd7e7-6f15-55d7-bc30-b2d4b3155811	a7906be2-315f-5b5e-b344-ac119fd04d1a	1f95823c-e9b9-5334-8f67-669822d8bd9f	Member	2026-03-05 07:16:00+00	\N
dec1e310-e96b-5f17-b9a7-bca036ba1dfc	a7906be2-315f-5b5e-b344-ac119fd04d1a	9a22f385-4227-5e99-8f8b-5d66bc7315a3	Member	2026-03-05 07:17:00+00	\N
23636885-407c-5a2a-9f11-74b00f8ce3ca	a7906be2-315f-5b5e-b344-ac119fd04d1a	3681b9d5-7732-52da-b97e-97efdcf08fd9	Member	2026-03-05 07:18:00+00	\N
42abe9b3-f26e-54b5-bd41-6a355cf3e824	a7906be2-315f-5b5e-b344-ac119fd04d1a	fe59379a-ab41-581e-8b2e-24d95eb4cee8	Member	2026-03-05 07:19:00+00	\N
0c6bda19-e6a6-52a3-9535-1b808a877e37	a7906be2-315f-5b5e-b344-ac119fd04d1a	18664d65-3906-58e7-91fd-d67ffedd1b64	Member	2026-03-05 07:21:00+00	\N
0ce2dd49-3e42-5322-b861-e7389770da91	b8cd683c-fe4d-538c-bdaf-68c28e1e14ef	6503790e-ec8d-5c9c-a6f9-20766eed6fb4	Member	2026-03-05 03:03:00+00	\N
f4a66226-17a2-589f-a36e-7f0f861533b0	b8cd683c-fe4d-538c-bdaf-68c28e1e14ef	75243589-322b-5eea-941f-54c424751a23	Owner	2026-03-05 03:05:00+00	\N
f9b74c2f-5cf0-556e-bb35-fba1acf26d73	b8cd683c-fe4d-538c-bdaf-68c28e1e14ef	1f95823c-e9b9-5334-8f67-669822d8bd9f	Member	2026-03-05 03:16:00+00	\N
1186c40b-0d6c-5c3a-97af-4b2100fd1189	b8cd683c-fe4d-538c-bdaf-68c28e1e14ef	3c3001bd-6e38-504d-9b49-01d36a027754	Member	2026-03-05 03:06:00+00	\N
bf891b03-ec76-55d6-bfd9-936a82dd069d	b8cd683c-fe4d-538c-bdaf-68c28e1e14ef	69b673aa-8141-5faa-8677-2839e80e1d78	Member	2026-03-05 03:07:00+00	\N
f37c9a51-7587-568a-a5a7-d5791f13de31	b8cd683c-fe4d-538c-bdaf-68c28e1e14ef	44d6afb5-6765-5cc4-b4c9-a8877761b0ca	Member	2026-03-05 03:08:00+00	\N
39bb982b-37f2-5ce5-9ffc-7a5e27cadff3	b8cd683c-fe4d-538c-bdaf-68c28e1e14ef	636cb5b4-a95e-5d50-b513-6871826ee53f	Member	2026-03-05 03:09:00+00	\N
8d2068c6-68bb-51d1-be39-28cb30037211	b8cd683c-fe4d-538c-bdaf-68c28e1e14ef	cbe7100e-7e0b-5f30-9fec-aca7c60cad25	Member	2026-03-05 03:10:00+00	\N
d8b03776-938c-56e3-ac49-9b59d2b32fd7	b8cd683c-fe4d-538c-bdaf-68c28e1e14ef	0f2178f1-017b-5762-b9fd-a197cb6cce9c	Member	2026-03-05 03:11:00+00	\N
27d62fb7-c7b0-5ab5-8789-39e0cad9eb83	b8cd683c-fe4d-538c-bdaf-68c28e1e14ef	68e81bc4-dc44-5a60-b522-6f6909339289	Member	2026-03-05 03:12:00+00	\N
2fbf9542-c071-50e2-bb27-215e81cf8a75	e7ea37c3-9fe3-5010-bb38-8c7330ef5bdc	6657781f-74d0-50d8-8f90-7c701d622872	Member	2026-03-05 06:28:00+00	\N
103f68bc-4b7f-576a-b966-e23ab724dd46	e7ea37c3-9fe3-5010-bb38-8c7330ef5bdc	3c3001bd-6e38-504d-9b49-01d36a027754	Member	2026-03-05 06:06:00+00	\N
42720fae-edb8-534a-b4a5-8956dc726afa	e7ea37c3-9fe3-5010-bb38-8c7330ef5bdc	44d6afb5-6765-5cc4-b4c9-a8877761b0ca	Owner	2026-03-05 06:08:00+00	\N
dcee5621-7788-5c94-8f0e-b80a5588059b	e7ea37c3-9fe3-5010-bb38-8c7330ef5bdc	fe59379a-ab41-581e-8b2e-24d95eb4cee8	Member	2026-03-05 06:19:00+00	\N
279fd4bf-382f-5f5e-988a-7b347a6baa3c	e7ea37c3-9fe3-5010-bb38-8c7330ef5bdc	75243589-322b-5eea-941f-54c424751a23	Member	2026-03-05 06:05:00+00	\N
e175535c-53c0-5444-8231-5d03640078ff	e7ea37c3-9fe3-5010-bb38-8c7330ef5bdc	69b673aa-8141-5faa-8677-2839e80e1d78	Member	2026-03-05 06:07:00+00	\N
9462fbdd-b3db-5087-b0b4-eeaccaf0bdd9	e7ea37c3-9fe3-5010-bb38-8c7330ef5bdc	636cb5b4-a95e-5d50-b513-6871826ee53f	Member	2026-03-05 06:09:00+00	\N
05b9f029-d9ed-591e-b223-5586b12d34aa	eb73aa6c-87aa-532d-8b94-109b8b863733	36904740-e579-521d-8461-726ccb5f1806	Member	2026-03-05 02:15:00+00	\N
00dcd94c-ed11-5b25-a3e6-55c20c60a0d0	eb73aa6c-87aa-532d-8b94-109b8b863733	bb6bdf69-6501-5ad2-9a1b-0148f459d5f3	Member	2026-03-05 02:02:00+00	\N
78e36303-60bb-5dbb-b1ef-578678dc10bb	eb73aa6c-87aa-532d-8b94-109b8b863733	de529b34-39ac-5368-86e8-1d1076117642	Owner	2026-03-05 02:04:00+00	\N
926cc002-c66f-51e9-ab9d-6d1276bb6d6f	eb73aa6c-87aa-532d-8b94-109b8b863733	636cb5b4-a95e-5d50-b513-6871826ee53f	Member	2026-03-05 02:09:00+00	\N
97f9b396-8062-5e45-bbbf-a89f82913406	eb73aa6c-87aa-532d-8b94-109b8b863733	cbe7100e-7e0b-5f30-9fec-aca7c60cad25	Member	2026-03-05 02:10:00+00	\N
c75a0eb2-5ccb-505d-bb44-4efc138f5738	eb73aa6c-87aa-532d-8b94-109b8b863733	0f2178f1-017b-5762-b9fd-a197cb6cce9c	Member	2026-03-05 02:11:00+00	\N
5cadc680-2dc8-5c29-b7ea-346ff1095c67	f04245fa-9e0e-5905-80fa-524e9f1e172f	bc1ce6aa-f011-56ab-9e10-492c111f50ba	Member	2026-03-05 01:01:00+00	\N
3c665794-7271-56f7-90cc-5e5168f7cf49	f04245fa-9e0e-5905-80fa-524e9f1e172f	bb6bdf69-6501-5ad2-9a1b-0148f459d5f3	Owner	2026-03-05 01:02:00+00	\N
25a3aa6d-c7e4-521e-a7c7-095dce81f957	f04245fa-9e0e-5905-80fa-524e9f1e172f	97447306-b2af-5ad3-a0bb-ab876cfe713a	Member	2026-03-05 01:14:00+00	\N
f9bcec4a-9b47-58e6-b385-7c152b6bc4eb	f04245fa-9e0e-5905-80fa-524e9f1e172f	5c8e49c9-c065-5bc8-a57a-0a69e1a89a5e	Member	2026-03-05 01:20:00+00	\N
200378d9-7076-5d74-8346-1fd9c8e30073	f04245fa-9e0e-5905-80fa-524e9f1e172f	18664d65-3906-58e7-91fd-d67ffedd1b64	Member	2026-03-05 01:21:00+00	\N
6f3c5d73-31e6-509b-a944-0e2b043e70e3	f04245fa-9e0e-5905-80fa-524e9f1e172f	2d40ec7a-98f2-5e42-84d6-c8bafec1e0b2	Member	2026-03-05 01:22:00+00	\N
04f83731-2570-5c90-94a5-56e3543e257a	f04245fa-9e0e-5905-80fa-524e9f1e172f	8e9f41ef-4f61-5811-a73e-3a8bfbf74881	Member	2026-03-05 01:23:00+00	\N
3fbb8565-c2df-5c3a-95e2-6c7641ea6405	f04245fa-9e0e-5905-80fa-524e9f1e172f	3d0cfe6d-2c3e-5102-a541-f86e8aef695d	Member	2026-03-05 01:24:00+00	\N
436ad757-a5de-5e2d-9ec5-39a6f5ca42ec	f07ee933-bae1-5f0f-9e95-6c303aba6f5d	3d0cfe6d-2c3e-5102-a541-f86e8aef695d	Member	2026-03-05 12:24:00+00	\N
74e69dd5-547c-5ef3-97bc-aee27edcc416	f07ee933-bae1-5f0f-9e95-6c303aba6f5d	0f2178f1-017b-5762-b9fd-a197cb6cce9c	Member	2026-03-05 12:11:00+00	\N
3609a98a-9d71-5383-8069-01ae901e1814	f07ee933-bae1-5f0f-9e95-6c303aba6f5d	97447306-b2af-5ad3-a0bb-ab876cfe713a	Owner	2026-03-05 12:14:00+00	\N
2ef090a3-ca52-575a-9f60-40fdeaba9be4	f07ee933-bae1-5f0f-9e95-6c303aba6f5d	8e9f41ef-4f61-5811-a73e-3a8bfbf74881	Member	2026-03-05 12:23:00+00	\N
6a6f1833-c01f-5105-b488-f4bbb0730270	f07ee933-bae1-5f0f-9e95-6c303aba6f5d	372b5e87-7bf3-5e30-98c4-56a4c19d17fa	Member	2026-03-05 12:25:00+00	\N
82400d8f-d9da-5442-9488-965bcf74666c	f07ee933-bae1-5f0f-9e95-6c303aba6f5d	e5222c33-013c-5ba6-9bcb-a11c7a43cbf0	Member	2026-03-05 12:26:00+00	\N
da210737-ef5c-5bcc-ac22-aa6cd5be57ea	f07ee933-bae1-5f0f-9e95-6c303aba6f5d	75243589-322b-5eea-941f-54c424751a23	Member	2026-03-05 12:05:00+00	\N
7a608573-16ff-51a2-b03d-6266f734f8fa	f07ee933-bae1-5f0f-9e95-6c303aba6f5d	3c3001bd-6e38-504d-9b49-01d36a027754	Member	2026-03-05 12:06:00+00	\N
e0ab3afe-a81e-5676-a109-6f4ab6e4e8e9	f07ee933-bae1-5f0f-9e95-6c303aba6f5d	69b673aa-8141-5faa-8677-2839e80e1d78	Member	2026-03-05 12:07:00+00	\N
058f0de7-17e2-5422-a9d0-8dfedc7be68e	f07ee933-bae1-5f0f-9e95-6c303aba6f5d	44d6afb5-6765-5cc4-b4c9-a8877761b0ca	Member	2026-03-05 12:08:00+00	\N
c91e3ecc-d602-55ca-893c-b2b091772f84	f07ee933-bae1-5f0f-9e95-6c303aba6f5d	636cb5b4-a95e-5d50-b513-6871826ee53f	Member	2026-03-05 12:09:00+00	\N
\.


--
-- Data for Name: quartz_blob_triggers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.quartz_blob_triggers (sched_name, trigger_name, trigger_group, blob_data) FROM stdin;
\.


--
-- Data for Name: quartz_calendars; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.quartz_calendars (sched_name, calendar_name, calendar) FROM stdin;
\.


--
-- Data for Name: quartz_cron_triggers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.quartz_cron_triggers (sched_name, trigger_name, trigger_group, cron_expression, time_zone_id) FROM stdin;
\.


--
-- Data for Name: quartz_fired_triggers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.quartz_fired_triggers (sched_name, entry_id, trigger_name, trigger_group, instance_name, fired_time, sched_time, priority, state, job_name, job_group, is_nonconcurrent, requests_recovery) FROM stdin;
\.


--
-- Data for Name: quartz_job_details; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.quartz_job_details (sched_name, job_name, job_group, description, job_class_name, is_durable, is_nonconcurrent, is_update_data, requests_recovery, job_data) FROM stdin;
\.


--
-- Data for Name: quartz_locks; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.quartz_locks (sched_name, lock_name) FROM stdin;
\.


--
-- Data for Name: quartz_paused_trigger_grps; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.quartz_paused_trigger_grps (sched_name, trigger_group) FROM stdin;
\.


--
-- Data for Name: quartz_scheduler_state; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.quartz_scheduler_state (sched_name, instance_name, last_checkin_time, checkin_interval) FROM stdin;
\.


--
-- Data for Name: quartz_simple_triggers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.quartz_simple_triggers (sched_name, trigger_name, trigger_group, repeat_count, repeat_interval, times_triggered) FROM stdin;
\.


--
-- Data for Name: quartz_simprop_triggers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.quartz_simprop_triggers (sched_name, trigger_name, trigger_group, str_prop_1, str_prop_2, str_prop_3, int_prop_1, int_prop_2, long_prop_1, long_prop_2, dec_prop_1, dec_prop_2, bool_prop_1, bool_prop_2) FROM stdin;
\.


--
-- Data for Name: quartz_triggers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.quartz_triggers (sched_name, trigger_name, trigger_group, job_name, job_group, description, next_fire_time, prev_fire_time, priority, trigger_state, trigger_type, start_time, end_time, calendar_name, misfire_instr, job_data) FROM stdin;
\.


--
-- Data for Name: refresh_token; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.refresh_token (user_id, device_id, user_agent, value, authed_by, last_authed_at, created_at, expired_at) FROM stdin;
\.


--
-- Data for Name: saml_config; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.saml_config (organization_id, idp_cert, idp_entity_id, idp_sso_url, lang_code, validity_duration, allow_account_init, is_enabled, created_at) FROM stdin;
\.


--
-- Data for Name: saml_request; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.saml_request (id, one_time_token, user_id, used, created_at) FROM stdin;
\.


--
-- Data for Name: sendgrid_mail_event; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sendgrid_mail_event (mail_uuid, environment, email, event, ip, mc_stats, phase_id, send_at, sg_content_type, sg_event_id, sg_message_id, sg_template_id, sg_template_name, singlesend_id, singlesend_name, template_hash, template_id, template_version_id, "timestamp", useragent, processed, reason) FROM stdin;
\.


--
-- Data for Name: user; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."user" (id, first_name, last_name, avatar, color, is_super_admin, created_at, modified_at, archived_at) FROM stdin;
bc1ce6aa-f011-56ab-9e10-492c111f50ba	Amelia	Nowak	\N	#5B5BD6	t	2026-02-13 00:01:00+00	2026-02-13 00:01:00+00	\N
bb6bdf69-6501-5ad2-9a1b-0148f459d5f3	Jan	Lewandowski	\N	#2E90FA	t	2026-02-13 00:02:00+00	2026-02-13 00:02:00+00	\N
6503790e-ec8d-5c9c-a6f9-20766eed6fb4	Marta	Zielińska	\N	#12B76A	f	2026-02-13 00:03:00+00	2026-02-13 00:03:00+00	\N
de529b34-39ac-5368-86e8-1d1076117642	Piotr	Wiśniewski	\N	#F79009	f	2026-02-13 00:04:00+00	2026-02-13 00:04:00+00	\N
75243589-322b-5eea-941f-54c424751a23	Alicja	Kowalska	\N	#F04438	f	2026-02-13 00:05:00+00	2026-02-13 00:05:00+00	\N
3c3001bd-6e38-504d-9b49-01d36a027754	Kamil	Wójcik	\N	#7A5AF8	f	2026-02-13 00:06:00+00	2026-02-13 00:06:00+00	\N
69b673aa-8141-5faa-8677-2839e80e1d78	Lena	Kamińska	\N	#06AED4	f	2026-02-13 00:07:00+00	2026-02-13 00:07:00+00	\N
44d6afb5-6765-5cc4-b4c9-a8877761b0ca	Michał	Dąbrowski	\N	#EE46BC	f	2026-02-13 00:08:00+00	2026-02-13 00:08:00+00	\N
636cb5b4-a95e-5d50-b513-6871826ee53f	Zofia	Kaczmarek	\N	#5B5BD6	f	2026-02-13 00:09:00+00	2026-02-13 00:09:00+00	\N
cbe7100e-7e0b-5f30-9fec-aca7c60cad25	Tomasz	Mazur	\N	#2E90FA	f	2026-02-13 00:10:00+00	2026-02-13 00:10:00+00	\N
0f2178f1-017b-5762-b9fd-a197cb6cce9c	Julia	Krawczyk	\N	#12B76A	f	2026-02-13 00:11:00+00	2026-02-13 00:11:00+00	\N
68e81bc4-dc44-5a60-b522-6f6909339289	Paweł	Piotrowski	\N	#F79009	f	2026-02-13 00:12:00+00	2026-02-13 00:12:00+00	\N
b47a0c61-e4a8-5afd-b215-61150a1e3066	Natalia	Grabowska	\N	#F04438	f	2026-02-13 00:13:00+00	2026-02-13 00:13:00+00	\N
97447306-b2af-5ad3-a0bb-ab876cfe713a	Jakub	Pawlak	\N	#7A5AF8	f	2026-02-13 00:14:00+00	2026-02-13 00:14:00+00	\N
36904740-e579-521d-8461-726ccb5f1806	Emilia	Michalska	\N	#06AED4	f	2026-02-13 00:15:00+00	2026-02-13 00:15:00+00	\N
1f95823c-e9b9-5334-8f67-669822d8bd9f	Filip	Nowicki	\N	#EE46BC	f	2026-02-13 00:16:00+00	2026-02-13 00:16:00+00	\N
9a22f385-4227-5e99-8f8b-5d66bc7315a3	Maja	Adamczyk	\N	#5B5BD6	f	2026-02-13 00:17:00+00	2026-02-13 00:17:00+00	\N
3681b9d5-7732-52da-b97e-97efdcf08fd9	Wojciech	Dudek	\N	#2E90FA	f	2026-02-13 00:18:00+00	2026-02-13 00:18:00+00	\N
fe59379a-ab41-581e-8b2e-24d95eb4cee8	Hanna	Wieczorek	\N	#12B76A	f	2026-02-13 00:19:00+00	2026-02-13 00:19:00+00	\N
5c8e49c9-c065-5bc8-a57a-0a69e1a89a5e	Adam	Jankowski	\N	#F79009	f	2026-02-13 00:20:00+00	2026-02-13 00:20:00+00	\N
18664d65-3906-58e7-91fd-d67ffedd1b64	Oliwia	Król	\N	#F04438	f	2026-02-13 00:21:00+00	2026-02-13 00:21:00+00	\N
2d40ec7a-98f2-5e42-84d6-c8bafec1e0b2	Szymon	Lis	\N	#7A5AF8	f	2026-02-13 00:22:00+00	2026-02-13 00:22:00+00	\N
8e9f41ef-4f61-5811-a73e-3a8bfbf74881	Laura	Sadowska	\N	#06AED4	f	2026-02-13 00:23:00+00	2026-02-13 00:23:00+00	\N
3d0cfe6d-2c3e-5102-a541-f86e8aef695d	Krzysztof	Baran	\N	#EE46BC	f	2026-02-13 00:24:00+00	2026-02-13 00:24:00+00	\N
372b5e87-7bf3-5e30-98c4-56a4c19d17fa	Iga	Sikora	\N	#5B5BD6	f	2026-02-13 00:25:00+00	2026-02-13 00:25:00+00	\N
e5222c33-013c-5ba6-9bcb-a11c7a43cbf0	Damian	Górski	\N	#2E90FA	f	2026-02-13 00:26:00+00	2026-02-13 00:26:00+00	\N
8205f025-5eee-5f16-9e8e-b6a44f2a90e7	Sara	Nilsson	\N	#12B76A	f	2026-02-13 00:27:00+00	2026-02-13 00:27:00+00	\N
6657781f-74d0-50d8-8f90-7c701d622872	Lucas	Martin	\N	#F79009	f	2026-02-13 00:28:00+00	2026-02-13 00:28:00+00	\N
1bfc7228-78d0-5a5c-8562-deb1f1a7b28f	Nina	Petrova	\N	#F04438	f	2026-02-13 00:29:00+00	2026-02-13 00:29:00+00	\N
f3048101-4480-533e-896e-9295fb7f01d5	Mateo	Costa	\N	#7A5AF8	f	2026-02-13 00:30:00+00	2026-02-13 00:30:00+00	\N
\.


--
-- Data for Name: user_identity; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_identity (id, user_id, type, value, main, device_id, confirmed, confirmation_code, created_at) FROM stdin;
4b229808-6436-5bc1-81f3-d6dc6799fb4c	bc1ce6aa-f011-56ab-9e10-492c111f50ba	MailAddress	demo+amelia-nowak@epoca.example.invalid	t	\N	t	\N	2026-02-13 00:01:00
29a50aa6-3cc1-517f-af92-32e25b51ac94	bb6bdf69-6501-5ad2-9a1b-0148f459d5f3	MailAddress	demo+jan-lewandowski@epoca.example.invalid	t	\N	t	\N	2026-02-13 00:02:00
bacf2ba5-a5d1-572e-b471-3897d6253c3c	6503790e-ec8d-5c9c-a6f9-20766eed6fb4	MailAddress	demo+marta-zielinska@epoca.example.invalid	t	\N	t	\N	2026-02-13 00:03:00
b42ffba2-ad44-556c-8b6f-06d17951c0ab	de529b34-39ac-5368-86e8-1d1076117642	MailAddress	demo+piotr-wisniewski@epoca.example.invalid	t	\N	t	\N	2026-02-13 00:04:00
5eab2ada-7592-537e-be99-bbc7a85172ab	75243589-322b-5eea-941f-54c424751a23	MailAddress	demo+alicja-kowalska@epoca.example.invalid	t	\N	t	\N	2026-02-13 00:05:00
dc5ebb1e-a288-5ff0-b95d-97e0a178df6b	3c3001bd-6e38-504d-9b49-01d36a027754	MailAddress	demo+kamil-wojcik@epoca.example.invalid	t	\N	t	\N	2026-02-13 00:06:00
2f2b4005-3664-5a08-a457-2de245411058	69b673aa-8141-5faa-8677-2839e80e1d78	MailAddress	demo+lena-kaminska@epoca.example.invalid	t	\N	t	\N	2026-02-13 00:07:00
dbf62ca0-1685-5fbb-98a7-64ce2ae5637e	44d6afb5-6765-5cc4-b4c9-a8877761b0ca	MailAddress	demo+michal-dabrowski@epoca.example.invalid	t	\N	t	\N	2026-02-13 00:08:00
874516e0-d4ab-5e45-9f90-3d9a85787e87	636cb5b4-a95e-5d50-b513-6871826ee53f	MailAddress	demo+zofia-kaczmarek@epoca.example.invalid	t	\N	t	\N	2026-02-13 00:09:00
685709b5-ba4a-5ce8-a9ce-ac82f0ce05ef	cbe7100e-7e0b-5f30-9fec-aca7c60cad25	MailAddress	demo+tomasz-mazur@epoca.example.invalid	t	\N	t	\N	2026-02-13 00:10:00
238d1518-6952-57be-9a7c-f013f1df7b74	0f2178f1-017b-5762-b9fd-a197cb6cce9c	MailAddress	demo+julia-krawczyk@epoca.example.invalid	t	\N	t	\N	2026-02-13 00:11:00
8de0e7a8-5e88-537d-bfe8-a21cfb33437d	68e81bc4-dc44-5a60-b522-6f6909339289	MailAddress	demo+pawel-piotrowski@epoca.example.invalid	t	\N	t	\N	2026-02-13 00:12:00
61eaa1a2-f764-5fc8-8138-8e2b4ef7f09b	b47a0c61-e4a8-5afd-b215-61150a1e3066	MailAddress	demo+natalia-grabowska@epoca.example.invalid	t	\N	t	\N	2026-02-13 00:13:00
eb718e76-d7a1-50dc-abb8-2353ecbd5656	97447306-b2af-5ad3-a0bb-ab876cfe713a	MailAddress	demo+jakub-pawlak@epoca.example.invalid	t	\N	t	\N	2026-02-13 00:14:00
601db328-a4b9-5fb7-91e4-519981160a4b	36904740-e579-521d-8461-726ccb5f1806	MailAddress	demo+emilia-michalska@epoca.example.invalid	t	\N	t	\N	2026-02-13 00:15:00
25be305c-c86f-5e9a-b089-088b7df1e636	1f95823c-e9b9-5334-8f67-669822d8bd9f	MailAddress	demo+filip-nowicki@epoca.example.invalid	t	\N	t	\N	2026-02-13 00:16:00
fea14921-c048-58d3-b980-b8f2f80659e3	9a22f385-4227-5e99-8f8b-5d66bc7315a3	MailAddress	demo+maja-adamczyk@epoca.example.invalid	t	\N	t	\N	2026-02-13 00:17:00
51a4ef20-0219-5618-a266-80c8c7d232a9	3681b9d5-7732-52da-b97e-97efdcf08fd9	MailAddress	demo+wojciech-dudek@epoca.example.invalid	t	\N	t	\N	2026-02-13 00:18:00
debb7aea-14bd-54ba-a61a-2deafb303f1f	fe59379a-ab41-581e-8b2e-24d95eb4cee8	MailAddress	demo+hanna-wieczorek@epoca.example.invalid	t	\N	t	\N	2026-02-13 00:19:00
ed9ce254-3ec2-51c9-a68b-6167cfb27550	5c8e49c9-c065-5bc8-a57a-0a69e1a89a5e	MailAddress	demo+adam-jankowski@epoca.example.invalid	t	\N	t	\N	2026-02-13 00:20:00
37b098d7-6902-57d3-918e-30a4a396a091	18664d65-3906-58e7-91fd-d67ffedd1b64	MailAddress	demo+oliwia-krol@epoca.example.invalid	t	\N	t	\N	2026-02-13 00:21:00
62e558ee-c54a-54bb-9e2d-ad6df7b86a93	2d40ec7a-98f2-5e42-84d6-c8bafec1e0b2	MailAddress	demo+szymon-lis@epoca.example.invalid	t	\N	t	\N	2026-02-13 00:22:00
b0e5ed18-77d3-5886-8404-b8737a70ff5d	8e9f41ef-4f61-5811-a73e-3a8bfbf74881	MailAddress	demo+laura-sadowska@epoca.example.invalid	t	\N	t	\N	2026-02-13 00:23:00
fc640392-5531-5fdc-b43c-d50a949286ab	3d0cfe6d-2c3e-5102-a541-f86e8aef695d	MailAddress	demo+krzysztof-baran@epoca.example.invalid	t	\N	t	\N	2026-02-13 00:24:00
8030f4fc-dae7-581b-bda3-b2c5507c034f	372b5e87-7bf3-5e30-98c4-56a4c19d17fa	MailAddress	demo+iga-sikora@epoca.example.invalid	t	\N	t	\N	2026-02-13 00:25:00
e32908b5-fbc3-5808-9c6a-7b260d5c18a7	e5222c33-013c-5ba6-9bcb-a11c7a43cbf0	MailAddress	demo+damian-gorski@epoca.example.invalid	t	\N	t	\N	2026-02-13 00:26:00
b07959c3-5c0f-5cbf-9b03-a13a22d7ce59	8205f025-5eee-5f16-9e8e-b6a44f2a90e7	MailAddress	demo+sara-nilsson@epoca.example.invalid	t	\N	t	\N	2026-02-13 00:27:00
f8777876-877a-5cd4-8214-0fe357debb4f	6657781f-74d0-50d8-8f90-7c701d622872	MailAddress	demo+lucas-martin@epoca.example.invalid	t	\N	t	\N	2026-02-13 00:28:00
89432147-8d35-5a7f-93ac-2f51ccbe790b	1bfc7228-78d0-5a5c-8562-deb1f1a7b28f	MailAddress	demo+nina-petrova@epoca.example.invalid	t	\N	t	\N	2026-02-13 00:29:00
6e6287ee-8764-53a4-b39f-841bce9730a2	f3048101-4480-533e-896e-9295fb7f01d5	MailAddress	demo+mateo-costa@epoca.example.invalid	t	\N	t	\N	2026-02-13 00:30:00
\.


--
-- Data for Name: user_login_token; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_login_token (id, user_identity_id, login_token, valid_to) FROM stdin;
\.


--
-- Data for Name: user_password; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_password (user_identity_id, password) FROM stdin;
4b229808-6436-5bc1-81f3-d6dc6799fb4c	$2a$12$YnR4CcAvwX3gnw1qIllM.OgzpgUOPSfftXVJ/5ZiNUfc0tAC6GkVK
29a50aa6-3cc1-517f-af92-32e25b51ac94	$2a$12$YnR4CcAvwX3gnw1qIllM.OgzpgUOPSfftXVJ/5ZiNUfc0tAC6GkVK
bacf2ba5-a5d1-572e-b471-3897d6253c3c	$2a$12$YnR4CcAvwX3gnw1qIllM.OgzpgUOPSfftXVJ/5ZiNUfc0tAC6GkVK
b42ffba2-ad44-556c-8b6f-06d17951c0ab	$2a$12$YnR4CcAvwX3gnw1qIllM.OgzpgUOPSfftXVJ/5ZiNUfc0tAC6GkVK
5eab2ada-7592-537e-be99-bbc7a85172ab	$2a$12$YnR4CcAvwX3gnw1qIllM.OgzpgUOPSfftXVJ/5ZiNUfc0tAC6GkVK
dc5ebb1e-a288-5ff0-b95d-97e0a178df6b	$2a$12$YnR4CcAvwX3gnw1qIllM.OgzpgUOPSfftXVJ/5ZiNUfc0tAC6GkVK
2f2b4005-3664-5a08-a457-2de245411058	$2a$12$YnR4CcAvwX3gnw1qIllM.OgzpgUOPSfftXVJ/5ZiNUfc0tAC6GkVK
dbf62ca0-1685-5fbb-98a7-64ce2ae5637e	$2a$12$YnR4CcAvwX3gnw1qIllM.OgzpgUOPSfftXVJ/5ZiNUfc0tAC6GkVK
874516e0-d4ab-5e45-9f90-3d9a85787e87	$2a$12$YnR4CcAvwX3gnw1qIllM.OgzpgUOPSfftXVJ/5ZiNUfc0tAC6GkVK
685709b5-ba4a-5ce8-a9ce-ac82f0ce05ef	$2a$12$YnR4CcAvwX3gnw1qIllM.OgzpgUOPSfftXVJ/5ZiNUfc0tAC6GkVK
238d1518-6952-57be-9a7c-f013f1df7b74	$2a$12$YnR4CcAvwX3gnw1qIllM.OgzpgUOPSfftXVJ/5ZiNUfc0tAC6GkVK
8de0e7a8-5e88-537d-bfe8-a21cfb33437d	$2a$12$YnR4CcAvwX3gnw1qIllM.OgzpgUOPSfftXVJ/5ZiNUfc0tAC6GkVK
61eaa1a2-f764-5fc8-8138-8e2b4ef7f09b	$2a$12$YnR4CcAvwX3gnw1qIllM.OgzpgUOPSfftXVJ/5ZiNUfc0tAC6GkVK
eb718e76-d7a1-50dc-abb8-2353ecbd5656	$2a$12$YnR4CcAvwX3gnw1qIllM.OgzpgUOPSfftXVJ/5ZiNUfc0tAC6GkVK
601db328-a4b9-5fb7-91e4-519981160a4b	$2a$12$YnR4CcAvwX3gnw1qIllM.OgzpgUOPSfftXVJ/5ZiNUfc0tAC6GkVK
25be305c-c86f-5e9a-b089-088b7df1e636	$2a$12$YnR4CcAvwX3gnw1qIllM.OgzpgUOPSfftXVJ/5ZiNUfc0tAC6GkVK
fea14921-c048-58d3-b980-b8f2f80659e3	$2a$12$YnR4CcAvwX3gnw1qIllM.OgzpgUOPSfftXVJ/5ZiNUfc0tAC6GkVK
51a4ef20-0219-5618-a266-80c8c7d232a9	$2a$12$YnR4CcAvwX3gnw1qIllM.OgzpgUOPSfftXVJ/5ZiNUfc0tAC6GkVK
debb7aea-14bd-54ba-a61a-2deafb303f1f	$2a$12$YnR4CcAvwX3gnw1qIllM.OgzpgUOPSfftXVJ/5ZiNUfc0tAC6GkVK
ed9ce254-3ec2-51c9-a68b-6167cfb27550	$2a$12$YnR4CcAvwX3gnw1qIllM.OgzpgUOPSfftXVJ/5ZiNUfc0tAC6GkVK
37b098d7-6902-57d3-918e-30a4a396a091	$2a$12$YnR4CcAvwX3gnw1qIllM.OgzpgUOPSfftXVJ/5ZiNUfc0tAC6GkVK
62e558ee-c54a-54bb-9e2d-ad6df7b86a93	$2a$12$YnR4CcAvwX3gnw1qIllM.OgzpgUOPSfftXVJ/5ZiNUfc0tAC6GkVK
b0e5ed18-77d3-5886-8404-b8737a70ff5d	$2a$12$YnR4CcAvwX3gnw1qIllM.OgzpgUOPSfftXVJ/5ZiNUfc0tAC6GkVK
fc640392-5531-5fdc-b43c-d50a949286ab	$2a$12$YnR4CcAvwX3gnw1qIllM.OgzpgUOPSfftXVJ/5ZiNUfc0tAC6GkVK
8030f4fc-dae7-581b-bda3-b2c5507c034f	$2a$12$YnR4CcAvwX3gnw1qIllM.OgzpgUOPSfftXVJ/5ZiNUfc0tAC6GkVK
e32908b5-fbc3-5808-9c6a-7b260d5c18a7	$2a$12$YnR4CcAvwX3gnw1qIllM.OgzpgUOPSfftXVJ/5ZiNUfc0tAC6GkVK
b07959c3-5c0f-5cbf-9b03-a13a22d7ce59	$2a$12$YnR4CcAvwX3gnw1qIllM.OgzpgUOPSfftXVJ/5ZiNUfc0tAC6GkVK
f8777876-877a-5cd4-8214-0fe357debb4f	$2a$12$YnR4CcAvwX3gnw1qIllM.OgzpgUOPSfftXVJ/5ZiNUfc0tAC6GkVK
89432147-8d35-5a7f-93ac-2f51ccbe790b	$2a$12$YnR4CcAvwX3gnw1qIllM.OgzpgUOPSfftXVJ/5ZiNUfc0tAC6GkVK
6e6287ee-8764-53a4-b39f-841bce9730a2	$2a$12$YnR4CcAvwX3gnw1qIllM.OgzpgUOPSfftXVJ/5ZiNUfc0tAC6GkVK
\.


--
-- Data for Name: work_unit; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.work_unit (id, organization_id, user_id, project_id, date, duration, description, created_at, modified_at, archived_at, task_id, client_id, state, entry_type) FROM stdin;
8b140454-f316-57ea-9e93-392872be66f2	62445afe-3364-5e78-b55e-fb5429807a47	5c8e49c9-c065-5bc8-a57a-0a69e1a89a5e	a7906be2-315f-5b5e-b344-ac119fd04d1a	2026-05-20	01:30:00	Performance improvements — Omnichannel Checkout	2026-05-20 09:01:00+00	2026-05-20 09:01:00+00	\N	OC-119	3030e191-44de-5909-b035-5fe3679b482a	Active	Worklog
13652729-4e44-5ec7-bd01-6e688276e748	62445afe-3364-5e78-b55e-fb5429807a47	5c8e49c9-c065-5bc8-a57a-0a69e1a89a5e	f04245fa-9e0e-5905-80fa-524e9f1e172f	2026-05-21	03:00:00	Performance improvements — Delivery Operations Hub	2026-05-21 09:01:00+00	2026-05-21 09:01:00+00	\N	DOH-147	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
d7ddd582-77cd-5af3-8641-20d6701837d9	62445afe-3364-5e78-b55e-fb5429807a47	5c8e49c9-c065-5bc8-a57a-0a69e1a89a5e	a7906be2-315f-5b5e-b344-ac119fd04d1a	2026-05-22	03:30:00	Performance improvements — Omnichannel Checkout	2026-05-22 09:01:00+00	2026-05-22 09:01:00+00	\N	OC-166	3030e191-44de-5909-b035-5fe3679b482a	Active	Worklog
7c9d95eb-a7d3-5646-9dfb-c51171e7be87	62445afe-3364-5e78-b55e-fb5429807a47	5c8e49c9-c065-5bc8-a57a-0a69e1a89a5e	f04245fa-9e0e-5905-80fa-524e9f1e172f	2026-05-25	01:00:00	Performance improvements — Delivery Operations Hub	2026-05-25 09:01:00+00	2026-05-25 09:01:00+00	\N	DOH-121	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
68c5c43a-67a1-55f7-9eac-c51e39aca8bc	62445afe-3364-5e78-b55e-fb5429807a47	5c8e49c9-c065-5bc8-a57a-0a69e1a89a5e	a7906be2-315f-5b5e-b344-ac119fd04d1a	2026-05-26	01:30:00	Performance improvements — Omnichannel Checkout	2026-05-26 09:01:00+00	2026-05-26 09:01:00+00	\N	OC-140	3030e191-44de-5909-b035-5fe3679b482a	Active	Worklog
e38f1c21-4041-5310-af92-bb1bd695dec0	62445afe-3364-5e78-b55e-fb5429807a47	5c8e49c9-c065-5bc8-a57a-0a69e1a89a5e	a7906be2-315f-5b5e-b344-ac119fd04d1a	2026-05-28	03:30:00	Performance improvements — Omnichannel Checkout	2026-05-28 09:01:00+00	2026-05-28 09:01:00+00	\N	OC-114	3030e191-44de-5909-b035-5fe3679b482a	Active	Worklog
f9afd5f6-6af2-5325-a279-2f19dd2e1312	62445afe-3364-5e78-b55e-fb5429807a47	5c8e49c9-c065-5bc8-a57a-0a69e1a89a5e	a7906be2-315f-5b5e-b344-ac119fd04d1a	2026-05-31	01:30:00	Performance improvements — Omnichannel Checkout	2026-05-31 09:01:00+00	2026-05-31 09:01:00+00	\N	OC-161	3030e191-44de-5909-b035-5fe3679b482a	Active	Worklog
814efbcb-7c92-567d-9fd6-b181bc56097b	62445afe-3364-5e78-b55e-fb5429807a47	5c8e49c9-c065-5bc8-a57a-0a69e1a89a5e	a7906be2-315f-5b5e-b344-ac119fd04d1a	2026-06-02	03:30:00	Performance improvements — Omnichannel Checkout	2026-06-02 09:01:00+00	2026-06-02 09:01:00+00	\N	OC-135	3030e191-44de-5909-b035-5fe3679b482a	Active	Worklog
58da3523-4586-5eff-adb4-5f8d8d8d1c8e	62445afe-3364-5e78-b55e-fb5429807a47	5c8e49c9-c065-5bc8-a57a-0a69e1a89a5e	f04245fa-9e0e-5905-80fa-524e9f1e172f	2026-06-03	00:00:00	Decyzja zakresowa potwierdzona z zespołem — Delivery Operations Hub	2026-06-03 09:01:00+00	2026-06-03 09:01:00+00	\N	\N	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Note
0978641c-93dc-58d8-bd04-8e93ddfe6334	62445afe-3364-5e78-b55e-fb5429807a47	5c8e49c9-c065-5bc8-a57a-0a69e1a89a5e	a7906be2-315f-5b5e-b344-ac119fd04d1a	2026-06-04	01:30:00	Performance improvements — Omnichannel Checkout	2026-06-04 09:01:00+00	2026-06-04 09:01:00+00	\N	OC-109	3030e191-44de-5909-b035-5fe3679b482a	Active	Worklog
06c4f57f-969f-5a96-8a87-f2fe6e57e561	62445afe-3364-5e78-b55e-fb5429807a47	5c8e49c9-c065-5bc8-a57a-0a69e1a89a5e	a7906be2-315f-5b5e-b344-ac119fd04d1a	2026-06-08	03:30:00	Performance improvements — Omnichannel Checkout	2026-06-08 09:01:00+00	2026-06-08 09:01:00+00	\N	OC-156	3030e191-44de-5909-b035-5fe3679b482a	Active	Worklog
72e4ad8f-6015-553e-b96e-d32398b7095f	62445afe-3364-5e78-b55e-fb5429807a47	5c8e49c9-c065-5bc8-a57a-0a69e1a89a5e	a7906be2-315f-5b5e-b344-ac119fd04d1a	2026-06-10	01:30:00	Performance improvements — Omnichannel Checkout	2026-06-10 09:01:00+00	2026-06-10 09:01:00+00	\N	OC-130	3030e191-44de-5909-b035-5fe3679b482a	Active	Worklog
5e114012-28ae-58a6-ab9e-b040c2b3985b	62445afe-3364-5e78-b55e-fb5429807a47	5c8e49c9-c065-5bc8-a57a-0a69e1a89a5e	f04245fa-9e0e-5905-80fa-524e9f1e172f	2026-06-11	02:00:00	Performance improvements — Delivery Operations Hub	2026-06-11 09:01:00+00	2026-06-11 09:01:00+00	\N	DOH-149	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
76735f23-8b17-5e3c-b886-1d9520e2f6bb	62445afe-3364-5e78-b55e-fb5429807a47	5c8e49c9-c065-5bc8-a57a-0a69e1a89a5e	a7906be2-315f-5b5e-b344-ac119fd04d1a	2026-06-12	03:30:00	Performance improvements — Omnichannel Checkout	2026-06-12 09:01:00+00	2026-06-12 09:01:00+00	\N	OC-104	3030e191-44de-5909-b035-5fe3679b482a	Active	Worklog
9c97781c-fe21-5425-b477-ab0d8d8d61cf	62445afe-3364-5e78-b55e-fb5429807a47	5c8e49c9-c065-5bc8-a57a-0a69e1a89a5e	f04245fa-9e0e-5905-80fa-524e9f1e172f	2026-06-14	04:00:00	Performance improvements — Delivery Operations Hub	2026-06-14 09:01:00+00	2026-06-14 09:01:00+00	\N	DOH-123	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
aabaad89-aed9-5b07-8b1a-838f46a2b565	62445afe-3364-5e78-b55e-fb5429807a47	5c8e49c9-c065-5bc8-a57a-0a69e1a89a5e	f04245fa-9e0e-5905-80fa-524e9f1e172f	2026-06-16	02:00:00	Performance improvements — Delivery Operations Hub	2026-06-16 09:01:00+00	2026-06-16 09:01:00+00	\N	DOH-170	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
ba30ae47-bf5c-51e7-ae4f-cab5796e36c4	62445afe-3364-5e78-b55e-fb5429807a47	5c8e49c9-c065-5bc8-a57a-0a69e1a89a5e	f04245fa-9e0e-5905-80fa-524e9f1e172f	2026-06-18	04:00:00	Performance improvements — Delivery Operations Hub	2026-06-18 09:01:00+00	2026-06-18 09:01:00+00	\N	DOH-144	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
97182b18-966f-5afa-914e-3003ba72ef08	62445afe-3364-5e78-b55e-fb5429807a47	5c8e49c9-c065-5bc8-a57a-0a69e1a89a5e	f04245fa-9e0e-5905-80fa-524e9f1e172f	2026-06-22	02:00:00	Performance improvements — Delivery Operations Hub	2026-06-22 09:01:00+00	2026-06-22 09:01:00+00	\N	DOH-118	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
fc15eebd-744d-5d0a-bbf3-706ad7a9b9b9	62445afe-3364-5e78-b55e-fb5429807a47	5c8e49c9-c065-5bc8-a57a-0a69e1a89a5e	f04245fa-9e0e-5905-80fa-524e9f1e172f	2026-06-24	04:00:00	Performance improvements — Delivery Operations Hub	2026-06-24 09:01:00+00	2026-06-24 09:01:00+00	\N	DOH-165	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
8366c2b1-e806-5df8-9924-93412696995b	62445afe-3364-5e78-b55e-fb5429807a47	5c8e49c9-c065-5bc8-a57a-0a69e1a89a5e	a7906be2-315f-5b5e-b344-ac119fd04d1a	2026-06-25	00:00:00	Decyzja zakresowa potwierdzona z zespołem — Omnichannel Checkout	2026-06-25 09:01:00+00	2026-06-25 09:01:00+00	\N	\N	3030e191-44de-5909-b035-5fe3679b482a	Active	Note
02c62259-a089-5080-8c7c-ed7af10358e1	62445afe-3364-5e78-b55e-fb5429807a47	5c8e49c9-c065-5bc8-a57a-0a69e1a89a5e	f04245fa-9e0e-5905-80fa-524e9f1e172f	2026-06-26	02:00:00	Performance improvements — Delivery Operations Hub	2026-06-26 09:01:00+00	2026-06-26 09:01:00+00	\N	DOH-139	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
fcd3943b-e393-595a-b6ce-1f206b683dd2	62445afe-3364-5e78-b55e-fb5429807a47	5c8e49c9-c065-5bc8-a57a-0a69e1a89a5e	f04245fa-9e0e-5905-80fa-524e9f1e172f	2026-06-29	04:00:00	Performance improvements — Delivery Operations Hub	2026-06-29 09:01:00+00	2026-06-29 09:01:00+00	\N	DOH-113	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
c3de3820-3971-551d-a23f-650cd7d8775b	62445afe-3364-5e78-b55e-fb5429807a47	5c8e49c9-c065-5bc8-a57a-0a69e1a89a5e	f04245fa-9e0e-5905-80fa-524e9f1e172f	2026-07-01	02:00:00	Performance improvements — Delivery Operations Hub	2026-07-01 09:01:00+00	2026-07-01 09:01:00+00	\N	DOH-160	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
5dac62ce-a85f-55d2-9b89-b65ae919d325	62445afe-3364-5e78-b55e-fb5429807a47	5c8e49c9-c065-5bc8-a57a-0a69e1a89a5e	a7906be2-315f-5b5e-b344-ac119fd04d1a	2026-07-02	02:30:00	Performance improvements — Omnichannel Checkout	2026-07-02 09:01:00+00	2026-07-02 09:01:00+00	\N	OC-106	3030e191-44de-5909-b035-5fe3679b482a	Active	Worklog
f145507c-df4c-5468-8686-3c6bc7433e48	62445afe-3364-5e78-b55e-fb5429807a47	5c8e49c9-c065-5bc8-a57a-0a69e1a89a5e	f04245fa-9e0e-5905-80fa-524e9f1e172f	2026-07-03	04:00:00	Performance improvements — Delivery Operations Hub	2026-07-03 09:01:00+00	2026-07-03 09:01:00+00	\N	DOH-134	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
3a2c8179-f685-5a7e-9d14-8eac303c41ac	62445afe-3364-5e78-b55e-fb5429807a47	5c8e49c9-c065-5bc8-a57a-0a69e1a89a5e	a7906be2-315f-5b5e-b344-ac119fd04d1a	2026-07-06	00:30:00	Performance improvements — Omnichannel Checkout	2026-07-06 09:01:00+00	2026-07-06 09:01:00+00	\N	OC-153	3030e191-44de-5909-b035-5fe3679b482a	Active	Worklog
e6bc911a-1b2e-5120-86e1-395504ae50f2	62445afe-3364-5e78-b55e-fb5429807a47	5c8e49c9-c065-5bc8-a57a-0a69e1a89a5e	a7906be2-315f-5b5e-b344-ac119fd04d1a	2026-07-08	02:30:00	Performance improvements — Omnichannel Checkout	2026-07-08 09:01:00+00	2026-07-08 09:01:00+00	\N	OC-127	3030e191-44de-5909-b035-5fe3679b482a	Active	Worklog
cad48981-8c3c-509c-912c-a7838c57d06d	62445afe-3364-5e78-b55e-fb5429807a47	5c8e49c9-c065-5bc8-a57a-0a69e1a89a5e	a7906be2-315f-5b5e-b344-ac119fd04d1a	2026-07-10	00:30:00	Performance improvements — Omnichannel Checkout	2026-07-10 09:01:00+00	2026-07-10 09:01:00+00	\N	OC-101	3030e191-44de-5909-b035-5fe3679b482a	Active	Worklog
4547024a-e85d-5761-ad80-2d54c5dee098	62445afe-3364-5e78-b55e-fb5429807a47	5c8e49c9-c065-5bc8-a57a-0a69e1a89a5e	a7906be2-315f-5b5e-b344-ac119fd04d1a	2026-07-13	02:30:00	Performance improvements — Omnichannel Checkout	2026-07-13 09:01:00+00	2026-07-13 09:01:00+00	\N	OC-148	3030e191-44de-5909-b035-5fe3679b482a	Active	Worklog
6dc452f5-f67e-5c34-9c92-662d5b4341af	62445afe-3364-5e78-b55e-fb5429807a47	5c8e49c9-c065-5bc8-a57a-0a69e1a89a5e	a7906be2-315f-5b5e-b344-ac119fd04d1a	2026-07-15	00:30:00	Performance improvements — Omnichannel Checkout	2026-07-15 09:01:00+00	2026-07-15 09:01:00+00	\N	OC-122	3030e191-44de-5909-b035-5fe3679b482a	Active	Worklog
b217c1a6-373c-5afd-8f2f-ffd5806a2dc6	62445afe-3364-5e78-b55e-fb5429807a47	5c8e49c9-c065-5bc8-a57a-0a69e1a89a5e	f04245fa-9e0e-5905-80fa-524e9f1e172f	2026-07-16	00:00:00	Decyzja zakresowa potwierdzona z zespołem — Delivery Operations Hub	2026-07-16 09:01:00+00	2026-07-16 09:01:00+00	\N	\N	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Note
99b40441-98f9-540f-821a-5daec3c28baa	62445afe-3364-5e78-b55e-fb5429807a47	5c8e49c9-c065-5bc8-a57a-0a69e1a89a5e	a7906be2-315f-5b5e-b344-ac119fd04d1a	2026-07-17	02:30:00	Performance improvements — Omnichannel Checkout	2026-07-17 09:01:00+00	2026-07-17 09:01:00+00	\N	OC-169	3030e191-44de-5909-b035-5fe3679b482a	Active	Worklog
9f7e92c2-ccbc-52f6-8d0f-b5b7e8b27694	62445afe-3364-5e78-b55e-fb5429807a47	5c8e49c9-c065-5bc8-a57a-0a69e1a89a5e	a7906be2-315f-5b5e-b344-ac119fd04d1a	2026-07-21	00:30:00	Performance improvements — Omnichannel Checkout	2026-07-21 09:01:00+00	2026-07-21 09:01:00+00	\N	OC-143	3030e191-44de-5909-b035-5fe3679b482a	Active	Worklog
d9c106b1-f40a-5e1c-b0b5-2f71608094ca	62445afe-3364-5e78-b55e-fb5429807a47	5c8e49c9-c065-5bc8-a57a-0a69e1a89a5e	a7906be2-315f-5b5e-b344-ac119fd04d1a	2026-07-23	02:30:00	Performance improvements — Omnichannel Checkout	2026-07-23 09:01:00+00	2026-07-23 09:01:00+00	\N	OC-117	3030e191-44de-5909-b035-5fe3679b482a	Active	Worklog
ad9c9a8d-b903-5c4f-950e-3f3bdcba19c8	62445afe-3364-5e78-b55e-fb5429807a47	5c8e49c9-c065-5bc8-a57a-0a69e1a89a5e	f04245fa-9e0e-5905-80fa-524e9f1e172f	2026-07-24	03:00:00	Performance improvements — Delivery Operations Hub	2026-07-24 09:01:00+00	2026-07-24 09:01:00+00	\N	DOH-136	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
d243c619-5c40-5ba8-b8d5-79eb0cfbb09d	62445afe-3364-5e78-b55e-fb5429807a47	5c8e49c9-c065-5bc8-a57a-0a69e1a89a5e	a7906be2-315f-5b5e-b344-ac119fd04d1a	2026-07-26	00:30:00	Performance improvements — Omnichannel Checkout	2026-07-26 09:01:00+00	2026-07-26 09:01:00+00	\N	OC-164	3030e191-44de-5909-b035-5fe3679b482a	Active	Worklog
8ef88bb9-d650-578d-bc50-50595c5a7158	62445afe-3364-5e78-b55e-fb5429807a47	5c8e49c9-c065-5bc8-a57a-0a69e1a89a5e	f04245fa-9e0e-5905-80fa-524e9f1e172f	2026-07-27	01:00:00	Performance improvements — Delivery Operations Hub	2026-07-27 09:01:00+00	2026-07-27 09:01:00+00	\N	DOH-110	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
6bf73c8f-feef-5f1b-ab6b-6f6e77511077	62445afe-3364-5e78-b55e-fb5429807a47	5c8e49c9-c065-5bc8-a57a-0a69e1a89a5e	f04245fa-9e0e-5905-80fa-524e9f1e172f	2026-07-29	03:00:00	Performance improvements — Delivery Operations Hub	2026-07-29 09:01:00+00	2026-07-29 09:01:00+00	\N	DOH-157	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
86b19636-bd34-52a0-a708-3f4930b1f78f	62445afe-3364-5e78-b55e-fb5429807a47	5c8e49c9-c065-5bc8-a57a-0a69e1a89a5e	f04245fa-9e0e-5905-80fa-524e9f1e172f	2026-07-31	01:00:00	Performance improvements — Delivery Operations Hub	2026-07-31 09:01:00+00	2026-07-31 09:01:00+00	\N	DOH-131	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
11f09c82-6c9b-5088-bde4-1b4c37010d8e	62445afe-3364-5e78-b55e-fb5429807a47	5c8e49c9-c065-5bc8-a57a-0a69e1a89a5e	f04245fa-9e0e-5905-80fa-524e9f1e172f	2026-08-04	03:00:00	Performance improvements — Delivery Operations Hub	2026-08-04 09:01:00+00	2026-08-04 09:01:00+00	\N	DOH-105	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
ffe72e68-bf88-5577-97c1-e565f9137f2b	62445afe-3364-5e78-b55e-fb5429807a47	5c8e49c9-c065-5bc8-a57a-0a69e1a89a5e	f04245fa-9e0e-5905-80fa-524e9f1e172f	2026-08-06	01:00:00	Performance improvements — Delivery Operations Hub	2026-08-06 09:01:00+00	2026-08-06 09:01:00+00	\N	DOH-152	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
d34c1f68-f69a-5e54-b8e1-84384000375b	62445afe-3364-5e78-b55e-fb5429807a47	5c8e49c9-c065-5bc8-a57a-0a69e1a89a5e	f04245fa-9e0e-5905-80fa-524e9f1e172f	2026-08-09	03:00:00	Performance improvements — Delivery Operations Hub	2026-08-09 09:01:00+00	2026-08-09 09:01:00+00	\N	DOH-126	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
8d7db17f-d643-55a5-9f57-b4c7ae2fab7b	62445afe-3364-5e78-b55e-fb5429807a47	5c8e49c9-c065-5bc8-a57a-0a69e1a89a5e	f04245fa-9e0e-5905-80fa-524e9f1e172f	2026-08-11	01:00:00	Performance improvements — Delivery Operations Hub	2026-08-11 09:01:00+00	2026-08-11 09:01:00+00	\N	DOH-100	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
7299bf3e-5ddf-59d2-b16f-e3e28be59e29	62445afe-3364-5e78-b55e-fb5429807a47	75243589-322b-5eea-941f-54c424751a23	6dfe9630-59ce-507d-81a0-2f94cb54247f	2026-05-20	03:15:00	Data analysis — Fleet Companion	2026-05-20 09:01:00+00	2026-05-20 09:01:00+00	\N	FC-104	eba17d28-b076-534c-918a-dca0a5be8fab	Active	Worklog
41623f71-0093-5356-b128-3047a8894603	62445afe-3364-5e78-b55e-fb5429807a47	75243589-322b-5eea-941f-54c424751a23	04500693-9e94-55cd-a8ad-c3627d2dac80	2026-05-21	00:45:00	Data analysis — Commerce Growth	2026-05-21 09:01:00+00	2026-05-21 09:01:00+00	\N	CG-132	e7e99ce4-232e-5ade-abb1-0966c94d952e	Active	Worklog
33a0d40c-9711-56a5-86f1-3ccf879931a7	62445afe-3364-5e78-b55e-fb5429807a47	75243589-322b-5eea-941f-54c424751a23	b8cd683c-fe4d-538c-bdaf-68c28e1e14ef	2026-05-22	01:15:00	Data analysis — Time Intelligence	2026-05-22 09:01:00+00	2026-05-22 09:01:00+00	\N	TI-151	d677a650-2c23-5c0c-9f53-920636bd318e	Active	Worklog
de66e854-b62e-515e-8c3c-2b161280b186	62445afe-3364-5e78-b55e-fb5429807a47	75243589-322b-5eea-941f-54c424751a23	06f6bf38-0173-52de-aa5b-77d565741cb1	2026-05-25	02:45:00	Data analysis — Retail Insights	2026-05-25 09:01:00+00	2026-05-25 09:01:00+00	\N	RI-106	3030e191-44de-5909-b035-5fe3679b482a	Active	Worklog
230985ea-c804-5683-911d-20c5c09d44d0	62445afe-3364-5e78-b55e-fb5429807a47	75243589-322b-5eea-941f-54c424751a23	6dfe9630-59ce-507d-81a0-2f94cb54247f	2026-05-26	03:15:00	Data analysis — Fleet Companion	2026-05-26 09:01:00+00	2026-05-26 09:01:00+00	\N	FC-125	eba17d28-b076-534c-918a-dca0a5be8fab	Active	Worklog
61898a26-b6a3-5487-9c9a-cb128c0a619d	62445afe-3364-5e78-b55e-fb5429807a47	75243589-322b-5eea-941f-54c424751a23	b8cd683c-fe4d-538c-bdaf-68c28e1e14ef	2026-05-28	01:15:00	Data analysis — Time Intelligence	2026-05-28 09:01:00+00	2026-05-28 09:01:00+00	\N	TI-172	d677a650-2c23-5c0c-9f53-920636bd318e	Active	Worklog
6fa5c1eb-f74b-5c86-9a46-d2cf7aa9a0de	62445afe-3364-5e78-b55e-fb5429807a47	75243589-322b-5eea-941f-54c424751a23	6dfe9630-59ce-507d-81a0-2f94cb54247f	2026-05-31	03:15:00	Data analysis — Fleet Companion	2026-05-31 09:01:00+00	2026-05-31 09:01:00+00	\N	FC-146	eba17d28-b076-534c-918a-dca0a5be8fab	Active	Worklog
d8f7434a-4109-58b8-b9bf-b8cb8b955c48	62445afe-3364-5e78-b55e-fb5429807a47	75243589-322b-5eea-941f-54c424751a23	b8cd683c-fe4d-538c-bdaf-68c28e1e14ef	2026-06-02	01:15:00	Data analysis — Time Intelligence	2026-06-02 09:01:00+00	2026-06-02 09:01:00+00	\N	TI-120	d677a650-2c23-5c0c-9f53-920636bd318e	Active	Worklog
57311f70-0bc2-5493-8d27-30a21db1b08e	62445afe-3364-5e78-b55e-fb5429807a47	75243589-322b-5eea-941f-54c424751a23	04500693-9e94-55cd-a8ad-c3627d2dac80	2026-06-03	00:00:00	Client feedback added to the next iteration — Commerce Growth	2026-06-03 09:01:00+00	2026-06-03 09:01:00+00	\N	\N	e7e99ce4-232e-5ade-abb1-0966c94d952e	Active	Note
91283535-ddff-5b36-84cb-30dda711da95	62445afe-3364-5e78-b55e-fb5429807a47	75243589-322b-5eea-941f-54c424751a23	6dfe9630-59ce-507d-81a0-2f94cb54247f	2026-06-04	03:15:00	Data analysis — Fleet Companion	2026-06-04 09:01:00+00	2026-06-04 09:01:00+00	\N	FC-167	eba17d28-b076-534c-918a-dca0a5be8fab	Active	Worklog
21698a4b-70bc-5d84-aed6-2a377bf32869	62445afe-3364-5e78-b55e-fb5429807a47	75243589-322b-5eea-941f-54c424751a23	b8cd683c-fe4d-538c-bdaf-68c28e1e14ef	2026-06-08	01:15:00	Data analysis — Time Intelligence	2026-06-08 09:01:00+00	2026-06-08 09:01:00+00	\N	TI-141	d677a650-2c23-5c0c-9f53-920636bd318e	Active	Worklog
f2c5633f-5de5-59da-9fda-9957558b8611	62445afe-3364-5e78-b55e-fb5429807a47	75243589-322b-5eea-941f-54c424751a23	6dfe9630-59ce-507d-81a0-2f94cb54247f	2026-06-10	03:15:00	Data analysis — Fleet Companion	2026-06-10 09:01:00+00	2026-06-10 09:01:00+00	\N	FC-115	eba17d28-b076-534c-918a-dca0a5be8fab	Active	Worklog
c62aa888-1e54-5bee-9837-e4823ecaab49	62445afe-3364-5e78-b55e-fb5429807a47	75243589-322b-5eea-941f-54c424751a23	35f8aab0-9932-515e-80cc-e8fa82f9c650	2026-06-11	03:45:00	Data analysis — Risk Dashboard	2026-06-11 09:01:00+00	2026-06-11 09:01:00+00	\N	RD-134	f4c5b0e8-5503-5a50-8487-4ae103b885f2	Active	Worklog
39673516-5445-50c9-9e34-1fcb1ca9cab5	62445afe-3364-5e78-b55e-fb5429807a47	75243589-322b-5eea-941f-54c424751a23	b8cd683c-fe4d-538c-bdaf-68c28e1e14ef	2026-06-12	01:15:00	Data analysis — Time Intelligence	2026-06-12 09:01:00+00	2026-06-12 09:01:00+00	\N	TI-162	d677a650-2c23-5c0c-9f53-920636bd318e	Active	Worklog
eaf3ef62-3b36-5a2c-83e2-2f570626a325	62445afe-3364-5e78-b55e-fb5429807a47	75243589-322b-5eea-941f-54c424751a23	9406b74a-6b7a-578b-8fbd-958684d93780	2026-06-14	01:45:00	Data analysis — Patient Portal	2026-06-14 09:01:00+00	2026-06-14 09:01:00+00	\N	PP-108	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
d4410328-5a97-57ad-8e36-208ea9ef85af	62445afe-3364-5e78-b55e-fb5429807a47	75243589-322b-5eea-941f-54c424751a23	35f8aab0-9932-515e-80cc-e8fa82f9c650	2026-06-16	03:45:00	Data analysis — Risk Dashboard	2026-06-16 09:01:00+00	2026-06-16 09:01:00+00	\N	RD-155	f4c5b0e8-5503-5a50-8487-4ae103b885f2	Active	Worklog
43d3ac14-fa04-5a33-a339-b082b2047569	62445afe-3364-5e78-b55e-fb5429807a47	75243589-322b-5eea-941f-54c424751a23	9406b74a-6b7a-578b-8fbd-958684d93780	2026-06-18	01:45:00	Data analysis — Patient Portal	2026-06-18 09:01:00+00	2026-06-18 09:01:00+00	\N	PP-129	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
c035ee71-4269-575e-a705-a5d53beb9243	62445afe-3364-5e78-b55e-fb5429807a47	75243589-322b-5eea-941f-54c424751a23	35f8aab0-9932-515e-80cc-e8fa82f9c650	2026-06-22	03:45:00	Data analysis — Risk Dashboard	2026-06-22 09:01:00+00	2026-06-22 09:01:00+00	\N	RD-103	f4c5b0e8-5503-5a50-8487-4ae103b885f2	Active	Worklog
65bfb1a3-33dd-5632-a65d-da43d5b041c9	62445afe-3364-5e78-b55e-fb5429807a47	75243589-322b-5eea-941f-54c424751a23	9406b74a-6b7a-578b-8fbd-958684d93780	2026-06-24	01:45:00	Data analysis — Patient Portal	2026-06-24 09:01:00+00	2026-06-24 09:01:00+00	\N	PP-150	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
cc20aa3d-8899-558a-9b84-da5607a262ce	62445afe-3364-5e78-b55e-fb5429807a47	75243589-322b-5eea-941f-54c424751a23	b8cd683c-fe4d-538c-bdaf-68c28e1e14ef	2026-06-25	00:00:00	Client feedback added to the next iteration — Time Intelligence	2026-06-25 09:01:00+00	2026-06-25 09:01:00+00	\N	\N	d677a650-2c23-5c0c-9f53-920636bd318e	Active	Note
ce01f561-3e18-569b-8431-da2f4ab873e0	62445afe-3364-5e78-b55e-fb5429807a47	75243589-322b-5eea-941f-54c424751a23	35f8aab0-9932-515e-80cc-e8fa82f9c650	2026-06-26	03:45:00	Data analysis — Risk Dashboard	2026-06-26 09:01:00+00	2026-06-26 09:01:00+00	\N	RD-124	f4c5b0e8-5503-5a50-8487-4ae103b885f2	Active	Worklog
a9ef81f9-9d64-55e0-bce7-2957ee989507	62445afe-3364-5e78-b55e-fb5429807a47	75243589-322b-5eea-941f-54c424751a23	9406b74a-6b7a-578b-8fbd-958684d93780	2026-06-29	01:45:00	Data analysis — Patient Portal	2026-06-29 09:01:00+00	2026-06-29 09:01:00+00	\N	PP-171	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
7771ec66-87d3-56fb-8bcc-d265ee9f1d32	62445afe-3364-5e78-b55e-fb5429807a47	75243589-322b-5eea-941f-54c424751a23	35f8aab0-9932-515e-80cc-e8fa82f9c650	2026-07-01	03:45:00	Data analysis — Risk Dashboard	2026-07-01 09:01:00+00	2026-07-01 09:01:00+00	\N	RD-145	f4c5b0e8-5503-5a50-8487-4ae103b885f2	Active	Worklog
0cf0bc1b-39d3-5c92-8366-be6c28ed1d98	62445afe-3364-5e78-b55e-fb5429807a47	75243589-322b-5eea-941f-54c424751a23	f07ee933-bae1-5f0f-9e95-6c303aba6f5d	2026-07-02	00:15:00	Data analysis — Open Banking Integration	2026-07-02 09:01:00+00	2026-07-02 09:01:00+00	\N	OBI-164	f4c5b0e8-5503-5a50-8487-4ae103b885f2	Active	Worklog
79f7420f-caa1-503f-ae52-f64a0a13b972	62445afe-3364-5e78-b55e-fb5429807a47	75243589-322b-5eea-941f-54c424751a23	9406b74a-6b7a-578b-8fbd-958684d93780	2026-07-03	01:45:00	Data analysis — Patient Portal	2026-07-03 09:01:00+00	2026-07-03 09:01:00+00	\N	PP-119	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
d9912e1a-fbd0-53e1-b16c-764a72d1cac4	62445afe-3364-5e78-b55e-fb5429807a47	75243589-322b-5eea-941f-54c424751a23	e7ea37c3-9fe3-5010-bb38-8c7330ef5bdc	2026-07-06	02:15:00	Data analysis — Care Analytics	2026-07-06 09:01:00+00	2026-07-06 09:01:00+00	\N	CA-138	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
0adbcd8d-b0cc-58e7-bfb6-f6fa5ae0402c	62445afe-3364-5e78-b55e-fb5429807a47	75243589-322b-5eea-941f-54c424751a23	f07ee933-bae1-5f0f-9e95-6c303aba6f5d	2026-07-08	00:15:00	Data analysis — Open Banking Integration	2026-07-08 09:01:00+00	2026-07-08 09:01:00+00	\N	OBI-112	f4c5b0e8-5503-5a50-8487-4ae103b885f2	Active	Worklog
f1df5959-2a1f-5585-8013-c62a05e73fec	62445afe-3364-5e78-b55e-fb5429807a47	75243589-322b-5eea-941f-54c424751a23	e7ea37c3-9fe3-5010-bb38-8c7330ef5bdc	2026-07-10	02:15:00	Data analysis — Care Analytics	2026-07-10 09:01:00+00	2026-07-10 09:01:00+00	\N	CA-159	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
c8f92a30-d1ef-5798-bec2-f2c7ffe0aee3	62445afe-3364-5e78-b55e-fb5429807a47	75243589-322b-5eea-941f-54c424751a23	f07ee933-bae1-5f0f-9e95-6c303aba6f5d	2026-07-13	00:15:00	Data analysis — Open Banking Integration	2026-07-13 09:01:00+00	2026-07-13 09:01:00+00	\N	OBI-133	f4c5b0e8-5503-5a50-8487-4ae103b885f2	Active	Worklog
8c4e9cca-ffd4-56c2-85e8-5d54a83dacce	62445afe-3364-5e78-b55e-fb5429807a47	75243589-322b-5eea-941f-54c424751a23	e7ea37c3-9fe3-5010-bb38-8c7330ef5bdc	2026-07-15	02:15:00	Data analysis — Care Analytics	2026-07-15 09:01:00+00	2026-07-15 09:01:00+00	\N	CA-107	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
bc2b9e02-b8de-5edc-9037-0790b670ee49	62445afe-3364-5e78-b55e-fb5429807a47	75243589-322b-5eea-941f-54c424751a23	9406b74a-6b7a-578b-8fbd-958684d93780	2026-07-16	00:00:00	Client feedback added to the next iteration — Patient Portal	2026-07-16 09:01:00+00	2026-07-16 09:01:00+00	\N	\N	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Note
afccd285-f254-5335-8175-e3f5999df119	62445afe-3364-5e78-b55e-fb5429807a47	75243589-322b-5eea-941f-54c424751a23	f07ee933-bae1-5f0f-9e95-6c303aba6f5d	2026-07-17	00:15:00	Data analysis — Open Banking Integration	2026-07-17 09:01:00+00	2026-07-17 09:01:00+00	\N	OBI-154	f4c5b0e8-5503-5a50-8487-4ae103b885f2	Active	Worklog
75f2eda4-c8d2-5925-95ca-ae8f785f081e	62445afe-3364-5e78-b55e-fb5429807a47	75243589-322b-5eea-941f-54c424751a23	e7ea37c3-9fe3-5010-bb38-8c7330ef5bdc	2026-07-21	02:15:00	Data analysis — Care Analytics	2026-07-21 09:01:00+00	2026-07-21 09:01:00+00	\N	CA-128	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
b5d30d0c-893b-5a58-8777-7eef8b2be7fc	62445afe-3364-5e78-b55e-fb5429807a47	75243589-322b-5eea-941f-54c424751a23	f07ee933-bae1-5f0f-9e95-6c303aba6f5d	2026-07-23	00:15:00	Data analysis — Open Banking Integration	2026-07-23 09:01:00+00	2026-07-23 09:01:00+00	\N	OBI-102	f4c5b0e8-5503-5a50-8487-4ae103b885f2	Active	Worklog
600e5720-822f-5651-a5f1-32dc388aa6f1	62445afe-3364-5e78-b55e-fb5429807a47	75243589-322b-5eea-941f-54c424751a23	04500693-9e94-55cd-a8ad-c3627d2dac80	2026-07-24	00:45:00	Data analysis — Commerce Growth	2026-07-24 09:01:00+00	2026-07-24 09:01:00+00	\N	CG-121	e7e99ce4-232e-5ade-abb1-0966c94d952e	Active	Worklog
c4cd2345-fab7-590e-8714-e83598f759f2	62445afe-3364-5e78-b55e-fb5429807a47	75243589-322b-5eea-941f-54c424751a23	e7ea37c3-9fe3-5010-bb38-8c7330ef5bdc	2026-07-26	02:15:00	Data analysis — Care Analytics	2026-07-26 09:01:00+00	2026-07-26 09:01:00+00	\N	CA-149	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
7bf2d7d3-d9c4-527a-adfc-a1ceb7df9e10	62445afe-3364-5e78-b55e-fb5429807a47	75243589-322b-5eea-941f-54c424751a23	06f6bf38-0173-52de-aa5b-77d565741cb1	2026-07-27	02:45:00	Data analysis — Retail Insights	2026-07-27 09:01:00+00	2026-07-27 09:01:00+00	\N	RI-168	3030e191-44de-5909-b035-5fe3679b482a	Active	Worklog
dfc99b27-2f27-505c-859c-4fcf3970b5e7	62445afe-3364-5e78-b55e-fb5429807a47	75243589-322b-5eea-941f-54c424751a23	04500693-9e94-55cd-a8ad-c3627d2dac80	2026-07-29	00:45:00	Data analysis — Commerce Growth	2026-07-29 09:01:00+00	2026-07-29 09:01:00+00	\N	CG-142	e7e99ce4-232e-5ade-abb1-0966c94d952e	Active	Worklog
3bb87366-a7ee-56d2-960d-fd549b31156e	62445afe-3364-5e78-b55e-fb5429807a47	75243589-322b-5eea-941f-54c424751a23	06f6bf38-0173-52de-aa5b-77d565741cb1	2026-07-31	02:45:00	Data analysis — Retail Insights	2026-07-31 09:01:00+00	2026-07-31 09:01:00+00	\N	RI-116	3030e191-44de-5909-b035-5fe3679b482a	Active	Worklog
9eb0ecbe-5244-52ce-81ba-455656362c6c	62445afe-3364-5e78-b55e-fb5429807a47	75243589-322b-5eea-941f-54c424751a23	04500693-9e94-55cd-a8ad-c3627d2dac80	2026-08-04	00:45:00	Data analysis — Commerce Growth	2026-08-04 09:01:00+00	2026-08-04 09:01:00+00	\N	CG-163	e7e99ce4-232e-5ade-abb1-0966c94d952e	Active	Worklog
436ae02f-4dd7-5f20-a48d-57e516fb800b	62445afe-3364-5e78-b55e-fb5429807a47	75243589-322b-5eea-941f-54c424751a23	06f6bf38-0173-52de-aa5b-77d565741cb1	2026-08-06	02:45:00	Data analysis — Retail Insights	2026-08-06 09:01:00+00	2026-08-06 09:01:00+00	\N	RI-137	3030e191-44de-5909-b035-5fe3679b482a	Active	Worklog
db1678f8-4074-5759-b6b4-2cd387955559	62445afe-3364-5e78-b55e-fb5429807a47	75243589-322b-5eea-941f-54c424751a23	04500693-9e94-55cd-a8ad-c3627d2dac80	2026-08-09	00:45:00	Data analysis — Commerce Growth	2026-08-09 09:01:00+00	2026-08-09 09:01:00+00	\N	CG-111	e7e99ce4-232e-5ade-abb1-0966c94d952e	Active	Worklog
19444256-6ebc-5815-af03-b3a5e7e07541	62445afe-3364-5e78-b55e-fb5429807a47	75243589-322b-5eea-941f-54c424751a23	06f6bf38-0173-52de-aa5b-77d565741cb1	2026-08-11	02:45:00	Data analysis — Retail Insights	2026-08-11 09:01:00+00	2026-08-11 09:01:00+00	\N	RI-158	3030e191-44de-5909-b035-5fe3679b482a	Active	Worklog
8cef9cee-0b8a-58c1-a6df-b745c8e11811	62445afe-3364-5e78-b55e-fb5429807a47	bc1ce6aa-f011-56ab-9e10-492c111f50ba	f04245fa-9e0e-5905-80fa-524e9f1e172f	2026-05-20	00:15:00	Discovery workshop — Delivery Operations Hub	2026-05-20 09:01:00+00	2026-05-20 09:01:00+00	\N	DOH-100	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
f460f2c8-e903-5a21-838b-3597c324d98a	62445afe-3364-5e78-b55e-fb5429807a47	bc1ce6aa-f011-56ab-9e10-492c111f50ba	f04245fa-9e0e-5905-80fa-524e9f1e172f	2026-05-21	01:45:00	Discovery workshop — Delivery Operations Hub	2026-05-21 09:01:00+00	2026-05-21 09:01:00+00	\N	DOH-128	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
dd866ca8-eb32-54d2-8e0f-8bc28f438e6e	62445afe-3364-5e78-b55e-fb5429807a47	bc1ce6aa-f011-56ab-9e10-492c111f50ba	f04245fa-9e0e-5905-80fa-524e9f1e172f	2026-05-22	02:15:00	Discovery workshop — Delivery Operations Hub	2026-05-22 09:01:00+00	2026-05-22 09:01:00+00	\N	DOH-147	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
030d1e55-4ec0-5245-a59b-1d8418bd7cc1	62445afe-3364-5e78-b55e-fb5429807a47	bc1ce6aa-f011-56ab-9e10-492c111f50ba	f04245fa-9e0e-5905-80fa-524e9f1e172f	2026-05-25	03:45:00	Discovery workshop — Delivery Operations Hub	2026-05-25 09:01:00+00	2026-05-25 09:01:00+00	\N	DOH-102	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
c6d10f3a-2711-5470-9a09-439e8db803c7	62445afe-3364-5e78-b55e-fb5429807a47	bc1ce6aa-f011-56ab-9e10-492c111f50ba	f04245fa-9e0e-5905-80fa-524e9f1e172f	2026-05-26	00:15:00	Discovery workshop — Delivery Operations Hub	2026-05-26 09:01:00+00	2026-05-26 09:01:00+00	\N	DOH-121	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
6ca6eafd-1779-5e5b-8019-d592aecea33b	62445afe-3364-5e78-b55e-fb5429807a47	bc1ce6aa-f011-56ab-9e10-492c111f50ba	f04245fa-9e0e-5905-80fa-524e9f1e172f	2026-05-28	02:15:00	Discovery workshop — Delivery Operations Hub	2026-05-28 09:01:00+00	2026-05-28 09:01:00+00	\N	DOH-168	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
6ea596d5-2744-5588-a562-00c32fef77c9	62445afe-3364-5e78-b55e-fb5429807a47	bc1ce6aa-f011-56ab-9e10-492c111f50ba	f04245fa-9e0e-5905-80fa-524e9f1e172f	2026-05-31	00:15:00	Discovery workshop — Delivery Operations Hub	2026-05-31 09:01:00+00	2026-05-31 09:01:00+00	\N	DOH-142	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
080b13a7-324b-5526-861d-9e56e66adae2	62445afe-3364-5e78-b55e-fb5429807a47	bc1ce6aa-f011-56ab-9e10-492c111f50ba	f04245fa-9e0e-5905-80fa-524e9f1e172f	2026-06-02	02:15:00	Discovery workshop — Delivery Operations Hub	2026-06-02 09:01:00+00	2026-06-02 09:01:00+00	\N	DOH-116	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
d2ba5a2f-0ee3-592f-a431-a9454a2de694	62445afe-3364-5e78-b55e-fb5429807a47	bc1ce6aa-f011-56ab-9e10-492c111f50ba	f04245fa-9e0e-5905-80fa-524e9f1e172f	2026-06-03	00:00:00	Discovery follow-up zaplanowany na kolejny tydzień — Delivery Operations Hub	2026-06-03 09:01:00+00	2026-06-03 09:01:00+00	\N	\N	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Note
3278beea-706f-581b-94be-ed08d06a1219	62445afe-3364-5e78-b55e-fb5429807a47	bc1ce6aa-f011-56ab-9e10-492c111f50ba	f04245fa-9e0e-5905-80fa-524e9f1e172f	2026-06-04	00:15:00	Discovery workshop — Delivery Operations Hub	2026-06-04 09:01:00+00	2026-06-04 09:01:00+00	\N	DOH-163	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
08965d54-1918-560f-8df9-0be3b4c097de	62445afe-3364-5e78-b55e-fb5429807a47	bc1ce6aa-f011-56ab-9e10-492c111f50ba	f04245fa-9e0e-5905-80fa-524e9f1e172f	2026-06-08	02:15:00	Discovery workshop — Delivery Operations Hub	2026-06-08 09:01:00+00	2026-06-08 09:01:00+00	\N	DOH-137	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
dc04e68f-44aa-537a-b810-c8bda5efc556	62445afe-3364-5e78-b55e-fb5429807a47	bc1ce6aa-f011-56ab-9e10-492c111f50ba	f04245fa-9e0e-5905-80fa-524e9f1e172f	2026-06-10	00:15:00	Discovery workshop — Delivery Operations Hub	2026-06-10 09:01:00+00	2026-06-10 09:01:00+00	\N	DOH-111	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
a3aa0ea3-dbc3-5532-b811-ab0774a9072f	62445afe-3364-5e78-b55e-fb5429807a47	bc1ce6aa-f011-56ab-9e10-492c111f50ba	f04245fa-9e0e-5905-80fa-524e9f1e172f	2026-06-11	00:45:00	Discovery workshop — Delivery Operations Hub	2026-06-11 09:01:00+00	2026-06-11 09:01:00+00	\N	DOH-130	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
01a97c18-3971-524c-9d3b-0fc77fad2686	62445afe-3364-5e78-b55e-fb5429807a47	bc1ce6aa-f011-56ab-9e10-492c111f50ba	f04245fa-9e0e-5905-80fa-524e9f1e172f	2026-06-12	02:15:00	Discovery workshop — Delivery Operations Hub	2026-06-12 09:01:00+00	2026-06-12 09:01:00+00	\N	DOH-158	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
5115607a-e644-5447-96f5-d9cb7fa7da3f	62445afe-3364-5e78-b55e-fb5429807a47	bc1ce6aa-f011-56ab-9e10-492c111f50ba	f04245fa-9e0e-5905-80fa-524e9f1e172f	2026-06-14	02:45:00	Discovery workshop — Delivery Operations Hub	2026-06-14 09:01:00+00	2026-06-14 09:01:00+00	\N	DOH-104	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
01c5d948-055e-52a8-8bae-584852c3a32e	62445afe-3364-5e78-b55e-fb5429807a47	bc1ce6aa-f011-56ab-9e10-492c111f50ba	f04245fa-9e0e-5905-80fa-524e9f1e172f	2026-06-16	00:45:00	Discovery workshop — Delivery Operations Hub	2026-06-16 09:01:00+00	2026-06-16 09:01:00+00	\N	DOH-151	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
7707e8e0-a704-5c97-b7ff-1942117489ef	62445afe-3364-5e78-b55e-fb5429807a47	bc1ce6aa-f011-56ab-9e10-492c111f50ba	f04245fa-9e0e-5905-80fa-524e9f1e172f	2026-06-18	02:45:00	Discovery workshop — Delivery Operations Hub	2026-06-18 09:01:00+00	2026-06-18 09:01:00+00	\N	DOH-125	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
ae9e29e0-3321-57ff-a930-dbe0796168c0	62445afe-3364-5e78-b55e-fb5429807a47	bc1ce6aa-f011-56ab-9e10-492c111f50ba	f04245fa-9e0e-5905-80fa-524e9f1e172f	2026-06-22	00:45:00	Discovery workshop — Delivery Operations Hub	2026-06-22 09:01:00+00	2026-06-22 09:01:00+00	\N	DOH-172	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
9cabf883-2755-5e5b-9b3a-1617c4c9e59e	62445afe-3364-5e78-b55e-fb5429807a47	bc1ce6aa-f011-56ab-9e10-492c111f50ba	f04245fa-9e0e-5905-80fa-524e9f1e172f	2026-06-24	02:45:00	Discovery workshop — Delivery Operations Hub	2026-06-24 09:01:00+00	2026-06-24 09:01:00+00	\N	DOH-146	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
eede611d-6295-5c78-988a-b501ef1bf6af	62445afe-3364-5e78-b55e-fb5429807a47	bc1ce6aa-f011-56ab-9e10-492c111f50ba	f04245fa-9e0e-5905-80fa-524e9f1e172f	2026-06-25	00:00:00	Discovery follow-up zaplanowany na kolejny tydzień — Delivery Operations Hub	2026-06-25 09:01:00+00	2026-06-25 09:01:00+00	\N	\N	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Note
bd8b07db-455b-5c60-a3ae-1ca4ff5aefad	62445afe-3364-5e78-b55e-fb5429807a47	bc1ce6aa-f011-56ab-9e10-492c111f50ba	f04245fa-9e0e-5905-80fa-524e9f1e172f	2026-06-26	00:45:00	Discovery workshop — Delivery Operations Hub	2026-06-26 09:01:00+00	2026-06-26 09:01:00+00	\N	DOH-120	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
c1021ef0-380e-5571-8f5b-af5515e6ff37	62445afe-3364-5e78-b55e-fb5429807a47	bc1ce6aa-f011-56ab-9e10-492c111f50ba	f04245fa-9e0e-5905-80fa-524e9f1e172f	2026-06-29	02:45:00	Discovery workshop — Delivery Operations Hub	2026-06-29 09:01:00+00	2026-06-29 09:01:00+00	\N	DOH-167	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
75cbde21-dc53-59cd-bb3b-125bb53d9bb9	62445afe-3364-5e78-b55e-fb5429807a47	bc1ce6aa-f011-56ab-9e10-492c111f50ba	f04245fa-9e0e-5905-80fa-524e9f1e172f	2026-07-01	00:45:00	Discovery workshop — Delivery Operations Hub	2026-07-01 09:01:00+00	2026-07-01 09:01:00+00	\N	DOH-141	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
6dd228c8-a10d-557e-ad8a-84f7f2b130ac	62445afe-3364-5e78-b55e-fb5429807a47	bc1ce6aa-f011-56ab-9e10-492c111f50ba	f04245fa-9e0e-5905-80fa-524e9f1e172f	2026-07-02	01:15:00	Discovery workshop — Delivery Operations Hub	2026-07-02 09:01:00+00	2026-07-02 09:01:00+00	\N	DOH-160	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
a61c214c-62a0-52f9-9dd4-c535237da448	62445afe-3364-5e78-b55e-fb5429807a47	bc1ce6aa-f011-56ab-9e10-492c111f50ba	f04245fa-9e0e-5905-80fa-524e9f1e172f	2026-07-03	02:45:00	Discovery workshop — Delivery Operations Hub	2026-07-03 09:01:00+00	2026-07-03 09:01:00+00	\N	DOH-115	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
4e3f4f26-d484-5203-89b9-04dda18addec	62445afe-3364-5e78-b55e-fb5429807a47	bc1ce6aa-f011-56ab-9e10-492c111f50ba	f04245fa-9e0e-5905-80fa-524e9f1e172f	2026-07-06	03:15:00	Discovery workshop — Delivery Operations Hub	2026-07-06 09:01:00+00	2026-07-06 09:01:00+00	\N	DOH-134	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
834535f2-31af-5dd0-8bb2-b5c3a6d555ef	62445afe-3364-5e78-b55e-fb5429807a47	bc1ce6aa-f011-56ab-9e10-492c111f50ba	f04245fa-9e0e-5905-80fa-524e9f1e172f	2026-07-08	01:15:00	Discovery workshop — Delivery Operations Hub	2026-07-08 09:01:00+00	2026-07-08 09:01:00+00	\N	DOH-108	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
82640ee1-54b9-5f51-9374-c5acd473a48c	62445afe-3364-5e78-b55e-fb5429807a47	bc1ce6aa-f011-56ab-9e10-492c111f50ba	f04245fa-9e0e-5905-80fa-524e9f1e172f	2026-07-10	03:15:00	Discovery workshop — Delivery Operations Hub	2026-07-10 09:01:00+00	2026-07-10 09:01:00+00	\N	DOH-155	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
8497ad1a-3108-5e74-8e59-106111d82e60	62445afe-3364-5e78-b55e-fb5429807a47	bc1ce6aa-f011-56ab-9e10-492c111f50ba	f04245fa-9e0e-5905-80fa-524e9f1e172f	2026-07-13	01:15:00	Discovery workshop — Delivery Operations Hub	2026-07-13 09:01:00+00	2026-07-13 09:01:00+00	\N	DOH-129	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
7980e42b-306d-5c04-abeb-39184f80abea	62445afe-3364-5e78-b55e-fb5429807a47	bc1ce6aa-f011-56ab-9e10-492c111f50ba	f04245fa-9e0e-5905-80fa-524e9f1e172f	2026-07-15	03:15:00	Discovery workshop — Delivery Operations Hub	2026-07-15 09:01:00+00	2026-07-15 09:01:00+00	\N	DOH-103	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
67d8a0e9-2afe-5a2e-9355-80808ac904d6	62445afe-3364-5e78-b55e-fb5429807a47	bc1ce6aa-f011-56ab-9e10-492c111f50ba	f04245fa-9e0e-5905-80fa-524e9f1e172f	2026-07-16	00:00:00	Discovery follow-up zaplanowany na kolejny tydzień — Delivery Operations Hub	2026-07-16 09:01:00+00	2026-07-16 09:01:00+00	\N	\N	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Note
3a106b3f-96bf-560c-8809-74b538a6615a	62445afe-3364-5e78-b55e-fb5429807a47	bc1ce6aa-f011-56ab-9e10-492c111f50ba	f04245fa-9e0e-5905-80fa-524e9f1e172f	2026-07-17	01:15:00	Discovery workshop — Delivery Operations Hub	2026-07-17 09:01:00+00	2026-07-17 09:01:00+00	\N	DOH-150	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
3eb06e35-bb10-57bf-9572-e76711689281	62445afe-3364-5e78-b55e-fb5429807a47	bc1ce6aa-f011-56ab-9e10-492c111f50ba	f04245fa-9e0e-5905-80fa-524e9f1e172f	2026-07-21	03:15:00	Discovery workshop — Delivery Operations Hub	2026-07-21 09:01:00+00	2026-07-21 09:01:00+00	\N	DOH-124	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
014bc5e0-070f-5fb3-bdcc-ef9212147e06	62445afe-3364-5e78-b55e-fb5429807a47	bc1ce6aa-f011-56ab-9e10-492c111f50ba	f04245fa-9e0e-5905-80fa-524e9f1e172f	2026-07-23	01:15:00	Discovery workshop — Delivery Operations Hub	2026-07-23 09:01:00+00	2026-07-23 09:01:00+00	\N	DOH-171	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
2be76c0a-a489-57dd-afcc-b473836497c2	62445afe-3364-5e78-b55e-fb5429807a47	bc1ce6aa-f011-56ab-9e10-492c111f50ba	f04245fa-9e0e-5905-80fa-524e9f1e172f	2026-07-24	01:45:00	Discovery workshop — Delivery Operations Hub	2026-07-24 09:01:00+00	2026-07-24 09:01:00+00	\N	DOH-117	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
840825ca-e6ea-56bb-a6a5-6a0fd0d8aa25	62445afe-3364-5e78-b55e-fb5429807a47	bc1ce6aa-f011-56ab-9e10-492c111f50ba	f04245fa-9e0e-5905-80fa-524e9f1e172f	2026-07-26	03:15:00	Discovery workshop — Delivery Operations Hub	2026-07-26 09:01:00+00	2026-07-26 09:01:00+00	\N	DOH-145	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
65a333fc-1edd-5edd-8622-7d35047fd63b	62445afe-3364-5e78-b55e-fb5429807a47	bc1ce6aa-f011-56ab-9e10-492c111f50ba	f04245fa-9e0e-5905-80fa-524e9f1e172f	2026-07-27	03:45:00	Discovery workshop — Delivery Operations Hub	2026-07-27 09:01:00+00	2026-07-27 09:01:00+00	\N	DOH-164	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
d1032247-25ba-52d7-9e99-fcc0574e3e4c	62445afe-3364-5e78-b55e-fb5429807a47	bc1ce6aa-f011-56ab-9e10-492c111f50ba	f04245fa-9e0e-5905-80fa-524e9f1e172f	2026-07-29	01:45:00	Discovery workshop — Delivery Operations Hub	2026-07-29 09:01:00+00	2026-07-29 09:01:00+00	\N	DOH-138	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
0330cc67-51c0-5df2-a640-f835f8cabc24	62445afe-3364-5e78-b55e-fb5429807a47	bc1ce6aa-f011-56ab-9e10-492c111f50ba	f04245fa-9e0e-5905-80fa-524e9f1e172f	2026-07-31	03:45:00	Discovery workshop — Delivery Operations Hub	2026-07-31 09:01:00+00	2026-07-31 09:01:00+00	\N	DOH-112	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
235b6669-349a-5f61-ad11-7695276b521e	62445afe-3364-5e78-b55e-fb5429807a47	bc1ce6aa-f011-56ab-9e10-492c111f50ba	f04245fa-9e0e-5905-80fa-524e9f1e172f	2026-08-04	01:45:00	Discovery workshop — Delivery Operations Hub	2026-08-04 09:01:00+00	2026-08-04 09:01:00+00	\N	DOH-159	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
d20c047c-b3fc-5c45-8643-14d08f342fc3	62445afe-3364-5e78-b55e-fb5429807a47	bc1ce6aa-f011-56ab-9e10-492c111f50ba	f04245fa-9e0e-5905-80fa-524e9f1e172f	2026-08-06	03:45:00	Discovery workshop — Delivery Operations Hub	2026-08-06 09:01:00+00	2026-08-06 09:01:00+00	\N	DOH-133	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
caa1c7ce-ee57-5529-84f8-5efe64c5eac4	62445afe-3364-5e78-b55e-fb5429807a47	bc1ce6aa-f011-56ab-9e10-492c111f50ba	f04245fa-9e0e-5905-80fa-524e9f1e172f	2026-08-09	01:45:00	Discovery workshop — Delivery Operations Hub	2026-08-09 09:01:00+00	2026-08-09 09:01:00+00	\N	DOH-107	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
46a18041-39d7-53c6-a1fe-f365c73437a5	62445afe-3364-5e78-b55e-fb5429807a47	bc1ce6aa-f011-56ab-9e10-492c111f50ba	f04245fa-9e0e-5905-80fa-524e9f1e172f	2026-08-11	03:45:00	Discovery workshop — Delivery Operations Hub	2026-08-11 09:01:00+00	2026-08-11 09:01:00+00	\N	DOH-154	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
5b65a02f-7dc2-5be9-a0a8-589914e76edc	62445afe-3364-5e78-b55e-fb5429807a47	e5222c33-013c-5ba6-9bcb-a11c7a43cbf0	f07ee933-bae1-5f0f-9e95-6c303aba6f5d	2026-05-20	04:00:00	Client sync — Open Banking Integration	2026-05-20 09:01:00+00	2026-05-20 09:01:00+00	\N	OBI-125	f4c5b0e8-5503-5a50-8487-4ae103b885f2	Active	Worklog
db58c618-e958-5e77-b6e8-bc6a2f6ee7e2	62445afe-3364-5e78-b55e-fb5429807a47	e5222c33-013c-5ba6-9bcb-a11c7a43cbf0	6dfe9630-59ce-507d-81a0-2f94cb54247f	2026-05-21	01:30:00	Client sync — Fleet Companion	2026-05-21 09:01:00+00	2026-05-21 09:01:00+00	\N	FC-153	eba17d28-b076-534c-918a-dca0a5be8fab	Active	Worklog
ec7d1e24-bf30-547b-b410-30943904d673	62445afe-3364-5e78-b55e-fb5429807a47	e5222c33-013c-5ba6-9bcb-a11c7a43cbf0	04500693-9e94-55cd-a8ad-c3627d2dac80	2026-05-22	02:00:00	Client sync — Commerce Growth	2026-05-22 09:01:00+00	2026-05-22 09:01:00+00	\N	CG-172	e7e99ce4-232e-5ade-abb1-0966c94d952e	Active	Worklog
814a967d-2d1b-5434-b179-8af32aa8b8e5	62445afe-3364-5e78-b55e-fb5429807a47	e5222c33-013c-5ba6-9bcb-a11c7a43cbf0	f07ee933-bae1-5f0f-9e95-6c303aba6f5d	2026-05-25	03:30:00	Client sync — Open Banking Integration	2026-05-25 09:01:00+00	2026-05-25 09:01:00+00	\N	OBI-127	f4c5b0e8-5503-5a50-8487-4ae103b885f2	Active	Worklog
9c396d59-7b7c-55d3-81ab-82cecdd9e364	62445afe-3364-5e78-b55e-fb5429807a47	e5222c33-013c-5ba6-9bcb-a11c7a43cbf0	6dfe9630-59ce-507d-81a0-2f94cb54247f	2026-05-26	04:00:00	Client sync — Fleet Companion	2026-05-26 09:01:00+00	2026-05-26 09:01:00+00	\N	FC-146	eba17d28-b076-534c-918a-dca0a5be8fab	Active	Worklog
e6762188-0ee8-53d1-9a72-a2173b93f868	62445afe-3364-5e78-b55e-fb5429807a47	e5222c33-013c-5ba6-9bcb-a11c7a43cbf0	f07ee933-bae1-5f0f-9e95-6c303aba6f5d	2026-05-28	02:00:00	Client sync — Open Banking Integration	2026-05-28 09:01:00+00	2026-05-28 09:01:00+00	\N	OBI-120	f4c5b0e8-5503-5a50-8487-4ae103b885f2	Active	Worklog
ececb072-354c-50b8-b603-70d8c6f8c7b4	62445afe-3364-5e78-b55e-fb5429807a47	e5222c33-013c-5ba6-9bcb-a11c7a43cbf0	04500693-9e94-55cd-a8ad-c3627d2dac80	2026-05-31	04:00:00	Client sync — Commerce Growth	2026-05-31 09:01:00+00	2026-05-31 09:01:00+00	\N	CG-167	e7e99ce4-232e-5ade-abb1-0966c94d952e	Active	Worklog
3bc726d0-b404-5c48-8fd0-8846dd1dc6fc	62445afe-3364-5e78-b55e-fb5429807a47	e5222c33-013c-5ba6-9bcb-a11c7a43cbf0	6dfe9630-59ce-507d-81a0-2f94cb54247f	2026-06-02	02:00:00	Client sync — Fleet Companion	2026-06-02 09:01:00+00	2026-06-02 09:01:00+00	\N	FC-141	eba17d28-b076-534c-918a-dca0a5be8fab	Active	Worklog
3142c819-7766-59f4-bb9a-83488a75bb32	62445afe-3364-5e78-b55e-fb5429807a47	e5222c33-013c-5ba6-9bcb-a11c7a43cbf0	6dfe9630-59ce-507d-81a0-2f94cb54247f	2026-06-03	00:00:00	Decyzja zakresowa potwierdzona z zespołem — Fleet Companion	2026-06-03 09:01:00+00	2026-06-03 09:01:00+00	\N	\N	eba17d28-b076-534c-918a-dca0a5be8fab	Active	Note
6910740f-13a7-507c-99ce-08fd6a41c252	62445afe-3364-5e78-b55e-fb5429807a47	e5222c33-013c-5ba6-9bcb-a11c7a43cbf0	f07ee933-bae1-5f0f-9e95-6c303aba6f5d	2026-06-04	04:00:00	Client sync — Open Banking Integration	2026-06-04 09:01:00+00	2026-06-04 09:01:00+00	\N	OBI-115	f4c5b0e8-5503-5a50-8487-4ae103b885f2	Active	Worklog
5fb92d83-4c8e-5fda-98fd-c5c00388815f	62445afe-3364-5e78-b55e-fb5429807a47	e5222c33-013c-5ba6-9bcb-a11c7a43cbf0	04500693-9e94-55cd-a8ad-c3627d2dac80	2026-06-08	02:00:00	Client sync — Commerce Growth	2026-06-08 09:01:00+00	2026-06-08 09:01:00+00	\N	CG-162	e7e99ce4-232e-5ade-abb1-0966c94d952e	Active	Worklog
255452be-d525-5ee5-9185-52538d523e82	62445afe-3364-5e78-b55e-fb5429807a47	e5222c33-013c-5ba6-9bcb-a11c7a43cbf0	6dfe9630-59ce-507d-81a0-2f94cb54247f	2026-06-10	04:00:00	Client sync — Fleet Companion	2026-06-10 09:01:00+00	2026-06-10 09:01:00+00	\N	FC-136	eba17d28-b076-534c-918a-dca0a5be8fab	Active	Worklog
5a6028f6-938d-51f8-9529-6bd4ed92e0e4	62445afe-3364-5e78-b55e-fb5429807a47	e5222c33-013c-5ba6-9bcb-a11c7a43cbf0	04500693-9e94-55cd-a8ad-c3627d2dac80	2026-06-11	00:30:00	Client sync — Commerce Growth	2026-06-11 09:01:00+00	2026-06-11 09:01:00+00	\N	CG-155	e7e99ce4-232e-5ade-abb1-0966c94d952e	Active	Worklog
5d791c46-0557-555c-9ee6-47185c7a43b0	62445afe-3364-5e78-b55e-fb5429807a47	e5222c33-013c-5ba6-9bcb-a11c7a43cbf0	f07ee933-bae1-5f0f-9e95-6c303aba6f5d	2026-06-12	02:00:00	Client sync — Open Banking Integration	2026-06-12 09:01:00+00	2026-06-12 09:01:00+00	\N	OBI-110	f4c5b0e8-5503-5a50-8487-4ae103b885f2	Active	Worklog
1974cffa-e8c0-5f77-92e5-7599aae43d3d	62445afe-3364-5e78-b55e-fb5429807a47	e5222c33-013c-5ba6-9bcb-a11c7a43cbf0	6dfe9630-59ce-507d-81a0-2f94cb54247f	2026-06-14	02:30:00	Client sync — Fleet Companion	2026-06-14 09:01:00+00	2026-06-14 09:01:00+00	\N	FC-129	eba17d28-b076-534c-918a-dca0a5be8fab	Active	Worklog
95116cb5-b113-5e34-9ba4-06024dfdb547	62445afe-3364-5e78-b55e-fb5429807a47	e5222c33-013c-5ba6-9bcb-a11c7a43cbf0	f07ee933-bae1-5f0f-9e95-6c303aba6f5d	2026-06-16	00:30:00	Client sync — Open Banking Integration	2026-06-16 09:01:00+00	2026-06-16 09:01:00+00	\N	OBI-103	f4c5b0e8-5503-5a50-8487-4ae103b885f2	Active	Worklog
6f664cd4-2de8-511f-8b5a-32c9dbb34673	62445afe-3364-5e78-b55e-fb5429807a47	e5222c33-013c-5ba6-9bcb-a11c7a43cbf0	04500693-9e94-55cd-a8ad-c3627d2dac80	2026-06-18	02:30:00	Client sync — Commerce Growth	2026-06-18 09:01:00+00	2026-06-18 09:01:00+00	\N	CG-150	e7e99ce4-232e-5ade-abb1-0966c94d952e	Active	Worklog
9e2a485b-ca49-57c7-ba1f-7d445640c9a0	62445afe-3364-5e78-b55e-fb5429807a47	e5222c33-013c-5ba6-9bcb-a11c7a43cbf0	6dfe9630-59ce-507d-81a0-2f94cb54247f	2026-06-22	00:30:00	Client sync — Fleet Companion	2026-06-22 09:01:00+00	2026-06-22 09:01:00+00	\N	FC-124	eba17d28-b076-534c-918a-dca0a5be8fab	Active	Worklog
f9d9067c-4d39-520c-8130-53c3ae9eb8f4	62445afe-3364-5e78-b55e-fb5429807a47	e5222c33-013c-5ba6-9bcb-a11c7a43cbf0	f07ee933-bae1-5f0f-9e95-6c303aba6f5d	2026-06-24	02:30:00	Client sync — Open Banking Integration	2026-06-24 09:01:00+00	2026-06-24 09:01:00+00	\N	OBI-171	f4c5b0e8-5503-5a50-8487-4ae103b885f2	Active	Worklog
2e33ffb1-f3d1-54d0-8ac9-b61561d8edff	62445afe-3364-5e78-b55e-fb5429807a47	e5222c33-013c-5ba6-9bcb-a11c7a43cbf0	f07ee933-bae1-5f0f-9e95-6c303aba6f5d	2026-06-25	00:00:00	Decyzja zakresowa potwierdzona z zespołem — Open Banking Integration	2026-06-25 09:01:00+00	2026-06-25 09:01:00+00	\N	\N	f4c5b0e8-5503-5a50-8487-4ae103b885f2	Active	Note
f34c80fd-b52f-527c-b80b-cfa26d37b98f	62445afe-3364-5e78-b55e-fb5429807a47	e5222c33-013c-5ba6-9bcb-a11c7a43cbf0	04500693-9e94-55cd-a8ad-c3627d2dac80	2026-06-26	00:30:00	Client sync — Commerce Growth	2026-06-26 09:01:00+00	2026-06-26 09:01:00+00	\N	CG-145	e7e99ce4-232e-5ade-abb1-0966c94d952e	Active	Worklog
f7af3ca0-9530-551c-aed2-d6d3120f9f2c	62445afe-3364-5e78-b55e-fb5429807a47	e5222c33-013c-5ba6-9bcb-a11c7a43cbf0	6dfe9630-59ce-507d-81a0-2f94cb54247f	2026-06-29	02:30:00	Client sync — Fleet Companion	2026-06-29 09:01:00+00	2026-06-29 09:01:00+00	\N	FC-119	eba17d28-b076-534c-918a-dca0a5be8fab	Active	Worklog
5a460f83-b0cb-5e53-a0c0-865c5edc7db7	62445afe-3364-5e78-b55e-fb5429807a47	e5222c33-013c-5ba6-9bcb-a11c7a43cbf0	f07ee933-bae1-5f0f-9e95-6c303aba6f5d	2026-07-01	00:30:00	Client sync — Open Banking Integration	2026-07-01 09:01:00+00	2026-07-01 09:01:00+00	\N	OBI-166	f4c5b0e8-5503-5a50-8487-4ae103b885f2	Active	Worklog
f1c668a6-f36a-5509-8365-7b022235b7b6	62445afe-3364-5e78-b55e-fb5429807a47	e5222c33-013c-5ba6-9bcb-a11c7a43cbf0	6dfe9630-59ce-507d-81a0-2f94cb54247f	2026-07-02	01:00:00	Client sync — Fleet Companion	2026-07-02 09:01:00+00	2026-07-02 09:01:00+00	\N	FC-112	eba17d28-b076-534c-918a-dca0a5be8fab	Active	Worklog
0e0e4baa-7fe3-5c90-954f-11a349276e4c	62445afe-3364-5e78-b55e-fb5429807a47	e5222c33-013c-5ba6-9bcb-a11c7a43cbf0	04500693-9e94-55cd-a8ad-c3627d2dac80	2026-07-03	02:30:00	Client sync — Commerce Growth	2026-07-03 09:01:00+00	2026-07-03 09:01:00+00	\N	CG-140	e7e99ce4-232e-5ade-abb1-0966c94d952e	Active	Worklog
7f5c2d94-0ae8-52c2-83e1-7c9b8c2e6057	62445afe-3364-5e78-b55e-fb5429807a47	e5222c33-013c-5ba6-9bcb-a11c7a43cbf0	f07ee933-bae1-5f0f-9e95-6c303aba6f5d	2026-07-06	03:00:00	Client sync — Open Banking Integration	2026-07-06 09:01:00+00	2026-07-06 09:01:00+00	\N	OBI-159	f4c5b0e8-5503-5a50-8487-4ae103b885f2	Active	Worklog
6e186c5b-fd78-56e8-b784-f92b15e1e989	62445afe-3364-5e78-b55e-fb5429807a47	e5222c33-013c-5ba6-9bcb-a11c7a43cbf0	04500693-9e94-55cd-a8ad-c3627d2dac80	2026-07-08	01:00:00	Client sync — Commerce Growth	2026-07-08 09:01:00+00	2026-07-08 09:01:00+00	\N	CG-133	e7e99ce4-232e-5ade-abb1-0966c94d952e	Active	Worklog
34374aaa-6da6-5368-a9f6-0eab78c4a9ca	62445afe-3364-5e78-b55e-fb5429807a47	e5222c33-013c-5ba6-9bcb-a11c7a43cbf0	6dfe9630-59ce-507d-81a0-2f94cb54247f	2026-07-10	03:00:00	Client sync — Fleet Companion	2026-07-10 09:01:00+00	2026-07-10 09:01:00+00	\N	FC-107	eba17d28-b076-534c-918a-dca0a5be8fab	Active	Worklog
1d5bf64b-63b1-57a9-b57d-50ca5d1d9148	62445afe-3364-5e78-b55e-fb5429807a47	e5222c33-013c-5ba6-9bcb-a11c7a43cbf0	f07ee933-bae1-5f0f-9e95-6c303aba6f5d	2026-07-13	01:00:00	Client sync — Open Banking Integration	2026-07-13 09:01:00+00	2026-07-13 09:01:00+00	\N	OBI-154	f4c5b0e8-5503-5a50-8487-4ae103b885f2	Active	Worklog
c88e6e34-d7a9-5380-b73f-e535c341f0d0	62445afe-3364-5e78-b55e-fb5429807a47	e5222c33-013c-5ba6-9bcb-a11c7a43cbf0	04500693-9e94-55cd-a8ad-c3627d2dac80	2026-07-15	03:00:00	Client sync — Commerce Growth	2026-07-15 09:01:00+00	2026-07-15 09:01:00+00	\N	CG-128	e7e99ce4-232e-5ade-abb1-0966c94d952e	Active	Worklog
a920af00-66e0-5a74-8842-65bc2fb008c9	62445afe-3364-5e78-b55e-fb5429807a47	e5222c33-013c-5ba6-9bcb-a11c7a43cbf0	04500693-9e94-55cd-a8ad-c3627d2dac80	2026-07-16	00:00:00	Decyzja zakresowa potwierdzona z zespołem — Commerce Growth	2026-07-16 09:01:00+00	2026-07-16 09:01:00+00	\N	\N	e7e99ce4-232e-5ade-abb1-0966c94d952e	Active	Note
607e5959-ed64-5089-a153-dbc899bb312d	62445afe-3364-5e78-b55e-fb5429807a47	e5222c33-013c-5ba6-9bcb-a11c7a43cbf0	6dfe9630-59ce-507d-81a0-2f94cb54247f	2026-07-17	01:00:00	Client sync — Fleet Companion	2026-07-17 09:01:00+00	2026-07-17 09:01:00+00	\N	FC-102	eba17d28-b076-534c-918a-dca0a5be8fab	Active	Worklog
1116d1ba-2230-56b1-8d68-3dc58afd58fc	62445afe-3364-5e78-b55e-fb5429807a47	e5222c33-013c-5ba6-9bcb-a11c7a43cbf0	f07ee933-bae1-5f0f-9e95-6c303aba6f5d	2026-07-21	03:00:00	Client sync — Open Banking Integration	2026-07-21 09:01:00+00	2026-07-21 09:01:00+00	\N	OBI-149	f4c5b0e8-5503-5a50-8487-4ae103b885f2	Active	Worklog
18659939-b3f4-59cf-adae-9a871959075c	62445afe-3364-5e78-b55e-fb5429807a47	e5222c33-013c-5ba6-9bcb-a11c7a43cbf0	04500693-9e94-55cd-a8ad-c3627d2dac80	2026-07-23	01:00:00	Client sync — Commerce Growth	2026-07-23 09:01:00+00	2026-07-23 09:01:00+00	\N	CG-123	e7e99ce4-232e-5ade-abb1-0966c94d952e	Active	Worklog
a7557062-437f-5399-b51b-4f0dffeddb29	62445afe-3364-5e78-b55e-fb5429807a47	e5222c33-013c-5ba6-9bcb-a11c7a43cbf0	f07ee933-bae1-5f0f-9e95-6c303aba6f5d	2026-07-24	01:30:00	Client sync — Open Banking Integration	2026-07-24 09:01:00+00	2026-07-24 09:01:00+00	\N	OBI-142	f4c5b0e8-5503-5a50-8487-4ae103b885f2	Active	Worklog
f2dfe398-2ac0-5fd0-adc3-8ed2d318ac3e	62445afe-3364-5e78-b55e-fb5429807a47	e5222c33-013c-5ba6-9bcb-a11c7a43cbf0	6dfe9630-59ce-507d-81a0-2f94cb54247f	2026-07-26	03:00:00	Client sync — Fleet Companion	2026-07-26 09:01:00+00	2026-07-26 09:01:00+00	\N	FC-170	eba17d28-b076-534c-918a-dca0a5be8fab	Active	Worklog
e7e73e79-f8a6-5507-8ccd-893f1c094598	62445afe-3364-5e78-b55e-fb5429807a47	e5222c33-013c-5ba6-9bcb-a11c7a43cbf0	04500693-9e94-55cd-a8ad-c3627d2dac80	2026-07-27	03:30:00	Client sync — Commerce Growth	2026-07-27 09:01:00+00	2026-07-27 09:01:00+00	\N	CG-116	e7e99ce4-232e-5ade-abb1-0966c94d952e	Active	Worklog
7269296c-f6aa-51ab-acc3-ce98b2b087c2	62445afe-3364-5e78-b55e-fb5429807a47	e5222c33-013c-5ba6-9bcb-a11c7a43cbf0	6dfe9630-59ce-507d-81a0-2f94cb54247f	2026-07-29	01:30:00	Client sync — Fleet Companion	2026-07-29 09:01:00+00	2026-07-29 09:01:00+00	\N	FC-163	eba17d28-b076-534c-918a-dca0a5be8fab	Active	Worklog
f920b8c6-befc-5f48-b1a6-3f6268808cd9	62445afe-3364-5e78-b55e-fb5429807a47	e5222c33-013c-5ba6-9bcb-a11c7a43cbf0	f07ee933-bae1-5f0f-9e95-6c303aba6f5d	2026-07-31	03:30:00	Client sync — Open Banking Integration	2026-07-31 09:01:00+00	2026-07-31 09:01:00+00	\N	OBI-137	f4c5b0e8-5503-5a50-8487-4ae103b885f2	Active	Worklog
8c0f1a14-5da3-55a0-b124-659f7a0e999f	62445afe-3364-5e78-b55e-fb5429807a47	e5222c33-013c-5ba6-9bcb-a11c7a43cbf0	04500693-9e94-55cd-a8ad-c3627d2dac80	2026-08-04	01:30:00	Client sync — Commerce Growth	2026-08-04 09:01:00+00	2026-08-04 09:01:00+00	\N	CG-111	e7e99ce4-232e-5ade-abb1-0966c94d952e	Active	Worklog
6e1b5c60-4007-5e1b-ab5d-c6d33502af58	62445afe-3364-5e78-b55e-fb5429807a47	e5222c33-013c-5ba6-9bcb-a11c7a43cbf0	6dfe9630-59ce-507d-81a0-2f94cb54247f	2026-08-06	03:30:00	Client sync — Fleet Companion	2026-08-06 09:01:00+00	2026-08-06 09:01:00+00	\N	FC-158	eba17d28-b076-534c-918a-dca0a5be8fab	Active	Worklog
a3813455-2652-5977-9ac4-ffa429f1e174	62445afe-3364-5e78-b55e-fb5429807a47	e5222c33-013c-5ba6-9bcb-a11c7a43cbf0	f07ee933-bae1-5f0f-9e95-6c303aba6f5d	2026-08-09	01:30:00	Client sync — Open Banking Integration	2026-08-09 09:01:00+00	2026-08-09 09:01:00+00	\N	OBI-132	f4c5b0e8-5503-5a50-8487-4ae103b885f2	Active	Worklog
d99e1e55-6258-555d-831b-2a1ea9dddbff	62445afe-3364-5e78-b55e-fb5429807a47	e5222c33-013c-5ba6-9bcb-a11c7a43cbf0	04500693-9e94-55cd-a8ad-c3627d2dac80	2026-08-11	03:30:00	Client sync — Commerce Growth	2026-08-11 09:01:00+00	2026-08-11 09:01:00+00	\N	CG-106	e7e99ce4-232e-5ade-abb1-0966c94d952e	Active	Worklog
0308cf64-56be-541a-9b09-08cb830fbd14	62445afe-3364-5e78-b55e-fb5429807a47	36904740-e579-521d-8461-726ccb5f1806	1146e928-4d82-581f-84f2-b8c9b6c83378	2026-05-20	00:45:00	Data analysis — Learning Experience	2026-05-20 09:01:00+00	2026-05-20 09:01:00+00	\N	LE-114	a9e0bb14-488c-5643-96ca-5848796322a3	Active	Worklog
b7802883-fba8-535c-95ac-dfe52dab6546	62445afe-3364-5e78-b55e-fb5429807a47	36904740-e579-521d-8461-726ccb5f1806	9406b74a-6b7a-578b-8fbd-958684d93780	2026-05-21	02:15:00	Data analysis — Patient Portal	2026-05-21 09:01:00+00	2026-05-21 09:01:00+00	\N	PP-142	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
f92521fe-ca7f-5a92-b97c-367d6f45c139	62445afe-3364-5e78-b55e-fb5429807a47	36904740-e579-521d-8461-726ccb5f1806	eb73aa6c-87aa-532d-8b94-109b8b863733	2026-05-22	02:45:00	Data analysis — Design System Evolution	2026-05-22 09:01:00+00	2026-05-22 09:01:00+00	\N	DSE-161	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
8889922b-3a7d-5fd9-ac26-f5139dc0a440	62445afe-3364-5e78-b55e-fb5429807a47	36904740-e579-521d-8461-726ccb5f1806	1146e928-4d82-581f-84f2-b8c9b6c83378	2026-05-25	00:15:00	Data analysis — Learning Experience	2026-05-25 09:01:00+00	2026-05-25 09:01:00+00	\N	LE-116	a9e0bb14-488c-5643-96ca-5848796322a3	Active	Worklog
ab728442-e66b-59d1-94e2-66c542c8af06	62445afe-3364-5e78-b55e-fb5429807a47	36904740-e579-521d-8461-726ccb5f1806	9406b74a-6b7a-578b-8fbd-958684d93780	2026-05-26	00:45:00	Data analysis — Patient Portal	2026-05-26 09:01:00+00	2026-05-26 09:01:00+00	\N	PP-135	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
d2757493-a4a9-5e67-a0fc-1507ea45221b	62445afe-3364-5e78-b55e-fb5429807a47	36904740-e579-521d-8461-726ccb5f1806	1146e928-4d82-581f-84f2-b8c9b6c83378	2026-05-28	02:45:00	Data analysis — Learning Experience	2026-05-28 09:01:00+00	2026-05-28 09:01:00+00	\N	LE-109	a9e0bb14-488c-5643-96ca-5848796322a3	Active	Worklog
6f6fb5ef-df2b-5b32-9d2d-c6a5b1b0a59f	62445afe-3364-5e78-b55e-fb5429807a47	36904740-e579-521d-8461-726ccb5f1806	eb73aa6c-87aa-532d-8b94-109b8b863733	2026-05-31	00:45:00	Data analysis — Design System Evolution	2026-05-31 09:01:00+00	2026-05-31 09:01:00+00	\N	DSE-156	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
85155734-c349-5ac5-8b26-5d29e3761155	62445afe-3364-5e78-b55e-fb5429807a47	36904740-e579-521d-8461-726ccb5f1806	9406b74a-6b7a-578b-8fbd-958684d93780	2026-06-02	02:45:00	Data analysis — Patient Portal	2026-06-02 09:01:00+00	2026-06-02 09:01:00+00	\N	PP-130	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
9d939a48-adbb-53b9-a967-24703403d97e	62445afe-3364-5e78-b55e-fb5429807a47	36904740-e579-521d-8461-726ccb5f1806	9406b74a-6b7a-578b-8fbd-958684d93780	2026-06-03	00:00:00	Blocker integracji wymaga odpowiedzi partnera — Patient Portal	2026-06-03 09:01:00+00	2026-06-03 09:01:00+00	\N	\N	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Note
db04129f-2e44-5e51-a95b-524ff1d8d02c	62445afe-3364-5e78-b55e-fb5429807a47	36904740-e579-521d-8461-726ccb5f1806	1146e928-4d82-581f-84f2-b8c9b6c83378	2026-06-04	00:45:00	Data analysis — Learning Experience	2026-06-04 09:01:00+00	2026-06-04 09:01:00+00	\N	LE-104	a9e0bb14-488c-5643-96ca-5848796322a3	Active	Worklog
133a015c-1ede-55b5-b983-19b4716a4827	62445afe-3364-5e78-b55e-fb5429807a47	36904740-e579-521d-8461-726ccb5f1806	eb73aa6c-87aa-532d-8b94-109b8b863733	2026-06-08	02:45:00	Data analysis — Design System Evolution	2026-06-08 09:01:00+00	2026-06-08 09:01:00+00	\N	DSE-151	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
f09ba647-7332-504b-84f4-08af4e458393	62445afe-3364-5e78-b55e-fb5429807a47	36904740-e579-521d-8461-726ccb5f1806	9406b74a-6b7a-578b-8fbd-958684d93780	2026-06-10	00:45:00	Data analysis — Patient Portal	2026-06-10 09:01:00+00	2026-06-10 09:01:00+00	\N	PP-125	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
349b960b-1ac2-581c-af85-17d38ca1d7c2	62445afe-3364-5e78-b55e-fb5429807a47	36904740-e579-521d-8461-726ccb5f1806	eb73aa6c-87aa-532d-8b94-109b8b863733	2026-06-11	01:15:00	Data analysis — Design System Evolution	2026-06-11 09:01:00+00	2026-06-11 09:01:00+00	\N	DSE-144	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
81f50e94-39fd-563e-92d2-45ee755f710a	62445afe-3364-5e78-b55e-fb5429807a47	36904740-e579-521d-8461-726ccb5f1806	1146e928-4d82-581f-84f2-b8c9b6c83378	2026-06-12	02:45:00	Data analysis — Learning Experience	2026-06-12 09:01:00+00	2026-06-12 09:01:00+00	\N	LE-172	a9e0bb14-488c-5643-96ca-5848796322a3	Active	Worklog
0a045aff-1b77-5d64-821e-6c7ca2048dd4	62445afe-3364-5e78-b55e-fb5429807a47	36904740-e579-521d-8461-726ccb5f1806	9406b74a-6b7a-578b-8fbd-958684d93780	2026-06-14	03:15:00	Data analysis — Patient Portal	2026-06-14 09:01:00+00	2026-06-14 09:01:00+00	\N	PP-118	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
815b84d2-e007-5628-948f-a00b5c6c9faa	62445afe-3364-5e78-b55e-fb5429807a47	36904740-e579-521d-8461-726ccb5f1806	1146e928-4d82-581f-84f2-b8c9b6c83378	2026-06-16	01:15:00	Data analysis — Learning Experience	2026-06-16 09:01:00+00	2026-06-16 09:01:00+00	\N	LE-165	a9e0bb14-488c-5643-96ca-5848796322a3	Active	Worklog
dd76d4c3-1c39-526b-ab47-b988b4eeb4d0	62445afe-3364-5e78-b55e-fb5429807a47	36904740-e579-521d-8461-726ccb5f1806	eb73aa6c-87aa-532d-8b94-109b8b863733	2026-06-18	03:15:00	Data analysis — Design System Evolution	2026-06-18 09:01:00+00	2026-06-18 09:01:00+00	\N	DSE-139	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
252a6ef4-d912-577c-8030-decbcba06e78	62445afe-3364-5e78-b55e-fb5429807a47	36904740-e579-521d-8461-726ccb5f1806	9406b74a-6b7a-578b-8fbd-958684d93780	2026-06-22	01:15:00	Data analysis — Patient Portal	2026-06-22 09:01:00+00	2026-06-22 09:01:00+00	\N	PP-113	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
d6ce3e82-734e-54f2-9269-d7d759f26d1b	62445afe-3364-5e78-b55e-fb5429807a47	36904740-e579-521d-8461-726ccb5f1806	1146e928-4d82-581f-84f2-b8c9b6c83378	2026-06-24	03:15:00	Data analysis — Learning Experience	2026-06-24 09:01:00+00	2026-06-24 09:01:00+00	\N	LE-160	a9e0bb14-488c-5643-96ca-5848796322a3	Active	Worklog
59a6b123-587f-5bf5-84ba-1bc7b5c7f5e8	62445afe-3364-5e78-b55e-fb5429807a47	36904740-e579-521d-8461-726ccb5f1806	1146e928-4d82-581f-84f2-b8c9b6c83378	2026-06-25	00:00:00	Blocker integracji wymaga odpowiedzi partnera — Learning Experience	2026-06-25 09:01:00+00	2026-06-25 09:01:00+00	\N	\N	a9e0bb14-488c-5643-96ca-5848796322a3	Active	Note
71eb0ea9-a770-5dbf-b20d-9f28a7785b88	62445afe-3364-5e78-b55e-fb5429807a47	36904740-e579-521d-8461-726ccb5f1806	eb73aa6c-87aa-532d-8b94-109b8b863733	2026-06-26	01:15:00	Data analysis — Design System Evolution	2026-06-26 09:01:00+00	2026-06-26 09:01:00+00	\N	DSE-134	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
794b002e-2e16-597d-8bd3-8a881b071249	62445afe-3364-5e78-b55e-fb5429807a47	36904740-e579-521d-8461-726ccb5f1806	613fe369-ab85-5812-9136-0d147b91706d	2026-06-28	00:45:00	Historical delivery wrap-up — Mobility Discovery	2026-06-28 09:01:00+00	2026-06-28 09:01:00+00	2026-07-13 00:00:00+00	MD-930	eba17d28-b076-534c-918a-dca0a5be8fab	Archived	Worklog
03a56ccc-64cb-5c10-9d18-e3a15d178610	62445afe-3364-5e78-b55e-fb5429807a47	36904740-e579-521d-8461-726ccb5f1806	9406b74a-6b7a-578b-8fbd-958684d93780	2026-06-29	03:15:00	Data analysis — Patient Portal	2026-06-29 09:01:00+00	2026-06-29 09:01:00+00	\N	PP-108	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
46c3a6a6-4268-5860-a4d7-abbb5b2668be	62445afe-3364-5e78-b55e-fb5429807a47	36904740-e579-521d-8461-726ccb5f1806	1146e928-4d82-581f-84f2-b8c9b6c83378	2026-07-01	01:15:00	Data analysis — Learning Experience	2026-07-01 09:01:00+00	2026-07-01 09:01:00+00	\N	LE-155	a9e0bb14-488c-5643-96ca-5848796322a3	Active	Worklog
9e663b58-6a82-517d-86e0-c0984b04a8b9	62445afe-3364-5e78-b55e-fb5429807a47	36904740-e579-521d-8461-726ccb5f1806	613fe369-ab85-5812-9136-0d147b91706d	2026-07-01	03:45:00	Historical delivery wrap-up — Mobility Discovery	2026-07-01 09:02:00+00	2026-07-01 09:02:00+00	2026-07-13 00:00:00+00	MD-918	eba17d28-b076-534c-918a-dca0a5be8fab	Archived	Worklog
70a50d3e-703a-59e7-bbe1-f1f2561626d9	62445afe-3364-5e78-b55e-fb5429807a47	36904740-e579-521d-8461-726ccb5f1806	9406b74a-6b7a-578b-8fbd-958684d93780	2026-07-02	01:45:00	Data analysis — Patient Portal	2026-07-02 09:01:00+00	2026-07-02 09:01:00+00	\N	PP-101	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
a8c13462-3f3b-53b9-9552-9c9b633957b1	62445afe-3364-5e78-b55e-fb5429807a47	36904740-e579-521d-8461-726ccb5f1806	eb73aa6c-87aa-532d-8b94-109b8b863733	2026-07-03	03:15:00	Data analysis — Design System Evolution	2026-07-03 09:01:00+00	2026-07-03 09:01:00+00	\N	DSE-129	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
ff03ef65-1b36-5cd6-b021-896784073a18	62445afe-3364-5e78-b55e-fb5429807a47	36904740-e579-521d-8461-726ccb5f1806	613fe369-ab85-5812-9136-0d147b91706d	2026-07-04	02:45:00	Historical delivery wrap-up — Mobility Discovery	2026-07-04 09:01:00+00	2026-07-04 09:01:00+00	2026-07-13 00:00:00+00	MD-906	eba17d28-b076-534c-918a-dca0a5be8fab	Archived	Worklog
b7f45c6c-bc22-58fd-b58d-54c8855fb741	62445afe-3364-5e78-b55e-fb5429807a47	36904740-e579-521d-8461-726ccb5f1806	1146e928-4d82-581f-84f2-b8c9b6c83378	2026-07-06	03:45:00	Data analysis — Learning Experience	2026-07-06 09:01:00+00	2026-07-06 09:01:00+00	\N	LE-148	a9e0bb14-488c-5643-96ca-5848796322a3	Active	Worklog
2e81a45b-798f-5afd-b395-27e652bd0674	62445afe-3364-5e78-b55e-fb5429807a47	36904740-e579-521d-8461-726ccb5f1806	613fe369-ab85-5812-9136-0d147b91706d	2026-07-07	02:45:00	Historical delivery wrap-up — Mobility Discovery	2026-07-07 09:01:00+00	2026-07-07 09:01:00+00	2026-07-13 00:00:00+00	MD-954	eba17d28-b076-534c-918a-dca0a5be8fab	Archived	Worklog
eca36fe3-393b-59eb-a859-9958bbaaf4a4	62445afe-3364-5e78-b55e-fb5429807a47	36904740-e579-521d-8461-726ccb5f1806	eb73aa6c-87aa-532d-8b94-109b8b863733	2026-07-08	01:45:00	Data analysis — Design System Evolution	2026-07-08 09:01:00+00	2026-07-08 09:01:00+00	\N	DSE-122	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
239ba15f-e2b9-582b-bd2e-5ef5e0fb2f3b	62445afe-3364-5e78-b55e-fb5429807a47	36904740-e579-521d-8461-726ccb5f1806	9406b74a-6b7a-578b-8fbd-958684d93780	2026-07-10	03:45:00	Data analysis — Patient Portal	2026-07-10 09:01:00+00	2026-07-10 09:01:00+00	\N	PP-169	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
2c23d868-492e-58e2-afe7-5fb2f76e2c33	62445afe-3364-5e78-b55e-fb5429807a47	36904740-e579-521d-8461-726ccb5f1806	613fe369-ab85-5812-9136-0d147b91706d	2026-07-10	01:45:00	Historical delivery wrap-up — Mobility Discovery	2026-07-10 09:02:00+00	2026-07-10 09:02:00+00	2026-07-13 00:00:00+00	MD-942	eba17d28-b076-534c-918a-dca0a5be8fab	Archived	Worklog
ca4eeb4a-f4c7-56dc-94d4-1c0e6d1e0adc	62445afe-3364-5e78-b55e-fb5429807a47	36904740-e579-521d-8461-726ccb5f1806	1146e928-4d82-581f-84f2-b8c9b6c83378	2026-07-13	01:45:00	Data analysis — Learning Experience	2026-07-13 09:01:00+00	2026-07-13 09:01:00+00	\N	LE-143	a9e0bb14-488c-5643-96ca-5848796322a3	Active	Worklog
a719ada6-5870-54a5-9203-e30647e58eef	62445afe-3364-5e78-b55e-fb5429807a47	36904740-e579-521d-8461-726ccb5f1806	eb73aa6c-87aa-532d-8b94-109b8b863733	2026-07-15	03:45:00	Data analysis — Design System Evolution	2026-07-15 09:01:00+00	2026-07-15 09:01:00+00	\N	DSE-117	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
bc979a70-8711-5d10-a76e-009740643185	62445afe-3364-5e78-b55e-fb5429807a47	36904740-e579-521d-8461-726ccb5f1806	eb73aa6c-87aa-532d-8b94-109b8b863733	2026-07-16	00:00:00	Blocker integracji wymaga odpowiedzi partnera — Design System Evolution	2026-07-16 09:01:00+00	2026-07-16 09:01:00+00	\N	\N	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Note
86107b2e-86c9-5d8d-b602-a0a1b81c870b	62445afe-3364-5e78-b55e-fb5429807a47	36904740-e579-521d-8461-726ccb5f1806	9406b74a-6b7a-578b-8fbd-958684d93780	2026-07-17	01:45:00	Data analysis — Patient Portal	2026-07-17 09:01:00+00	2026-07-17 09:01:00+00	\N	PP-164	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
3e41f7cf-bc16-5cfd-a712-dea3409f754b	62445afe-3364-5e78-b55e-fb5429807a47	36904740-e579-521d-8461-726ccb5f1806	1146e928-4d82-581f-84f2-b8c9b6c83378	2026-07-21	03:45:00	Data analysis — Learning Experience	2026-07-21 09:01:00+00	2026-07-21 09:01:00+00	\N	LE-138	a9e0bb14-488c-5643-96ca-5848796322a3	Active	Worklog
95588151-ec19-5ee9-9126-4b0e9f357708	62445afe-3364-5e78-b55e-fb5429807a47	36904740-e579-521d-8461-726ccb5f1806	eb73aa6c-87aa-532d-8b94-109b8b863733	2026-07-23	01:45:00	Data analysis — Design System Evolution	2026-07-23 09:01:00+00	2026-07-23 09:01:00+00	\N	DSE-112	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
da38b390-13d1-5cd4-8521-1b9673adac3f	62445afe-3364-5e78-b55e-fb5429807a47	36904740-e579-521d-8461-726ccb5f1806	1146e928-4d82-581f-84f2-b8c9b6c83378	2026-07-24	02:15:00	Data analysis — Learning Experience	2026-07-24 09:01:00+00	2026-07-24 09:01:00+00	\N	LE-131	a9e0bb14-488c-5643-96ca-5848796322a3	Active	Worklog
5219e042-bcff-5e8d-ab37-efb000c2367c	62445afe-3364-5e78-b55e-fb5429807a47	36904740-e579-521d-8461-726ccb5f1806	9406b74a-6b7a-578b-8fbd-958684d93780	2026-07-26	03:45:00	Data analysis — Patient Portal	2026-07-26 09:01:00+00	2026-07-26 09:01:00+00	\N	PP-159	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
ffe52fd8-8ecb-5969-b2fe-14f60389421c	62445afe-3364-5e78-b55e-fb5429807a47	36904740-e579-521d-8461-726ccb5f1806	eb73aa6c-87aa-532d-8b94-109b8b863733	2026-07-27	00:15:00	Data analysis — Design System Evolution	2026-07-27 09:01:00+00	2026-07-27 09:01:00+00	\N	DSE-105	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
6b1fb1a1-1131-5b41-83a8-851bea8a5585	62445afe-3364-5e78-b55e-fb5429807a47	36904740-e579-521d-8461-726ccb5f1806	9406b74a-6b7a-578b-8fbd-958684d93780	2026-07-29	02:15:00	Data analysis — Patient Portal	2026-07-29 09:01:00+00	2026-07-29 09:01:00+00	\N	PP-152	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
dd613aa9-1390-54a5-9d34-bf762cdd36d1	62445afe-3364-5e78-b55e-fb5429807a47	36904740-e579-521d-8461-726ccb5f1806	1146e928-4d82-581f-84f2-b8c9b6c83378	2026-07-31	00:15:00	Data analysis — Learning Experience	2026-07-31 09:01:00+00	2026-07-31 09:01:00+00	\N	LE-126	a9e0bb14-488c-5643-96ca-5848796322a3	Active	Worklog
ae19c1b5-b036-53e1-afec-a68d0f014525	62445afe-3364-5e78-b55e-fb5429807a47	36904740-e579-521d-8461-726ccb5f1806	eb73aa6c-87aa-532d-8b94-109b8b863733	2026-08-04	02:15:00	Data analysis — Design System Evolution	2026-08-04 09:01:00+00	2026-08-04 09:01:00+00	\N	DSE-100	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
60b43667-f84c-50e1-b88e-99977654e5ef	62445afe-3364-5e78-b55e-fb5429807a47	36904740-e579-521d-8461-726ccb5f1806	9406b74a-6b7a-578b-8fbd-958684d93780	2026-08-06	00:15:00	Data analysis — Patient Portal	2026-08-06 09:01:00+00	2026-08-06 09:01:00+00	\N	PP-147	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
c806d190-954c-533a-95f0-c92a73452c5a	62445afe-3364-5e78-b55e-fb5429807a47	36904740-e579-521d-8461-726ccb5f1806	9406b74a-6b7a-578b-8fbd-958684d93780	2026-08-07	00:00:00	Blocker integracji wymaga odpowiedzi partnera — Patient Portal	2026-08-07 09:01:00+00	2026-08-07 09:01:00+00	\N	\N	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Note
bf7df8c0-a280-5320-936c-44120186f769	62445afe-3364-5e78-b55e-fb5429807a47	36904740-e579-521d-8461-726ccb5f1806	1146e928-4d82-581f-84f2-b8c9b6c83378	2026-08-09	02:15:00	Data analysis — Learning Experience	2026-08-09 09:01:00+00	2026-08-09 09:01:00+00	\N	LE-121	a9e0bb14-488c-5643-96ca-5848796322a3	Active	Worklog
75f98a7a-1d8b-5456-9946-9772c42b9ad3	62445afe-3364-5e78-b55e-fb5429807a47	36904740-e579-521d-8461-726ccb5f1806	eb73aa6c-87aa-532d-8b94-109b8b863733	2026-08-11	00:15:00	Data analysis — Design System Evolution	2026-08-11 09:01:00+00	2026-08-11 09:01:00+00	\N	DSE-168	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
d8d3ad14-607b-547b-9f35-b2ce310bbde6	62445afe-3364-5e78-b55e-fb5429807a47	1f95823c-e9b9-5334-8f67-669822d8bd9f	04500693-9e94-55cd-a8ad-c3627d2dac80	2026-05-20	02:30:00	Client sync — Commerce Growth	2026-05-20 09:01:00+00	2026-05-20 09:01:00+00	\N	CG-115	e7e99ce4-232e-5ade-abb1-0966c94d952e	Active	Worklog
b591b07f-3b6e-5d0e-9034-350e213e56fe	62445afe-3364-5e78-b55e-fb5429807a47	1f95823c-e9b9-5334-8f67-669822d8bd9f	1146e928-4d82-581f-84f2-b8c9b6c83378	2026-05-21	04:00:00	Client sync — Learning Experience	2026-05-21 09:01:00+00	2026-05-21 09:01:00+00	\N	LE-143	a9e0bb14-488c-5643-96ca-5848796322a3	Active	Worklog
b1108598-6b98-5e19-956e-89f3b340b7a3	62445afe-3364-5e78-b55e-fb5429807a47	1f95823c-e9b9-5334-8f67-669822d8bd9f	04500693-9e94-55cd-a8ad-c3627d2dac80	2026-05-22	00:30:00	Client sync — Commerce Growth	2026-05-22 09:01:00+00	2026-05-22 09:01:00+00	\N	CG-162	e7e99ce4-232e-5ade-abb1-0966c94d952e	Active	Worklog
3ab7617d-cedf-5fca-8be1-cc11d1142098	62445afe-3364-5e78-b55e-fb5429807a47	1f95823c-e9b9-5334-8f67-669822d8bd9f	1146e928-4d82-581f-84f2-b8c9b6c83378	2026-05-25	02:00:00	Client sync — Learning Experience	2026-05-25 09:01:00+00	2026-05-25 09:01:00+00	\N	LE-117	a9e0bb14-488c-5643-96ca-5848796322a3	Active	Worklog
2be2b6e2-61e3-5c39-97e2-4ebc8807e48c	62445afe-3364-5e78-b55e-fb5429807a47	1f95823c-e9b9-5334-8f67-669822d8bd9f	04500693-9e94-55cd-a8ad-c3627d2dac80	2026-05-26	02:30:00	Client sync — Commerce Growth	2026-05-26 09:01:00+00	2026-05-26 09:01:00+00	\N	CG-136	e7e99ce4-232e-5ade-abb1-0966c94d952e	Active	Worklog
ca229be1-eedd-55c8-a5b4-f16c5c974c2f	62445afe-3364-5e78-b55e-fb5429807a47	1f95823c-e9b9-5334-8f67-669822d8bd9f	04500693-9e94-55cd-a8ad-c3627d2dac80	2026-05-28	00:30:00	Client sync — Commerce Growth	2026-05-28 09:01:00+00	2026-05-28 09:01:00+00	\N	CG-110	e7e99ce4-232e-5ade-abb1-0966c94d952e	Active	Worklog
3b221cf6-b578-5156-ae18-3e79e37e8bb0	62445afe-3364-5e78-b55e-fb5429807a47	1f95823c-e9b9-5334-8f67-669822d8bd9f	04500693-9e94-55cd-a8ad-c3627d2dac80	2026-05-31	02:30:00	Client sync — Commerce Growth	2026-05-31 09:01:00+00	2026-05-31 09:01:00+00	\N	CG-157	e7e99ce4-232e-5ade-abb1-0966c94d952e	Active	Worklog
2153aa27-49af-5a29-b8db-6821ad7d812a	62445afe-3364-5e78-b55e-fb5429807a47	1f95823c-e9b9-5334-8f67-669822d8bd9f	04500693-9e94-55cd-a8ad-c3627d2dac80	2026-06-02	00:30:00	Client sync — Commerce Growth	2026-06-02 09:01:00+00	2026-06-02 09:01:00+00	\N	CG-131	e7e99ce4-232e-5ade-abb1-0966c94d952e	Active	Worklog
b78eb826-4d27-5a37-a48f-9fcf4d0bff71	62445afe-3364-5e78-b55e-fb5429807a47	1f95823c-e9b9-5334-8f67-669822d8bd9f	1146e928-4d82-581f-84f2-b8c9b6c83378	2026-06-03	00:00:00	Planowana nieobecność uwzględniona w harmonogramie — Learning Experience	2026-06-03 09:01:00+00	2026-06-03 09:01:00+00	\N	\N	a9e0bb14-488c-5643-96ca-5848796322a3	Active	Note
02cccc22-7cd2-56f7-bafc-3f231af8ce2a	62445afe-3364-5e78-b55e-fb5429807a47	1f95823c-e9b9-5334-8f67-669822d8bd9f	04500693-9e94-55cd-a8ad-c3627d2dac80	2026-06-04	02:30:00	Client sync — Commerce Growth	2026-06-04 09:01:00+00	2026-06-04 09:01:00+00	\N	CG-105	e7e99ce4-232e-5ade-abb1-0966c94d952e	Active	Worklog
5624be7b-ed9f-5603-bced-b616d3b81dcf	62445afe-3364-5e78-b55e-fb5429807a47	1f95823c-e9b9-5334-8f67-669822d8bd9f	04500693-9e94-55cd-a8ad-c3627d2dac80	2026-06-08	00:30:00	Client sync — Commerce Growth	2026-06-08 09:01:00+00	2026-06-08 09:01:00+00	\N	CG-152	e7e99ce4-232e-5ade-abb1-0966c94d952e	Active	Worklog
83e73f97-e8e8-5866-a9db-e11b8348c396	62445afe-3364-5e78-b55e-fb5429807a47	1f95823c-e9b9-5334-8f67-669822d8bd9f	04500693-9e94-55cd-a8ad-c3627d2dac80	2026-06-10	02:30:00	Client sync — Commerce Growth	2026-06-10 09:01:00+00	2026-06-10 09:01:00+00	\N	CG-126	e7e99ce4-232e-5ade-abb1-0966c94d952e	Active	Worklog
1e77be0b-29c7-5a41-9aa1-49e7130d826e	62445afe-3364-5e78-b55e-fb5429807a47	1f95823c-e9b9-5334-8f67-669822d8bd9f	b8cd683c-fe4d-538c-bdaf-68c28e1e14ef	2026-06-11	03:00:00	Client sync — Time Intelligence	2026-06-11 09:01:00+00	2026-06-11 09:01:00+00	\N	TI-145	d677a650-2c23-5c0c-9f53-920636bd318e	Active	Worklog
3bd17bd2-6064-55f0-835b-5bd4c4c342c7	62445afe-3364-5e78-b55e-fb5429807a47	1f95823c-e9b9-5334-8f67-669822d8bd9f	04500693-9e94-55cd-a8ad-c3627d2dac80	2026-06-12	00:30:00	Client sync — Commerce Growth	2026-06-12 09:01:00+00	2026-06-12 09:01:00+00	\N	CG-100	e7e99ce4-232e-5ade-abb1-0966c94d952e	Active	Worklog
d90c651c-2fc1-5a71-bfbe-f7e1d3f4e824	62445afe-3364-5e78-b55e-fb5429807a47	1f95823c-e9b9-5334-8f67-669822d8bd9f	b8cd683c-fe4d-538c-bdaf-68c28e1e14ef	2026-06-14	01:00:00	Client sync — Time Intelligence	2026-06-14 09:01:00+00	2026-06-14 09:01:00+00	\N	TI-119	d677a650-2c23-5c0c-9f53-920636bd318e	Active	Worklog
3c406d28-ed3f-533e-b834-aa8e7a77093e	62445afe-3364-5e78-b55e-fb5429807a47	1f95823c-e9b9-5334-8f67-669822d8bd9f	b8cd683c-fe4d-538c-bdaf-68c28e1e14ef	2026-06-16	03:00:00	Client sync — Time Intelligence	2026-06-16 09:01:00+00	2026-06-16 09:01:00+00	\N	TI-166	d677a650-2c23-5c0c-9f53-920636bd318e	Active	Worklog
6166a1cc-3726-53bf-88ce-a42e5b34298d	62445afe-3364-5e78-b55e-fb5429807a47	1f95823c-e9b9-5334-8f67-669822d8bd9f	b8cd683c-fe4d-538c-bdaf-68c28e1e14ef	2026-06-18	01:00:00	Client sync — Time Intelligence	2026-06-18 09:01:00+00	2026-06-18 09:01:00+00	\N	TI-140	d677a650-2c23-5c0c-9f53-920636bd318e	Active	Worklog
d02329f6-7c69-5998-8b96-80dbd9e78735	62445afe-3364-5e78-b55e-fb5429807a47	1f95823c-e9b9-5334-8f67-669822d8bd9f	b8cd683c-fe4d-538c-bdaf-68c28e1e14ef	2026-06-22	03:00:00	Client sync — Time Intelligence	2026-06-22 09:01:00+00	2026-06-22 09:01:00+00	\N	TI-114	d677a650-2c23-5c0c-9f53-920636bd318e	Active	Worklog
db7937d9-d31d-59e8-8598-71c9dad9425e	62445afe-3364-5e78-b55e-fb5429807a47	1f95823c-e9b9-5334-8f67-669822d8bd9f	b8cd683c-fe4d-538c-bdaf-68c28e1e14ef	2026-06-24	01:00:00	Client sync — Time Intelligence	2026-06-24 09:01:00+00	2026-06-24 09:01:00+00	\N	TI-161	d677a650-2c23-5c0c-9f53-920636bd318e	Active	Worklog
6e7a3b2e-eb19-5050-8fd1-595e9e0a9323	62445afe-3364-5e78-b55e-fb5429807a47	1f95823c-e9b9-5334-8f67-669822d8bd9f	04500693-9e94-55cd-a8ad-c3627d2dac80	2026-06-25	00:00:00	Planowana nieobecność uwzględniona w harmonogramie — Commerce Growth	2026-06-25 09:01:00+00	2026-06-25 09:01:00+00	\N	\N	e7e99ce4-232e-5ade-abb1-0966c94d952e	Active	Note
5f63e5b0-4be6-5d11-b56b-f716b3657344	62445afe-3364-5e78-b55e-fb5429807a47	1f95823c-e9b9-5334-8f67-669822d8bd9f	b8cd683c-fe4d-538c-bdaf-68c28e1e14ef	2026-06-26	03:00:00	Client sync — Time Intelligence	2026-06-26 09:01:00+00	2026-06-26 09:01:00+00	\N	TI-135	d677a650-2c23-5c0c-9f53-920636bd318e	Active	Worklog
2d709238-64c6-52fc-845a-53af759e6856	62445afe-3364-5e78-b55e-fb5429807a47	1f95823c-e9b9-5334-8f67-669822d8bd9f	613fe369-ab85-5812-9136-0d147b91706d	2026-06-28	03:00:00	Historical delivery wrap-up — Mobility Discovery	2026-06-28 09:01:00+00	2026-06-28 09:01:00+00	2026-07-13 00:00:00+00	MD-945	eba17d28-b076-534c-918a-dca0a5be8fab	Archived	Worklog
f104d6b0-0493-5142-8c26-f0a4c2d9af37	62445afe-3364-5e78-b55e-fb5429807a47	1f95823c-e9b9-5334-8f67-669822d8bd9f	b8cd683c-fe4d-538c-bdaf-68c28e1e14ef	2026-06-29	01:00:00	Client sync — Time Intelligence	2026-06-29 09:01:00+00	2026-06-29 09:01:00+00	\N	TI-109	d677a650-2c23-5c0c-9f53-920636bd318e	Active	Worklog
d718e891-d059-5079-8f10-5277b72efefe	62445afe-3364-5e78-b55e-fb5429807a47	1f95823c-e9b9-5334-8f67-669822d8bd9f	b8cd683c-fe4d-538c-bdaf-68c28e1e14ef	2026-07-01	03:00:00	Client sync — Time Intelligence	2026-07-01 09:01:00+00	2026-07-01 09:01:00+00	\N	TI-156	d677a650-2c23-5c0c-9f53-920636bd318e	Active	Worklog
3fb57e81-fdfc-5dc6-8886-5f9e719e1f94	62445afe-3364-5e78-b55e-fb5429807a47	1f95823c-e9b9-5334-8f67-669822d8bd9f	613fe369-ab85-5812-9136-0d147b91706d	2026-07-01	02:00:00	Historical delivery wrap-up — Mobility Discovery	2026-07-01 09:02:00+00	2026-07-01 09:02:00+00	2026-07-13 00:00:00+00	MD-933	eba17d28-b076-534c-918a-dca0a5be8fab	Archived	Worklog
6368a490-ad20-58b1-96e3-63bfe5a36e35	62445afe-3364-5e78-b55e-fb5429807a47	1f95823c-e9b9-5334-8f67-669822d8bd9f	a7906be2-315f-5b5e-b344-ac119fd04d1a	2026-07-02	03:30:00	Client sync — Omnichannel Checkout	2026-07-02 09:01:00+00	2026-07-02 09:01:00+00	\N	OC-102	3030e191-44de-5909-b035-5fe3679b482a	Active	Worklog
b351eefb-22e0-5b4f-9731-eb0c29744875	62445afe-3364-5e78-b55e-fb5429807a47	1f95823c-e9b9-5334-8f67-669822d8bd9f	b8cd683c-fe4d-538c-bdaf-68c28e1e14ef	2026-07-03	01:00:00	Client sync — Time Intelligence	2026-07-03 09:01:00+00	2026-07-03 09:01:00+00	\N	TI-130	d677a650-2c23-5c0c-9f53-920636bd318e	Active	Worklog
f25bedd8-c39c-5d9a-98f5-64cddaff06c2	62445afe-3364-5e78-b55e-fb5429807a47	1f95823c-e9b9-5334-8f67-669822d8bd9f	613fe369-ab85-5812-9136-0d147b91706d	2026-07-04	01:00:00	Historical delivery wrap-up — Mobility Discovery	2026-07-04 09:01:00+00	2026-07-04 09:01:00+00	2026-07-13 00:00:00+00	MD-921	eba17d28-b076-534c-918a-dca0a5be8fab	Archived	Worklog
49d71399-d547-5c85-afb0-8c9fa6435836	62445afe-3364-5e78-b55e-fb5429807a47	1f95823c-e9b9-5334-8f67-669822d8bd9f	a7906be2-315f-5b5e-b344-ac119fd04d1a	2026-07-06	01:30:00	Client sync — Omnichannel Checkout	2026-07-06 09:01:00+00	2026-07-06 09:01:00+00	\N	OC-149	3030e191-44de-5909-b035-5fe3679b482a	Active	Worklog
f15bef4d-2a5e-5b8c-bba1-9663c742a318	62445afe-3364-5e78-b55e-fb5429807a47	1f95823c-e9b9-5334-8f67-669822d8bd9f	613fe369-ab85-5812-9136-0d147b91706d	2026-07-07	04:00:00	Historical delivery wrap-up — Mobility Discovery	2026-07-07 09:01:00+00	2026-07-07 09:01:00+00	2026-07-13 00:00:00+00	MD-909	eba17d28-b076-534c-918a-dca0a5be8fab	Archived	Worklog
f2608abc-274c-5503-b8cf-fdfd77610b96	62445afe-3364-5e78-b55e-fb5429807a47	1f95823c-e9b9-5334-8f67-669822d8bd9f	a7906be2-315f-5b5e-b344-ac119fd04d1a	2026-07-08	03:30:00	Client sync — Omnichannel Checkout	2026-07-08 09:01:00+00	2026-07-08 09:01:00+00	\N	OC-123	3030e191-44de-5909-b035-5fe3679b482a	Active	Worklog
1302b9ca-89fa-5124-bf38-af01f07d3408	62445afe-3364-5e78-b55e-fb5429807a47	1f95823c-e9b9-5334-8f67-669822d8bd9f	a7906be2-315f-5b5e-b344-ac119fd04d1a	2026-07-10	01:30:00	Client sync — Omnichannel Checkout	2026-07-10 09:01:00+00	2026-07-10 09:01:00+00	\N	OC-170	3030e191-44de-5909-b035-5fe3679b482a	Active	Worklog
6f37baa1-e8d1-5323-88e0-da3ed7185faf	62445afe-3364-5e78-b55e-fb5429807a47	1f95823c-e9b9-5334-8f67-669822d8bd9f	613fe369-ab85-5812-9136-0d147b91706d	2026-07-10	04:00:00	Historical delivery wrap-up — Mobility Discovery	2026-07-10 09:02:00+00	2026-07-10 09:02:00+00	2026-07-13 00:00:00+00	MD-957	eba17d28-b076-534c-918a-dca0a5be8fab	Archived	Worklog
355e9bc3-7d40-521e-8912-25e4160027de	62445afe-3364-5e78-b55e-fb5429807a47	1f95823c-e9b9-5334-8f67-669822d8bd9f	a7906be2-315f-5b5e-b344-ac119fd04d1a	2026-07-13	03:30:00	Client sync — Omnichannel Checkout	2026-07-13 09:01:00+00	2026-07-13 09:01:00+00	\N	OC-144	3030e191-44de-5909-b035-5fe3679b482a	Active	Worklog
ade68bdb-def9-576b-8b8c-3b30001e30ca	62445afe-3364-5e78-b55e-fb5429807a47	1f95823c-e9b9-5334-8f67-669822d8bd9f	a7906be2-315f-5b5e-b344-ac119fd04d1a	2026-07-15	01:30:00	Client sync — Omnichannel Checkout	2026-07-15 09:01:00+00	2026-07-15 09:01:00+00	\N	OC-118	3030e191-44de-5909-b035-5fe3679b482a	Active	Worklog
d747875f-b8b8-57e6-859f-26741d5f10d5	62445afe-3364-5e78-b55e-fb5429807a47	1f95823c-e9b9-5334-8f67-669822d8bd9f	b8cd683c-fe4d-538c-bdaf-68c28e1e14ef	2026-07-16	00:00:00	Planowana nieobecność uwzględniona w harmonogramie — Time Intelligence	2026-07-16 09:01:00+00	2026-07-16 09:01:00+00	\N	\N	d677a650-2c23-5c0c-9f53-920636bd318e	Active	Note
b54d52e4-5c57-5da3-b4d6-a3c23a5a71c6	62445afe-3364-5e78-b55e-fb5429807a47	1f95823c-e9b9-5334-8f67-669822d8bd9f	a7906be2-315f-5b5e-b344-ac119fd04d1a	2026-07-17	03:30:00	Client sync — Omnichannel Checkout	2026-07-17 09:01:00+00	2026-07-17 09:01:00+00	\N	OC-165	3030e191-44de-5909-b035-5fe3679b482a	Active	Worklog
6245d74e-258b-5045-bc02-f4c415fcf943	62445afe-3364-5e78-b55e-fb5429807a47	1f95823c-e9b9-5334-8f67-669822d8bd9f	a7906be2-315f-5b5e-b344-ac119fd04d1a	2026-07-21	01:30:00	Client sync — Omnichannel Checkout	2026-07-21 09:01:00+00	2026-07-21 09:01:00+00	\N	OC-139	3030e191-44de-5909-b035-5fe3679b482a	Active	Worklog
4935656e-9148-5819-8e16-54e18ab0214d	62445afe-3364-5e78-b55e-fb5429807a47	1f95823c-e9b9-5334-8f67-669822d8bd9f	a7906be2-315f-5b5e-b344-ac119fd04d1a	2026-07-23	03:30:00	Client sync — Omnichannel Checkout	2026-07-23 09:01:00+00	2026-07-23 09:01:00+00	\N	OC-113	3030e191-44de-5909-b035-5fe3679b482a	Active	Worklog
ad9dbe55-a3e5-5b60-8c33-30f4a4ad894c	62445afe-3364-5e78-b55e-fb5429807a47	1f95823c-e9b9-5334-8f67-669822d8bd9f	1146e928-4d82-581f-84f2-b8c9b6c83378	2026-07-24	04:00:00	Client sync — Learning Experience	2026-07-24 09:01:00+00	2026-07-24 09:01:00+00	\N	LE-132	a9e0bb14-488c-5643-96ca-5848796322a3	Active	Worklog
bb8674a1-dca7-5dc2-9603-245f83a78a34	62445afe-3364-5e78-b55e-fb5429807a47	1f95823c-e9b9-5334-8f67-669822d8bd9f	a7906be2-315f-5b5e-b344-ac119fd04d1a	2026-07-26	01:30:00	Client sync — Omnichannel Checkout	2026-07-26 09:01:00+00	2026-07-26 09:01:00+00	\N	OC-160	3030e191-44de-5909-b035-5fe3679b482a	Active	Worklog
eb3ef4ce-d28d-5bdd-941d-fa5769bbcebd	62445afe-3364-5e78-b55e-fb5429807a47	1f95823c-e9b9-5334-8f67-669822d8bd9f	1146e928-4d82-581f-84f2-b8c9b6c83378	2026-07-27	02:00:00	Client sync — Learning Experience	2026-07-27 09:01:00+00	2026-07-27 09:01:00+00	\N	LE-106	a9e0bb14-488c-5643-96ca-5848796322a3	Active	Worklog
c0ed8821-1ced-5e38-88d6-a506b0fb80d5	62445afe-3364-5e78-b55e-fb5429807a47	1f95823c-e9b9-5334-8f67-669822d8bd9f	1146e928-4d82-581f-84f2-b8c9b6c83378	2026-07-29	04:00:00	Client sync — Learning Experience	2026-07-29 09:01:00+00	2026-07-29 09:01:00+00	\N	LE-153	a9e0bb14-488c-5643-96ca-5848796322a3	Active	Worklog
ca4332bd-3156-5c89-9293-906a6b7d6dcd	62445afe-3364-5e78-b55e-fb5429807a47	1f95823c-e9b9-5334-8f67-669822d8bd9f	1146e928-4d82-581f-84f2-b8c9b6c83378	2026-07-31	02:00:00	Client sync — Learning Experience	2026-07-31 09:01:00+00	2026-07-31 09:01:00+00	\N	LE-127	a9e0bb14-488c-5643-96ca-5848796322a3	Active	Worklog
4b66b801-6c26-5dca-bb74-c36b86521a4c	62445afe-3364-5e78-b55e-fb5429807a47	1f95823c-e9b9-5334-8f67-669822d8bd9f	1146e928-4d82-581f-84f2-b8c9b6c83378	2026-08-04	04:00:00	Client sync — Learning Experience	2026-08-04 09:01:00+00	2026-08-04 09:01:00+00	\N	LE-101	a9e0bb14-488c-5643-96ca-5848796322a3	Active	Worklog
a6f577d4-f64b-5e60-a31e-acef6b7859fa	62445afe-3364-5e78-b55e-fb5429807a47	1f95823c-e9b9-5334-8f67-669822d8bd9f	1146e928-4d82-581f-84f2-b8c9b6c83378	2026-08-06	02:00:00	Client sync — Learning Experience	2026-08-06 09:01:00+00	2026-08-06 09:01:00+00	\N	LE-148	a9e0bb14-488c-5643-96ca-5848796322a3	Active	Worklog
2cfdd892-7e04-5a97-a3a2-b641247e5f84	62445afe-3364-5e78-b55e-fb5429807a47	1f95823c-e9b9-5334-8f67-669822d8bd9f	a7906be2-315f-5b5e-b344-ac119fd04d1a	2026-08-07	00:00:00	Planowana nieobecność uwzględniona w harmonogramie — Omnichannel Checkout	2026-08-07 09:01:00+00	2026-08-07 09:01:00+00	\N	\N	3030e191-44de-5909-b035-5fe3679b482a	Active	Note
f1f7b0e4-8f83-56e6-956b-da060dbefc6d	62445afe-3364-5e78-b55e-fb5429807a47	1f95823c-e9b9-5334-8f67-669822d8bd9f	1146e928-4d82-581f-84f2-b8c9b6c83378	2026-08-09	04:00:00	Client sync — Learning Experience	2026-08-09 09:01:00+00	2026-08-09 09:01:00+00	\N	LE-122	a9e0bb14-488c-5643-96ca-5848796322a3	Active	Worklog
fe0c99c6-7089-512b-bc83-193c87e476bc	62445afe-3364-5e78-b55e-fb5429807a47	1f95823c-e9b9-5334-8f67-669822d8bd9f	1146e928-4d82-581f-84f2-b8c9b6c83378	2026-08-11	02:00:00	Client sync — Learning Experience	2026-08-11 09:01:00+00	2026-08-11 09:01:00+00	\N	LE-169	a9e0bb14-488c-5643-96ca-5848796322a3	Active	Worklog
c0e797df-4978-56e2-b39c-dbe45029382e	62445afe-3364-5e78-b55e-fb5429807a47	fe59379a-ab41-581e-8b2e-24d95eb4cee8	67164958-1bad-5a9c-8d3a-7c4f7dfb7282	2026-05-20	03:45:00	Accessibility review — Reporting Sandbox	2026-05-20 09:01:00+00	2026-05-20 09:01:00+00	\N	RS-118	d677a650-2c23-5c0c-9f53-920636bd318e	Active	Worklog
685689f9-1e19-58e1-b462-937d8dd90a22	62445afe-3364-5e78-b55e-fb5429807a47	fe59379a-ab41-581e-8b2e-24d95eb4cee8	a7906be2-315f-5b5e-b344-ac119fd04d1a	2026-05-21	01:15:00	Accessibility review — Omnichannel Checkout	2026-05-21 09:01:00+00	2026-05-21 09:01:00+00	\N	OC-146	3030e191-44de-5909-b035-5fe3679b482a	Active	Worklog
87b861ca-a78d-5a7f-b741-fe8dc94d3727	62445afe-3364-5e78-b55e-fb5429807a47	fe59379a-ab41-581e-8b2e-24d95eb4cee8	e7ea37c3-9fe3-5010-bb38-8c7330ef5bdc	2026-05-22	01:45:00	Accessibility review — Care Analytics	2026-05-22 09:01:00+00	2026-05-22 09:01:00+00	\N	CA-165	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
5a28aad2-eb55-5887-911b-977bb796216e	62445afe-3364-5e78-b55e-fb5429807a47	fe59379a-ab41-581e-8b2e-24d95eb4cee8	67164958-1bad-5a9c-8d3a-7c4f7dfb7282	2026-05-25	03:15:00	Accessibility review — Reporting Sandbox	2026-05-25 09:01:00+00	2026-05-25 09:01:00+00	\N	RS-120	d677a650-2c23-5c0c-9f53-920636bd318e	Active	Worklog
c6d7cf43-2546-501e-931a-29147a93bee1	62445afe-3364-5e78-b55e-fb5429807a47	fe59379a-ab41-581e-8b2e-24d95eb4cee8	a7906be2-315f-5b5e-b344-ac119fd04d1a	2026-05-26	03:45:00	Accessibility review — Omnichannel Checkout	2026-05-26 09:01:00+00	2026-05-26 09:01:00+00	\N	OC-139	3030e191-44de-5909-b035-5fe3679b482a	Active	Worklog
c11bb2b4-5c21-54d3-a0f7-ad8c4d66fd3a	62445afe-3364-5e78-b55e-fb5429807a47	fe59379a-ab41-581e-8b2e-24d95eb4cee8	67164958-1bad-5a9c-8d3a-7c4f7dfb7282	2026-05-28	01:45:00	Accessibility review — Reporting Sandbox	2026-05-28 09:01:00+00	2026-05-28 09:01:00+00	\N	RS-113	d677a650-2c23-5c0c-9f53-920636bd318e	Active	Worklog
df3f4467-5a03-51dd-888d-0eadb47ac349	62445afe-3364-5e78-b55e-fb5429807a47	fe59379a-ab41-581e-8b2e-24d95eb4cee8	e7ea37c3-9fe3-5010-bb38-8c7330ef5bdc	2026-05-31	03:45:00	Accessibility review — Care Analytics	2026-05-31 09:01:00+00	2026-05-31 09:01:00+00	\N	CA-160	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
d7df23fb-5e4a-5ff8-9766-5202435f0a95	62445afe-3364-5e78-b55e-fb5429807a47	fe59379a-ab41-581e-8b2e-24d95eb4cee8	a7906be2-315f-5b5e-b344-ac119fd04d1a	2026-06-02	01:45:00	Accessibility review — Omnichannel Checkout	2026-06-02 09:01:00+00	2026-06-02 09:01:00+00	\N	OC-134	3030e191-44de-5909-b035-5fe3679b482a	Active	Worklog
c8ab7043-69c4-567f-9b0b-e2cd4a60af4b	62445afe-3364-5e78-b55e-fb5429807a47	fe59379a-ab41-581e-8b2e-24d95eb4cee8	a7906be2-315f-5b5e-b344-ac119fd04d1a	2026-06-03	00:00:00	Discovery follow-up zaplanowany na kolejny tydzień — Omnichannel Checkout	2026-06-03 09:01:00+00	2026-06-03 09:01:00+00	\N	\N	3030e191-44de-5909-b035-5fe3679b482a	Active	Note
6d5018f2-4656-5971-a282-8ed7947bf736	62445afe-3364-5e78-b55e-fb5429807a47	fe59379a-ab41-581e-8b2e-24d95eb4cee8	67164958-1bad-5a9c-8d3a-7c4f7dfb7282	2026-06-04	03:45:00	Accessibility review — Reporting Sandbox	2026-06-04 09:01:00+00	2026-06-04 09:01:00+00	\N	RS-108	d677a650-2c23-5c0c-9f53-920636bd318e	Active	Worklog
0d362849-d86d-5d1a-9c38-58455a46da47	62445afe-3364-5e78-b55e-fb5429807a47	fe59379a-ab41-581e-8b2e-24d95eb4cee8	e7ea37c3-9fe3-5010-bb38-8c7330ef5bdc	2026-06-08	01:45:00	Accessibility review — Care Analytics	2026-06-08 09:01:00+00	2026-06-08 09:01:00+00	\N	CA-155	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
39f7963e-de2e-5556-a642-9a23abb7113e	62445afe-3364-5e78-b55e-fb5429807a47	fe59379a-ab41-581e-8b2e-24d95eb4cee8	a7906be2-315f-5b5e-b344-ac119fd04d1a	2026-06-10	03:45:00	Accessibility review — Omnichannel Checkout	2026-06-10 09:01:00+00	2026-06-10 09:01:00+00	\N	OC-129	3030e191-44de-5909-b035-5fe3679b482a	Active	Worklog
46d265e7-f755-512f-9160-78c7bd1977cb	62445afe-3364-5e78-b55e-fb5429807a47	fe59379a-ab41-581e-8b2e-24d95eb4cee8	e7ea37c3-9fe3-5010-bb38-8c7330ef5bdc	2026-06-11	00:15:00	Accessibility review — Care Analytics	2026-06-11 09:01:00+00	2026-06-11 09:01:00+00	\N	CA-148	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
b504b599-b85d-5826-9e15-93445057e702	62445afe-3364-5e78-b55e-fb5429807a47	fe59379a-ab41-581e-8b2e-24d95eb4cee8	67164958-1bad-5a9c-8d3a-7c4f7dfb7282	2026-06-12	01:45:00	Accessibility review — Reporting Sandbox	2026-06-12 09:01:00+00	2026-06-12 09:01:00+00	\N	RS-103	d677a650-2c23-5c0c-9f53-920636bd318e	Active	Worklog
fcfcc6c5-2d3f-5ec2-aa4e-dc12d8d4fff7	62445afe-3364-5e78-b55e-fb5429807a47	fe59379a-ab41-581e-8b2e-24d95eb4cee8	a7906be2-315f-5b5e-b344-ac119fd04d1a	2026-06-14	02:15:00	Accessibility review — Omnichannel Checkout	2026-06-14 09:01:00+00	2026-06-14 09:01:00+00	\N	OC-122	3030e191-44de-5909-b035-5fe3679b482a	Active	Worklog
bc0810fe-21c2-57ce-a370-bfcc28d149b3	62445afe-3364-5e78-b55e-fb5429807a47	fe59379a-ab41-581e-8b2e-24d95eb4cee8	67164958-1bad-5a9c-8d3a-7c4f7dfb7282	2026-06-16	00:15:00	Accessibility review — Reporting Sandbox	2026-06-16 09:01:00+00	2026-06-16 09:01:00+00	\N	RS-169	d677a650-2c23-5c0c-9f53-920636bd318e	Active	Worklog
b29639a5-1269-56c5-8399-619bc82ecc77	62445afe-3364-5e78-b55e-fb5429807a47	fe59379a-ab41-581e-8b2e-24d95eb4cee8	e7ea37c3-9fe3-5010-bb38-8c7330ef5bdc	2026-06-18	02:15:00	Accessibility review — Care Analytics	2026-06-18 09:01:00+00	2026-06-18 09:01:00+00	\N	CA-143	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
634d4fa5-f990-56ae-b7d9-7ad0f9b43d9b	62445afe-3364-5e78-b55e-fb5429807a47	fe59379a-ab41-581e-8b2e-24d95eb4cee8	a7906be2-315f-5b5e-b344-ac119fd04d1a	2026-06-22	00:15:00	Accessibility review — Omnichannel Checkout	2026-06-22 09:01:00+00	2026-06-22 09:01:00+00	\N	OC-117	3030e191-44de-5909-b035-5fe3679b482a	Active	Worklog
aa74140f-9ef8-5bac-907e-2d42edde05c5	62445afe-3364-5e78-b55e-fb5429807a47	fe59379a-ab41-581e-8b2e-24d95eb4cee8	67164958-1bad-5a9c-8d3a-7c4f7dfb7282	2026-06-24	02:15:00	Accessibility review — Reporting Sandbox	2026-06-24 09:01:00+00	2026-06-24 09:01:00+00	\N	RS-164	d677a650-2c23-5c0c-9f53-920636bd318e	Active	Worklog
e4020ca2-80a9-595f-be54-3440df285b0e	62445afe-3364-5e78-b55e-fb5429807a47	fe59379a-ab41-581e-8b2e-24d95eb4cee8	67164958-1bad-5a9c-8d3a-7c4f7dfb7282	2026-06-25	00:00:00	Discovery follow-up zaplanowany na kolejny tydzień — Reporting Sandbox	2026-06-25 09:01:00+00	2026-06-25 09:01:00+00	\N	\N	d677a650-2c23-5c0c-9f53-920636bd318e	Active	Note
e487e6b7-e0b5-5a6e-8c28-48a4f7b6d592	62445afe-3364-5e78-b55e-fb5429807a47	fe59379a-ab41-581e-8b2e-24d95eb4cee8	e7ea37c3-9fe3-5010-bb38-8c7330ef5bdc	2026-06-26	00:15:00	Accessibility review — Care Analytics	2026-06-26 09:01:00+00	2026-06-26 09:01:00+00	\N	CA-138	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
7b90211f-27c6-5a7a-bef3-d68efd5c7b27	62445afe-3364-5e78-b55e-fb5429807a47	fe59379a-ab41-581e-8b2e-24d95eb4cee8	a7906be2-315f-5b5e-b344-ac119fd04d1a	2026-06-29	02:15:00	Accessibility review — Omnichannel Checkout	2026-06-29 09:01:00+00	2026-06-29 09:01:00+00	\N	OC-112	3030e191-44de-5909-b035-5fe3679b482a	Active	Worklog
8aa416e2-11e6-5afb-b55b-6edff7fccd76	62445afe-3364-5e78-b55e-fb5429807a47	fe59379a-ab41-581e-8b2e-24d95eb4cee8	67164958-1bad-5a9c-8d3a-7c4f7dfb7282	2026-07-01	00:15:00	Accessibility review — Reporting Sandbox	2026-07-01 09:01:00+00	2026-07-01 09:01:00+00	\N	RS-159	d677a650-2c23-5c0c-9f53-920636bd318e	Active	Worklog
37fe6c66-c7d6-528e-bda9-86cabf58d112	62445afe-3364-5e78-b55e-fb5429807a47	fe59379a-ab41-581e-8b2e-24d95eb4cee8	a7906be2-315f-5b5e-b344-ac119fd04d1a	2026-07-02	00:45:00	Accessibility review — Omnichannel Checkout	2026-07-02 09:01:00+00	2026-07-02 09:01:00+00	\N	OC-105	3030e191-44de-5909-b035-5fe3679b482a	Active	Worklog
3542dae1-2f11-5885-98a1-587fffd80280	62445afe-3364-5e78-b55e-fb5429807a47	fe59379a-ab41-581e-8b2e-24d95eb4cee8	e7ea37c3-9fe3-5010-bb38-8c7330ef5bdc	2026-07-03	02:15:00	Accessibility review — Care Analytics	2026-07-03 09:01:00+00	2026-07-03 09:01:00+00	\N	CA-133	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
c924ff17-90f7-5b8e-a42f-e575235929f9	62445afe-3364-5e78-b55e-fb5429807a47	fe59379a-ab41-581e-8b2e-24d95eb4cee8	67164958-1bad-5a9c-8d3a-7c4f7dfb7282	2026-07-06	02:45:00	Accessibility review — Reporting Sandbox	2026-07-06 09:01:00+00	2026-07-06 09:01:00+00	\N	RS-152	d677a650-2c23-5c0c-9f53-920636bd318e	Active	Worklog
9ce7969e-ae1c-5718-b240-187b6d6097fe	62445afe-3364-5e78-b55e-fb5429807a47	fe59379a-ab41-581e-8b2e-24d95eb4cee8	e7ea37c3-9fe3-5010-bb38-8c7330ef5bdc	2026-07-08	00:45:00	Accessibility review — Care Analytics	2026-07-08 09:01:00+00	2026-07-08 09:01:00+00	\N	CA-126	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
f7dac1d2-6180-5a14-8b92-552e4cc1de63	62445afe-3364-5e78-b55e-fb5429807a47	fe59379a-ab41-581e-8b2e-24d95eb4cee8	a7906be2-315f-5b5e-b344-ac119fd04d1a	2026-07-10	02:45:00	Accessibility review — Omnichannel Checkout	2026-07-10 09:01:00+00	2026-07-10 09:01:00+00	\N	OC-100	3030e191-44de-5909-b035-5fe3679b482a	Active	Worklog
99ad3ae6-c1bb-5461-97a3-803a067cc7bf	62445afe-3364-5e78-b55e-fb5429807a47	fe59379a-ab41-581e-8b2e-24d95eb4cee8	67164958-1bad-5a9c-8d3a-7c4f7dfb7282	2026-07-13	00:45:00	Accessibility review — Reporting Sandbox	2026-07-13 09:01:00+00	2026-07-13 09:01:00+00	\N	RS-147	d677a650-2c23-5c0c-9f53-920636bd318e	Active	Worklog
07c27ff9-3f7d-5989-918e-1dcdfb43ca4d	62445afe-3364-5e78-b55e-fb5429807a47	fe59379a-ab41-581e-8b2e-24d95eb4cee8	e7ea37c3-9fe3-5010-bb38-8c7330ef5bdc	2026-07-15	02:45:00	Accessibility review — Care Analytics	2026-07-15 09:01:00+00	2026-07-15 09:01:00+00	\N	CA-121	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
00cdea10-b097-50e8-8b2b-80f354581424	62445afe-3364-5e78-b55e-fb5429807a47	fe59379a-ab41-581e-8b2e-24d95eb4cee8	e7ea37c3-9fe3-5010-bb38-8c7330ef5bdc	2026-07-16	00:00:00	Discovery follow-up zaplanowany na kolejny tydzień — Care Analytics	2026-07-16 09:01:00+00	2026-07-16 09:01:00+00	\N	\N	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Note
2eaf324c-63dd-55ff-b7eb-bacf925147aa	62445afe-3364-5e78-b55e-fb5429807a47	fe59379a-ab41-581e-8b2e-24d95eb4cee8	a7906be2-315f-5b5e-b344-ac119fd04d1a	2026-07-17	00:45:00	Accessibility review — Omnichannel Checkout	2026-07-17 09:01:00+00	2026-07-17 09:01:00+00	\N	OC-168	3030e191-44de-5909-b035-5fe3679b482a	Active	Worklog
5c6133b4-138b-5e5d-89b6-9eea825be4e6	62445afe-3364-5e78-b55e-fb5429807a47	fe59379a-ab41-581e-8b2e-24d95eb4cee8	67164958-1bad-5a9c-8d3a-7c4f7dfb7282	2026-07-21	02:45:00	Accessibility review — Reporting Sandbox	2026-07-21 09:01:00+00	2026-07-21 09:01:00+00	\N	RS-142	d677a650-2c23-5c0c-9f53-920636bd318e	Active	Worklog
29f1de54-aca0-5bff-ac50-88c178667f1c	62445afe-3364-5e78-b55e-fb5429807a47	fe59379a-ab41-581e-8b2e-24d95eb4cee8	e7ea37c3-9fe3-5010-bb38-8c7330ef5bdc	2026-07-23	00:45:00	Accessibility review — Care Analytics	2026-07-23 09:01:00+00	2026-07-23 09:01:00+00	\N	CA-116	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
e532316b-a495-568b-9f95-8d23c52c7450	62445afe-3364-5e78-b55e-fb5429807a47	fe59379a-ab41-581e-8b2e-24d95eb4cee8	67164958-1bad-5a9c-8d3a-7c4f7dfb7282	2026-07-24	01:15:00	Accessibility review — Reporting Sandbox	2026-07-24 09:01:00+00	2026-07-24 09:01:00+00	\N	RS-135	d677a650-2c23-5c0c-9f53-920636bd318e	Active	Worklog
8ec4328f-b673-5a05-8a5f-f358149e3aff	62445afe-3364-5e78-b55e-fb5429807a47	fe59379a-ab41-581e-8b2e-24d95eb4cee8	a7906be2-315f-5b5e-b344-ac119fd04d1a	2026-07-26	02:45:00	Accessibility review — Omnichannel Checkout	2026-07-26 09:01:00+00	2026-07-26 09:01:00+00	\N	OC-163	3030e191-44de-5909-b035-5fe3679b482a	Active	Worklog
f2a3ced8-8a61-51d4-96b2-e09d83cd2800	62445afe-3364-5e78-b55e-fb5429807a47	fe59379a-ab41-581e-8b2e-24d95eb4cee8	e7ea37c3-9fe3-5010-bb38-8c7330ef5bdc	2026-07-27	03:15:00	Accessibility review — Care Analytics	2026-07-27 09:01:00+00	2026-07-27 09:01:00+00	\N	CA-109	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
22c6fb07-b5fc-55c7-a560-10477d294e5f	62445afe-3364-5e78-b55e-fb5429807a47	fe59379a-ab41-581e-8b2e-24d95eb4cee8	a7906be2-315f-5b5e-b344-ac119fd04d1a	2026-07-29	01:15:00	Accessibility review — Omnichannel Checkout	2026-07-29 09:01:00+00	2026-07-29 09:01:00+00	\N	OC-156	3030e191-44de-5909-b035-5fe3679b482a	Active	Worklog
4cffec47-3daa-5a8f-b00f-5bd9305312da	62445afe-3364-5e78-b55e-fb5429807a47	fe59379a-ab41-581e-8b2e-24d95eb4cee8	67164958-1bad-5a9c-8d3a-7c4f7dfb7282	2026-07-31	03:15:00	Accessibility review — Reporting Sandbox	2026-07-31 09:01:00+00	2026-07-31 09:01:00+00	\N	RS-130	d677a650-2c23-5c0c-9f53-920636bd318e	Active	Worklog
cf9d33fa-d70c-549d-8eda-d9ec6adec522	62445afe-3364-5e78-b55e-fb5429807a47	fe59379a-ab41-581e-8b2e-24d95eb4cee8	e7ea37c3-9fe3-5010-bb38-8c7330ef5bdc	2026-08-04	01:15:00	Accessibility review — Care Analytics	2026-08-04 09:01:00+00	2026-08-04 09:01:00+00	\N	CA-104	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
2846037e-19c4-51c1-99fa-275708864c19	62445afe-3364-5e78-b55e-fb5429807a47	fe59379a-ab41-581e-8b2e-24d95eb4cee8	a7906be2-315f-5b5e-b344-ac119fd04d1a	2026-08-06	03:15:00	Accessibility review — Omnichannel Checkout	2026-08-06 09:01:00+00	2026-08-06 09:01:00+00	\N	OC-151	3030e191-44de-5909-b035-5fe3679b482a	Active	Worklog
818e5a1d-726e-5b4e-930d-225c949c358c	62445afe-3364-5e78-b55e-fb5429807a47	fe59379a-ab41-581e-8b2e-24d95eb4cee8	67164958-1bad-5a9c-8d3a-7c4f7dfb7282	2026-08-09	01:15:00	Accessibility review — Reporting Sandbox	2026-08-09 09:01:00+00	2026-08-09 09:01:00+00	\N	RS-125	d677a650-2c23-5c0c-9f53-920636bd318e	Active	Worklog
d4ea15e2-72fb-55cc-bedd-31c49d12c8e5	62445afe-3364-5e78-b55e-fb5429807a47	fe59379a-ab41-581e-8b2e-24d95eb4cee8	e7ea37c3-9fe3-5010-bb38-8c7330ef5bdc	2026-08-11	03:15:00	Accessibility review — Care Analytics	2026-08-11 09:01:00+00	2026-08-11 09:01:00+00	\N	CA-172	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
bfde3ac0-a773-5efb-9fa4-80ddf486a55c	62445afe-3364-5e78-b55e-fb5429807a47	372b5e87-7bf3-5e30-98c4-56a4c19d17fa	6dfe9630-59ce-507d-81a0-2f94cb54247f	2026-05-20	02:15:00	Data analysis — Fleet Companion	2026-05-20 09:01:00+00	2026-05-20 09:01:00+00	\N	FC-124	eba17d28-b076-534c-918a-dca0a5be8fab	Active	Worklog
df4c6a3c-238c-5b83-ab9e-1866a804ac83	62445afe-3364-5e78-b55e-fb5429807a47	372b5e87-7bf3-5e30-98c4-56a4c19d17fa	1146e928-4d82-581f-84f2-b8c9b6c83378	2026-05-21	03:45:00	Data analysis — Learning Experience	2026-05-21 09:01:00+00	2026-05-21 09:01:00+00	\N	LE-152	a9e0bb14-488c-5643-96ca-5848796322a3	Active	Worklog
0e7ff155-4a5c-5e9e-b3dc-ac230501661f	62445afe-3364-5e78-b55e-fb5429807a47	372b5e87-7bf3-5e30-98c4-56a4c19d17fa	f07ee933-bae1-5f0f-9e95-6c303aba6f5d	2026-05-22	00:15:00	Data analysis — Open Banking Integration	2026-05-22 09:01:00+00	2026-05-22 09:01:00+00	\N	OBI-171	f4c5b0e8-5503-5a50-8487-4ae103b885f2	Active	Worklog
7bcdc2a6-c560-56c2-b457-90fcd3baaa06	62445afe-3364-5e78-b55e-fb5429807a47	372b5e87-7bf3-5e30-98c4-56a4c19d17fa	6dfe9630-59ce-507d-81a0-2f94cb54247f	2026-05-25	01:45:00	Data analysis — Fleet Companion	2026-05-25 09:01:00+00	2026-05-25 09:01:00+00	\N	FC-126	eba17d28-b076-534c-918a-dca0a5be8fab	Active	Worklog
8b4d28cf-6f28-5bcf-a875-09a1f2e527a5	62445afe-3364-5e78-b55e-fb5429807a47	372b5e87-7bf3-5e30-98c4-56a4c19d17fa	1146e928-4d82-581f-84f2-b8c9b6c83378	2026-05-26	02:15:00	Data analysis — Learning Experience	2026-05-26 09:01:00+00	2026-05-26 09:01:00+00	\N	LE-145	a9e0bb14-488c-5643-96ca-5848796322a3	Active	Worklog
03b432fa-bf5b-5259-9c88-8cbe72fcd4af	62445afe-3364-5e78-b55e-fb5429807a47	372b5e87-7bf3-5e30-98c4-56a4c19d17fa	6dfe9630-59ce-507d-81a0-2f94cb54247f	2026-05-28	00:15:00	Data analysis — Fleet Companion	2026-05-28 09:01:00+00	2026-05-28 09:01:00+00	\N	FC-119	eba17d28-b076-534c-918a-dca0a5be8fab	Active	Worklog
92b9bf8b-e426-5e8f-8695-e95a5a36769f	62445afe-3364-5e78-b55e-fb5429807a47	372b5e87-7bf3-5e30-98c4-56a4c19d17fa	f07ee933-bae1-5f0f-9e95-6c303aba6f5d	2026-05-31	02:15:00	Data analysis — Open Banking Integration	2026-05-31 09:01:00+00	2026-05-31 09:01:00+00	\N	OBI-166	f4c5b0e8-5503-5a50-8487-4ae103b885f2	Active	Worklog
e081d864-b96b-5314-ae62-e3fd7ca7b4c5	62445afe-3364-5e78-b55e-fb5429807a47	372b5e87-7bf3-5e30-98c4-56a4c19d17fa	1146e928-4d82-581f-84f2-b8c9b6c83378	2026-06-02	00:15:00	Data analysis — Learning Experience	2026-06-02 09:01:00+00	2026-06-02 09:01:00+00	\N	LE-140	a9e0bb14-488c-5643-96ca-5848796322a3	Active	Worklog
3476d421-5d30-5af0-8041-0f5ad3a909c5	62445afe-3364-5e78-b55e-fb5429807a47	372b5e87-7bf3-5e30-98c4-56a4c19d17fa	1146e928-4d82-581f-84f2-b8c9b6c83378	2026-06-03	00:00:00	Discovery follow-up zaplanowany na kolejny tydzień — Learning Experience	2026-06-03 09:01:00+00	2026-06-03 09:01:00+00	\N	\N	a9e0bb14-488c-5643-96ca-5848796322a3	Active	Note
0dc6296f-9bb4-543b-abf3-9097f7f629f7	62445afe-3364-5e78-b55e-fb5429807a47	372b5e87-7bf3-5e30-98c4-56a4c19d17fa	6dfe9630-59ce-507d-81a0-2f94cb54247f	2026-06-04	02:15:00	Data analysis — Fleet Companion	2026-06-04 09:01:00+00	2026-06-04 09:01:00+00	\N	FC-114	eba17d28-b076-534c-918a-dca0a5be8fab	Active	Worklog
abfee7b2-6ec2-50d8-a9fd-d61f678bcbde	62445afe-3364-5e78-b55e-fb5429807a47	372b5e87-7bf3-5e30-98c4-56a4c19d17fa	f07ee933-bae1-5f0f-9e95-6c303aba6f5d	2026-06-08	00:15:00	Data analysis — Open Banking Integration	2026-06-08 09:01:00+00	2026-06-08 09:01:00+00	\N	OBI-161	f4c5b0e8-5503-5a50-8487-4ae103b885f2	Active	Worklog
8525c95b-9946-54cf-8f94-dffa4ae000f6	62445afe-3364-5e78-b55e-fb5429807a47	372b5e87-7bf3-5e30-98c4-56a4c19d17fa	1146e928-4d82-581f-84f2-b8c9b6c83378	2026-06-10	02:15:00	Data analysis — Learning Experience	2026-06-10 09:01:00+00	2026-06-10 09:01:00+00	\N	LE-135	a9e0bb14-488c-5643-96ca-5848796322a3	Active	Worklog
6b265ffb-c3bc-5dc5-af9a-6dd5d72a4159	62445afe-3364-5e78-b55e-fb5429807a47	372b5e87-7bf3-5e30-98c4-56a4c19d17fa	f07ee933-bae1-5f0f-9e95-6c303aba6f5d	2026-06-11	02:45:00	Data analysis — Open Banking Integration	2026-06-11 09:01:00+00	2026-06-11 09:01:00+00	\N	OBI-154	f4c5b0e8-5503-5a50-8487-4ae103b885f2	Active	Worklog
2f79273a-8dbe-52cb-97b3-be9308f0496c	62445afe-3364-5e78-b55e-fb5429807a47	372b5e87-7bf3-5e30-98c4-56a4c19d17fa	6dfe9630-59ce-507d-81a0-2f94cb54247f	2026-06-12	00:15:00	Data analysis — Fleet Companion	2026-06-12 09:01:00+00	2026-06-12 09:01:00+00	\N	FC-109	eba17d28-b076-534c-918a-dca0a5be8fab	Active	Worklog
ebda343a-e7fd-5400-b377-a6c7236e3a9d	62445afe-3364-5e78-b55e-fb5429807a47	372b5e87-7bf3-5e30-98c4-56a4c19d17fa	1146e928-4d82-581f-84f2-b8c9b6c83378	2026-06-14	00:45:00	Data analysis — Learning Experience	2026-06-14 09:01:00+00	2026-06-14 09:01:00+00	\N	LE-128	a9e0bb14-488c-5643-96ca-5848796322a3	Active	Worklog
f550e27f-f2d0-546d-b5cc-5062c638bb7d	62445afe-3364-5e78-b55e-fb5429807a47	372b5e87-7bf3-5e30-98c4-56a4c19d17fa	6dfe9630-59ce-507d-81a0-2f94cb54247f	2026-06-16	02:45:00	Data analysis — Fleet Companion	2026-06-16 09:01:00+00	2026-06-16 09:01:00+00	\N	FC-102	eba17d28-b076-534c-918a-dca0a5be8fab	Active	Worklog
03379d4a-bcd4-588b-a354-a2331b8e2bde	62445afe-3364-5e78-b55e-fb5429807a47	372b5e87-7bf3-5e30-98c4-56a4c19d17fa	f07ee933-bae1-5f0f-9e95-6c303aba6f5d	2026-06-18	00:45:00	Data analysis — Open Banking Integration	2026-06-18 09:01:00+00	2026-06-18 09:01:00+00	\N	OBI-149	f4c5b0e8-5503-5a50-8487-4ae103b885f2	Active	Worklog
de6145ea-cee1-55c1-afd4-1972fb5d1905	62445afe-3364-5e78-b55e-fb5429807a47	372b5e87-7bf3-5e30-98c4-56a4c19d17fa	1146e928-4d82-581f-84f2-b8c9b6c83378	2026-06-22	02:45:00	Data analysis — Learning Experience	2026-06-22 09:01:00+00	2026-06-22 09:01:00+00	\N	LE-123	a9e0bb14-488c-5643-96ca-5848796322a3	Active	Worklog
590d871b-41af-5741-a302-b4bfd794b81c	62445afe-3364-5e78-b55e-fb5429807a47	372b5e87-7bf3-5e30-98c4-56a4c19d17fa	6dfe9630-59ce-507d-81a0-2f94cb54247f	2026-06-24	00:45:00	Data analysis — Fleet Companion	2026-06-24 09:01:00+00	2026-06-24 09:01:00+00	\N	FC-170	eba17d28-b076-534c-918a-dca0a5be8fab	Active	Worklog
5d9a138f-5d85-5592-b81c-94173ea9435c	62445afe-3364-5e78-b55e-fb5429807a47	372b5e87-7bf3-5e30-98c4-56a4c19d17fa	6dfe9630-59ce-507d-81a0-2f94cb54247f	2026-06-25	00:00:00	Discovery follow-up zaplanowany na kolejny tydzień — Fleet Companion	2026-06-25 09:01:00+00	2026-06-25 09:01:00+00	\N	\N	eba17d28-b076-534c-918a-dca0a5be8fab	Active	Note
c1b3b5ce-672e-5ea0-8775-ed1e863b64b9	62445afe-3364-5e78-b55e-fb5429807a47	372b5e87-7bf3-5e30-98c4-56a4c19d17fa	f07ee933-bae1-5f0f-9e95-6c303aba6f5d	2026-06-26	02:45:00	Data analysis — Open Banking Integration	2026-06-26 09:01:00+00	2026-06-26 09:01:00+00	\N	OBI-144	f4c5b0e8-5503-5a50-8487-4ae103b885f2	Active	Worklog
e7799fab-6801-59f9-b644-a6b0adc51c29	62445afe-3364-5e78-b55e-fb5429807a47	372b5e87-7bf3-5e30-98c4-56a4c19d17fa	1146e928-4d82-581f-84f2-b8c9b6c83378	2026-06-29	00:45:00	Data analysis — Learning Experience	2026-06-29 09:01:00+00	2026-06-29 09:01:00+00	\N	LE-118	a9e0bb14-488c-5643-96ca-5848796322a3	Active	Worklog
085955d2-efbd-51bf-a7a6-33f3aee4242b	62445afe-3364-5e78-b55e-fb5429807a47	372b5e87-7bf3-5e30-98c4-56a4c19d17fa	3d5d3faf-2bbd-5bca-ac00-1c6056bf7ca6	2026-06-29	00:15:00	Historical delivery wrap-up — Dispatch Optimizer	2026-06-29 09:02:00+00	2026-06-29 09:02:00+00	2026-07-13 00:00:00+00	DOP-916	141122b1-9a71-570d-a44c-efc88209be99	Archived	Worklog
5fa92017-d6f7-5638-8bf4-b8352c07cc18	62445afe-3364-5e78-b55e-fb5429807a47	372b5e87-7bf3-5e30-98c4-56a4c19d17fa	6dfe9630-59ce-507d-81a0-2f94cb54247f	2026-07-01	02:45:00	Data analysis — Fleet Companion	2026-07-01 09:01:00+00	2026-07-01 09:01:00+00	\N	FC-165	eba17d28-b076-534c-918a-dca0a5be8fab	Active	Worklog
7edef733-8492-5cb6-b7e6-6d905b878433	62445afe-3364-5e78-b55e-fb5429807a47	372b5e87-7bf3-5e30-98c4-56a4c19d17fa	1146e928-4d82-581f-84f2-b8c9b6c83378	2026-07-02	03:15:00	Data analysis — Learning Experience	2026-07-02 09:01:00+00	2026-07-02 09:01:00+00	\N	LE-111	a9e0bb14-488c-5643-96ca-5848796322a3	Active	Worklog
c6f20c80-3b9a-5530-978e-77ab3f693874	62445afe-3364-5e78-b55e-fb5429807a47	372b5e87-7bf3-5e30-98c4-56a4c19d17fa	3d5d3faf-2bbd-5bca-ac00-1c6056bf7ca6	2026-07-02	03:45:00	Historical delivery wrap-up — Dispatch Optimizer	2026-07-02 09:02:00+00	2026-07-02 09:02:00+00	2026-07-13 00:00:00+00	DOP-934	141122b1-9a71-570d-a44c-efc88209be99	Archived	Worklog
1087f5a9-1e43-55e4-8a8b-607ea6ccd290	62445afe-3364-5e78-b55e-fb5429807a47	372b5e87-7bf3-5e30-98c4-56a4c19d17fa	f07ee933-bae1-5f0f-9e95-6c303aba6f5d	2026-07-03	00:45:00	Data analysis — Open Banking Integration	2026-07-03 09:01:00+00	2026-07-03 09:01:00+00	\N	OBI-139	f4c5b0e8-5503-5a50-8487-4ae103b885f2	Active	Worklog
095ccb5b-2e53-59ee-9397-5a6ed17de244	62445afe-3364-5e78-b55e-fb5429807a47	372b5e87-7bf3-5e30-98c4-56a4c19d17fa	3d5d3faf-2bbd-5bca-ac00-1c6056bf7ca6	2026-07-05	03:15:00	Historical delivery wrap-up — Dispatch Optimizer	2026-07-05 09:01:00+00	2026-07-05 09:01:00+00	2026-07-13 00:00:00+00	DOP-952	141122b1-9a71-570d-a44c-efc88209be99	Archived	Worklog
69afa25a-6252-5233-8394-1d28b7d50c1e	62445afe-3364-5e78-b55e-fb5429807a47	372b5e87-7bf3-5e30-98c4-56a4c19d17fa	6dfe9630-59ce-507d-81a0-2f94cb54247f	2026-07-06	01:15:00	Data analysis — Fleet Companion	2026-07-06 09:01:00+00	2026-07-06 09:01:00+00	\N	FC-158	eba17d28-b076-534c-918a-dca0a5be8fab	Active	Worklog
79f92174-ad36-5b84-bba9-115f6e22d49f	62445afe-3364-5e78-b55e-fb5429807a47	372b5e87-7bf3-5e30-98c4-56a4c19d17fa	f07ee933-bae1-5f0f-9e95-6c303aba6f5d	2026-07-08	03:15:00	Data analysis — Open Banking Integration	2026-07-08 09:01:00+00	2026-07-08 09:01:00+00	\N	OBI-132	f4c5b0e8-5503-5a50-8487-4ae103b885f2	Active	Worklog
64daf7ce-8b5a-5ecf-a6e6-40309c12a181	62445afe-3364-5e78-b55e-fb5429807a47	372b5e87-7bf3-5e30-98c4-56a4c19d17fa	1146e928-4d82-581f-84f2-b8c9b6c83378	2026-07-10	01:15:00	Data analysis — Learning Experience	2026-07-10 09:01:00+00	2026-07-10 09:01:00+00	\N	LE-106	a9e0bb14-488c-5643-96ca-5848796322a3	Active	Worklog
89314d98-c9f7-5bad-a828-be12cbf4da62	62445afe-3364-5e78-b55e-fb5429807a47	372b5e87-7bf3-5e30-98c4-56a4c19d17fa	6dfe9630-59ce-507d-81a0-2f94cb54247f	2026-07-13	03:15:00	Data analysis — Fleet Companion	2026-07-13 09:01:00+00	2026-07-13 09:01:00+00	\N	FC-153	eba17d28-b076-534c-918a-dca0a5be8fab	Active	Worklog
7d047715-a511-540a-bf28-91542b1d9de4	62445afe-3364-5e78-b55e-fb5429807a47	372b5e87-7bf3-5e30-98c4-56a4c19d17fa	f07ee933-bae1-5f0f-9e95-6c303aba6f5d	2026-07-15	01:15:00	Data analysis — Open Banking Integration	2026-07-15 09:01:00+00	2026-07-15 09:01:00+00	\N	OBI-127	f4c5b0e8-5503-5a50-8487-4ae103b885f2	Active	Worklog
3472645b-7722-5925-aea0-b7792ab41ac6	62445afe-3364-5e78-b55e-fb5429807a47	372b5e87-7bf3-5e30-98c4-56a4c19d17fa	f07ee933-bae1-5f0f-9e95-6c303aba6f5d	2026-07-16	00:00:00	Discovery follow-up zaplanowany na kolejny tydzień — Open Banking Integration	2026-07-16 09:01:00+00	2026-07-16 09:01:00+00	\N	\N	f4c5b0e8-5503-5a50-8487-4ae103b885f2	Active	Note
5cba3b93-7ce6-513e-bde6-46db4d728032	62445afe-3364-5e78-b55e-fb5429807a47	372b5e87-7bf3-5e30-98c4-56a4c19d17fa	1146e928-4d82-581f-84f2-b8c9b6c83378	2026-07-17	03:15:00	Data analysis — Learning Experience	2026-07-17 09:01:00+00	2026-07-17 09:01:00+00	\N	LE-101	a9e0bb14-488c-5643-96ca-5848796322a3	Active	Worklog
a71fdd27-5a18-5501-9359-8c1ffa350f9f	62445afe-3364-5e78-b55e-fb5429807a47	372b5e87-7bf3-5e30-98c4-56a4c19d17fa	6dfe9630-59ce-507d-81a0-2f94cb54247f	2026-07-21	01:15:00	Data analysis — Fleet Companion	2026-07-21 09:01:00+00	2026-07-21 09:01:00+00	\N	FC-148	eba17d28-b076-534c-918a-dca0a5be8fab	Active	Worklog
00559428-5bcd-5d1f-a1ed-c11c8fc30c9e	62445afe-3364-5e78-b55e-fb5429807a47	372b5e87-7bf3-5e30-98c4-56a4c19d17fa	f07ee933-bae1-5f0f-9e95-6c303aba6f5d	2026-07-23	03:15:00	Data analysis — Open Banking Integration	2026-07-23 09:01:00+00	2026-07-23 09:01:00+00	\N	OBI-122	f4c5b0e8-5503-5a50-8487-4ae103b885f2	Active	Worklog
e47e4916-e564-5f75-bab3-21222724a36f	62445afe-3364-5e78-b55e-fb5429807a47	372b5e87-7bf3-5e30-98c4-56a4c19d17fa	6dfe9630-59ce-507d-81a0-2f94cb54247f	2026-07-24	03:45:00	Data analysis — Fleet Companion	2026-07-24 09:01:00+00	2026-07-24 09:01:00+00	\N	FC-141	eba17d28-b076-534c-918a-dca0a5be8fab	Active	Worklog
3ebb075b-4338-568e-99ea-8ac74e1fbc7e	62445afe-3364-5e78-b55e-fb5429807a47	372b5e87-7bf3-5e30-98c4-56a4c19d17fa	1146e928-4d82-581f-84f2-b8c9b6c83378	2026-07-26	01:15:00	Data analysis — Learning Experience	2026-07-26 09:01:00+00	2026-07-26 09:01:00+00	\N	LE-169	a9e0bb14-488c-5643-96ca-5848796322a3	Active	Worklog
c1dd59bf-cfcd-5f50-b751-4cd626a0e1bb	62445afe-3364-5e78-b55e-fb5429807a47	372b5e87-7bf3-5e30-98c4-56a4c19d17fa	f07ee933-bae1-5f0f-9e95-6c303aba6f5d	2026-07-27	01:45:00	Data analysis — Open Banking Integration	2026-07-27 09:01:00+00	2026-07-27 09:01:00+00	\N	OBI-115	f4c5b0e8-5503-5a50-8487-4ae103b885f2	Active	Worklog
6455c1cd-dba4-5ac7-85a2-a0d3cb1d9b9b	62445afe-3364-5e78-b55e-fb5429807a47	372b5e87-7bf3-5e30-98c4-56a4c19d17fa	1146e928-4d82-581f-84f2-b8c9b6c83378	2026-07-29	03:45:00	Data analysis — Learning Experience	2026-07-29 09:01:00+00	2026-07-29 09:01:00+00	\N	LE-162	a9e0bb14-488c-5643-96ca-5848796322a3	Active	Worklog
9792c30f-c71d-5117-a1e9-f24fa0c5da58	62445afe-3364-5e78-b55e-fb5429807a47	372b5e87-7bf3-5e30-98c4-56a4c19d17fa	6dfe9630-59ce-507d-81a0-2f94cb54247f	2026-07-31	01:45:00	Data analysis — Fleet Companion	2026-07-31 09:01:00+00	2026-07-31 09:01:00+00	\N	FC-136	eba17d28-b076-534c-918a-dca0a5be8fab	Active	Worklog
646735e2-ff3e-5d1b-ad7c-d518f89c965a	62445afe-3364-5e78-b55e-fb5429807a47	372b5e87-7bf3-5e30-98c4-56a4c19d17fa	f07ee933-bae1-5f0f-9e95-6c303aba6f5d	2026-08-04	03:45:00	Data analysis — Open Banking Integration	2026-08-04 09:01:00+00	2026-08-04 09:01:00+00	\N	OBI-110	f4c5b0e8-5503-5a50-8487-4ae103b885f2	Active	Worklog
c98d5141-121f-5009-be71-25fd3175111f	62445afe-3364-5e78-b55e-fb5429807a47	372b5e87-7bf3-5e30-98c4-56a4c19d17fa	1146e928-4d82-581f-84f2-b8c9b6c83378	2026-08-06	01:45:00	Data analysis — Learning Experience	2026-08-06 09:01:00+00	2026-08-06 09:01:00+00	\N	LE-157	a9e0bb14-488c-5643-96ca-5848796322a3	Active	Worklog
201c18b0-4694-523d-8faa-4e775a60c566	62445afe-3364-5e78-b55e-fb5429807a47	372b5e87-7bf3-5e30-98c4-56a4c19d17fa	6dfe9630-59ce-507d-81a0-2f94cb54247f	2026-08-09	03:45:00	Data analysis — Fleet Companion	2026-08-09 09:01:00+00	2026-08-09 09:01:00+00	\N	FC-131	eba17d28-b076-534c-918a-dca0a5be8fab	Active	Worklog
c3816444-a5a2-50c9-a2be-ed4cc459e191	62445afe-3364-5e78-b55e-fb5429807a47	372b5e87-7bf3-5e30-98c4-56a4c19d17fa	f07ee933-bae1-5f0f-9e95-6c303aba6f5d	2026-08-11	01:45:00	Data analysis — Open Banking Integration	2026-08-11 09:01:00+00	2026-08-11 09:01:00+00	\N	OBI-105	f4c5b0e8-5503-5a50-8487-4ae103b885f2	Active	Worklog
f3831e8e-0a24-576e-8088-6007ae10341a	62445afe-3364-5e78-b55e-fb5429807a47	97447306-b2af-5ad3-a0bb-ab876cfe713a	9406b74a-6b7a-578b-8fbd-958684d93780	2026-05-20	03:00:00	Regression testing — Patient Portal	2026-05-20 09:01:00+00	2026-05-20 09:01:00+00	\N	PP-113	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
558151f9-21c1-5bb5-b6e0-8d41fb2d2123	62445afe-3364-5e78-b55e-fb5429807a47	97447306-b2af-5ad3-a0bb-ab876cfe713a	f04245fa-9e0e-5905-80fa-524e9f1e172f	2026-05-21	00:30:00	Regression testing — Delivery Operations Hub	2026-05-21 09:01:00+00	2026-05-21 09:01:00+00	\N	DOH-141	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
65cb7d97-e74a-5a35-8ceb-893d1d47d03f	62445afe-3364-5e78-b55e-fb5429807a47	97447306-b2af-5ad3-a0bb-ab876cfe713a	9406b74a-6b7a-578b-8fbd-958684d93780	2026-05-22	01:00:00	Regression testing — Patient Portal	2026-05-22 09:01:00+00	2026-05-22 09:01:00+00	\N	PP-160	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
2ddfca2c-6f21-5934-85df-5ef7f2631233	62445afe-3364-5e78-b55e-fb5429807a47	97447306-b2af-5ad3-a0bb-ab876cfe713a	f04245fa-9e0e-5905-80fa-524e9f1e172f	2026-05-25	02:30:00	Regression testing — Delivery Operations Hub	2026-05-25 09:01:00+00	2026-05-25 09:01:00+00	\N	DOH-115	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
d220a636-eb95-5344-ac73-822a3dc5ebe7	62445afe-3364-5e78-b55e-fb5429807a47	97447306-b2af-5ad3-a0bb-ab876cfe713a	9406b74a-6b7a-578b-8fbd-958684d93780	2026-05-26	03:00:00	Regression testing — Patient Portal	2026-05-26 09:01:00+00	2026-05-26 09:01:00+00	\N	PP-134	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
98fb4fbb-746b-5423-840d-46abe93ff182	62445afe-3364-5e78-b55e-fb5429807a47	97447306-b2af-5ad3-a0bb-ab876cfe713a	9406b74a-6b7a-578b-8fbd-958684d93780	2026-05-28	01:00:00	Regression testing — Patient Portal	2026-05-28 09:01:00+00	2026-05-28 09:01:00+00	\N	PP-108	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
353bee86-3c4a-5175-85a7-d115ea86929d	62445afe-3364-5e78-b55e-fb5429807a47	97447306-b2af-5ad3-a0bb-ab876cfe713a	9406b74a-6b7a-578b-8fbd-958684d93780	2026-05-31	03:00:00	Regression testing — Patient Portal	2026-05-31 09:01:00+00	2026-05-31 09:01:00+00	\N	PP-155	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
3679f2e9-820e-58e7-b439-c887fb5338ad	62445afe-3364-5e78-b55e-fb5429807a47	97447306-b2af-5ad3-a0bb-ab876cfe713a	9406b74a-6b7a-578b-8fbd-958684d93780	2026-06-02	01:00:00	Regression testing — Patient Portal	2026-06-02 09:01:00+00	2026-06-02 09:01:00+00	\N	PP-129	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
38bdd134-cec1-5970-8872-3f4072932da3	62445afe-3364-5e78-b55e-fb5429807a47	97447306-b2af-5ad3-a0bb-ab876cfe713a	f04245fa-9e0e-5905-80fa-524e9f1e172f	2026-06-03	00:00:00	Decyzja zakresowa potwierdzona z zespołem — Delivery Operations Hub	2026-06-03 09:01:00+00	2026-06-03 09:01:00+00	\N	\N	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Note
6f5dd163-eb1d-588f-8ebd-64b0a090aea4	62445afe-3364-5e78-b55e-fb5429807a47	97447306-b2af-5ad3-a0bb-ab876cfe713a	9406b74a-6b7a-578b-8fbd-958684d93780	2026-06-04	03:00:00	Regression testing — Patient Portal	2026-06-04 09:01:00+00	2026-06-04 09:01:00+00	\N	PP-103	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
8e2f61cb-b761-5e44-9790-bb17224072f2	62445afe-3364-5e78-b55e-fb5429807a47	97447306-b2af-5ad3-a0bb-ab876cfe713a	9406b74a-6b7a-578b-8fbd-958684d93780	2026-06-08	01:00:00	Regression testing — Patient Portal	2026-06-08 09:01:00+00	2026-06-08 09:01:00+00	\N	PP-150	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
c10977c4-4ce2-5c5e-8fc8-41e202baaefe	62445afe-3364-5e78-b55e-fb5429807a47	97447306-b2af-5ad3-a0bb-ab876cfe713a	9406b74a-6b7a-578b-8fbd-958684d93780	2026-06-10	03:00:00	Regression testing — Patient Portal	2026-06-10 09:01:00+00	2026-06-10 09:01:00+00	\N	PP-124	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
1159532a-7587-5da3-b1d3-e7e1d8b332f0	62445afe-3364-5e78-b55e-fb5429807a47	97447306-b2af-5ad3-a0bb-ab876cfe713a	f07ee933-bae1-5f0f-9e95-6c303aba6f5d	2026-06-11	03:30:00	Regression testing — Open Banking Integration	2026-06-11 09:01:00+00	2026-06-11 09:01:00+00	\N	OBI-143	f4c5b0e8-5503-5a50-8487-4ae103b885f2	Active	Worklog
77dfb896-5a8d-5c41-b416-28ce16426b24	62445afe-3364-5e78-b55e-fb5429807a47	97447306-b2af-5ad3-a0bb-ab876cfe713a	9406b74a-6b7a-578b-8fbd-958684d93780	2026-06-12	01:00:00	Regression testing — Patient Portal	2026-06-12 09:01:00+00	2026-06-12 09:01:00+00	\N	PP-171	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
71444c00-4f7a-56e0-9547-6d3e2f419927	62445afe-3364-5e78-b55e-fb5429807a47	97447306-b2af-5ad3-a0bb-ab876cfe713a	f07ee933-bae1-5f0f-9e95-6c303aba6f5d	2026-06-14	01:30:00	Regression testing — Open Banking Integration	2026-06-14 09:01:00+00	2026-06-14 09:01:00+00	\N	OBI-117	f4c5b0e8-5503-5a50-8487-4ae103b885f2	Active	Worklog
a54bf76b-8b3c-5582-9206-951b16df771f	62445afe-3364-5e78-b55e-fb5429807a47	97447306-b2af-5ad3-a0bb-ab876cfe713a	f07ee933-bae1-5f0f-9e95-6c303aba6f5d	2026-06-16	03:30:00	Regression testing — Open Banking Integration	2026-06-16 09:01:00+00	2026-06-16 09:01:00+00	\N	OBI-164	f4c5b0e8-5503-5a50-8487-4ae103b885f2	Active	Worklog
e8d9e89e-a092-53d0-9427-48d989641b26	62445afe-3364-5e78-b55e-fb5429807a47	97447306-b2af-5ad3-a0bb-ab876cfe713a	f07ee933-bae1-5f0f-9e95-6c303aba6f5d	2026-06-18	01:30:00	Regression testing — Open Banking Integration	2026-06-18 09:01:00+00	2026-06-18 09:01:00+00	\N	OBI-138	f4c5b0e8-5503-5a50-8487-4ae103b885f2	Active	Worklog
c2323b27-09f5-54dc-9118-75d33cb9e306	62445afe-3364-5e78-b55e-fb5429807a47	97447306-b2af-5ad3-a0bb-ab876cfe713a	f07ee933-bae1-5f0f-9e95-6c303aba6f5d	2026-06-22	03:30:00	Regression testing — Open Banking Integration	2026-06-22 09:01:00+00	2026-06-22 09:01:00+00	\N	OBI-112	f4c5b0e8-5503-5a50-8487-4ae103b885f2	Active	Worklog
4ce61bf0-a48a-5b66-875f-563127e35a50	62445afe-3364-5e78-b55e-fb5429807a47	97447306-b2af-5ad3-a0bb-ab876cfe713a	f07ee933-bae1-5f0f-9e95-6c303aba6f5d	2026-06-24	01:30:00	Regression testing — Open Banking Integration	2026-06-24 09:01:00+00	2026-06-24 09:01:00+00	\N	OBI-159	f4c5b0e8-5503-5a50-8487-4ae103b885f2	Active	Worklog
7cde6542-d0ff-51aa-9cb5-e128a0335802	62445afe-3364-5e78-b55e-fb5429807a47	97447306-b2af-5ad3-a0bb-ab876cfe713a	9406b74a-6b7a-578b-8fbd-958684d93780	2026-06-25	00:00:00	Decyzja zakresowa potwierdzona z zespołem — Patient Portal	2026-06-25 09:01:00+00	2026-06-25 09:01:00+00	\N	\N	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Note
4aaf2f3c-d348-5d30-9d3b-d79c51a89fb5	62445afe-3364-5e78-b55e-fb5429807a47	97447306-b2af-5ad3-a0bb-ab876cfe713a	f07ee933-bae1-5f0f-9e95-6c303aba6f5d	2026-06-26	03:30:00	Regression testing — Open Banking Integration	2026-06-26 09:01:00+00	2026-06-26 09:01:00+00	\N	OBI-133	f4c5b0e8-5503-5a50-8487-4ae103b885f2	Active	Worklog
3f0c210a-ced8-573f-be1a-93935e20cd34	62445afe-3364-5e78-b55e-fb5429807a47	97447306-b2af-5ad3-a0bb-ab876cfe713a	613fe369-ab85-5812-9136-0d147b91706d	2026-06-28	02:30:00	Historical delivery wrap-up — Mobility Discovery	2026-06-28 09:01:00+00	2026-06-28 09:01:00+00	2026-07-13 00:00:00+00	MD-915	eba17d28-b076-534c-918a-dca0a5be8fab	Archived	Worklog
2403e9e8-b551-5145-a47f-1c8511147750	62445afe-3364-5e78-b55e-fb5429807a47	97447306-b2af-5ad3-a0bb-ab876cfe713a	f07ee933-bae1-5f0f-9e95-6c303aba6f5d	2026-06-29	01:30:00	Regression testing — Open Banking Integration	2026-06-29 09:01:00+00	2026-06-29 09:01:00+00	\N	OBI-107	f4c5b0e8-5503-5a50-8487-4ae103b885f2	Active	Worklog
89299e02-784b-5795-854e-c770ab6466fa	62445afe-3364-5e78-b55e-fb5429807a47	97447306-b2af-5ad3-a0bb-ab876cfe713a	f07ee933-bae1-5f0f-9e95-6c303aba6f5d	2026-07-01	03:30:00	Regression testing — Open Banking Integration	2026-07-01 09:01:00+00	2026-07-01 09:01:00+00	\N	OBI-154	f4c5b0e8-5503-5a50-8487-4ae103b885f2	Active	Worklog
17574be8-f272-566c-9786-5ad1dcada7e2	62445afe-3364-5e78-b55e-fb5429807a47	97447306-b2af-5ad3-a0bb-ab876cfe713a	613fe369-ab85-5812-9136-0d147b91706d	2026-07-01	01:30:00	Historical delivery wrap-up — Mobility Discovery	2026-07-01 09:02:00+00	2026-07-01 09:02:00+00	2026-07-13 00:00:00+00	MD-903	eba17d28-b076-534c-918a-dca0a5be8fab	Archived	Worklog
35e77962-261f-536e-8977-99682a57df58	62445afe-3364-5e78-b55e-fb5429807a47	97447306-b2af-5ad3-a0bb-ab876cfe713a	1146e928-4d82-581f-84f2-b8c9b6c83378	2026-07-02	04:00:00	Regression testing — Learning Experience	2026-07-02 09:01:00+00	2026-07-02 09:01:00+00	\N	LE-100	a9e0bb14-488c-5643-96ca-5848796322a3	Active	Worklog
5fdbdb3a-e946-5dfb-87df-e5d404b3c0e4	62445afe-3364-5e78-b55e-fb5429807a47	97447306-b2af-5ad3-a0bb-ab876cfe713a	f07ee933-bae1-5f0f-9e95-6c303aba6f5d	2026-07-03	01:30:00	Regression testing — Open Banking Integration	2026-07-03 09:01:00+00	2026-07-03 09:01:00+00	\N	OBI-128	f4c5b0e8-5503-5a50-8487-4ae103b885f2	Active	Worklog
8ca2df7c-00cf-513c-b33f-0cf029dcf142	62445afe-3364-5e78-b55e-fb5429807a47	97447306-b2af-5ad3-a0bb-ab876cfe713a	613fe369-ab85-5812-9136-0d147b91706d	2026-07-04	01:30:00	Historical delivery wrap-up — Mobility Discovery	2026-07-04 09:01:00+00	2026-07-04 09:01:00+00	2026-07-13 00:00:00+00	MD-951	eba17d28-b076-534c-918a-dca0a5be8fab	Archived	Worklog
b8ddf1c8-1ead-525d-8db5-f3d2f259f3d6	62445afe-3364-5e78-b55e-fb5429807a47	97447306-b2af-5ad3-a0bb-ab876cfe713a	1146e928-4d82-581f-84f2-b8c9b6c83378	2026-07-06	02:00:00	Regression testing — Learning Experience	2026-07-06 09:01:00+00	2026-07-06 09:01:00+00	\N	LE-147	a9e0bb14-488c-5643-96ca-5848796322a3	Active	Worklog
8308b57c-081f-5e98-a9e7-0fa0eb43b085	62445afe-3364-5e78-b55e-fb5429807a47	97447306-b2af-5ad3-a0bb-ab876cfe713a	613fe369-ab85-5812-9136-0d147b91706d	2026-07-07	00:30:00	Historical delivery wrap-up — Mobility Discovery	2026-07-07 09:01:00+00	2026-07-07 09:01:00+00	2026-07-13 00:00:00+00	MD-939	eba17d28-b076-534c-918a-dca0a5be8fab	Archived	Worklog
596149a7-e2b3-5599-afb1-36853825df0c	62445afe-3364-5e78-b55e-fb5429807a47	97447306-b2af-5ad3-a0bb-ab876cfe713a	1146e928-4d82-581f-84f2-b8c9b6c83378	2026-07-08	04:00:00	Regression testing — Learning Experience	2026-07-08 09:01:00+00	2026-07-08 09:01:00+00	\N	LE-121	a9e0bb14-488c-5643-96ca-5848796322a3	Active	Worklog
bc3da950-29d5-5197-8271-d1d47268bbfb	62445afe-3364-5e78-b55e-fb5429807a47	97447306-b2af-5ad3-a0bb-ab876cfe713a	1146e928-4d82-581f-84f2-b8c9b6c83378	2026-07-10	02:00:00	Regression testing — Learning Experience	2026-07-10 09:01:00+00	2026-07-10 09:01:00+00	\N	LE-168	a9e0bb14-488c-5643-96ca-5848796322a3	Active	Worklog
fe565db1-a79d-5b2f-aa16-c7c99e619657	62445afe-3364-5e78-b55e-fb5429807a47	97447306-b2af-5ad3-a0bb-ab876cfe713a	613fe369-ab85-5812-9136-0d147b91706d	2026-07-10	03:30:00	Historical delivery wrap-up — Mobility Discovery	2026-07-10 09:02:00+00	2026-07-10 09:02:00+00	2026-07-13 00:00:00+00	MD-927	eba17d28-b076-534c-918a-dca0a5be8fab	Archived	Worklog
0b8f593a-175b-580a-9651-269aaf7a515b	62445afe-3364-5e78-b55e-fb5429807a47	97447306-b2af-5ad3-a0bb-ab876cfe713a	1146e928-4d82-581f-84f2-b8c9b6c83378	2026-07-13	04:00:00	Regression testing — Learning Experience	2026-07-13 09:01:00+00	2026-07-13 09:01:00+00	\N	LE-142	a9e0bb14-488c-5643-96ca-5848796322a3	Active	Worklog
b78eb1fa-8c66-5bdd-9295-2b698e0f0243	62445afe-3364-5e78-b55e-fb5429807a47	97447306-b2af-5ad3-a0bb-ab876cfe713a	1146e928-4d82-581f-84f2-b8c9b6c83378	2026-07-15	02:00:00	Regression testing — Learning Experience	2026-07-15 09:01:00+00	2026-07-15 09:01:00+00	\N	LE-116	a9e0bb14-488c-5643-96ca-5848796322a3	Active	Worklog
7b97e3b1-927b-54bd-b43a-8bfbddd04e78	62445afe-3364-5e78-b55e-fb5429807a47	97447306-b2af-5ad3-a0bb-ab876cfe713a	f07ee933-bae1-5f0f-9e95-6c303aba6f5d	2026-07-16	00:00:00	Decyzja zakresowa potwierdzona z zespołem — Open Banking Integration	2026-07-16 09:01:00+00	2026-07-16 09:01:00+00	\N	\N	f4c5b0e8-5503-5a50-8487-4ae103b885f2	Active	Note
c9ad1cc9-5959-5fae-b0b4-6deb080dadd7	62445afe-3364-5e78-b55e-fb5429807a47	97447306-b2af-5ad3-a0bb-ab876cfe713a	1146e928-4d82-581f-84f2-b8c9b6c83378	2026-07-17	04:00:00	Regression testing — Learning Experience	2026-07-17 09:01:00+00	2026-07-17 09:01:00+00	\N	LE-163	a9e0bb14-488c-5643-96ca-5848796322a3	Active	Worklog
589531c4-739b-5d01-985c-8fbab23c14a2	62445afe-3364-5e78-b55e-fb5429807a47	97447306-b2af-5ad3-a0bb-ab876cfe713a	1146e928-4d82-581f-84f2-b8c9b6c83378	2026-07-21	02:00:00	Regression testing — Learning Experience	2026-07-21 09:01:00+00	2026-07-21 09:01:00+00	\N	LE-137	a9e0bb14-488c-5643-96ca-5848796322a3	Active	Worklog
b7b4bfad-a0b8-5b0b-860a-41b6ab98378a	62445afe-3364-5e78-b55e-fb5429807a47	97447306-b2af-5ad3-a0bb-ab876cfe713a	1146e928-4d82-581f-84f2-b8c9b6c83378	2026-07-23	04:00:00	Regression testing — Learning Experience	2026-07-23 09:01:00+00	2026-07-23 09:01:00+00	\N	LE-111	a9e0bb14-488c-5643-96ca-5848796322a3	Active	Worklog
4332b50b-1388-52dd-888c-ff7abe7ef2e5	62445afe-3364-5e78-b55e-fb5429807a47	97447306-b2af-5ad3-a0bb-ab876cfe713a	f04245fa-9e0e-5905-80fa-524e9f1e172f	2026-07-24	00:30:00	Regression testing — Delivery Operations Hub	2026-07-24 09:01:00+00	2026-07-24 09:01:00+00	\N	DOH-130	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
969d586c-8ed6-5d4c-8663-d9e6627957e8	62445afe-3364-5e78-b55e-fb5429807a47	97447306-b2af-5ad3-a0bb-ab876cfe713a	1146e928-4d82-581f-84f2-b8c9b6c83378	2026-07-26	02:00:00	Regression testing — Learning Experience	2026-07-26 09:01:00+00	2026-07-26 09:01:00+00	\N	LE-158	a9e0bb14-488c-5643-96ca-5848796322a3	Active	Worklog
56975eee-9c8f-54f9-a49d-b56a75b64b27	62445afe-3364-5e78-b55e-fb5429807a47	97447306-b2af-5ad3-a0bb-ab876cfe713a	f04245fa-9e0e-5905-80fa-524e9f1e172f	2026-07-27	02:30:00	Regression testing — Delivery Operations Hub	2026-07-27 09:01:00+00	2026-07-27 09:01:00+00	\N	DOH-104	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
f96f7859-5505-5419-944f-303e769857ef	62445afe-3364-5e78-b55e-fb5429807a47	97447306-b2af-5ad3-a0bb-ab876cfe713a	f04245fa-9e0e-5905-80fa-524e9f1e172f	2026-07-29	00:30:00	Regression testing — Delivery Operations Hub	2026-07-29 09:01:00+00	2026-07-29 09:01:00+00	\N	DOH-151	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
e6b34531-b439-523c-b520-6336db33f751	62445afe-3364-5e78-b55e-fb5429807a47	97447306-b2af-5ad3-a0bb-ab876cfe713a	f04245fa-9e0e-5905-80fa-524e9f1e172f	2026-07-31	02:30:00	Regression testing — Delivery Operations Hub	2026-07-31 09:01:00+00	2026-07-31 09:01:00+00	\N	DOH-125	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
0bc2c2c7-5756-56a7-b72d-9bd61aca596e	62445afe-3364-5e78-b55e-fb5429807a47	97447306-b2af-5ad3-a0bb-ab876cfe713a	f04245fa-9e0e-5905-80fa-524e9f1e172f	2026-08-04	00:30:00	Regression testing — Delivery Operations Hub	2026-08-04 09:01:00+00	2026-08-04 09:01:00+00	\N	DOH-172	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
42f7b312-5bc5-585a-ad7d-73c81398055a	62445afe-3364-5e78-b55e-fb5429807a47	97447306-b2af-5ad3-a0bb-ab876cfe713a	f04245fa-9e0e-5905-80fa-524e9f1e172f	2026-08-06	02:30:00	Regression testing — Delivery Operations Hub	2026-08-06 09:01:00+00	2026-08-06 09:01:00+00	\N	DOH-146	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
4217c566-8870-5ff8-b2ab-2066cacb8396	62445afe-3364-5e78-b55e-fb5429807a47	97447306-b2af-5ad3-a0bb-ab876cfe713a	1146e928-4d82-581f-84f2-b8c9b6c83378	2026-08-07	00:00:00	Decyzja zakresowa potwierdzona z zespołem — Learning Experience	2026-08-07 09:01:00+00	2026-08-07 09:01:00+00	\N	\N	a9e0bb14-488c-5643-96ca-5848796322a3	Active	Note
e1eea6c1-505b-5535-82e4-c38d0ff3d165	62445afe-3364-5e78-b55e-fb5429807a47	97447306-b2af-5ad3-a0bb-ab876cfe713a	f04245fa-9e0e-5905-80fa-524e9f1e172f	2026-08-09	00:30:00	Regression testing — Delivery Operations Hub	2026-08-09 09:01:00+00	2026-08-09 09:01:00+00	\N	DOH-120	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
73d154cf-02e9-5969-8022-7443c15de8c8	62445afe-3364-5e78-b55e-fb5429807a47	97447306-b2af-5ad3-a0bb-ab876cfe713a	f04245fa-9e0e-5905-80fa-524e9f1e172f	2026-08-11	02:30:00	Regression testing — Delivery Operations Hub	2026-08-11 09:01:00+00	2026-08-11 09:01:00+00	\N	DOH-167	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
8ddb3bf5-bfac-5978-9d9b-12f72f7f50cd	62445afe-3364-5e78-b55e-fb5429807a47	bb6bdf69-6501-5ad2-9a1b-0148f459d5f3	eb73aa6c-87aa-532d-8b94-109b8b863733	2026-05-20	02:00:00	Implementation and pairing — Design System Evolution	2026-05-20 09:01:00+00	2026-05-20 09:01:00+00	\N	DSE-101	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
85e8131f-3c6a-50f5-91cd-e98f6299230c	62445afe-3364-5e78-b55e-fb5429807a47	bb6bdf69-6501-5ad2-9a1b-0148f459d5f3	f04245fa-9e0e-5905-80fa-524e9f1e172f	2026-05-21	03:30:00	Implementation and pairing — Delivery Operations Hub	2026-05-21 09:01:00+00	2026-05-21 09:01:00+00	\N	DOH-129	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
8bcff2f5-fe26-5a9c-8a4a-17c545cf988a	62445afe-3364-5e78-b55e-fb5429807a47	bb6bdf69-6501-5ad2-9a1b-0148f459d5f3	eb73aa6c-87aa-532d-8b94-109b8b863733	2026-05-22	04:00:00	Implementation and pairing — Design System Evolution	2026-05-22 09:01:00+00	2026-05-22 09:01:00+00	\N	DSE-148	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
ca21e22f-1b7a-5218-a19f-65b506f7c018	62445afe-3364-5e78-b55e-fb5429807a47	bb6bdf69-6501-5ad2-9a1b-0148f459d5f3	f04245fa-9e0e-5905-80fa-524e9f1e172f	2026-05-25	01:30:00	Implementation and pairing — Delivery Operations Hub	2026-05-25 09:01:00+00	2026-05-25 09:01:00+00	\N	DOH-103	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
fc441651-40bb-5fbd-9dfe-86f13b9c6b82	62445afe-3364-5e78-b55e-fb5429807a47	bb6bdf69-6501-5ad2-9a1b-0148f459d5f3	eb73aa6c-87aa-532d-8b94-109b8b863733	2026-05-26	02:00:00	Implementation and pairing — Design System Evolution	2026-05-26 09:01:00+00	2026-05-26 09:01:00+00	\N	DSE-122	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
20b8bafe-22d3-570e-a564-3d3936414d1f	62445afe-3364-5e78-b55e-fb5429807a47	bb6bdf69-6501-5ad2-9a1b-0148f459d5f3	eb73aa6c-87aa-532d-8b94-109b8b863733	2026-05-28	04:00:00	Implementation and pairing — Design System Evolution	2026-05-28 09:01:00+00	2026-05-28 09:01:00+00	\N	DSE-169	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
1fa7abb3-3432-5e52-9ba8-a77fe69ed0fc	62445afe-3364-5e78-b55e-fb5429807a47	bb6bdf69-6501-5ad2-9a1b-0148f459d5f3	eb73aa6c-87aa-532d-8b94-109b8b863733	2026-05-31	02:00:00	Implementation and pairing — Design System Evolution	2026-05-31 09:01:00+00	2026-05-31 09:01:00+00	\N	DSE-143	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
05a149dc-bb0a-555d-b2c6-1587be4f8a99	62445afe-3364-5e78-b55e-fb5429807a47	bb6bdf69-6501-5ad2-9a1b-0148f459d5f3	eb73aa6c-87aa-532d-8b94-109b8b863733	2026-06-02	04:00:00	Implementation and pairing — Design System Evolution	2026-06-02 09:01:00+00	2026-06-02 09:01:00+00	\N	DSE-117	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
02f0d1a3-b725-5cb8-b7b1-7a4a1741b32d	62445afe-3364-5e78-b55e-fb5429807a47	bb6bdf69-6501-5ad2-9a1b-0148f459d5f3	f04245fa-9e0e-5905-80fa-524e9f1e172f	2026-06-03	00:00:00	Decyzja zakresowa potwierdzona z zespołem — Delivery Operations Hub	2026-06-03 09:01:00+00	2026-06-03 09:01:00+00	\N	\N	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Note
25a9f54a-50cd-5741-81dd-71695d9650ab	62445afe-3364-5e78-b55e-fb5429807a47	bb6bdf69-6501-5ad2-9a1b-0148f459d5f3	eb73aa6c-87aa-532d-8b94-109b8b863733	2026-06-04	02:00:00	Implementation and pairing — Design System Evolution	2026-06-04 09:01:00+00	2026-06-04 09:01:00+00	\N	DSE-164	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
f92e1abc-d587-5ddd-9b22-f3f40dc8fd20	62445afe-3364-5e78-b55e-fb5429807a47	bb6bdf69-6501-5ad2-9a1b-0148f459d5f3	eb73aa6c-87aa-532d-8b94-109b8b863733	2026-06-08	04:00:00	Implementation and pairing — Design System Evolution	2026-06-08 09:01:00+00	2026-06-08 09:01:00+00	\N	DSE-138	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
783d9834-491a-5b11-ae53-14e0058fb3c3	62445afe-3364-5e78-b55e-fb5429807a47	bb6bdf69-6501-5ad2-9a1b-0148f459d5f3	eb73aa6c-87aa-532d-8b94-109b8b863733	2026-06-10	02:00:00	Implementation and pairing — Design System Evolution	2026-06-10 09:01:00+00	2026-06-10 09:01:00+00	\N	DSE-112	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
112fd690-2cab-5765-8f4b-bfa9ef585132	62445afe-3364-5e78-b55e-fb5429807a47	bb6bdf69-6501-5ad2-9a1b-0148f459d5f3	f04245fa-9e0e-5905-80fa-524e9f1e172f	2026-06-11	02:30:00	Implementation and pairing — Delivery Operations Hub	2026-06-11 09:01:00+00	2026-06-11 09:01:00+00	\N	DOH-131	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
b7194cdf-73ac-5041-8626-1775f3f23aaa	62445afe-3364-5e78-b55e-fb5429807a47	bb6bdf69-6501-5ad2-9a1b-0148f459d5f3	eb73aa6c-87aa-532d-8b94-109b8b863733	2026-06-12	04:00:00	Implementation and pairing — Design System Evolution	2026-06-12 09:01:00+00	2026-06-12 09:01:00+00	\N	DSE-159	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
dd2a3c47-daf6-55df-adad-b083f81be3a6	62445afe-3364-5e78-b55e-fb5429807a47	bb6bdf69-6501-5ad2-9a1b-0148f459d5f3	f04245fa-9e0e-5905-80fa-524e9f1e172f	2026-06-14	00:30:00	Implementation and pairing — Delivery Operations Hub	2026-06-14 09:01:00+00	2026-06-14 09:01:00+00	\N	DOH-105	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
e0854a45-9ec6-55d8-afea-2281ce09da83	62445afe-3364-5e78-b55e-fb5429807a47	bb6bdf69-6501-5ad2-9a1b-0148f459d5f3	f04245fa-9e0e-5905-80fa-524e9f1e172f	2026-06-16	02:30:00	Implementation and pairing — Delivery Operations Hub	2026-06-16 09:01:00+00	2026-06-16 09:01:00+00	\N	DOH-152	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
3efb5e3e-a331-504a-b8ac-26dbd85346ca	62445afe-3364-5e78-b55e-fb5429807a47	bb6bdf69-6501-5ad2-9a1b-0148f459d5f3	f04245fa-9e0e-5905-80fa-524e9f1e172f	2026-06-18	00:30:00	Implementation and pairing — Delivery Operations Hub	2026-06-18 09:01:00+00	2026-06-18 09:01:00+00	\N	DOH-126	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
a8ae82c8-37b4-5d05-accc-0942e6469029	62445afe-3364-5e78-b55e-fb5429807a47	bb6bdf69-6501-5ad2-9a1b-0148f459d5f3	f04245fa-9e0e-5905-80fa-524e9f1e172f	2026-06-22	02:30:00	Implementation and pairing — Delivery Operations Hub	2026-06-22 09:01:00+00	2026-06-22 09:01:00+00	\N	DOH-100	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
d7e3baa4-7664-59a4-a828-11403ed3a9de	62445afe-3364-5e78-b55e-fb5429807a47	bb6bdf69-6501-5ad2-9a1b-0148f459d5f3	f04245fa-9e0e-5905-80fa-524e9f1e172f	2026-06-24	00:30:00	Implementation and pairing — Delivery Operations Hub	2026-06-24 09:01:00+00	2026-06-24 09:01:00+00	\N	DOH-147	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
e2fc7a36-fe5a-53e1-9a58-c01db5217011	62445afe-3364-5e78-b55e-fb5429807a47	bb6bdf69-6501-5ad2-9a1b-0148f459d5f3	eb73aa6c-87aa-532d-8b94-109b8b863733	2026-06-25	00:00:00	Decyzja zakresowa potwierdzona z zespołem — Design System Evolution	2026-06-25 09:01:00+00	2026-06-25 09:01:00+00	\N	\N	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Note
5db8c9f0-82be-51ef-8eaa-c9cfdd1ff3e9	62445afe-3364-5e78-b55e-fb5429807a47	bb6bdf69-6501-5ad2-9a1b-0148f459d5f3	f04245fa-9e0e-5905-80fa-524e9f1e172f	2026-06-26	02:30:00	Implementation and pairing — Delivery Operations Hub	2026-06-26 09:01:00+00	2026-06-26 09:01:00+00	\N	DOH-121	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
8d99d879-77e2-53bc-aed3-2db6d66e3c7b	62445afe-3364-5e78-b55e-fb5429807a47	bb6bdf69-6501-5ad2-9a1b-0148f459d5f3	f04245fa-9e0e-5905-80fa-524e9f1e172f	2026-06-29	00:30:00	Implementation and pairing — Delivery Operations Hub	2026-06-29 09:01:00+00	2026-06-29 09:01:00+00	\N	DOH-168	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
b70cb7dd-74c4-5843-998d-58c997e816f1	62445afe-3364-5e78-b55e-fb5429807a47	bb6bdf69-6501-5ad2-9a1b-0148f459d5f3	f04245fa-9e0e-5905-80fa-524e9f1e172f	2026-07-01	02:30:00	Implementation and pairing — Delivery Operations Hub	2026-07-01 09:01:00+00	2026-07-01 09:01:00+00	\N	DOH-142	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
3f554f25-e8b7-5d70-ae75-d26941b4d0f4	62445afe-3364-5e78-b55e-fb5429807a47	bb6bdf69-6501-5ad2-9a1b-0148f459d5f3	eb73aa6c-87aa-532d-8b94-109b8b863733	2026-07-02	03:00:00	Implementation and pairing — Design System Evolution	2026-07-02 09:01:00+00	2026-07-02 09:01:00+00	\N	DSE-161	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
b8708da7-73ee-5052-866d-38ca12f01d13	62445afe-3364-5e78-b55e-fb5429807a47	bb6bdf69-6501-5ad2-9a1b-0148f459d5f3	f04245fa-9e0e-5905-80fa-524e9f1e172f	2026-07-03	00:30:00	Implementation and pairing — Delivery Operations Hub	2026-07-03 09:01:00+00	2026-07-03 09:01:00+00	\N	DOH-116	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
2a2552b6-3d42-5712-a56b-2c4042b712f3	62445afe-3364-5e78-b55e-fb5429807a47	bb6bdf69-6501-5ad2-9a1b-0148f459d5f3	eb73aa6c-87aa-532d-8b94-109b8b863733	2026-07-06	01:00:00	Implementation and pairing — Design System Evolution	2026-07-06 09:01:00+00	2026-07-06 09:01:00+00	\N	DSE-135	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
c6326b52-dfe3-5a48-8457-ba0794420af6	62445afe-3364-5e78-b55e-fb5429807a47	bb6bdf69-6501-5ad2-9a1b-0148f459d5f3	eb73aa6c-87aa-532d-8b94-109b8b863733	2026-07-08	03:00:00	Implementation and pairing — Design System Evolution	2026-07-08 09:01:00+00	2026-07-08 09:01:00+00	\N	DSE-109	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
6e214442-a7ac-5b59-8db7-6ceb3c59148b	62445afe-3364-5e78-b55e-fb5429807a47	bb6bdf69-6501-5ad2-9a1b-0148f459d5f3	eb73aa6c-87aa-532d-8b94-109b8b863733	2026-07-10	01:00:00	Implementation and pairing — Design System Evolution	2026-07-10 09:01:00+00	2026-07-10 09:01:00+00	\N	DSE-156	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
c7279751-70c1-5876-8e2c-b5a5724f9b7e	62445afe-3364-5e78-b55e-fb5429807a47	bb6bdf69-6501-5ad2-9a1b-0148f459d5f3	eb73aa6c-87aa-532d-8b94-109b8b863733	2026-07-13	03:00:00	Implementation and pairing — Design System Evolution	2026-07-13 09:01:00+00	2026-07-13 09:01:00+00	\N	DSE-130	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
b94c152f-00ac-53e4-9354-6a16493f6826	62445afe-3364-5e78-b55e-fb5429807a47	bb6bdf69-6501-5ad2-9a1b-0148f459d5f3	eb73aa6c-87aa-532d-8b94-109b8b863733	2026-07-15	01:00:00	Implementation and pairing — Design System Evolution	2026-07-15 09:01:00+00	2026-07-15 09:01:00+00	\N	DSE-104	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
89451d52-4d71-5fc7-920c-34d8f2e185e8	62445afe-3364-5e78-b55e-fb5429807a47	bb6bdf69-6501-5ad2-9a1b-0148f459d5f3	f04245fa-9e0e-5905-80fa-524e9f1e172f	2026-07-16	00:00:00	Decyzja zakresowa potwierdzona z zespołem — Delivery Operations Hub	2026-07-16 09:01:00+00	2026-07-16 09:01:00+00	\N	\N	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Note
6db0cb22-2c66-5b79-a357-b6e5968217f8	62445afe-3364-5e78-b55e-fb5429807a47	bb6bdf69-6501-5ad2-9a1b-0148f459d5f3	eb73aa6c-87aa-532d-8b94-109b8b863733	2026-07-17	03:00:00	Implementation and pairing — Design System Evolution	2026-07-17 09:01:00+00	2026-07-17 09:01:00+00	\N	DSE-151	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
23569653-4c6f-5797-b2d0-84ecf82cb73f	62445afe-3364-5e78-b55e-fb5429807a47	bb6bdf69-6501-5ad2-9a1b-0148f459d5f3	eb73aa6c-87aa-532d-8b94-109b8b863733	2026-07-21	01:00:00	Implementation and pairing — Design System Evolution	2026-07-21 09:01:00+00	2026-07-21 09:01:00+00	\N	DSE-125	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
e51abd8f-0414-5bd6-ac4f-d15800a80723	62445afe-3364-5e78-b55e-fb5429807a47	bb6bdf69-6501-5ad2-9a1b-0148f459d5f3	eb73aa6c-87aa-532d-8b94-109b8b863733	2026-07-23	03:00:00	Implementation and pairing — Design System Evolution	2026-07-23 09:01:00+00	2026-07-23 09:01:00+00	\N	DSE-172	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
a1344763-d000-5da3-bc45-d614a610bbbd	62445afe-3364-5e78-b55e-fb5429807a47	bb6bdf69-6501-5ad2-9a1b-0148f459d5f3	f04245fa-9e0e-5905-80fa-524e9f1e172f	2026-07-24	03:30:00	Implementation and pairing — Delivery Operations Hub	2026-07-24 09:01:00+00	2026-07-24 09:01:00+00	\N	DOH-118	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
6c0b16f0-e602-5469-b108-bdbb6fdd2669	62445afe-3364-5e78-b55e-fb5429807a47	bb6bdf69-6501-5ad2-9a1b-0148f459d5f3	eb73aa6c-87aa-532d-8b94-109b8b863733	2026-07-26	01:00:00	Implementation and pairing — Design System Evolution	2026-07-26 09:01:00+00	2026-07-26 09:01:00+00	\N	DSE-146	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
cc6e6f0a-3ee4-5555-88c2-060d4ea1eed4	62445afe-3364-5e78-b55e-fb5429807a47	bb6bdf69-6501-5ad2-9a1b-0148f459d5f3	f04245fa-9e0e-5905-80fa-524e9f1e172f	2026-07-27	01:30:00	Implementation and pairing — Delivery Operations Hub	2026-07-27 09:01:00+00	2026-07-27 09:01:00+00	\N	DOH-165	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
8a4cc461-38d0-5a15-8383-62491498db89	62445afe-3364-5e78-b55e-fb5429807a47	bb6bdf69-6501-5ad2-9a1b-0148f459d5f3	f04245fa-9e0e-5905-80fa-524e9f1e172f	2026-07-29	03:30:00	Implementation and pairing — Delivery Operations Hub	2026-07-29 09:01:00+00	2026-07-29 09:01:00+00	\N	DOH-139	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
7baea4f2-7fe7-5145-bd6e-626a643aeb5f	62445afe-3364-5e78-b55e-fb5429807a47	bb6bdf69-6501-5ad2-9a1b-0148f459d5f3	f04245fa-9e0e-5905-80fa-524e9f1e172f	2026-07-31	01:30:00	Implementation and pairing — Delivery Operations Hub	2026-07-31 09:01:00+00	2026-07-31 09:01:00+00	\N	DOH-113	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
6eea843a-28c3-583a-8cfc-9b1ea55feb75	62445afe-3364-5e78-b55e-fb5429807a47	bb6bdf69-6501-5ad2-9a1b-0148f459d5f3	f04245fa-9e0e-5905-80fa-524e9f1e172f	2026-08-04	03:30:00	Implementation and pairing — Delivery Operations Hub	2026-08-04 09:01:00+00	2026-08-04 09:01:00+00	\N	DOH-160	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
bc18a991-cd12-5257-9fba-1174874cf51f	62445afe-3364-5e78-b55e-fb5429807a47	bb6bdf69-6501-5ad2-9a1b-0148f459d5f3	f04245fa-9e0e-5905-80fa-524e9f1e172f	2026-08-06	01:30:00	Implementation and pairing — Delivery Operations Hub	2026-08-06 09:01:00+00	2026-08-06 09:01:00+00	\N	DOH-134	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
3fe05bab-ab0e-52b7-8c2f-97d6716eda53	62445afe-3364-5e78-b55e-fb5429807a47	bb6bdf69-6501-5ad2-9a1b-0148f459d5f3	f04245fa-9e0e-5905-80fa-524e9f1e172f	2026-08-09	03:30:00	Implementation and pairing — Delivery Operations Hub	2026-08-09 09:01:00+00	2026-08-09 09:01:00+00	\N	DOH-108	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
39074ac4-3aa0-5a8d-ac18-831ff7362fee	62445afe-3364-5e78-b55e-fb5429807a47	bb6bdf69-6501-5ad2-9a1b-0148f459d5f3	f04245fa-9e0e-5905-80fa-524e9f1e172f	2026-08-11	01:30:00	Implementation and pairing — Delivery Operations Hub	2026-08-11 09:01:00+00	2026-08-11 09:01:00+00	\N	DOH-155	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
3ba514f3-fbb2-5d63-aac0-97174bf9d5d9	62445afe-3364-5e78-b55e-fb5429807a47	0f2178f1-017b-5762-b9fd-a197cb6cce9c	eb73aa6c-87aa-532d-8b94-109b8b863733	2026-05-20	01:45:00	Discovery workshop — Design System Evolution	2026-05-20 09:01:00+00	2026-05-20 09:01:00+00	\N	DSE-110	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
05bf06c6-8cf6-5c97-8c3d-7007a6329427	62445afe-3364-5e78-b55e-fb5429807a47	0f2178f1-017b-5762-b9fd-a197cb6cce9c	eb73aa6c-87aa-532d-8b94-109b8b863733	2026-05-21	03:15:00	Discovery workshop — Design System Evolution	2026-05-21 09:01:00+00	2026-05-21 09:01:00+00	\N	DSE-138	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
e200d6b3-0de6-58ec-ab2b-81ba683f05bb	62445afe-3364-5e78-b55e-fb5429807a47	0f2178f1-017b-5762-b9fd-a197cb6cce9c	f07ee933-bae1-5f0f-9e95-6c303aba6f5d	2026-05-22	03:45:00	Discovery workshop — Open Banking Integration	2026-05-22 09:01:00+00	2026-05-22 09:01:00+00	\N	OBI-157	f4c5b0e8-5503-5a50-8487-4ae103b885f2	Active	Worklog
7ca68da9-7525-5f54-8620-26ba3521a8c7	62445afe-3364-5e78-b55e-fb5429807a47	0f2178f1-017b-5762-b9fd-a197cb6cce9c	f07ee933-bae1-5f0f-9e95-6c303aba6f5d	2026-05-25	01:15:00	Discovery workshop — Open Banking Integration	2026-05-25 09:01:00+00	2026-05-25 09:01:00+00	\N	OBI-112	f4c5b0e8-5503-5a50-8487-4ae103b885f2	Active	Worklog
a98ecbcd-1de1-5622-8ebe-46dad610159c	62445afe-3364-5e78-b55e-fb5429807a47	0f2178f1-017b-5762-b9fd-a197cb6cce9c	6dfe9630-59ce-507d-81a0-2f94cb54247f	2026-05-26	01:45:00	Discovery workshop — Fleet Companion	2026-05-26 09:01:00+00	2026-05-26 09:01:00+00	\N	FC-131	eba17d28-b076-534c-918a-dca0a5be8fab	Active	Worklog
48d03f2b-2eb4-56c7-93cc-52f9c2555f9f	62445afe-3364-5e78-b55e-fb5429807a47	0f2178f1-017b-5762-b9fd-a197cb6cce9c	9406b74a-6b7a-578b-8fbd-958684d93780	2026-05-28	03:45:00	Discovery workshop — Patient Portal	2026-05-28 09:01:00+00	2026-05-28 09:01:00+00	\N	PP-105	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
29e237be-f4c5-505f-9350-62242a1494db	62445afe-3364-5e78-b55e-fb5429807a47	0f2178f1-017b-5762-b9fd-a197cb6cce9c	b8cd683c-fe4d-538c-bdaf-68c28e1e14ef	2026-05-31	01:45:00	Discovery workshop — Time Intelligence	2026-05-31 09:01:00+00	2026-05-31 09:01:00+00	\N	TI-152	d677a650-2c23-5c0c-9f53-920636bd318e	Active	Worklog
0fb48b12-4712-5cc1-9f21-22812f1f6569	62445afe-3364-5e78-b55e-fb5429807a47	0f2178f1-017b-5762-b9fd-a197cb6cce9c	eb73aa6c-87aa-532d-8b94-109b8b863733	2026-06-02	03:45:00	Discovery workshop — Design System Evolution	2026-06-02 09:01:00+00	2026-06-02 09:01:00+00	\N	DSE-126	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
82eb2449-d9b8-5971-814a-0146eba6e0dd	62445afe-3364-5e78-b55e-fb5429807a47	0f2178f1-017b-5762-b9fd-a197cb6cce9c	b8cd683c-fe4d-538c-bdaf-68c28e1e14ef	2026-06-03	00:00:00	Client feedback added to the next iteration — Time Intelligence	2026-06-03 09:01:00+00	2026-06-03 09:01:00+00	\N	\N	d677a650-2c23-5c0c-9f53-920636bd318e	Active	Note
789b78c4-8d96-524b-a189-2f5da2a94f0e	62445afe-3364-5e78-b55e-fb5429807a47	0f2178f1-017b-5762-b9fd-a197cb6cce9c	f07ee933-bae1-5f0f-9e95-6c303aba6f5d	2026-06-04	01:45:00	Discovery workshop — Open Banking Integration	2026-06-04 09:01:00+00	2026-06-04 09:01:00+00	\N	OBI-100	f4c5b0e8-5503-5a50-8487-4ae103b885f2	Active	Worklog
3777e4c0-9b58-5d24-b0a2-f2c2a51fd276	62445afe-3364-5e78-b55e-fb5429807a47	0f2178f1-017b-5762-b9fd-a197cb6cce9c	6dfe9630-59ce-507d-81a0-2f94cb54247f	2026-06-08	03:45:00	Discovery workshop — Fleet Companion	2026-06-08 09:01:00+00	2026-06-08 09:01:00+00	\N	FC-147	eba17d28-b076-534c-918a-dca0a5be8fab	Active	Worklog
d4b6d55d-3aaa-5257-94b8-4f3efd83a94b	62445afe-3364-5e78-b55e-fb5429807a47	0f2178f1-017b-5762-b9fd-a197cb6cce9c	9406b74a-6b7a-578b-8fbd-958684d93780	2026-06-10	01:45:00	Discovery workshop — Patient Portal	2026-06-10 09:01:00+00	2026-06-10 09:01:00+00	\N	PP-121	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
471ccb71-bbfb-5a6f-85e3-6eba01e8247b	62445afe-3364-5e78-b55e-fb5429807a47	0f2178f1-017b-5762-b9fd-a197cb6cce9c	b8cd683c-fe4d-538c-bdaf-68c28e1e14ef	2026-06-11	02:15:00	Discovery workshop — Time Intelligence	2026-06-11 09:01:00+00	2026-06-11 09:01:00+00	\N	TI-140	d677a650-2c23-5c0c-9f53-920636bd318e	Active	Worklog
681d5166-6746-53c1-bf72-55783116c6ad	62445afe-3364-5e78-b55e-fb5429807a47	0f2178f1-017b-5762-b9fd-a197cb6cce9c	b8cd683c-fe4d-538c-bdaf-68c28e1e14ef	2026-06-12	03:45:00	Discovery workshop — Time Intelligence	2026-06-12 09:01:00+00	2026-06-12 09:01:00+00	\N	TI-168	d677a650-2c23-5c0c-9f53-920636bd318e	Active	Worklog
1a24442f-b9e4-5afb-888a-dcdf6dcd5e92	62445afe-3364-5e78-b55e-fb5429807a47	0f2178f1-017b-5762-b9fd-a197cb6cce9c	eb73aa6c-87aa-532d-8b94-109b8b863733	2026-06-14	00:15:00	Discovery workshop — Design System Evolution	2026-06-14 09:01:00+00	2026-06-14 09:01:00+00	\N	DSE-114	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
42942e17-b2f1-5f1b-b681-6f6da1b9efb5	62445afe-3364-5e78-b55e-fb5429807a47	0f2178f1-017b-5762-b9fd-a197cb6cce9c	f07ee933-bae1-5f0f-9e95-6c303aba6f5d	2026-06-16	02:15:00	Discovery workshop — Open Banking Integration	2026-06-16 09:01:00+00	2026-06-16 09:01:00+00	\N	OBI-161	f4c5b0e8-5503-5a50-8487-4ae103b885f2	Active	Worklog
a5d77e92-9329-59e5-863e-c967307be3ee	62445afe-3364-5e78-b55e-fb5429807a47	0f2178f1-017b-5762-b9fd-a197cb6cce9c	6dfe9630-59ce-507d-81a0-2f94cb54247f	2026-06-18	00:15:00	Discovery workshop — Fleet Companion	2026-06-18 09:01:00+00	2026-06-18 09:01:00+00	\N	FC-135	eba17d28-b076-534c-918a-dca0a5be8fab	Active	Worklog
704ffcc0-0a13-5a4a-8b14-8ab61ddb653c	62445afe-3364-5e78-b55e-fb5429807a47	0f2178f1-017b-5762-b9fd-a197cb6cce9c	9406b74a-6b7a-578b-8fbd-958684d93780	2026-06-22	02:15:00	Discovery workshop — Patient Portal	2026-06-22 09:01:00+00	2026-06-22 09:01:00+00	\N	PP-109	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
36428d41-054d-5516-8b4a-24858b44b633	62445afe-3364-5e78-b55e-fb5429807a47	0f2178f1-017b-5762-b9fd-a197cb6cce9c	b8cd683c-fe4d-538c-bdaf-68c28e1e14ef	2026-06-24	00:15:00	Discovery workshop — Time Intelligence	2026-06-24 09:01:00+00	2026-06-24 09:01:00+00	\N	TI-156	d677a650-2c23-5c0c-9f53-920636bd318e	Active	Worklog
2ee8dd75-d0f0-5ab5-8ede-3771981a29e2	62445afe-3364-5e78-b55e-fb5429807a47	0f2178f1-017b-5762-b9fd-a197cb6cce9c	9406b74a-6b7a-578b-8fbd-958684d93780	2026-06-25	00:00:00	Client feedback added to the next iteration — Patient Portal	2026-06-25 09:01:00+00	2026-06-25 09:01:00+00	\N	\N	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Note
82917bcc-14d1-5eb0-a0af-bcb7f3679101	62445afe-3364-5e78-b55e-fb5429807a47	0f2178f1-017b-5762-b9fd-a197cb6cce9c	eb73aa6c-87aa-532d-8b94-109b8b863733	2026-06-26	02:15:00	Discovery workshop — Design System Evolution	2026-06-26 09:01:00+00	2026-06-26 09:01:00+00	\N	DSE-130	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
0730c0db-23a5-579b-85d6-e7bf90894b04	62445afe-3364-5e78-b55e-fb5429807a47	0f2178f1-017b-5762-b9fd-a197cb6cce9c	f07ee933-bae1-5f0f-9e95-6c303aba6f5d	2026-06-29	00:15:00	Discovery workshop — Open Banking Integration	2026-06-29 09:01:00+00	2026-06-29 09:01:00+00	\N	OBI-104	f4c5b0e8-5503-5a50-8487-4ae103b885f2	Active	Worklog
aa70fa57-41d0-52c3-8a1e-ec3983ab1b29	62445afe-3364-5e78-b55e-fb5429807a47	0f2178f1-017b-5762-b9fd-a197cb6cce9c	6f343524-7197-5868-bc07-4ca1a311dc9e	2026-06-30	00:15:00	Historical delivery wrap-up — Guest Journey	2026-06-30 09:01:00+00	2026-06-30 09:01:00+00	2026-07-13 00:00:00+00	GJ-932	498db7da-8df6-5797-90f5-e34933a83972	Archived	Worklog
767294a2-38ff-56c3-8c94-ae8fdb0b850a	62445afe-3364-5e78-b55e-fb5429807a47	0f2178f1-017b-5762-b9fd-a197cb6cce9c	6dfe9630-59ce-507d-81a0-2f94cb54247f	2026-07-01	02:15:00	Discovery workshop — Fleet Companion	2026-07-01 09:01:00+00	2026-07-01 09:01:00+00	\N	FC-151	eba17d28-b076-534c-918a-dca0a5be8fab	Active	Worklog
f5e62709-fe8d-58ba-ad39-4cfc0d2756fc	62445afe-3364-5e78-b55e-fb5429807a47	0f2178f1-017b-5762-b9fd-a197cb6cce9c	9406b74a-6b7a-578b-8fbd-958684d93780	2026-07-02	02:45:00	Discovery workshop — Patient Portal	2026-07-02 09:01:00+00	2026-07-02 09:01:00+00	\N	PP-170	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
bb161304-87c3-54a4-ae9b-9777e33528c0	62445afe-3364-5e78-b55e-fb5429807a47	0f2178f1-017b-5762-b9fd-a197cb6cce9c	9406b74a-6b7a-578b-8fbd-958684d93780	2026-07-03	00:15:00	Discovery workshop — Patient Portal	2026-07-03 09:01:00+00	2026-07-03 09:01:00+00	\N	PP-125	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
2e949619-dee1-5b34-af0c-fb3450a1a03e	62445afe-3364-5e78-b55e-fb5429807a47	0f2178f1-017b-5762-b9fd-a197cb6cce9c	6f343524-7197-5868-bc07-4ca1a311dc9e	2026-07-03	01:00:00	Historical delivery wrap-up — Guest Journey	2026-07-03 09:02:00+00	2026-07-03 09:02:00+00	2026-07-13 00:00:00+00	GJ-905	498db7da-8df6-5797-90f5-e34933a83972	Archived	Worklog
3b9fbabc-a20b-508f-a746-97162b2cc6d9	62445afe-3364-5e78-b55e-fb5429807a47	0f2178f1-017b-5762-b9fd-a197cb6cce9c	6f343524-7197-5868-bc07-4ca1a311dc9e	2026-07-03	03:45:00	Historical delivery wrap-up — Guest Journey	2026-07-03 09:03:00+00	2026-07-03 09:03:00+00	2026-07-13 00:00:00+00	GJ-950	498db7da-8df6-5797-90f5-e34933a83972	Archived	Worklog
bfb63632-5429-5512-9f88-cfbf5f3b2eef	62445afe-3364-5e78-b55e-fb5429807a47	0f2178f1-017b-5762-b9fd-a197cb6cce9c	b8cd683c-fe4d-538c-bdaf-68c28e1e14ef	2026-07-06	00:45:00	Discovery workshop — Time Intelligence	2026-07-06 09:01:00+00	2026-07-06 09:01:00+00	\N	TI-144	d677a650-2c23-5c0c-9f53-920636bd318e	Active	Worklog
76a3e969-7c2f-5622-acca-cfb346ba9b58	62445afe-3364-5e78-b55e-fb5429807a47	0f2178f1-017b-5762-b9fd-a197cb6cce9c	6f343524-7197-5868-bc07-4ca1a311dc9e	2026-07-06	00:30:00	Historical delivery wrap-up — Guest Journey	2026-07-06 09:02:00+00	2026-07-06 09:02:00+00	2026-07-13 00:00:00+00	GJ-923	498db7da-8df6-5797-90f5-e34933a83972	Archived	Worklog
02afe7ce-b349-5284-b0fc-a82a8017f6fb	62445afe-3364-5e78-b55e-fb5429807a47	0f2178f1-017b-5762-b9fd-a197cb6cce9c	eb73aa6c-87aa-532d-8b94-109b8b863733	2026-07-08	02:45:00	Discovery workshop — Design System Evolution	2026-07-08 09:01:00+00	2026-07-08 09:01:00+00	\N	DSE-118	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
1cc72f1f-6cac-5d85-9a2f-3a007428e097	62445afe-3364-5e78-b55e-fb5429807a47	0f2178f1-017b-5762-b9fd-a197cb6cce9c	6f343524-7197-5868-bc07-4ca1a311dc9e	2026-07-09	04:00:00	Historical delivery wrap-up — Guest Journey	2026-07-09 09:01:00+00	2026-07-09 09:01:00+00	2026-07-13 00:00:00+00	GJ-941	498db7da-8df6-5797-90f5-e34933a83972	Archived	Worklog
ddcafd79-8ca4-57a7-881c-3ae6e50d4a6e	62445afe-3364-5e78-b55e-fb5429807a47	0f2178f1-017b-5762-b9fd-a197cb6cce9c	f07ee933-bae1-5f0f-9e95-6c303aba6f5d	2026-07-10	00:45:00	Discovery workshop — Open Banking Integration	2026-07-10 09:01:00+00	2026-07-10 09:01:00+00	\N	OBI-165	f4c5b0e8-5503-5a50-8487-4ae103b885f2	Active	Worklog
e6c69094-a152-5a81-802a-bf82bc5dc651	62445afe-3364-5e78-b55e-fb5429807a47	0f2178f1-017b-5762-b9fd-a197cb6cce9c	6f343524-7197-5868-bc07-4ca1a311dc9e	2026-07-12	00:45:00	Historical delivery wrap-up — Guest Journey	2026-07-12 09:01:00+00	2026-07-12 09:01:00+00	2026-07-13 00:00:00+00	GJ-914	498db7da-8df6-5797-90f5-e34933a83972	Archived	Worklog
026d524e-c480-501e-b127-a6176ae5c144	62445afe-3364-5e78-b55e-fb5429807a47	0f2178f1-017b-5762-b9fd-a197cb6cce9c	6f343524-7197-5868-bc07-4ca1a311dc9e	2026-07-12	03:30:00	Historical delivery wrap-up — Guest Journey	2026-07-12 09:02:00+00	2026-07-12 09:02:00+00	2026-07-13 00:00:00+00	GJ-959	498db7da-8df6-5797-90f5-e34933a83972	Archived	Worklog
5fd9d51d-2a14-50ba-b992-9bc0dba7d63d	62445afe-3364-5e78-b55e-fb5429807a47	0f2178f1-017b-5762-b9fd-a197cb6cce9c	6dfe9630-59ce-507d-81a0-2f94cb54247f	2026-07-13	02:45:00	Discovery workshop — Fleet Companion	2026-07-13 09:01:00+00	2026-07-13 09:01:00+00	\N	FC-139	eba17d28-b076-534c-918a-dca0a5be8fab	Active	Worklog
f1aa905c-f6ce-554a-9fc5-7dbd85c446ee	62445afe-3364-5e78-b55e-fb5429807a47	0f2178f1-017b-5762-b9fd-a197cb6cce9c	9406b74a-6b7a-578b-8fbd-958684d93780	2026-07-15	00:45:00	Discovery workshop — Patient Portal	2026-07-15 09:01:00+00	2026-07-15 09:01:00+00	\N	PP-113	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
67471d2d-848b-58e2-97d1-0ea2120c0263	62445afe-3364-5e78-b55e-fb5429807a47	0f2178f1-017b-5762-b9fd-a197cb6cce9c	6dfe9630-59ce-507d-81a0-2f94cb54247f	2026-07-16	00:00:00	Client feedback added to the next iteration — Fleet Companion	2026-07-16 09:01:00+00	2026-07-16 09:01:00+00	\N	\N	eba17d28-b076-534c-918a-dca0a5be8fab	Active	Note
f4695e22-8345-5802-ba58-79047f2593b0	62445afe-3364-5e78-b55e-fb5429807a47	0f2178f1-017b-5762-b9fd-a197cb6cce9c	b8cd683c-fe4d-538c-bdaf-68c28e1e14ef	2026-07-17	02:45:00	Discovery workshop — Time Intelligence	2026-07-17 09:01:00+00	2026-07-17 09:01:00+00	\N	TI-160	d677a650-2c23-5c0c-9f53-920636bd318e	Active	Worklog
b841b79a-f950-5639-b027-81f27814841f	62445afe-3364-5e78-b55e-fb5429807a47	0f2178f1-017b-5762-b9fd-a197cb6cce9c	eb73aa6c-87aa-532d-8b94-109b8b863733	2026-07-21	00:45:00	Discovery workshop — Design System Evolution	2026-07-21 09:01:00+00	2026-07-21 09:01:00+00	\N	DSE-134	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
f31ed578-9340-5bcf-a09f-809cf55a5c53	62445afe-3364-5e78-b55e-fb5429807a47	0f2178f1-017b-5762-b9fd-a197cb6cce9c	f07ee933-bae1-5f0f-9e95-6c303aba6f5d	2026-07-23	02:45:00	Discovery workshop — Open Banking Integration	2026-07-23 09:01:00+00	2026-07-23 09:01:00+00	\N	OBI-108	f4c5b0e8-5503-5a50-8487-4ae103b885f2	Active	Worklog
cfdae1e2-b1b7-57c0-8e6b-2a603709e900	62445afe-3364-5e78-b55e-fb5429807a47	0f2178f1-017b-5762-b9fd-a197cb6cce9c	6dfe9630-59ce-507d-81a0-2f94cb54247f	2026-07-24	03:15:00	Discovery workshop — Fleet Companion	2026-07-24 09:01:00+00	2026-07-24 09:01:00+00	\N	FC-127	eba17d28-b076-534c-918a-dca0a5be8fab	Active	Worklog
eeef8c89-67e3-578c-85ec-97b77eca5223	62445afe-3364-5e78-b55e-fb5429807a47	0f2178f1-017b-5762-b9fd-a197cb6cce9c	6dfe9630-59ce-507d-81a0-2f94cb54247f	2026-07-26	00:45:00	Discovery workshop — Fleet Companion	2026-07-26 09:01:00+00	2026-07-26 09:01:00+00	\N	FC-155	eba17d28-b076-534c-918a-dca0a5be8fab	Active	Worklog
6358c41b-0c71-5c9c-989c-0fa7375a0fa1	62445afe-3364-5e78-b55e-fb5429807a47	0f2178f1-017b-5762-b9fd-a197cb6cce9c	9406b74a-6b7a-578b-8fbd-958684d93780	2026-07-27	01:15:00	Discovery workshop — Patient Portal	2026-07-27 09:01:00+00	2026-07-27 09:01:00+00	\N	PP-101	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
dbc44446-d8df-5235-a14b-71e318847108	62445afe-3364-5e78-b55e-fb5429807a47	0f2178f1-017b-5762-b9fd-a197cb6cce9c	b8cd683c-fe4d-538c-bdaf-68c28e1e14ef	2026-07-29	03:15:00	Discovery workshop — Time Intelligence	2026-07-29 09:01:00+00	2026-07-29 09:01:00+00	\N	TI-148	d677a650-2c23-5c0c-9f53-920636bd318e	Active	Worklog
1a0e9b62-7da2-525b-822b-edc68f8c8d0f	62445afe-3364-5e78-b55e-fb5429807a47	0f2178f1-017b-5762-b9fd-a197cb6cce9c	eb73aa6c-87aa-532d-8b94-109b8b863733	2026-07-31	01:15:00	Discovery workshop — Design System Evolution	2026-07-31 09:01:00+00	2026-07-31 09:01:00+00	\N	DSE-122	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
6005c031-fd7a-53a7-8dd0-cb49da48ef5b	62445afe-3364-5e78-b55e-fb5429807a47	0f2178f1-017b-5762-b9fd-a197cb6cce9c	f07ee933-bae1-5f0f-9e95-6c303aba6f5d	2026-08-04	03:15:00	Discovery workshop — Open Banking Integration	2026-08-04 09:01:00+00	2026-08-04 09:01:00+00	\N	OBI-169	f4c5b0e8-5503-5a50-8487-4ae103b885f2	Active	Worklog
6f829340-963e-5a8e-b668-92876c0ab8fc	62445afe-3364-5e78-b55e-fb5429807a47	0f2178f1-017b-5762-b9fd-a197cb6cce9c	6dfe9630-59ce-507d-81a0-2f94cb54247f	2026-08-06	01:15:00	Discovery workshop — Fleet Companion	2026-08-06 09:01:00+00	2026-08-06 09:01:00+00	\N	FC-143	eba17d28-b076-534c-918a-dca0a5be8fab	Active	Worklog
6d2169db-0445-5e0f-a276-afe4f7b02a83	62445afe-3364-5e78-b55e-fb5429807a47	0f2178f1-017b-5762-b9fd-a197cb6cce9c	f07ee933-bae1-5f0f-9e95-6c303aba6f5d	2026-08-07	00:00:00	Client feedback added to the next iteration — Open Banking Integration	2026-08-07 09:01:00+00	2026-08-07 09:01:00+00	\N	\N	f4c5b0e8-5503-5a50-8487-4ae103b885f2	Active	Note
1fb2a142-3b33-538a-aa14-4ba9cbb59cf0	62445afe-3364-5e78-b55e-fb5429807a47	0f2178f1-017b-5762-b9fd-a197cb6cce9c	9406b74a-6b7a-578b-8fbd-958684d93780	2026-08-09	03:15:00	Discovery workshop — Patient Portal	2026-08-09 09:01:00+00	2026-08-09 09:01:00+00	\N	PP-117	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
9621a8ed-e297-5c93-abcd-d880738311e5	62445afe-3364-5e78-b55e-fb5429807a47	0f2178f1-017b-5762-b9fd-a197cb6cce9c	b8cd683c-fe4d-538c-bdaf-68c28e1e14ef	2026-08-11	01:15:00	Discovery workshop — Time Intelligence	2026-08-11 09:01:00+00	2026-08-11 09:01:00+00	\N	TI-164	d677a650-2c23-5c0c-9f53-920636bd318e	Active	Worklog
82f436bf-78b6-5741-adf2-f114b554ce72	62445afe-3364-5e78-b55e-fb5429807a47	3c3001bd-6e38-504d-9b49-01d36a027754	f07ee933-bae1-5f0f-9e95-6c303aba6f5d	2026-05-20	01:00:00	Client sync — Open Banking Integration	2026-05-20 09:01:00+00	2026-05-20 09:01:00+00	\N	OBI-105	f4c5b0e8-5503-5a50-8487-4ae103b885f2	Active	Worklog
8e7d71aa-8147-5fa8-ad84-fa5d9c12edf1	62445afe-3364-5e78-b55e-fb5429807a47	3c3001bd-6e38-504d-9b49-01d36a027754	f07ee933-bae1-5f0f-9e95-6c303aba6f5d	2026-05-21	02:30:00	Client sync — Open Banking Integration	2026-05-21 09:01:00+00	2026-05-21 09:01:00+00	\N	OBI-133	f4c5b0e8-5503-5a50-8487-4ae103b885f2	Active	Worklog
1358b07c-d7c8-54d7-974b-06e0a7aab76f	62445afe-3364-5e78-b55e-fb5429807a47	3c3001bd-6e38-504d-9b49-01d36a027754	e7ea37c3-9fe3-5010-bb38-8c7330ef5bdc	2026-05-22	03:00:00	Client sync — Care Analytics	2026-05-22 09:01:00+00	2026-05-22 09:01:00+00	\N	CA-152	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
6252b844-031d-5aa8-a8a4-8eebaba5f3a7	62445afe-3364-5e78-b55e-fb5429807a47	3c3001bd-6e38-504d-9b49-01d36a027754	e7ea37c3-9fe3-5010-bb38-8c7330ef5bdc	2026-05-25	00:30:00	Client sync — Care Analytics	2026-05-25 09:01:00+00	2026-05-25 09:01:00+00	\N	CA-107	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
0138d335-d69e-53fc-9cbb-39870861ba9d	62445afe-3364-5e78-b55e-fb5429807a47	3c3001bd-6e38-504d-9b49-01d36a027754	04500693-9e94-55cd-a8ad-c3627d2dac80	2026-05-26	01:00:00	Client sync — Commerce Growth	2026-05-26 09:01:00+00	2026-05-26 09:01:00+00	\N	CG-126	e7e99ce4-232e-5ade-abb1-0966c94d952e	Active	Worklog
3fc76cd3-1291-54a1-952c-e9ddc1172885	62445afe-3364-5e78-b55e-fb5429807a47	3c3001bd-6e38-504d-9b49-01d36a027754	6dfe9630-59ce-507d-81a0-2f94cb54247f	2026-05-28	03:00:00	Client sync — Fleet Companion	2026-05-28 09:01:00+00	2026-05-28 09:01:00+00	\N	FC-100	eba17d28-b076-534c-918a-dca0a5be8fab	Active	Worklog
cd169d0e-96b0-5c47-803c-7c15b8551b78	62445afe-3364-5e78-b55e-fb5429807a47	3c3001bd-6e38-504d-9b49-01d36a027754	b8cd683c-fe4d-538c-bdaf-68c28e1e14ef	2026-05-31	01:00:00	Client sync — Time Intelligence	2026-05-31 09:01:00+00	2026-05-31 09:01:00+00	\N	TI-147	d677a650-2c23-5c0c-9f53-920636bd318e	Active	Worklog
d95a35ce-a96a-5399-9a20-b80e5a7837e2	62445afe-3364-5e78-b55e-fb5429807a47	3c3001bd-6e38-504d-9b49-01d36a027754	35f8aab0-9932-515e-80cc-e8fa82f9c650	2026-06-02	03:00:00	Client sync — Risk Dashboard	2026-06-02 09:01:00+00	2026-06-02 09:01:00+00	\N	RD-121	f4c5b0e8-5503-5a50-8487-4ae103b885f2	Active	Worklog
1629155e-f3ee-5801-9917-4677558e4c92	62445afe-3364-5e78-b55e-fb5429807a47	3c3001bd-6e38-504d-9b49-01d36a027754	e7ea37c3-9fe3-5010-bb38-8c7330ef5bdc	2026-06-03	00:00:00	Ryzyko release omówione i przypisane — Care Analytics	2026-06-03 09:01:00+00	2026-06-03 09:01:00+00	\N	\N	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Note
d6f9278f-a197-5ea4-add6-a7f1f4c1f343	62445afe-3364-5e78-b55e-fb5429807a47	3c3001bd-6e38-504d-9b49-01d36a027754	67164958-1bad-5a9c-8d3a-7c4f7dfb7282	2026-06-04	01:00:00	Client sync — Reporting Sandbox	2026-06-04 09:01:00+00	2026-06-04 09:01:00+00	\N	RS-168	d677a650-2c23-5c0c-9f53-920636bd318e	Active	Worklog
64ef07f7-234d-5271-9ddd-3e5ac14a5cbf	62445afe-3364-5e78-b55e-fb5429807a47	3c3001bd-6e38-504d-9b49-01d36a027754	f07ee933-bae1-5f0f-9e95-6c303aba6f5d	2026-06-08	03:00:00	Client sync — Open Banking Integration	2026-06-08 09:01:00+00	2026-06-08 09:01:00+00	\N	OBI-142	f4c5b0e8-5503-5a50-8487-4ae103b885f2	Active	Worklog
89922fb8-8f07-5a4b-bf39-20d1eb097f53	62445afe-3364-5e78-b55e-fb5429807a47	3c3001bd-6e38-504d-9b49-01d36a027754	e7ea37c3-9fe3-5010-bb38-8c7330ef5bdc	2026-06-10	01:00:00	Client sync — Care Analytics	2026-06-10 09:01:00+00	2026-06-10 09:01:00+00	\N	CA-116	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
ddfc1e20-3b09-5edf-ab7e-46d35c31c382	62445afe-3364-5e78-b55e-fb5429807a47	3c3001bd-6e38-504d-9b49-01d36a027754	04500693-9e94-55cd-a8ad-c3627d2dac80	2026-06-11	01:30:00	Client sync — Commerce Growth	2026-06-11 09:01:00+00	2026-06-11 09:01:00+00	\N	CG-135	e7e99ce4-232e-5ade-abb1-0966c94d952e	Active	Worklog
d0329047-d68b-5de9-b94c-809f8e1d1a0b	62445afe-3364-5e78-b55e-fb5429807a47	3c3001bd-6e38-504d-9b49-01d36a027754	04500693-9e94-55cd-a8ad-c3627d2dac80	2026-06-12	03:00:00	Client sync — Commerce Growth	2026-06-12 09:01:00+00	2026-06-12 09:01:00+00	\N	CG-163	e7e99ce4-232e-5ade-abb1-0966c94d952e	Active	Worklog
8fc4368e-3449-541b-9f97-f7ae3bf8da0f	62445afe-3364-5e78-b55e-fb5429807a47	3c3001bd-6e38-504d-9b49-01d36a027754	6dfe9630-59ce-507d-81a0-2f94cb54247f	2026-06-14	03:30:00	Client sync — Fleet Companion	2026-06-14 09:01:00+00	2026-06-14 09:01:00+00	\N	FC-109	eba17d28-b076-534c-918a-dca0a5be8fab	Active	Worklog
f33519e1-76ed-5ac2-9762-353cd6c88019	62445afe-3364-5e78-b55e-fb5429807a47	3c3001bd-6e38-504d-9b49-01d36a027754	b8cd683c-fe4d-538c-bdaf-68c28e1e14ef	2026-06-16	01:30:00	Client sync — Time Intelligence	2026-06-16 09:01:00+00	2026-06-16 09:01:00+00	\N	TI-156	d677a650-2c23-5c0c-9f53-920636bd318e	Active	Worklog
beeb7b67-41e3-565e-a47b-5165a6acb7bc	62445afe-3364-5e78-b55e-fb5429807a47	3c3001bd-6e38-504d-9b49-01d36a027754	35f8aab0-9932-515e-80cc-e8fa82f9c650	2026-06-18	03:30:00	Client sync — Risk Dashboard	2026-06-18 09:01:00+00	2026-06-18 09:01:00+00	\N	RD-130	f4c5b0e8-5503-5a50-8487-4ae103b885f2	Active	Worklog
04ba803f-46b0-5e7b-80c0-4160e15e9bfa	62445afe-3364-5e78-b55e-fb5429807a47	3c3001bd-6e38-504d-9b49-01d36a027754	67164958-1bad-5a9c-8d3a-7c4f7dfb7282	2026-06-22	01:30:00	Client sync — Reporting Sandbox	2026-06-22 09:01:00+00	2026-06-22 09:01:00+00	\N	RS-104	d677a650-2c23-5c0c-9f53-920636bd318e	Active	Worklog
3e02b367-2e22-5dee-ae06-6353b616450c	62445afe-3364-5e78-b55e-fb5429807a47	3c3001bd-6e38-504d-9b49-01d36a027754	f07ee933-bae1-5f0f-9e95-6c303aba6f5d	2026-06-24	03:30:00	Client sync — Open Banking Integration	2026-06-24 09:01:00+00	2026-06-24 09:01:00+00	\N	OBI-151	f4c5b0e8-5503-5a50-8487-4ae103b885f2	Active	Worklog
75d8ed30-7dd8-5767-975f-3046f8b5b88e	62445afe-3364-5e78-b55e-fb5429807a47	3c3001bd-6e38-504d-9b49-01d36a027754	6dfe9630-59ce-507d-81a0-2f94cb54247f	2026-06-25	00:00:00	Ryzyko release omówione i przypisane — Fleet Companion	2026-06-25 09:01:00+00	2026-06-25 09:01:00+00	\N	\N	eba17d28-b076-534c-918a-dca0a5be8fab	Active	Note
31aad754-5208-5412-8dc2-3318433a38ab	62445afe-3364-5e78-b55e-fb5429807a47	3c3001bd-6e38-504d-9b49-01d36a027754	e7ea37c3-9fe3-5010-bb38-8c7330ef5bdc	2026-06-26	01:30:00	Client sync — Care Analytics	2026-06-26 09:01:00+00	2026-06-26 09:01:00+00	\N	CA-125	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
5305cd22-b309-57d9-8a60-f188201d9a5c	62445afe-3364-5e78-b55e-fb5429807a47	3c3001bd-6e38-504d-9b49-01d36a027754	04500693-9e94-55cd-a8ad-c3627d2dac80	2026-06-29	03:30:00	Client sync — Commerce Growth	2026-06-29 09:01:00+00	2026-06-29 09:01:00+00	\N	CG-172	e7e99ce4-232e-5ade-abb1-0966c94d952e	Active	Worklog
2612eb6d-e9d3-5719-bc9d-6ca01de036de	62445afe-3364-5e78-b55e-fb5429807a47	3c3001bd-6e38-504d-9b49-01d36a027754	6dfe9630-59ce-507d-81a0-2f94cb54247f	2026-07-01	01:30:00	Client sync — Fleet Companion	2026-07-01 09:01:00+00	2026-07-01 09:01:00+00	\N	FC-146	eba17d28-b076-534c-918a-dca0a5be8fab	Active	Worklog
5e529c1e-6ee6-50db-a011-97799fa73e46	62445afe-3364-5e78-b55e-fb5429807a47	3c3001bd-6e38-504d-9b49-01d36a027754	b8cd683c-fe4d-538c-bdaf-68c28e1e14ef	2026-07-02	02:00:00	Client sync — Time Intelligence	2026-07-02 09:01:00+00	2026-07-02 09:01:00+00	\N	TI-165	d677a650-2c23-5c0c-9f53-920636bd318e	Active	Worklog
4319c00a-b182-5689-8864-b296bb874d42	62445afe-3364-5e78-b55e-fb5429807a47	3c3001bd-6e38-504d-9b49-01d36a027754	b8cd683c-fe4d-538c-bdaf-68c28e1e14ef	2026-07-03	03:30:00	Client sync — Time Intelligence	2026-07-03 09:01:00+00	2026-07-03 09:01:00+00	\N	TI-120	d677a650-2c23-5c0c-9f53-920636bd318e	Active	Worklog
3f453839-9160-5d52-b5f5-3e51aa3e9269	62445afe-3364-5e78-b55e-fb5429807a47	3c3001bd-6e38-504d-9b49-01d36a027754	35f8aab0-9932-515e-80cc-e8fa82f9c650	2026-07-06	04:00:00	Client sync — Risk Dashboard	2026-07-06 09:01:00+00	2026-07-06 09:01:00+00	\N	RD-139	f4c5b0e8-5503-5a50-8487-4ae103b885f2	Active	Worklog
661e550d-e71c-53d2-8423-b2b99f204900	62445afe-3364-5e78-b55e-fb5429807a47	3c3001bd-6e38-504d-9b49-01d36a027754	67164958-1bad-5a9c-8d3a-7c4f7dfb7282	2026-07-08	02:00:00	Client sync — Reporting Sandbox	2026-07-08 09:01:00+00	2026-07-08 09:01:00+00	\N	RS-113	d677a650-2c23-5c0c-9f53-920636bd318e	Active	Worklog
491bab68-a4c0-5729-bd27-e5d77f04e691	62445afe-3364-5e78-b55e-fb5429807a47	3c3001bd-6e38-504d-9b49-01d36a027754	f07ee933-bae1-5f0f-9e95-6c303aba6f5d	2026-07-10	04:00:00	Client sync — Open Banking Integration	2026-07-10 09:01:00+00	2026-07-10 09:01:00+00	\N	OBI-160	f4c5b0e8-5503-5a50-8487-4ae103b885f2	Active	Worklog
d66c0261-b0b5-5663-b498-5535e548bdea	62445afe-3364-5e78-b55e-fb5429807a47	3c3001bd-6e38-504d-9b49-01d36a027754	e7ea37c3-9fe3-5010-bb38-8c7330ef5bdc	2026-07-13	02:00:00	Client sync — Care Analytics	2026-07-13 09:01:00+00	2026-07-13 09:01:00+00	\N	CA-134	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
4a09a50c-dd71-5120-a7cb-30670bbf032d	62445afe-3364-5e78-b55e-fb5429807a47	3c3001bd-6e38-504d-9b49-01d36a027754	04500693-9e94-55cd-a8ad-c3627d2dac80	2026-07-15	04:00:00	Client sync — Commerce Growth	2026-07-15 09:01:00+00	2026-07-15 09:01:00+00	\N	CG-108	e7e99ce4-232e-5ade-abb1-0966c94d952e	Active	Worklog
65e7a98f-b330-59c5-a382-766f91e909f6	62445afe-3364-5e78-b55e-fb5429807a47	3c3001bd-6e38-504d-9b49-01d36a027754	35f8aab0-9932-515e-80cc-e8fa82f9c650	2026-07-16	00:00:00	Ryzyko release omówione i przypisane — Risk Dashboard	2026-07-16 09:01:00+00	2026-07-16 09:01:00+00	\N	\N	f4c5b0e8-5503-5a50-8487-4ae103b885f2	Active	Note
cbe748a6-ea86-5c71-8be2-550051bfb141	62445afe-3364-5e78-b55e-fb5429807a47	3c3001bd-6e38-504d-9b49-01d36a027754	6dfe9630-59ce-507d-81a0-2f94cb54247f	2026-07-17	02:00:00	Client sync — Fleet Companion	2026-07-17 09:01:00+00	2026-07-17 09:01:00+00	\N	FC-155	eba17d28-b076-534c-918a-dca0a5be8fab	Active	Worklog
bcc35587-75fb-5e8f-9a0b-13ee6d824133	62445afe-3364-5e78-b55e-fb5429807a47	3c3001bd-6e38-504d-9b49-01d36a027754	b8cd683c-fe4d-538c-bdaf-68c28e1e14ef	2026-07-21	04:00:00	Client sync — Time Intelligence	2026-07-21 09:01:00+00	2026-07-21 09:01:00+00	\N	TI-129	d677a650-2c23-5c0c-9f53-920636bd318e	Active	Worklog
d5866c95-e1b5-562a-852b-fbd6674c0982	62445afe-3364-5e78-b55e-fb5429807a47	3c3001bd-6e38-504d-9b49-01d36a027754	35f8aab0-9932-515e-80cc-e8fa82f9c650	2026-07-23	02:00:00	Client sync — Risk Dashboard	2026-07-23 09:01:00+00	2026-07-23 09:01:00+00	\N	RD-103	f4c5b0e8-5503-5a50-8487-4ae103b885f2	Active	Worklog
466254fe-0a83-53ad-aeb8-8e00ed75189a	62445afe-3364-5e78-b55e-fb5429807a47	3c3001bd-6e38-504d-9b49-01d36a027754	67164958-1bad-5a9c-8d3a-7c4f7dfb7282	2026-07-24	02:30:00	Client sync — Reporting Sandbox	2026-07-24 09:01:00+00	2026-07-24 09:01:00+00	\N	RS-122	d677a650-2c23-5c0c-9f53-920636bd318e	Active	Worklog
f4706c3d-d303-5322-9c5a-431db1e5b859	62445afe-3364-5e78-b55e-fb5429807a47	3c3001bd-6e38-504d-9b49-01d36a027754	67164958-1bad-5a9c-8d3a-7c4f7dfb7282	2026-07-26	04:00:00	Client sync — Reporting Sandbox	2026-07-26 09:01:00+00	2026-07-26 09:01:00+00	\N	RS-150	d677a650-2c23-5c0c-9f53-920636bd318e	Active	Worklog
3075ccb8-0fe2-58ae-a190-e46c1af573f9	62445afe-3364-5e78-b55e-fb5429807a47	3c3001bd-6e38-504d-9b49-01d36a027754	f07ee933-bae1-5f0f-9e95-6c303aba6f5d	2026-07-27	00:30:00	Client sync — Open Banking Integration	2026-07-27 09:01:00+00	2026-07-27 09:01:00+00	\N	OBI-169	f4c5b0e8-5503-5a50-8487-4ae103b885f2	Active	Worklog
ab483a10-71e0-5a8a-9e3a-0e72f3e2f26e	62445afe-3364-5e78-b55e-fb5429807a47	3c3001bd-6e38-504d-9b49-01d36a027754	e7ea37c3-9fe3-5010-bb38-8c7330ef5bdc	2026-07-29	02:30:00	Client sync — Care Analytics	2026-07-29 09:01:00+00	2026-07-29 09:01:00+00	\N	CA-143	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
6bf3f888-02d3-588a-97e6-db10eef3e2a1	62445afe-3364-5e78-b55e-fb5429807a47	3c3001bd-6e38-504d-9b49-01d36a027754	04500693-9e94-55cd-a8ad-c3627d2dac80	2026-07-31	00:30:00	Client sync — Commerce Growth	2026-07-31 09:01:00+00	2026-07-31 09:01:00+00	\N	CG-117	e7e99ce4-232e-5ade-abb1-0966c94d952e	Active	Worklog
95caf9e7-04de-58a7-954e-e1c411d4f04f	62445afe-3364-5e78-b55e-fb5429807a47	3c3001bd-6e38-504d-9b49-01d36a027754	6dfe9630-59ce-507d-81a0-2f94cb54247f	2026-08-04	02:30:00	Client sync — Fleet Companion	2026-08-04 09:01:00+00	2026-08-04 09:01:00+00	\N	FC-164	eba17d28-b076-534c-918a-dca0a5be8fab	Active	Worklog
9ac017cd-bd0d-5eb5-9850-80ed0753bb95	62445afe-3364-5e78-b55e-fb5429807a47	3c3001bd-6e38-504d-9b49-01d36a027754	b8cd683c-fe4d-538c-bdaf-68c28e1e14ef	2026-08-06	00:30:00	Client sync — Time Intelligence	2026-08-06 09:01:00+00	2026-08-06 09:01:00+00	\N	TI-138	d677a650-2c23-5c0c-9f53-920636bd318e	Active	Worklog
71aebb1e-3b42-5730-8195-4cd6cbac1c7e	62445afe-3364-5e78-b55e-fb5429807a47	3c3001bd-6e38-504d-9b49-01d36a027754	35f8aab0-9932-515e-80cc-e8fa82f9c650	2026-08-09	02:30:00	Client sync — Risk Dashboard	2026-08-09 09:01:00+00	2026-08-09 09:01:00+00	\N	RD-112	f4c5b0e8-5503-5a50-8487-4ae103b885f2	Active	Worklog
adc00349-d662-584d-8ca6-dc2d54480e64	62445afe-3364-5e78-b55e-fb5429807a47	3c3001bd-6e38-504d-9b49-01d36a027754	67164958-1bad-5a9c-8d3a-7c4f7dfb7282	2026-08-11	00:30:00	Client sync — Reporting Sandbox	2026-08-11 09:01:00+00	2026-08-11 09:01:00+00	\N	RS-159	d677a650-2c23-5c0c-9f53-920636bd318e	Active	Worklog
7940b0a0-5069-59ee-9703-e664df0f5421	62445afe-3364-5e78-b55e-fb5429807a47	3d0cfe6d-2c3e-5102-a541-f86e8aef695d	f07ee933-bae1-5f0f-9e95-6c303aba6f5d	2026-05-20	00:30:00	Regression testing — Open Banking Integration	2026-05-20 09:01:00+00	2026-05-20 09:01:00+00	\N	OBI-123	f4c5b0e8-5503-5a50-8487-4ae103b885f2	Active	Worklog
b197dd05-96d6-5aed-9861-dded4c2113ef	62445afe-3364-5e78-b55e-fb5429807a47	3d0cfe6d-2c3e-5102-a541-f86e8aef695d	f04245fa-9e0e-5905-80fa-524e9f1e172f	2026-05-21	02:00:00	Regression testing — Delivery Operations Hub	2026-05-21 09:01:00+00	2026-05-21 09:01:00+00	\N	DOH-151	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
0e0b0d4c-ac30-504d-953a-1a92b0b62e4c	62445afe-3364-5e78-b55e-fb5429807a47	3d0cfe6d-2c3e-5102-a541-f86e8aef695d	f07ee933-bae1-5f0f-9e95-6c303aba6f5d	2026-05-22	02:30:00	Regression testing — Open Banking Integration	2026-05-22 09:01:00+00	2026-05-22 09:01:00+00	\N	OBI-170	f4c5b0e8-5503-5a50-8487-4ae103b885f2	Active	Worklog
53a7422e-ae5c-5b6f-8999-40ff8240495d	62445afe-3364-5e78-b55e-fb5429807a47	3d0cfe6d-2c3e-5102-a541-f86e8aef695d	f04245fa-9e0e-5905-80fa-524e9f1e172f	2026-05-25	04:00:00	Regression testing — Delivery Operations Hub	2026-05-25 09:01:00+00	2026-05-25 09:01:00+00	\N	DOH-125	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
91c031a1-964f-5751-8fc8-2333e841575f	62445afe-3364-5e78-b55e-fb5429807a47	3d0cfe6d-2c3e-5102-a541-f86e8aef695d	f07ee933-bae1-5f0f-9e95-6c303aba6f5d	2026-05-26	00:30:00	Regression testing — Open Banking Integration	2026-05-26 09:01:00+00	2026-05-26 09:01:00+00	\N	OBI-144	f4c5b0e8-5503-5a50-8487-4ae103b885f2	Active	Worklog
bb7031c2-034d-551a-80fb-724782904be8	62445afe-3364-5e78-b55e-fb5429807a47	3d0cfe6d-2c3e-5102-a541-f86e8aef695d	f07ee933-bae1-5f0f-9e95-6c303aba6f5d	2026-05-28	02:30:00	Regression testing — Open Banking Integration	2026-05-28 09:01:00+00	2026-05-28 09:01:00+00	\N	OBI-118	f4c5b0e8-5503-5a50-8487-4ae103b885f2	Active	Worklog
9c0c5e7d-6e40-5eb3-b0f4-719d849113b7	62445afe-3364-5e78-b55e-fb5429807a47	3d0cfe6d-2c3e-5102-a541-f86e8aef695d	f07ee933-bae1-5f0f-9e95-6c303aba6f5d	2026-05-31	00:30:00	Regression testing — Open Banking Integration	2026-05-31 09:01:00+00	2026-05-31 09:01:00+00	\N	OBI-165	f4c5b0e8-5503-5a50-8487-4ae103b885f2	Active	Worklog
96972db6-26d5-55bb-84f7-ef3f877273ee	62445afe-3364-5e78-b55e-fb5429807a47	3d0cfe6d-2c3e-5102-a541-f86e8aef695d	f07ee933-bae1-5f0f-9e95-6c303aba6f5d	2026-06-02	02:30:00	Regression testing — Open Banking Integration	2026-06-02 09:01:00+00	2026-06-02 09:01:00+00	\N	OBI-139	f4c5b0e8-5503-5a50-8487-4ae103b885f2	Active	Worklog
8b508c0c-42e9-5380-bafc-f9ca2313ecf5	62445afe-3364-5e78-b55e-fb5429807a47	3d0cfe6d-2c3e-5102-a541-f86e8aef695d	f04245fa-9e0e-5905-80fa-524e9f1e172f	2026-06-03	00:00:00	Ryzyko release omówione i przypisane — Delivery Operations Hub	2026-06-03 09:01:00+00	2026-06-03 09:01:00+00	\N	\N	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Note
e83f6173-af32-5746-8baa-6c27dcc1ee5e	62445afe-3364-5e78-b55e-fb5429807a47	3d0cfe6d-2c3e-5102-a541-f86e8aef695d	f07ee933-bae1-5f0f-9e95-6c303aba6f5d	2026-06-04	00:30:00	Regression testing — Open Banking Integration	2026-06-04 09:01:00+00	2026-06-04 09:01:00+00	\N	OBI-113	f4c5b0e8-5503-5a50-8487-4ae103b885f2	Active	Worklog
fcf73a83-56c5-59d5-ad2d-aca453f896f9	62445afe-3364-5e78-b55e-fb5429807a47	3d0cfe6d-2c3e-5102-a541-f86e8aef695d	f07ee933-bae1-5f0f-9e95-6c303aba6f5d	2026-06-08	02:30:00	Regression testing — Open Banking Integration	2026-06-08 09:01:00+00	2026-06-08 09:01:00+00	\N	OBI-160	f4c5b0e8-5503-5a50-8487-4ae103b885f2	Active	Worklog
6a3e5750-2271-5387-b1e1-47d47e25771d	62445afe-3364-5e78-b55e-fb5429807a47	3d0cfe6d-2c3e-5102-a541-f86e8aef695d	f07ee933-bae1-5f0f-9e95-6c303aba6f5d	2026-06-10	00:30:00	Regression testing — Open Banking Integration	2026-06-10 09:01:00+00	2026-06-10 09:01:00+00	\N	OBI-134	f4c5b0e8-5503-5a50-8487-4ae103b885f2	Active	Worklog
22ffc953-7096-5661-9e5b-662052cddfac	62445afe-3364-5e78-b55e-fb5429807a47	3d0cfe6d-2c3e-5102-a541-f86e8aef695d	f04245fa-9e0e-5905-80fa-524e9f1e172f	2026-06-11	01:00:00	Regression testing — Delivery Operations Hub	2026-06-11 09:01:00+00	2026-06-11 09:01:00+00	\N	DOH-153	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
e3cde833-f0de-5a67-8114-f4d0497b1d81	62445afe-3364-5e78-b55e-fb5429807a47	3d0cfe6d-2c3e-5102-a541-f86e8aef695d	f07ee933-bae1-5f0f-9e95-6c303aba6f5d	2026-06-12	02:30:00	Regression testing — Open Banking Integration	2026-06-12 09:01:00+00	2026-06-12 09:01:00+00	\N	OBI-108	f4c5b0e8-5503-5a50-8487-4ae103b885f2	Active	Worklog
3fc90330-4b74-53f0-b4f6-f75fe71e8c16	62445afe-3364-5e78-b55e-fb5429807a47	3d0cfe6d-2c3e-5102-a541-f86e8aef695d	f04245fa-9e0e-5905-80fa-524e9f1e172f	2026-06-14	03:00:00	Regression testing — Delivery Operations Hub	2026-06-14 09:01:00+00	2026-06-14 09:01:00+00	\N	DOH-127	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
56458a2d-6e74-53d8-a330-241f270544cf	62445afe-3364-5e78-b55e-fb5429807a47	3d0cfe6d-2c3e-5102-a541-f86e8aef695d	f04245fa-9e0e-5905-80fa-524e9f1e172f	2026-06-16	01:00:00	Regression testing — Delivery Operations Hub	2026-06-16 09:01:00+00	2026-06-16 09:01:00+00	\N	DOH-101	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
9ee6c7da-01e7-5939-90de-041dc2a7cea3	62445afe-3364-5e78-b55e-fb5429807a47	3d0cfe6d-2c3e-5102-a541-f86e8aef695d	f04245fa-9e0e-5905-80fa-524e9f1e172f	2026-06-18	03:00:00	Regression testing — Delivery Operations Hub	2026-06-18 09:01:00+00	2026-06-18 09:01:00+00	\N	DOH-148	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
15359356-ecc6-5630-8a1c-04d746ac0559	62445afe-3364-5e78-b55e-fb5429807a47	3d0cfe6d-2c3e-5102-a541-f86e8aef695d	f04245fa-9e0e-5905-80fa-524e9f1e172f	2026-06-22	01:00:00	Regression testing — Delivery Operations Hub	2026-06-22 09:01:00+00	2026-06-22 09:01:00+00	\N	DOH-122	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
a592b6b9-61cb-51c7-9599-8460c8dd2bbb	62445afe-3364-5e78-b55e-fb5429807a47	3d0cfe6d-2c3e-5102-a541-f86e8aef695d	f04245fa-9e0e-5905-80fa-524e9f1e172f	2026-06-24	03:00:00	Regression testing — Delivery Operations Hub	2026-06-24 09:01:00+00	2026-06-24 09:01:00+00	\N	DOH-169	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
cd99f6fd-66d2-579c-8ac1-0b1ac6bac519	62445afe-3364-5e78-b55e-fb5429807a47	3d0cfe6d-2c3e-5102-a541-f86e8aef695d	f07ee933-bae1-5f0f-9e95-6c303aba6f5d	2026-06-25	00:00:00	Ryzyko release omówione i przypisane — Open Banking Integration	2026-06-25 09:01:00+00	2026-06-25 09:01:00+00	\N	\N	f4c5b0e8-5503-5a50-8487-4ae103b885f2	Active	Note
a03a92ed-20f9-532a-ae0c-f0dce92e7f5b	62445afe-3364-5e78-b55e-fb5429807a47	3d0cfe6d-2c3e-5102-a541-f86e8aef695d	f04245fa-9e0e-5905-80fa-524e9f1e172f	2026-06-26	01:00:00	Regression testing — Delivery Operations Hub	2026-06-26 09:01:00+00	2026-06-26 09:01:00+00	\N	DOH-143	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
a2cca6d0-6e43-5e56-8e83-d6bede1798bc	62445afe-3364-5e78-b55e-fb5429807a47	3d0cfe6d-2c3e-5102-a541-f86e8aef695d	f04245fa-9e0e-5905-80fa-524e9f1e172f	2026-06-29	03:00:00	Regression testing — Delivery Operations Hub	2026-06-29 09:01:00+00	2026-06-29 09:01:00+00	\N	DOH-117	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
f579d213-66bc-5ffc-b29b-37ab59b874d5	62445afe-3364-5e78-b55e-fb5429807a47	3d0cfe6d-2c3e-5102-a541-f86e8aef695d	3d5d3faf-2bbd-5bca-ac00-1c6056bf7ca6	2026-06-29	02:30:00	Historical delivery wrap-up — Dispatch Optimizer	2026-06-29 09:02:00+00	2026-06-29 09:02:00+00	2026-07-13 00:00:00+00	DOP-931	141122b1-9a71-570d-a44c-efc88209be99	Archived	Worklog
2e95a2c5-fb76-5f8e-b7a0-1fba345b79bb	62445afe-3364-5e78-b55e-fb5429807a47	3d0cfe6d-2c3e-5102-a541-f86e8aef695d	f04245fa-9e0e-5905-80fa-524e9f1e172f	2026-07-01	01:00:00	Regression testing — Delivery Operations Hub	2026-07-01 09:01:00+00	2026-07-01 09:01:00+00	\N	DOH-164	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
45cd01f0-ab61-5906-9c85-f448027aff62	62445afe-3364-5e78-b55e-fb5429807a47	3d0cfe6d-2c3e-5102-a541-f86e8aef695d	f07ee933-bae1-5f0f-9e95-6c303aba6f5d	2026-07-02	01:30:00	Regression testing — Open Banking Integration	2026-07-02 09:01:00+00	2026-07-02 09:01:00+00	\N	OBI-110	f4c5b0e8-5503-5a50-8487-4ae103b885f2	Active	Worklog
88aa6682-dd9f-54d8-8755-670af86f4a52	62445afe-3364-5e78-b55e-fb5429807a47	3d0cfe6d-2c3e-5102-a541-f86e8aef695d	3d5d3faf-2bbd-5bca-ac00-1c6056bf7ca6	2026-07-02	02:00:00	Historical delivery wrap-up — Dispatch Optimizer	2026-07-02 09:02:00+00	2026-07-02 09:02:00+00	2026-07-13 00:00:00+00	DOP-949	141122b1-9a71-570d-a44c-efc88209be99	Archived	Worklog
e5047183-fbb1-53f3-8e17-0aae637bca78	62445afe-3364-5e78-b55e-fb5429807a47	3d0cfe6d-2c3e-5102-a541-f86e8aef695d	f04245fa-9e0e-5905-80fa-524e9f1e172f	2026-07-03	03:00:00	Regression testing — Delivery Operations Hub	2026-07-03 09:01:00+00	2026-07-03 09:01:00+00	\N	DOH-138	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
8d51a94d-55a1-5587-a9ad-880de7adc3aa	62445afe-3364-5e78-b55e-fb5429807a47	3d0cfe6d-2c3e-5102-a541-f86e8aef695d	f07ee933-bae1-5f0f-9e95-6c303aba6f5d	2026-07-06	03:30:00	Regression testing — Open Banking Integration	2026-07-06 09:01:00+00	2026-07-06 09:01:00+00	\N	OBI-157	f4c5b0e8-5503-5a50-8487-4ae103b885f2	Active	Worklog
3bb0ba45-62c1-5299-9336-90c4ff6c6310	62445afe-3364-5e78-b55e-fb5429807a47	3d0cfe6d-2c3e-5102-a541-f86e8aef695d	f07ee933-bae1-5f0f-9e95-6c303aba6f5d	2026-07-08	01:30:00	Regression testing — Open Banking Integration	2026-07-08 09:01:00+00	2026-07-08 09:01:00+00	\N	OBI-131	f4c5b0e8-5503-5a50-8487-4ae103b885f2	Active	Worklog
b5eb4ee4-035e-5ec1-832d-91a857c9d45a	62445afe-3364-5e78-b55e-fb5429807a47	3d0cfe6d-2c3e-5102-a541-f86e8aef695d	f07ee933-bae1-5f0f-9e95-6c303aba6f5d	2026-07-10	03:30:00	Regression testing — Open Banking Integration	2026-07-10 09:01:00+00	2026-07-10 09:01:00+00	\N	OBI-105	f4c5b0e8-5503-5a50-8487-4ae103b885f2	Active	Worklog
0f23ed01-e130-5452-8e12-72763c7ec22d	62445afe-3364-5e78-b55e-fb5429807a47	3d0cfe6d-2c3e-5102-a541-f86e8aef695d	3d5d3faf-2bbd-5bca-ac00-1c6056bf7ca6	2026-07-11	03:00:00	Historical delivery wrap-up — Dispatch Optimizer	2026-07-11 09:01:00+00	2026-07-11 09:01:00+00	2026-07-13 00:00:00+00	DOP-913	141122b1-9a71-570d-a44c-efc88209be99	Archived	Worklog
86811bd7-8856-57b9-9e9a-79ae6949742b	62445afe-3364-5e78-b55e-fb5429807a47	3d0cfe6d-2c3e-5102-a541-f86e8aef695d	f07ee933-bae1-5f0f-9e95-6c303aba6f5d	2026-07-13	01:30:00	Regression testing — Open Banking Integration	2026-07-13 09:01:00+00	2026-07-13 09:01:00+00	\N	OBI-152	f4c5b0e8-5503-5a50-8487-4ae103b885f2	Active	Worklog
4d7a5175-3506-56c1-bbcc-2a79aca4a79d	62445afe-3364-5e78-b55e-fb5429807a47	3d0cfe6d-2c3e-5102-a541-f86e8aef695d	f07ee933-bae1-5f0f-9e95-6c303aba6f5d	2026-07-15	03:30:00	Regression testing — Open Banking Integration	2026-07-15 09:01:00+00	2026-07-15 09:01:00+00	\N	OBI-126	f4c5b0e8-5503-5a50-8487-4ae103b885f2	Active	Worklog
9c673d1d-a394-5db1-b48a-74de80f12631	62445afe-3364-5e78-b55e-fb5429807a47	3d0cfe6d-2c3e-5102-a541-f86e8aef695d	f04245fa-9e0e-5905-80fa-524e9f1e172f	2026-07-16	00:00:00	Ryzyko release omówione i przypisane — Delivery Operations Hub	2026-07-16 09:01:00+00	2026-07-16 09:01:00+00	\N	\N	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Note
9bf109de-aa73-5dec-b6cf-a959cafc5431	62445afe-3364-5e78-b55e-fb5429807a47	3d0cfe6d-2c3e-5102-a541-f86e8aef695d	f07ee933-bae1-5f0f-9e95-6c303aba6f5d	2026-07-17	01:30:00	Regression testing — Open Banking Integration	2026-07-17 09:01:00+00	2026-07-17 09:01:00+00	\N	OBI-100	f4c5b0e8-5503-5a50-8487-4ae103b885f2	Active	Worklog
16d9da40-8a0f-5f07-9e66-ce30e82e0ccf	62445afe-3364-5e78-b55e-fb5429807a47	3d0cfe6d-2c3e-5102-a541-f86e8aef695d	f07ee933-bae1-5f0f-9e95-6c303aba6f5d	2026-07-21	03:30:00	Regression testing — Open Banking Integration	2026-07-21 09:01:00+00	2026-07-21 09:01:00+00	\N	OBI-147	f4c5b0e8-5503-5a50-8487-4ae103b885f2	Active	Worklog
5f0fc848-fa5d-50d3-a509-6c041a50bf09	62445afe-3364-5e78-b55e-fb5429807a47	3d0cfe6d-2c3e-5102-a541-f86e8aef695d	f07ee933-bae1-5f0f-9e95-6c303aba6f5d	2026-07-23	01:30:00	Regression testing — Open Banking Integration	2026-07-23 09:01:00+00	2026-07-23 09:01:00+00	\N	OBI-121	f4c5b0e8-5503-5a50-8487-4ae103b885f2	Active	Worklog
e497bcca-cca1-5a7f-9d96-68848376bb36	62445afe-3364-5e78-b55e-fb5429807a47	3d0cfe6d-2c3e-5102-a541-f86e8aef695d	f04245fa-9e0e-5905-80fa-524e9f1e172f	2026-07-24	02:00:00	Regression testing — Delivery Operations Hub	2026-07-24 09:01:00+00	2026-07-24 09:01:00+00	\N	DOH-140	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
1e706a0a-8647-5e13-9c0e-59d39e728387	62445afe-3364-5e78-b55e-fb5429807a47	3d0cfe6d-2c3e-5102-a541-f86e8aef695d	f07ee933-bae1-5f0f-9e95-6c303aba6f5d	2026-07-26	03:30:00	Regression testing — Open Banking Integration	2026-07-26 09:01:00+00	2026-07-26 09:01:00+00	\N	OBI-168	f4c5b0e8-5503-5a50-8487-4ae103b885f2	Active	Worklog
3ddbf8c2-4b29-5d64-a331-a6827d11a6b3	62445afe-3364-5e78-b55e-fb5429807a47	3d0cfe6d-2c3e-5102-a541-f86e8aef695d	f04245fa-9e0e-5905-80fa-524e9f1e172f	2026-07-27	04:00:00	Regression testing — Delivery Operations Hub	2026-07-27 09:01:00+00	2026-07-27 09:01:00+00	\N	DOH-114	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
4a035139-aa56-50b4-8286-fe17d98ac01c	62445afe-3364-5e78-b55e-fb5429807a47	3d0cfe6d-2c3e-5102-a541-f86e8aef695d	f04245fa-9e0e-5905-80fa-524e9f1e172f	2026-07-29	02:00:00	Regression testing — Delivery Operations Hub	2026-07-29 09:01:00+00	2026-07-29 09:01:00+00	\N	DOH-161	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
2c53dc31-2d4c-5007-ab2f-3bb7ee67a138	62445afe-3364-5e78-b55e-fb5429807a47	3d0cfe6d-2c3e-5102-a541-f86e8aef695d	f04245fa-9e0e-5905-80fa-524e9f1e172f	2026-07-31	04:00:00	Regression testing — Delivery Operations Hub	2026-07-31 09:01:00+00	2026-07-31 09:01:00+00	\N	DOH-135	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
1d6ecda9-6795-5329-80b5-4a48c0bdd713	62445afe-3364-5e78-b55e-fb5429807a47	3d0cfe6d-2c3e-5102-a541-f86e8aef695d	f04245fa-9e0e-5905-80fa-524e9f1e172f	2026-08-04	02:00:00	Regression testing — Delivery Operations Hub	2026-08-04 09:01:00+00	2026-08-04 09:01:00+00	\N	DOH-109	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
e8eb5079-7adf-53d5-8ca8-f8d1f11ae192	62445afe-3364-5e78-b55e-fb5429807a47	3d0cfe6d-2c3e-5102-a541-f86e8aef695d	f04245fa-9e0e-5905-80fa-524e9f1e172f	2026-08-06	04:00:00	Regression testing — Delivery Operations Hub	2026-08-06 09:01:00+00	2026-08-06 09:01:00+00	\N	DOH-156	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
3e8dd976-2fa0-519e-8d32-113391bc6e06	62445afe-3364-5e78-b55e-fb5429807a47	3d0cfe6d-2c3e-5102-a541-f86e8aef695d	f04245fa-9e0e-5905-80fa-524e9f1e172f	2026-08-09	02:00:00	Regression testing — Delivery Operations Hub	2026-08-09 09:01:00+00	2026-08-09 09:01:00+00	\N	DOH-130	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
8c47aa07-82eb-556e-911b-b50c8962f9ac	62445afe-3364-5e78-b55e-fb5429807a47	3d0cfe6d-2c3e-5102-a541-f86e8aef695d	f04245fa-9e0e-5905-80fa-524e9f1e172f	2026-08-11	04:00:00	Regression testing — Delivery Operations Hub	2026-08-11 09:01:00+00	2026-08-11 09:01:00+00	\N	DOH-104	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
f0ff0b1b-8905-5aa3-a880-a61874a8b362	62445afe-3364-5e78-b55e-fb5429807a47	8e9f41ef-4f61-5811-a73e-3a8bfbf74881	35f8aab0-9932-515e-80cc-e8fa82f9c650	2026-05-20	02:45:00	Code review — Risk Dashboard	2026-05-20 09:01:00+00	2026-05-20 09:01:00+00	\N	RD-122	f4c5b0e8-5503-5a50-8487-4ae103b885f2	Active	Worklog
00906218-d27a-5037-8966-310cab8408da	62445afe-3364-5e78-b55e-fb5429807a47	8e9f41ef-4f61-5811-a73e-3a8bfbf74881	f04245fa-9e0e-5905-80fa-524e9f1e172f	2026-05-21	00:15:00	Code review — Delivery Operations Hub	2026-05-21 09:01:00+00	2026-05-21 09:01:00+00	\N	DOH-150	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
0c26d1df-187a-5328-9245-b45a3977dd79	62445afe-3364-5e78-b55e-fb5429807a47	8e9f41ef-4f61-5811-a73e-3a8bfbf74881	f07ee933-bae1-5f0f-9e95-6c303aba6f5d	2026-05-22	00:45:00	Code review — Open Banking Integration	2026-05-22 09:01:00+00	2026-05-22 09:01:00+00	\N	OBI-169	f4c5b0e8-5503-5a50-8487-4ae103b885f2	Active	Worklog
c2fa1eb5-71b0-5c32-bd26-52527d3a2c13	62445afe-3364-5e78-b55e-fb5429807a47	8e9f41ef-4f61-5811-a73e-3a8bfbf74881	35f8aab0-9932-515e-80cc-e8fa82f9c650	2026-05-25	02:15:00	Code review — Risk Dashboard	2026-05-25 09:01:00+00	2026-05-25 09:01:00+00	\N	RD-124	f4c5b0e8-5503-5a50-8487-4ae103b885f2	Active	Worklog
26db47f0-3977-5788-b51e-781c9e8db9ff	62445afe-3364-5e78-b55e-fb5429807a47	8e9f41ef-4f61-5811-a73e-3a8bfbf74881	f04245fa-9e0e-5905-80fa-524e9f1e172f	2026-05-26	02:45:00	Code review — Delivery Operations Hub	2026-05-26 09:01:00+00	2026-05-26 09:01:00+00	\N	DOH-143	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
e51fea46-b2aa-53d4-8a87-d8db1d9253b7	62445afe-3364-5e78-b55e-fb5429807a47	8e9f41ef-4f61-5811-a73e-3a8bfbf74881	35f8aab0-9932-515e-80cc-e8fa82f9c650	2026-05-28	00:45:00	Code review — Risk Dashboard	2026-05-28 09:01:00+00	2026-05-28 09:01:00+00	\N	RD-117	f4c5b0e8-5503-5a50-8487-4ae103b885f2	Active	Worklog
ef1bd624-e492-52fd-8a09-c8e993db9bb7	62445afe-3364-5e78-b55e-fb5429807a47	8e9f41ef-4f61-5811-a73e-3a8bfbf74881	f07ee933-bae1-5f0f-9e95-6c303aba6f5d	2026-05-31	02:45:00	Code review — Open Banking Integration	2026-05-31 09:01:00+00	2026-05-31 09:01:00+00	\N	OBI-164	f4c5b0e8-5503-5a50-8487-4ae103b885f2	Active	Worklog
46fdb152-0f05-554d-82cc-178ae62fec6d	62445afe-3364-5e78-b55e-fb5429807a47	8e9f41ef-4f61-5811-a73e-3a8bfbf74881	f04245fa-9e0e-5905-80fa-524e9f1e172f	2026-06-02	00:45:00	Code review — Delivery Operations Hub	2026-06-02 09:01:00+00	2026-06-02 09:01:00+00	\N	DOH-138	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
72bcb3d7-7b98-5b0d-b411-31d7d7c21bf4	62445afe-3364-5e78-b55e-fb5429807a47	8e9f41ef-4f61-5811-a73e-3a8bfbf74881	f04245fa-9e0e-5905-80fa-524e9f1e172f	2026-06-03	00:00:00	Client feedback added to the next iteration — Delivery Operations Hub	2026-06-03 09:01:00+00	2026-06-03 09:01:00+00	\N	\N	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Note
cc871967-30af-5ef3-bf50-c969aac2278b	62445afe-3364-5e78-b55e-fb5429807a47	8e9f41ef-4f61-5811-a73e-3a8bfbf74881	35f8aab0-9932-515e-80cc-e8fa82f9c650	2026-06-04	02:45:00	Code review — Risk Dashboard	2026-06-04 09:01:00+00	2026-06-04 09:01:00+00	\N	RD-112	f4c5b0e8-5503-5a50-8487-4ae103b885f2	Active	Worklog
e6c33f6d-abc7-5540-b71c-ea72cf596f77	62445afe-3364-5e78-b55e-fb5429807a47	8e9f41ef-4f61-5811-a73e-3a8bfbf74881	f07ee933-bae1-5f0f-9e95-6c303aba6f5d	2026-06-08	00:45:00	Code review — Open Banking Integration	2026-06-08 09:01:00+00	2026-06-08 09:01:00+00	\N	OBI-159	f4c5b0e8-5503-5a50-8487-4ae103b885f2	Active	Worklog
d0455640-d1f3-5728-a8be-5e3218639092	62445afe-3364-5e78-b55e-fb5429807a47	8e9f41ef-4f61-5811-a73e-3a8bfbf74881	f04245fa-9e0e-5905-80fa-524e9f1e172f	2026-06-10	02:45:00	Code review — Delivery Operations Hub	2026-06-10 09:01:00+00	2026-06-10 09:01:00+00	\N	DOH-133	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
415383d7-9ddb-5e38-86d4-4a18d7adc943	62445afe-3364-5e78-b55e-fb5429807a47	8e9f41ef-4f61-5811-a73e-3a8bfbf74881	f07ee933-bae1-5f0f-9e95-6c303aba6f5d	2026-06-11	03:15:00	Code review — Open Banking Integration	2026-06-11 09:01:00+00	2026-06-11 09:01:00+00	\N	OBI-152	f4c5b0e8-5503-5a50-8487-4ae103b885f2	Active	Worklog
d5856acf-17dc-5cef-b7a9-473def6b5030	62445afe-3364-5e78-b55e-fb5429807a47	8e9f41ef-4f61-5811-a73e-3a8bfbf74881	35f8aab0-9932-515e-80cc-e8fa82f9c650	2026-06-12	00:45:00	Code review — Risk Dashboard	2026-06-12 09:01:00+00	2026-06-12 09:01:00+00	\N	RD-107	f4c5b0e8-5503-5a50-8487-4ae103b885f2	Active	Worklog
e649bd53-f2a8-5db0-9940-cc925d2f77c8	62445afe-3364-5e78-b55e-fb5429807a47	8e9f41ef-4f61-5811-a73e-3a8bfbf74881	f04245fa-9e0e-5905-80fa-524e9f1e172f	2026-06-14	01:15:00	Code review — Delivery Operations Hub	2026-06-14 09:01:00+00	2026-06-14 09:01:00+00	\N	DOH-126	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
dc052599-6641-5c02-ae08-c77985b2bbc6	62445afe-3364-5e78-b55e-fb5429807a47	8e9f41ef-4f61-5811-a73e-3a8bfbf74881	35f8aab0-9932-515e-80cc-e8fa82f9c650	2026-06-16	03:15:00	Code review — Risk Dashboard	2026-06-16 09:01:00+00	2026-06-16 09:01:00+00	\N	RD-100	f4c5b0e8-5503-5a50-8487-4ae103b885f2	Active	Worklog
e0bba031-2ed9-58d4-a407-a5dd312f451a	62445afe-3364-5e78-b55e-fb5429807a47	8e9f41ef-4f61-5811-a73e-3a8bfbf74881	f07ee933-bae1-5f0f-9e95-6c303aba6f5d	2026-06-18	01:15:00	Code review — Open Banking Integration	2026-06-18 09:01:00+00	2026-06-18 09:01:00+00	\N	OBI-147	f4c5b0e8-5503-5a50-8487-4ae103b885f2	Active	Worklog
2e5284f7-6fa5-5cf2-992f-3dee724f9fab	62445afe-3364-5e78-b55e-fb5429807a47	8e9f41ef-4f61-5811-a73e-3a8bfbf74881	f04245fa-9e0e-5905-80fa-524e9f1e172f	2026-06-22	03:15:00	Code review — Delivery Operations Hub	2026-06-22 09:01:00+00	2026-06-22 09:01:00+00	\N	DOH-121	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
76b0b9cd-423c-5f0b-9e0d-36b5bd09af61	62445afe-3364-5e78-b55e-fb5429807a47	8e9f41ef-4f61-5811-a73e-3a8bfbf74881	35f8aab0-9932-515e-80cc-e8fa82f9c650	2026-06-24	01:15:00	Code review — Risk Dashboard	2026-06-24 09:01:00+00	2026-06-24 09:01:00+00	\N	RD-168	f4c5b0e8-5503-5a50-8487-4ae103b885f2	Active	Worklog
78ed6297-6886-5d94-ad9a-55669fb3c3b4	62445afe-3364-5e78-b55e-fb5429807a47	8e9f41ef-4f61-5811-a73e-3a8bfbf74881	35f8aab0-9932-515e-80cc-e8fa82f9c650	2026-06-25	00:00:00	Client feedback added to the next iteration — Risk Dashboard	2026-06-25 09:01:00+00	2026-06-25 09:01:00+00	\N	\N	f4c5b0e8-5503-5a50-8487-4ae103b885f2	Active	Note
0c8d3cd7-4b33-5883-9706-792f842c9ea2	62445afe-3364-5e78-b55e-fb5429807a47	8e9f41ef-4f61-5811-a73e-3a8bfbf74881	f07ee933-bae1-5f0f-9e95-6c303aba6f5d	2026-06-26	03:15:00	Code review — Open Banking Integration	2026-06-26 09:01:00+00	2026-06-26 09:01:00+00	\N	OBI-142	f4c5b0e8-5503-5a50-8487-4ae103b885f2	Active	Worklog
ef5873ff-4b09-5d4e-84ad-a3ae96504166	62445afe-3364-5e78-b55e-fb5429807a47	8e9f41ef-4f61-5811-a73e-3a8bfbf74881	f04245fa-9e0e-5905-80fa-524e9f1e172f	2026-06-29	01:15:00	Code review — Delivery Operations Hub	2026-06-29 09:01:00+00	2026-06-29 09:01:00+00	\N	DOH-116	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
6d8b00b2-c818-59db-be72-3a67f0f536f7	62445afe-3364-5e78-b55e-fb5429807a47	8e9f41ef-4f61-5811-a73e-3a8bfbf74881	3d5d3faf-2bbd-5bca-ac00-1c6056bf7ca6	2026-06-29	00:45:00	Historical delivery wrap-up — Dispatch Optimizer	2026-06-29 09:02:00+00	2026-06-29 09:02:00+00	2026-07-13 00:00:00+00	DOP-946	141122b1-9a71-570d-a44c-efc88209be99	Archived	Worklog
36eccbb4-0fb8-5cdd-8855-31e78fe80300	62445afe-3364-5e78-b55e-fb5429807a47	8e9f41ef-4f61-5811-a73e-3a8bfbf74881	35f8aab0-9932-515e-80cc-e8fa82f9c650	2026-07-01	03:15:00	Code review — Risk Dashboard	2026-07-01 09:01:00+00	2026-07-01 09:01:00+00	\N	RD-163	f4c5b0e8-5503-5a50-8487-4ae103b885f2	Active	Worklog
94af98a5-3455-5f80-9421-c34ee5786bc5	62445afe-3364-5e78-b55e-fb5429807a47	8e9f41ef-4f61-5811-a73e-3a8bfbf74881	f04245fa-9e0e-5905-80fa-524e9f1e172f	2026-07-02	03:45:00	Code review — Delivery Operations Hub	2026-07-02 09:01:00+00	2026-07-02 09:01:00+00	\N	DOH-109	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
2b5c1b09-1df8-5343-b2aa-8d094229b629	62445afe-3364-5e78-b55e-fb5429807a47	8e9f41ef-4f61-5811-a73e-3a8bfbf74881	f07ee933-bae1-5f0f-9e95-6c303aba6f5d	2026-07-03	01:15:00	Code review — Open Banking Integration	2026-07-03 09:01:00+00	2026-07-03 09:01:00+00	\N	OBI-137	f4c5b0e8-5503-5a50-8487-4ae103b885f2	Active	Worklog
73615843-4111-574b-8118-9566b31e18c0	62445afe-3364-5e78-b55e-fb5429807a47	8e9f41ef-4f61-5811-a73e-3a8bfbf74881	35f8aab0-9932-515e-80cc-e8fa82f9c650	2026-07-06	01:45:00	Code review — Risk Dashboard	2026-07-06 09:01:00+00	2026-07-06 09:01:00+00	\N	RD-156	f4c5b0e8-5503-5a50-8487-4ae103b885f2	Active	Worklog
0fb2379a-abfd-5e03-b2ee-1bf43ef233c0	62445afe-3364-5e78-b55e-fb5429807a47	8e9f41ef-4f61-5811-a73e-3a8bfbf74881	f07ee933-bae1-5f0f-9e95-6c303aba6f5d	2026-07-08	03:45:00	Code review — Open Banking Integration	2026-07-08 09:01:00+00	2026-07-08 09:01:00+00	\N	OBI-130	f4c5b0e8-5503-5a50-8487-4ae103b885f2	Active	Worklog
6e4f62a8-27f7-5a5d-8b7f-8e3148202d9a	62445afe-3364-5e78-b55e-fb5429807a47	8e9f41ef-4f61-5811-a73e-3a8bfbf74881	3d5d3faf-2bbd-5bca-ac00-1c6056bf7ca6	2026-07-08	01:45:00	Historical delivery wrap-up — Dispatch Optimizer	2026-07-08 09:02:00+00	2026-07-08 09:02:00+00	2026-07-13 00:00:00+00	DOP-910	141122b1-9a71-570d-a44c-efc88209be99	Archived	Worklog
72e16df9-fb7e-5b13-8807-7f0e593bcbb1	62445afe-3364-5e78-b55e-fb5429807a47	8e9f41ef-4f61-5811-a73e-3a8bfbf74881	f04245fa-9e0e-5905-80fa-524e9f1e172f	2026-07-10	01:45:00	Code review — Delivery Operations Hub	2026-07-10 09:01:00+00	2026-07-10 09:01:00+00	\N	DOH-104	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
736b13f3-1a7f-5e0a-a1da-2b94c7a39fcc	62445afe-3364-5e78-b55e-fb5429807a47	8e9f41ef-4f61-5811-a73e-3a8bfbf74881	3d5d3faf-2bbd-5bca-ac00-1c6056bf7ca6	2026-07-11	01:15:00	Historical delivery wrap-up — Dispatch Optimizer	2026-07-11 09:01:00+00	2026-07-11 09:01:00+00	2026-07-13 00:00:00+00	DOP-928	141122b1-9a71-570d-a44c-efc88209be99	Archived	Worklog
bab4ffb9-c3d3-5ed2-9017-8685441736cd	62445afe-3364-5e78-b55e-fb5429807a47	8e9f41ef-4f61-5811-a73e-3a8bfbf74881	35f8aab0-9932-515e-80cc-e8fa82f9c650	2026-07-13	03:45:00	Code review — Risk Dashboard	2026-07-13 09:01:00+00	2026-07-13 09:01:00+00	\N	RD-151	f4c5b0e8-5503-5a50-8487-4ae103b885f2	Active	Worklog
c10d8f56-ac38-5e41-aa63-70724325c779	62445afe-3364-5e78-b55e-fb5429807a47	8e9f41ef-4f61-5811-a73e-3a8bfbf74881	f07ee933-bae1-5f0f-9e95-6c303aba6f5d	2026-07-15	01:45:00	Code review — Open Banking Integration	2026-07-15 09:01:00+00	2026-07-15 09:01:00+00	\N	OBI-125	f4c5b0e8-5503-5a50-8487-4ae103b885f2	Active	Worklog
f50ce82a-f20b-5726-a1bc-3770fb9b6909	62445afe-3364-5e78-b55e-fb5429807a47	8e9f41ef-4f61-5811-a73e-3a8bfbf74881	f07ee933-bae1-5f0f-9e95-6c303aba6f5d	2026-07-16	00:00:00	Client feedback added to the next iteration — Open Banking Integration	2026-07-16 09:01:00+00	2026-07-16 09:01:00+00	\N	\N	f4c5b0e8-5503-5a50-8487-4ae103b885f2	Active	Note
49264cc7-aaeb-5797-9f6a-51c5cc8095de	62445afe-3364-5e78-b55e-fb5429807a47	8e9f41ef-4f61-5811-a73e-3a8bfbf74881	f04245fa-9e0e-5905-80fa-524e9f1e172f	2026-07-17	03:45:00	Code review — Delivery Operations Hub	2026-07-17 09:01:00+00	2026-07-17 09:01:00+00	\N	DOH-172	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
38ac241e-7a5e-5d65-b54c-e230864fe65c	62445afe-3364-5e78-b55e-fb5429807a47	8e9f41ef-4f61-5811-a73e-3a8bfbf74881	35f8aab0-9932-515e-80cc-e8fa82f9c650	2026-07-21	01:45:00	Code review — Risk Dashboard	2026-07-21 09:01:00+00	2026-07-21 09:01:00+00	\N	RD-146	f4c5b0e8-5503-5a50-8487-4ae103b885f2	Active	Worklog
66cde87a-c2b9-5265-a802-ecc52a1bab85	62445afe-3364-5e78-b55e-fb5429807a47	8e9f41ef-4f61-5811-a73e-3a8bfbf74881	f07ee933-bae1-5f0f-9e95-6c303aba6f5d	2026-07-23	03:45:00	Code review — Open Banking Integration	2026-07-23 09:01:00+00	2026-07-23 09:01:00+00	\N	OBI-120	f4c5b0e8-5503-5a50-8487-4ae103b885f2	Active	Worklog
77057ada-7d2b-5220-8c25-2067103a89e4	62445afe-3364-5e78-b55e-fb5429807a47	8e9f41ef-4f61-5811-a73e-3a8bfbf74881	35f8aab0-9932-515e-80cc-e8fa82f9c650	2026-07-24	00:15:00	Code review — Risk Dashboard	2026-07-24 09:01:00+00	2026-07-24 09:01:00+00	\N	RD-139	f4c5b0e8-5503-5a50-8487-4ae103b885f2	Active	Worklog
3dcace4e-5119-5f5a-9703-6e1ab6b13906	62445afe-3364-5e78-b55e-fb5429807a47	8e9f41ef-4f61-5811-a73e-3a8bfbf74881	f04245fa-9e0e-5905-80fa-524e9f1e172f	2026-07-26	01:45:00	Code review — Delivery Operations Hub	2026-07-26 09:01:00+00	2026-07-26 09:01:00+00	\N	DOH-167	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
3373f77a-0048-5f21-9fc9-c837ea29a40d	62445afe-3364-5e78-b55e-fb5429807a47	8e9f41ef-4f61-5811-a73e-3a8bfbf74881	f07ee933-bae1-5f0f-9e95-6c303aba6f5d	2026-07-27	02:15:00	Code review — Open Banking Integration	2026-07-27 09:01:00+00	2026-07-27 09:01:00+00	\N	OBI-113	f4c5b0e8-5503-5a50-8487-4ae103b885f2	Active	Worklog
eb0b9ec6-5e11-5f38-80b2-253796b29906	62445afe-3364-5e78-b55e-fb5429807a47	8e9f41ef-4f61-5811-a73e-3a8bfbf74881	f04245fa-9e0e-5905-80fa-524e9f1e172f	2026-07-29	00:15:00	Code review — Delivery Operations Hub	2026-07-29 09:01:00+00	2026-07-29 09:01:00+00	\N	DOH-160	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
de1ea89f-a004-55b6-b9ea-715861ab8eaa	62445afe-3364-5e78-b55e-fb5429807a47	8e9f41ef-4f61-5811-a73e-3a8bfbf74881	35f8aab0-9932-515e-80cc-e8fa82f9c650	2026-07-31	02:15:00	Code review — Risk Dashboard	2026-07-31 09:01:00+00	2026-07-31 09:01:00+00	\N	RD-134	f4c5b0e8-5503-5a50-8487-4ae103b885f2	Active	Worklog
038eb853-62e3-5228-8db4-723350560523	62445afe-3364-5e78-b55e-fb5429807a47	8e9f41ef-4f61-5811-a73e-3a8bfbf74881	f07ee933-bae1-5f0f-9e95-6c303aba6f5d	2026-08-04	00:15:00	Code review — Open Banking Integration	2026-08-04 09:01:00+00	2026-08-04 09:01:00+00	\N	OBI-108	f4c5b0e8-5503-5a50-8487-4ae103b885f2	Active	Worklog
3ca0a93f-54d4-569e-9e81-1fe5e817f8e7	62445afe-3364-5e78-b55e-fb5429807a47	8e9f41ef-4f61-5811-a73e-3a8bfbf74881	f04245fa-9e0e-5905-80fa-524e9f1e172f	2026-08-06	02:15:00	Code review — Delivery Operations Hub	2026-08-06 09:01:00+00	2026-08-06 09:01:00+00	\N	DOH-155	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
e649ce33-4c3e-5ecb-a1e6-d6677281ca0c	62445afe-3364-5e78-b55e-fb5429807a47	8e9f41ef-4f61-5811-a73e-3a8bfbf74881	35f8aab0-9932-515e-80cc-e8fa82f9c650	2026-08-09	00:15:00	Code review — Risk Dashboard	2026-08-09 09:01:00+00	2026-08-09 09:01:00+00	\N	RD-129	f4c5b0e8-5503-5a50-8487-4ae103b885f2	Active	Worklog
2e766bbe-1f39-57db-a6cc-7b363463fb29	62445afe-3364-5e78-b55e-fb5429807a47	8e9f41ef-4f61-5811-a73e-3a8bfbf74881	f07ee933-bae1-5f0f-9e95-6c303aba6f5d	2026-08-11	02:15:00	Code review — Open Banking Integration	2026-08-11 09:01:00+00	2026-08-11 09:01:00+00	\N	OBI-103	f4c5b0e8-5503-5a50-8487-4ae103b885f2	Active	Worklog
2c04cdb3-7fcc-53d4-b8ca-8e941a711c57	62445afe-3364-5e78-b55e-fb5429807a47	69b673aa-8141-5faa-8677-2839e80e1d78	f07ee933-bae1-5f0f-9e95-6c303aba6f5d	2026-05-20	02:45:00	Release preparation — Open Banking Integration	2026-05-20 09:01:00+00	2026-05-20 09:01:00+00	\N	OBI-106	f4c5b0e8-5503-5a50-8487-4ae103b885f2	Active	Worklog
7bd386ee-e62b-55ff-8739-ceda715a0636	62445afe-3364-5e78-b55e-fb5429807a47	69b673aa-8141-5faa-8677-2839e80e1d78	f07ee933-bae1-5f0f-9e95-6c303aba6f5d	2026-05-21	00:15:00	Release preparation — Open Banking Integration	2026-05-21 09:01:00+00	2026-05-21 09:01:00+00	\N	OBI-134	f4c5b0e8-5503-5a50-8487-4ae103b885f2	Active	Worklog
6b405418-20de-5bce-9273-9aca47f58e90	62445afe-3364-5e78-b55e-fb5429807a47	69b673aa-8141-5faa-8677-2839e80e1d78	a7906be2-315f-5b5e-b344-ac119fd04d1a	2026-05-22	00:45:00	Release preparation — Omnichannel Checkout	2026-05-22 09:01:00+00	2026-05-22 09:01:00+00	\N	OC-153	3030e191-44de-5909-b035-5fe3679b482a	Active	Worklog
34092fd6-ab05-5fbc-8920-f86b00c10016	62445afe-3364-5e78-b55e-fb5429807a47	69b673aa-8141-5faa-8677-2839e80e1d78	a7906be2-315f-5b5e-b344-ac119fd04d1a	2026-05-25	02:15:00	Release preparation — Omnichannel Checkout	2026-05-25 09:01:00+00	2026-05-25 09:01:00+00	\N	OC-108	3030e191-44de-5909-b035-5fe3679b482a	Active	Worklog
9d5b3541-232a-574e-861b-8d1fb5e57ae7	62445afe-3364-5e78-b55e-fb5429807a47	69b673aa-8141-5faa-8677-2839e80e1d78	b8cd683c-fe4d-538c-bdaf-68c28e1e14ef	2026-05-26	02:45:00	Release preparation — Time Intelligence	2026-05-26 09:01:00+00	2026-05-26 09:01:00+00	\N	TI-127	d677a650-2c23-5c0c-9f53-920636bd318e	Active	Worklog
5e40fd39-6e44-55fa-b90d-65a2f97c62bb	62445afe-3364-5e78-b55e-fb5429807a47	69b673aa-8141-5faa-8677-2839e80e1d78	6dfe9630-59ce-507d-81a0-2f94cb54247f	2026-05-28	00:45:00	Release preparation — Fleet Companion	2026-05-28 09:01:00+00	2026-05-28 09:01:00+00	\N	FC-101	eba17d28-b076-534c-918a-dca0a5be8fab	Active	Worklog
d07b7d32-ad26-5835-8ef4-e818858d06cd	62445afe-3364-5e78-b55e-fb5429807a47	69b673aa-8141-5faa-8677-2839e80e1d78	9406b74a-6b7a-578b-8fbd-958684d93780	2026-05-31	02:45:00	Release preparation — Patient Portal	2026-05-31 09:01:00+00	2026-05-31 09:01:00+00	\N	PP-148	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
51469b54-74d6-5485-8c91-ce99a20e18b9	62445afe-3364-5e78-b55e-fb5429807a47	69b673aa-8141-5faa-8677-2839e80e1d78	35f8aab0-9932-515e-80cc-e8fa82f9c650	2026-06-02	00:45:00	Release preparation — Risk Dashboard	2026-06-02 09:01:00+00	2026-06-02 09:01:00+00	\N	RD-122	f4c5b0e8-5503-5a50-8487-4ae103b885f2	Active	Worklog
405a7388-5300-53e1-8867-2bb1ffc3572d	62445afe-3364-5e78-b55e-fb5429807a47	69b673aa-8141-5faa-8677-2839e80e1d78	a7906be2-315f-5b5e-b344-ac119fd04d1a	2026-06-03	00:00:00	Discovery follow-up zaplanowany na kolejny tydzień — Omnichannel Checkout	2026-06-03 09:01:00+00	2026-06-03 09:01:00+00	\N	\N	3030e191-44de-5909-b035-5fe3679b482a	Active	Note
79c3d6d5-7df3-54dc-9f1c-baba5b9237a0	62445afe-3364-5e78-b55e-fb5429807a47	69b673aa-8141-5faa-8677-2839e80e1d78	e7ea37c3-9fe3-5010-bb38-8c7330ef5bdc	2026-06-04	02:45:00	Release preparation — Care Analytics	2026-06-04 09:01:00+00	2026-06-04 09:01:00+00	\N	CA-169	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
9812349b-4be4-5885-9634-3e44e22e40a9	62445afe-3364-5e78-b55e-fb5429807a47	69b673aa-8141-5faa-8677-2839e80e1d78	f07ee933-bae1-5f0f-9e95-6c303aba6f5d	2026-06-08	00:45:00	Release preparation — Open Banking Integration	2026-06-08 09:01:00+00	2026-06-08 09:01:00+00	\N	OBI-143	f4c5b0e8-5503-5a50-8487-4ae103b885f2	Active	Worklog
9ca43bb7-3f65-5773-adb4-7b94370bc33e	62445afe-3364-5e78-b55e-fb5429807a47	69b673aa-8141-5faa-8677-2839e80e1d78	a7906be2-315f-5b5e-b344-ac119fd04d1a	2026-06-10	02:45:00	Release preparation — Omnichannel Checkout	2026-06-10 09:01:00+00	2026-06-10 09:01:00+00	\N	OC-117	3030e191-44de-5909-b035-5fe3679b482a	Active	Worklog
57e53aa1-1462-522b-83e3-68bce65c54d0	62445afe-3364-5e78-b55e-fb5429807a47	69b673aa-8141-5faa-8677-2839e80e1d78	b8cd683c-fe4d-538c-bdaf-68c28e1e14ef	2026-06-11	03:15:00	Release preparation — Time Intelligence	2026-06-11 09:01:00+00	2026-06-11 09:01:00+00	\N	TI-136	d677a650-2c23-5c0c-9f53-920636bd318e	Active	Worklog
e31c76ca-9300-5980-b6ec-7e81bbb26a84	62445afe-3364-5e78-b55e-fb5429807a47	69b673aa-8141-5faa-8677-2839e80e1d78	b8cd683c-fe4d-538c-bdaf-68c28e1e14ef	2026-06-12	00:45:00	Release preparation — Time Intelligence	2026-06-12 09:01:00+00	2026-06-12 09:01:00+00	\N	TI-164	d677a650-2c23-5c0c-9f53-920636bd318e	Active	Worklog
e01169df-d80e-5598-8153-ce0342405257	62445afe-3364-5e78-b55e-fb5429807a47	69b673aa-8141-5faa-8677-2839e80e1d78	6dfe9630-59ce-507d-81a0-2f94cb54247f	2026-06-14	01:15:00	Release preparation — Fleet Companion	2026-06-14 09:01:00+00	2026-06-14 09:01:00+00	\N	FC-110	eba17d28-b076-534c-918a-dca0a5be8fab	Active	Worklog
059b4884-a5d9-5ee7-b94e-94a2fd58897d	62445afe-3364-5e78-b55e-fb5429807a47	69b673aa-8141-5faa-8677-2839e80e1d78	9406b74a-6b7a-578b-8fbd-958684d93780	2026-06-16	03:15:00	Release preparation — Patient Portal	2026-06-16 09:01:00+00	2026-06-16 09:01:00+00	\N	PP-157	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
0dae8db6-a0da-5941-81ec-5b943e6303ab	62445afe-3364-5e78-b55e-fb5429807a47	69b673aa-8141-5faa-8677-2839e80e1d78	35f8aab0-9932-515e-80cc-e8fa82f9c650	2026-06-18	01:15:00	Release preparation — Risk Dashboard	2026-06-18 09:01:00+00	2026-06-18 09:01:00+00	\N	RD-131	f4c5b0e8-5503-5a50-8487-4ae103b885f2	Active	Worklog
3682f780-c85c-5a46-ac21-b98f4df60333	62445afe-3364-5e78-b55e-fb5429807a47	69b673aa-8141-5faa-8677-2839e80e1d78	e7ea37c3-9fe3-5010-bb38-8c7330ef5bdc	2026-06-22	03:15:00	Release preparation — Care Analytics	2026-06-22 09:01:00+00	2026-06-22 09:01:00+00	\N	CA-105	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
732d557d-f639-54c0-877b-ca6a7f4b0d4a	62445afe-3364-5e78-b55e-fb5429807a47	69b673aa-8141-5faa-8677-2839e80e1d78	f07ee933-bae1-5f0f-9e95-6c303aba6f5d	2026-06-24	01:15:00	Release preparation — Open Banking Integration	2026-06-24 09:01:00+00	2026-06-24 09:01:00+00	\N	OBI-152	f4c5b0e8-5503-5a50-8487-4ae103b885f2	Active	Worklog
7bfb802d-7360-5132-90ff-c3e91eb60f6a	62445afe-3364-5e78-b55e-fb5429807a47	69b673aa-8141-5faa-8677-2839e80e1d78	6dfe9630-59ce-507d-81a0-2f94cb54247f	2026-06-25	00:00:00	Discovery follow-up zaplanowany na kolejny tydzień — Fleet Companion	2026-06-25 09:01:00+00	2026-06-25 09:01:00+00	\N	\N	eba17d28-b076-534c-918a-dca0a5be8fab	Active	Note
c263dea8-c880-54d1-a3ba-2c0707cfcb70	62445afe-3364-5e78-b55e-fb5429807a47	69b673aa-8141-5faa-8677-2839e80e1d78	a7906be2-315f-5b5e-b344-ac119fd04d1a	2026-06-26	03:15:00	Release preparation — Omnichannel Checkout	2026-06-26 09:01:00+00	2026-06-26 09:01:00+00	\N	OC-126	3030e191-44de-5909-b035-5fe3679b482a	Active	Worklog
50173df5-e456-5d18-a214-9f0ef8fe8a7f	62445afe-3364-5e78-b55e-fb5429807a47	69b673aa-8141-5faa-8677-2839e80e1d78	b8cd683c-fe4d-538c-bdaf-68c28e1e14ef	2026-06-29	01:15:00	Release preparation — Time Intelligence	2026-06-29 09:01:00+00	2026-06-29 09:01:00+00	\N	TI-100	d677a650-2c23-5c0c-9f53-920636bd318e	Active	Worklog
04d3fa1f-7995-5c46-87b2-5b4156edfd73	62445afe-3364-5e78-b55e-fb5429807a47	69b673aa-8141-5faa-8677-2839e80e1d78	6dfe9630-59ce-507d-81a0-2f94cb54247f	2026-07-01	03:15:00	Release preparation — Fleet Companion	2026-07-01 09:01:00+00	2026-07-01 09:01:00+00	\N	FC-147	eba17d28-b076-534c-918a-dca0a5be8fab	Active	Worklog
39e5c9ae-93d6-52f9-a91e-f4ddb0a659a2	62445afe-3364-5e78-b55e-fb5429807a47	69b673aa-8141-5faa-8677-2839e80e1d78	9406b74a-6b7a-578b-8fbd-958684d93780	2026-07-02	03:45:00	Release preparation — Patient Portal	2026-07-02 09:01:00+00	2026-07-02 09:01:00+00	\N	PP-166	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
5d0cec72-6349-5d18-b5ec-8ec290e91544	62445afe-3364-5e78-b55e-fb5429807a47	69b673aa-8141-5faa-8677-2839e80e1d78	9406b74a-6b7a-578b-8fbd-958684d93780	2026-07-03	01:15:00	Release preparation — Patient Portal	2026-07-03 09:01:00+00	2026-07-03 09:01:00+00	\N	PP-121	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
34ec852e-19f5-54ac-b524-e21dc3112684	62445afe-3364-5e78-b55e-fb5429807a47	69b673aa-8141-5faa-8677-2839e80e1d78	35f8aab0-9932-515e-80cc-e8fa82f9c650	2026-07-06	01:45:00	Release preparation — Risk Dashboard	2026-07-06 09:01:00+00	2026-07-06 09:01:00+00	\N	RD-140	f4c5b0e8-5503-5a50-8487-4ae103b885f2	Active	Worklog
094aa41a-6d13-5559-b822-a31a197c1278	62445afe-3364-5e78-b55e-fb5429807a47	69b673aa-8141-5faa-8677-2839e80e1d78	e7ea37c3-9fe3-5010-bb38-8c7330ef5bdc	2026-07-08	03:45:00	Release preparation — Care Analytics	2026-07-08 09:01:00+00	2026-07-08 09:01:00+00	\N	CA-114	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
aee1a3a9-b15d-5237-934a-cd912d6425c1	62445afe-3364-5e78-b55e-fb5429807a47	69b673aa-8141-5faa-8677-2839e80e1d78	f07ee933-bae1-5f0f-9e95-6c303aba6f5d	2026-07-10	01:45:00	Release preparation — Open Banking Integration	2026-07-10 09:01:00+00	2026-07-10 09:01:00+00	\N	OBI-161	f4c5b0e8-5503-5a50-8487-4ae103b885f2	Active	Worklog
47c76a6f-9816-5e13-89a2-6e612b5b32fa	62445afe-3364-5e78-b55e-fb5429807a47	69b673aa-8141-5faa-8677-2839e80e1d78	a7906be2-315f-5b5e-b344-ac119fd04d1a	2026-07-13	03:45:00	Release preparation — Omnichannel Checkout	2026-07-13 09:01:00+00	2026-07-13 09:01:00+00	\N	OC-135	3030e191-44de-5909-b035-5fe3679b482a	Active	Worklog
7bffcf11-5751-5c59-b32a-d3e9a7a91327	62445afe-3364-5e78-b55e-fb5429807a47	69b673aa-8141-5faa-8677-2839e80e1d78	b8cd683c-fe4d-538c-bdaf-68c28e1e14ef	2026-07-15	01:45:00	Release preparation — Time Intelligence	2026-07-15 09:01:00+00	2026-07-15 09:01:00+00	\N	TI-109	d677a650-2c23-5c0c-9f53-920636bd318e	Active	Worklog
725fcb3c-2f3e-570f-817f-8ba5ece0f015	62445afe-3364-5e78-b55e-fb5429807a47	69b673aa-8141-5faa-8677-2839e80e1d78	35f8aab0-9932-515e-80cc-e8fa82f9c650	2026-07-16	00:00:00	Discovery follow-up zaplanowany na kolejny tydzień — Risk Dashboard	2026-07-16 09:01:00+00	2026-07-16 09:01:00+00	\N	\N	f4c5b0e8-5503-5a50-8487-4ae103b885f2	Active	Note
fed77439-5e5a-5bfb-97c1-bda99a5d1805	62445afe-3364-5e78-b55e-fb5429807a47	69b673aa-8141-5faa-8677-2839e80e1d78	6dfe9630-59ce-507d-81a0-2f94cb54247f	2026-07-17	03:45:00	Release preparation — Fleet Companion	2026-07-17 09:01:00+00	2026-07-17 09:01:00+00	\N	FC-156	eba17d28-b076-534c-918a-dca0a5be8fab	Active	Worklog
ec0f1033-f292-52d3-aab5-c69772e87cc3	62445afe-3364-5e78-b55e-fb5429807a47	69b673aa-8141-5faa-8677-2839e80e1d78	9406b74a-6b7a-578b-8fbd-958684d93780	2026-07-21	01:45:00	Release preparation — Patient Portal	2026-07-21 09:01:00+00	2026-07-21 09:01:00+00	\N	PP-130	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
caf11b03-19af-58dc-ab7a-e4043de2eb89	62445afe-3364-5e78-b55e-fb5429807a47	69b673aa-8141-5faa-8677-2839e80e1d78	35f8aab0-9932-515e-80cc-e8fa82f9c650	2026-07-23	03:45:00	Release preparation — Risk Dashboard	2026-07-23 09:01:00+00	2026-07-23 09:01:00+00	\N	RD-104	f4c5b0e8-5503-5a50-8487-4ae103b885f2	Active	Worklog
49c56f30-fb9d-579e-9fa7-e38ad0655964	62445afe-3364-5e78-b55e-fb5429807a47	69b673aa-8141-5faa-8677-2839e80e1d78	e7ea37c3-9fe3-5010-bb38-8c7330ef5bdc	2026-07-24	00:15:00	Release preparation — Care Analytics	2026-07-24 09:01:00+00	2026-07-24 09:01:00+00	\N	CA-123	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
cccf4b6f-f97d-5edb-ab31-9e50c7cdee32	62445afe-3364-5e78-b55e-fb5429807a47	69b673aa-8141-5faa-8677-2839e80e1d78	e7ea37c3-9fe3-5010-bb38-8c7330ef5bdc	2026-07-26	01:45:00	Release preparation — Care Analytics	2026-07-26 09:01:00+00	2026-07-26 09:01:00+00	\N	CA-151	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
8406965a-9550-514c-8872-62406a9cf8d3	62445afe-3364-5e78-b55e-fb5429807a47	69b673aa-8141-5faa-8677-2839e80e1d78	f07ee933-bae1-5f0f-9e95-6c303aba6f5d	2026-07-27	02:15:00	Release preparation — Open Banking Integration	2026-07-27 09:01:00+00	2026-07-27 09:01:00+00	\N	OBI-170	f4c5b0e8-5503-5a50-8487-4ae103b885f2	Active	Worklog
563f3bc7-ccc8-55ca-a974-ba02999edfdc	62445afe-3364-5e78-b55e-fb5429807a47	69b673aa-8141-5faa-8677-2839e80e1d78	a7906be2-315f-5b5e-b344-ac119fd04d1a	2026-07-29	00:15:00	Release preparation — Omnichannel Checkout	2026-07-29 09:01:00+00	2026-07-29 09:01:00+00	\N	OC-144	3030e191-44de-5909-b035-5fe3679b482a	Active	Worklog
7608a595-5a4a-5fb0-9b10-40f09a1490b0	62445afe-3364-5e78-b55e-fb5429807a47	69b673aa-8141-5faa-8677-2839e80e1d78	b8cd683c-fe4d-538c-bdaf-68c28e1e14ef	2026-07-31	02:15:00	Release preparation — Time Intelligence	2026-07-31 09:01:00+00	2026-07-31 09:01:00+00	\N	TI-118	d677a650-2c23-5c0c-9f53-920636bd318e	Active	Worklog
4e50774c-5e23-5b70-9d37-ff785a1d8f83	62445afe-3364-5e78-b55e-fb5429807a47	69b673aa-8141-5faa-8677-2839e80e1d78	6dfe9630-59ce-507d-81a0-2f94cb54247f	2026-08-04	00:15:00	Release preparation — Fleet Companion	2026-08-04 09:01:00+00	2026-08-04 09:01:00+00	\N	FC-165	eba17d28-b076-534c-918a-dca0a5be8fab	Active	Worklog
2dc08ca9-70c7-5212-91b0-9f202b8b37c9	62445afe-3364-5e78-b55e-fb5429807a47	69b673aa-8141-5faa-8677-2839e80e1d78	9406b74a-6b7a-578b-8fbd-958684d93780	2026-08-06	02:15:00	Release preparation — Patient Portal	2026-08-06 09:01:00+00	2026-08-06 09:01:00+00	\N	PP-139	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
2fe1e193-7304-5def-85cf-0638ee1e5daf	62445afe-3364-5e78-b55e-fb5429807a47	69b673aa-8141-5faa-8677-2839e80e1d78	35f8aab0-9932-515e-80cc-e8fa82f9c650	2026-08-09	00:15:00	Release preparation — Risk Dashboard	2026-08-09 09:01:00+00	2026-08-09 09:01:00+00	\N	RD-113	f4c5b0e8-5503-5a50-8487-4ae103b885f2	Active	Worklog
0708b059-f6e3-5d08-8130-56b712b65038	62445afe-3364-5e78-b55e-fb5429807a47	69b673aa-8141-5faa-8677-2839e80e1d78	e7ea37c3-9fe3-5010-bb38-8c7330ef5bdc	2026-08-11	02:15:00	Release preparation — Care Analytics	2026-08-11 09:01:00+00	2026-08-11 09:01:00+00	\N	CA-160	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
f71d2e81-e038-52c8-8e88-247280c684a2	62445afe-3364-5e78-b55e-fb5429807a47	6657781f-74d0-50d8-8f90-7c701d622872	e7ea37c3-9fe3-5010-bb38-8c7330ef5bdc	2026-05-20	03:30:00	Architecture notes — Care Analytics	2026-05-20 09:01:00+00	2026-05-20 09:01:00+00	\N	CA-127	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
dfa5e510-25a5-5ebd-b2fa-6608a51c9894	62445afe-3364-5e78-b55e-fb5429807a47	6657781f-74d0-50d8-8f90-7c701d622872	e7ea37c3-9fe3-5010-bb38-8c7330ef5bdc	2026-05-21	01:00:00	Architecture notes — Care Analytics	2026-05-21 09:01:00+00	2026-05-21 09:01:00+00	\N	CA-155	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
4c9f125b-adfe-59a5-a9d8-d41d6d1cd027	62445afe-3364-5e78-b55e-fb5429807a47	6657781f-74d0-50d8-8f90-7c701d622872	e7ea37c3-9fe3-5010-bb38-8c7330ef5bdc	2026-05-22	01:30:00	Architecture notes — Care Analytics	2026-05-22 09:01:00+00	2026-05-22 09:01:00+00	\N	CA-101	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
db195729-2e8f-5503-a9f2-2b15da395cc7	62445afe-3364-5e78-b55e-fb5429807a47	6657781f-74d0-50d8-8f90-7c701d622872	e7ea37c3-9fe3-5010-bb38-8c7330ef5bdc	2026-05-25	03:00:00	Architecture notes — Care Analytics	2026-05-25 09:01:00+00	2026-05-25 09:01:00+00	\N	CA-129	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
43ff66b1-0770-5b9b-bc01-ab97b98bc450	62445afe-3364-5e78-b55e-fb5429807a47	6657781f-74d0-50d8-8f90-7c701d622872	e7ea37c3-9fe3-5010-bb38-8c7330ef5bdc	2026-05-26	03:30:00	Architecture notes — Care Analytics	2026-05-26 09:01:00+00	2026-05-26 09:01:00+00	\N	CA-148	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
8653ac00-3810-5759-b02a-976a45f5629d	62445afe-3364-5e78-b55e-fb5429807a47	6657781f-74d0-50d8-8f90-7c701d622872	e7ea37c3-9fe3-5010-bb38-8c7330ef5bdc	2026-05-28	01:30:00	Architecture notes — Care Analytics	2026-05-28 09:01:00+00	2026-05-28 09:01:00+00	\N	CA-122	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
29852522-3aed-564c-9992-16cb172362a4	62445afe-3364-5e78-b55e-fb5429807a47	6657781f-74d0-50d8-8f90-7c701d622872	e7ea37c3-9fe3-5010-bb38-8c7330ef5bdc	2026-05-31	03:30:00	Architecture notes — Care Analytics	2026-05-31 09:01:00+00	2026-05-31 09:01:00+00	\N	CA-169	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
89da6116-e5c6-5094-885f-08125c2c70c1	62445afe-3364-5e78-b55e-fb5429807a47	6657781f-74d0-50d8-8f90-7c701d622872	e7ea37c3-9fe3-5010-bb38-8c7330ef5bdc	2026-06-02	01:30:00	Architecture notes — Care Analytics	2026-06-02 09:01:00+00	2026-06-02 09:01:00+00	\N	CA-143	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
5aef2e05-4b86-5dbb-9cbf-ad261b296e74	62445afe-3364-5e78-b55e-fb5429807a47	6657781f-74d0-50d8-8f90-7c701d622872	e7ea37c3-9fe3-5010-bb38-8c7330ef5bdc	2026-06-03	00:00:00	Planowana nieobecność uwzględniona w harmonogramie — Care Analytics	2026-06-03 09:01:00+00	2026-06-03 09:01:00+00	\N	\N	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Note
9d7848ce-820b-55c8-96b6-89e7ec5ce483	62445afe-3364-5e78-b55e-fb5429807a47	6657781f-74d0-50d8-8f90-7c701d622872	e7ea37c3-9fe3-5010-bb38-8c7330ef5bdc	2026-06-04	03:30:00	Architecture notes — Care Analytics	2026-06-04 09:01:00+00	2026-06-04 09:01:00+00	\N	CA-117	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
5e342695-e773-595e-a90d-ff82bb24b120	62445afe-3364-5e78-b55e-fb5429807a47	6657781f-74d0-50d8-8f90-7c701d622872	e7ea37c3-9fe3-5010-bb38-8c7330ef5bdc	2026-06-08	01:30:00	Architecture notes — Care Analytics	2026-06-08 09:01:00+00	2026-06-08 09:01:00+00	\N	CA-164	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
9cb53738-4c9c-55b4-951b-a2e84b34d7e4	62445afe-3364-5e78-b55e-fb5429807a47	6657781f-74d0-50d8-8f90-7c701d622872	e7ea37c3-9fe3-5010-bb38-8c7330ef5bdc	2026-06-10	03:30:00	Architecture notes — Care Analytics	2026-06-10 09:01:00+00	2026-06-10 09:01:00+00	\N	CA-138	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
fca73cf8-d034-5f9f-aee5-aabbd873fbb5	62445afe-3364-5e78-b55e-fb5429807a47	6657781f-74d0-50d8-8f90-7c701d622872	e7ea37c3-9fe3-5010-bb38-8c7330ef5bdc	2026-06-11	04:00:00	Architecture notes — Care Analytics	2026-06-11 09:01:00+00	2026-06-11 09:01:00+00	\N	CA-157	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
9bf0a536-a5e8-57fd-ac60-b15e1edd4551	62445afe-3364-5e78-b55e-fb5429807a47	6657781f-74d0-50d8-8f90-7c701d622872	e7ea37c3-9fe3-5010-bb38-8c7330ef5bdc	2026-06-12	01:30:00	Architecture notes — Care Analytics	2026-06-12 09:01:00+00	2026-06-12 09:01:00+00	\N	CA-112	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
02401e13-dbe2-5289-b2f1-631ca4131aac	62445afe-3364-5e78-b55e-fb5429807a47	6657781f-74d0-50d8-8f90-7c701d622872	e7ea37c3-9fe3-5010-bb38-8c7330ef5bdc	2026-06-14	02:00:00	Architecture notes — Care Analytics	2026-06-14 09:01:00+00	2026-06-14 09:01:00+00	\N	CA-131	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
02a29378-19c2-5e99-9810-366b35f357bc	62445afe-3364-5e78-b55e-fb5429807a47	6657781f-74d0-50d8-8f90-7c701d622872	e7ea37c3-9fe3-5010-bb38-8c7330ef5bdc	2026-06-16	04:00:00	Architecture notes — Care Analytics	2026-06-16 09:01:00+00	2026-06-16 09:01:00+00	\N	CA-105	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
24f60caf-e577-53fa-829b-00a30bfdcb76	62445afe-3364-5e78-b55e-fb5429807a47	6657781f-74d0-50d8-8f90-7c701d622872	e7ea37c3-9fe3-5010-bb38-8c7330ef5bdc	2026-06-18	02:00:00	Architecture notes — Care Analytics	2026-06-18 09:01:00+00	2026-06-18 09:01:00+00	\N	CA-152	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
7e3f1e3c-bf57-5660-aee6-be7d03831572	62445afe-3364-5e78-b55e-fb5429807a47	6657781f-74d0-50d8-8f90-7c701d622872	e7ea37c3-9fe3-5010-bb38-8c7330ef5bdc	2026-06-22	04:00:00	Architecture notes — Care Analytics	2026-06-22 09:01:00+00	2026-06-22 09:01:00+00	\N	CA-126	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
a9976dce-e453-5dc2-b54a-46bded8c7e61	62445afe-3364-5e78-b55e-fb5429807a47	6657781f-74d0-50d8-8f90-7c701d622872	e7ea37c3-9fe3-5010-bb38-8c7330ef5bdc	2026-06-24	02:00:00	Architecture notes — Care Analytics	2026-06-24 09:01:00+00	2026-06-24 09:01:00+00	\N	CA-100	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
1c3dfcac-ac38-5348-97fb-57cd5cad878b	62445afe-3364-5e78-b55e-fb5429807a47	6657781f-74d0-50d8-8f90-7c701d622872	e7ea37c3-9fe3-5010-bb38-8c7330ef5bdc	2026-06-25	00:00:00	Planowana nieobecność uwzględniona w harmonogramie — Care Analytics	2026-06-25 09:01:00+00	2026-06-25 09:01:00+00	\N	\N	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Note
8e1a025f-9ac7-54b1-93ea-fc3c2c54981d	62445afe-3364-5e78-b55e-fb5429807a47	6657781f-74d0-50d8-8f90-7c701d622872	e7ea37c3-9fe3-5010-bb38-8c7330ef5bdc	2026-06-26	04:00:00	Architecture notes — Care Analytics	2026-06-26 09:01:00+00	2026-06-26 09:01:00+00	\N	CA-147	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
896655a7-3e3b-50f9-8461-5c675dce959a	62445afe-3364-5e78-b55e-fb5429807a47	6657781f-74d0-50d8-8f90-7c701d622872	e7ea37c3-9fe3-5010-bb38-8c7330ef5bdc	2026-06-29	02:00:00	Architecture notes — Care Analytics	2026-06-29 09:01:00+00	2026-06-29 09:01:00+00	\N	CA-121	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
6c16a96b-bef0-5be3-b999-33faa6990b5a	62445afe-3364-5e78-b55e-fb5429807a47	6657781f-74d0-50d8-8f90-7c701d622872	e7ea37c3-9fe3-5010-bb38-8c7330ef5bdc	2026-07-01	04:00:00	Architecture notes — Care Analytics	2026-07-01 09:01:00+00	2026-07-01 09:01:00+00	\N	CA-168	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
38790111-fb94-5a5e-85ff-b45868298d32	62445afe-3364-5e78-b55e-fb5429807a47	6657781f-74d0-50d8-8f90-7c701d622872	e7ea37c3-9fe3-5010-bb38-8c7330ef5bdc	2026-07-02	00:30:00	Architecture notes — Care Analytics	2026-07-02 09:01:00+00	2026-07-02 09:01:00+00	\N	CA-114	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
ba58056c-6ac4-5e1f-9ef0-d9614489000a	62445afe-3364-5e78-b55e-fb5429807a47	6657781f-74d0-50d8-8f90-7c701d622872	e7ea37c3-9fe3-5010-bb38-8c7330ef5bdc	2026-07-03	02:00:00	Architecture notes — Care Analytics	2026-07-03 09:01:00+00	2026-07-03 09:01:00+00	\N	CA-142	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
d842df67-b233-53ea-82f6-cc7a9db2fd14	62445afe-3364-5e78-b55e-fb5429807a47	6657781f-74d0-50d8-8f90-7c701d622872	e7ea37c3-9fe3-5010-bb38-8c7330ef5bdc	2026-07-06	02:30:00	Architecture notes — Care Analytics	2026-07-06 09:01:00+00	2026-07-06 09:01:00+00	\N	CA-161	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
5101224a-71f4-5d52-8321-2949a1bf9be6	62445afe-3364-5e78-b55e-fb5429807a47	6657781f-74d0-50d8-8f90-7c701d622872	e7ea37c3-9fe3-5010-bb38-8c7330ef5bdc	2026-07-08	00:30:00	Architecture notes — Care Analytics	2026-07-08 09:01:00+00	2026-07-08 09:01:00+00	\N	CA-135	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
7a4fb568-bc33-5ddc-9220-b54a8ac5a372	62445afe-3364-5e78-b55e-fb5429807a47	6657781f-74d0-50d8-8f90-7c701d622872	e7ea37c3-9fe3-5010-bb38-8c7330ef5bdc	2026-07-10	02:30:00	Architecture notes — Care Analytics	2026-07-10 09:01:00+00	2026-07-10 09:01:00+00	\N	CA-109	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
33684ebd-6661-5a53-b4a3-8fa36d47a135	62445afe-3364-5e78-b55e-fb5429807a47	6657781f-74d0-50d8-8f90-7c701d622872	e7ea37c3-9fe3-5010-bb38-8c7330ef5bdc	2026-07-13	00:30:00	Architecture notes — Care Analytics	2026-07-13 09:01:00+00	2026-07-13 09:01:00+00	\N	CA-156	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
622bcd8c-56f1-5037-afaa-49791e374d2e	62445afe-3364-5e78-b55e-fb5429807a47	6657781f-74d0-50d8-8f90-7c701d622872	e7ea37c3-9fe3-5010-bb38-8c7330ef5bdc	2026-07-15	02:30:00	Architecture notes — Care Analytics	2026-07-15 09:01:00+00	2026-07-15 09:01:00+00	\N	CA-130	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
aca204c1-1f33-5c9e-aac2-ea9d8b436b4b	62445afe-3364-5e78-b55e-fb5429807a47	6657781f-74d0-50d8-8f90-7c701d622872	e7ea37c3-9fe3-5010-bb38-8c7330ef5bdc	2026-07-16	00:00:00	Planowana nieobecność uwzględniona w harmonogramie — Care Analytics	2026-07-16 09:01:00+00	2026-07-16 09:01:00+00	\N	\N	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Note
7f1f0af1-f0ce-5d15-a7f3-cda119309b83	62445afe-3364-5e78-b55e-fb5429807a47	6657781f-74d0-50d8-8f90-7c701d622872	e7ea37c3-9fe3-5010-bb38-8c7330ef5bdc	2026-07-17	00:30:00	Architecture notes — Care Analytics	2026-07-17 09:01:00+00	2026-07-17 09:01:00+00	\N	CA-104	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
5d86e9fe-a984-5dd1-bf17-7b78133655ab	62445afe-3364-5e78-b55e-fb5429807a47	6657781f-74d0-50d8-8f90-7c701d622872	e7ea37c3-9fe3-5010-bb38-8c7330ef5bdc	2026-07-21	02:30:00	Architecture notes — Care Analytics	2026-07-21 09:01:00+00	2026-07-21 09:01:00+00	\N	CA-151	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
a554a85b-003d-5353-96a5-1b515d3aff97	62445afe-3364-5e78-b55e-fb5429807a47	6657781f-74d0-50d8-8f90-7c701d622872	e7ea37c3-9fe3-5010-bb38-8c7330ef5bdc	2026-07-23	00:30:00	Architecture notes — Care Analytics	2026-07-23 09:01:00+00	2026-07-23 09:01:00+00	\N	CA-125	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
9101b10a-6ff4-5b38-9e7a-22d0798d1dd2	62445afe-3364-5e78-b55e-fb5429807a47	6657781f-74d0-50d8-8f90-7c701d622872	e7ea37c3-9fe3-5010-bb38-8c7330ef5bdc	2026-07-24	01:00:00	Architecture notes — Care Analytics	2026-07-24 09:01:00+00	2026-07-24 09:01:00+00	\N	CA-144	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
e72ad60b-4961-5b8b-ae98-54ec614b0c3d	62445afe-3364-5e78-b55e-fb5429807a47	6657781f-74d0-50d8-8f90-7c701d622872	e7ea37c3-9fe3-5010-bb38-8c7330ef5bdc	2026-07-26	02:30:00	Architecture notes — Care Analytics	2026-07-26 09:01:00+00	2026-07-26 09:01:00+00	\N	CA-172	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
a3771741-46ec-5528-b32d-773d4b0fcc36	62445afe-3364-5e78-b55e-fb5429807a47	6657781f-74d0-50d8-8f90-7c701d622872	e7ea37c3-9fe3-5010-bb38-8c7330ef5bdc	2026-07-27	03:00:00	Architecture notes — Care Analytics	2026-07-27 09:01:00+00	2026-07-27 09:01:00+00	\N	CA-118	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
e37a43e1-eb42-5424-b026-31ffaed0d3b7	62445afe-3364-5e78-b55e-fb5429807a47	6657781f-74d0-50d8-8f90-7c701d622872	e7ea37c3-9fe3-5010-bb38-8c7330ef5bdc	2026-07-29	01:00:00	Architecture notes — Care Analytics	2026-07-29 09:01:00+00	2026-07-29 09:01:00+00	\N	CA-165	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
499ee195-81a5-5417-aa5c-7098ab9ccafb	62445afe-3364-5e78-b55e-fb5429807a47	6657781f-74d0-50d8-8f90-7c701d622872	e7ea37c3-9fe3-5010-bb38-8c7330ef5bdc	2026-07-31	03:00:00	Architecture notes — Care Analytics	2026-07-31 09:01:00+00	2026-07-31 09:01:00+00	\N	CA-139	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
59171fc2-2dab-5b9e-9b44-f9e894daa352	62445afe-3364-5e78-b55e-fb5429807a47	6657781f-74d0-50d8-8f90-7c701d622872	e7ea37c3-9fe3-5010-bb38-8c7330ef5bdc	2026-08-04	01:00:00	Architecture notes — Care Analytics	2026-08-04 09:01:00+00	2026-08-04 09:01:00+00	\N	CA-113	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
53f5eae6-070b-5102-ae0f-9073abb11c78	62445afe-3364-5e78-b55e-fb5429807a47	6657781f-74d0-50d8-8f90-7c701d622872	e7ea37c3-9fe3-5010-bb38-8c7330ef5bdc	2026-08-06	03:00:00	Architecture notes — Care Analytics	2026-08-06 09:01:00+00	2026-08-06 09:01:00+00	\N	CA-160	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
5b3029ff-af19-59aa-bd55-188362780cfa	62445afe-3364-5e78-b55e-fb5429807a47	6657781f-74d0-50d8-8f90-7c701d622872	e7ea37c3-9fe3-5010-bb38-8c7330ef5bdc	2026-08-09	01:00:00	Architecture notes — Care Analytics	2026-08-09 09:01:00+00	2026-08-09 09:01:00+00	\N	CA-134	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
b28700fe-0e09-5ee7-a985-bc730c2e54ff	62445afe-3364-5e78-b55e-fb5429807a47	6657781f-74d0-50d8-8f90-7c701d622872	e7ea37c3-9fe3-5010-bb38-8c7330ef5bdc	2026-08-11	03:00:00	Architecture notes — Care Analytics	2026-08-11 09:01:00+00	2026-08-11 09:01:00+00	\N	CA-108	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
2edbe23a-cc86-589d-9697-f411ae0eaf6a	62445afe-3364-5e78-b55e-fb5429807a47	9a22f385-4227-5e99-8f8b-5d66bc7315a3	a7906be2-315f-5b5e-b344-ac119fd04d1a	2026-05-20	00:15:00	Release preparation — Omnichannel Checkout	2026-05-20 09:01:00+00	2026-05-20 09:01:00+00	\N	OC-116	3030e191-44de-5909-b035-5fe3679b482a	Active	Worklog
71a791f3-cd88-5578-9754-390d2119b7fa	62445afe-3364-5e78-b55e-fb5429807a47	9a22f385-4227-5e99-8f8b-5d66bc7315a3	67164958-1bad-5a9c-8d3a-7c4f7dfb7282	2026-05-21	01:45:00	Release preparation — Reporting Sandbox	2026-05-21 09:01:00+00	2026-05-21 09:01:00+00	\N	RS-144	d677a650-2c23-5c0c-9f53-920636bd318e	Active	Worklog
95a5f4a6-b70e-56e5-884e-e62b24ab3063	62445afe-3364-5e78-b55e-fb5429807a47	9a22f385-4227-5e99-8f8b-5d66bc7315a3	1146e928-4d82-581f-84f2-b8c9b6c83378	2026-05-22	02:15:00	Release preparation — Learning Experience	2026-05-22 09:01:00+00	2026-05-22 09:01:00+00	\N	LE-163	a9e0bb14-488c-5643-96ca-5848796322a3	Active	Worklog
bc10c90b-316f-59fa-8eff-538eeebcd334	62445afe-3364-5e78-b55e-fb5429807a47	9a22f385-4227-5e99-8f8b-5d66bc7315a3	a7906be2-315f-5b5e-b344-ac119fd04d1a	2026-05-25	03:45:00	Release preparation — Omnichannel Checkout	2026-05-25 09:01:00+00	2026-05-25 09:01:00+00	\N	OC-118	3030e191-44de-5909-b035-5fe3679b482a	Active	Worklog
97a96f2b-4aab-5f07-8044-1e85dd7b3916	62445afe-3364-5e78-b55e-fb5429807a47	9a22f385-4227-5e99-8f8b-5d66bc7315a3	67164958-1bad-5a9c-8d3a-7c4f7dfb7282	2026-05-26	00:15:00	Release preparation — Reporting Sandbox	2026-05-26 09:01:00+00	2026-05-26 09:01:00+00	\N	RS-137	d677a650-2c23-5c0c-9f53-920636bd318e	Active	Worklog
2e3d2d4e-a29a-54da-9f61-d110fe5b51e2	62445afe-3364-5e78-b55e-fb5429807a47	9a22f385-4227-5e99-8f8b-5d66bc7315a3	a7906be2-315f-5b5e-b344-ac119fd04d1a	2026-05-28	02:15:00	Release preparation — Omnichannel Checkout	2026-05-28 09:01:00+00	2026-05-28 09:01:00+00	\N	OC-111	3030e191-44de-5909-b035-5fe3679b482a	Active	Worklog
07e2bb14-7116-5a0f-baa6-8a9d4348b364	62445afe-3364-5e78-b55e-fb5429807a47	9a22f385-4227-5e99-8f8b-5d66bc7315a3	1146e928-4d82-581f-84f2-b8c9b6c83378	2026-05-31	00:15:00	Release preparation — Learning Experience	2026-05-31 09:01:00+00	2026-05-31 09:01:00+00	\N	LE-158	a9e0bb14-488c-5643-96ca-5848796322a3	Active	Worklog
c25ea9a7-001b-5018-85cc-096a16c2e62d	62445afe-3364-5e78-b55e-fb5429807a47	9a22f385-4227-5e99-8f8b-5d66bc7315a3	67164958-1bad-5a9c-8d3a-7c4f7dfb7282	2026-06-02	02:15:00	Release preparation — Reporting Sandbox	2026-06-02 09:01:00+00	2026-06-02 09:01:00+00	\N	RS-132	d677a650-2c23-5c0c-9f53-920636bd318e	Active	Worklog
91e31973-cf4d-57e0-beb4-d6acf027b784	62445afe-3364-5e78-b55e-fb5429807a47	9a22f385-4227-5e99-8f8b-5d66bc7315a3	67164958-1bad-5a9c-8d3a-7c4f7dfb7282	2026-06-03	00:00:00	Client feedback added to the next iteration — Reporting Sandbox	2026-06-03 09:01:00+00	2026-06-03 09:01:00+00	\N	\N	d677a650-2c23-5c0c-9f53-920636bd318e	Active	Note
4c97a290-e851-58d2-98e0-b16bbc51a780	62445afe-3364-5e78-b55e-fb5429807a47	9a22f385-4227-5e99-8f8b-5d66bc7315a3	a7906be2-315f-5b5e-b344-ac119fd04d1a	2026-06-04	00:15:00	Release preparation — Omnichannel Checkout	2026-06-04 09:01:00+00	2026-06-04 09:01:00+00	\N	OC-106	3030e191-44de-5909-b035-5fe3679b482a	Active	Worklog
92be3c2a-8d12-518d-81ce-ec3ef7a5ed78	62445afe-3364-5e78-b55e-fb5429807a47	9a22f385-4227-5e99-8f8b-5d66bc7315a3	1146e928-4d82-581f-84f2-b8c9b6c83378	2026-06-08	02:15:00	Release preparation — Learning Experience	2026-06-08 09:01:00+00	2026-06-08 09:01:00+00	\N	LE-153	a9e0bb14-488c-5643-96ca-5848796322a3	Active	Worklog
816ee87a-45e2-565d-ac40-98f2f48cb20e	62445afe-3364-5e78-b55e-fb5429807a47	9a22f385-4227-5e99-8f8b-5d66bc7315a3	67164958-1bad-5a9c-8d3a-7c4f7dfb7282	2026-06-10	00:15:00	Release preparation — Reporting Sandbox	2026-06-10 09:01:00+00	2026-06-10 09:01:00+00	\N	RS-127	d677a650-2c23-5c0c-9f53-920636bd318e	Active	Worklog
c7d6f322-6b9d-5421-b22b-f3171a490669	62445afe-3364-5e78-b55e-fb5429807a47	9a22f385-4227-5e99-8f8b-5d66bc7315a3	1146e928-4d82-581f-84f2-b8c9b6c83378	2026-06-11	00:45:00	Release preparation — Learning Experience	2026-06-11 09:01:00+00	2026-06-11 09:01:00+00	\N	LE-146	a9e0bb14-488c-5643-96ca-5848796322a3	Active	Worklog
7574aaed-0c85-5e86-93af-fe566587e7b6	62445afe-3364-5e78-b55e-fb5429807a47	9a22f385-4227-5e99-8f8b-5d66bc7315a3	a7906be2-315f-5b5e-b344-ac119fd04d1a	2026-06-12	02:15:00	Release preparation — Omnichannel Checkout	2026-06-12 09:01:00+00	2026-06-12 09:01:00+00	\N	OC-101	3030e191-44de-5909-b035-5fe3679b482a	Active	Worklog
6c570e1b-0c16-5f3d-93fa-b836766a9b48	62445afe-3364-5e78-b55e-fb5429807a47	9a22f385-4227-5e99-8f8b-5d66bc7315a3	67164958-1bad-5a9c-8d3a-7c4f7dfb7282	2026-06-14	02:45:00	Release preparation — Reporting Sandbox	2026-06-14 09:01:00+00	2026-06-14 09:01:00+00	\N	RS-120	d677a650-2c23-5c0c-9f53-920636bd318e	Active	Worklog
85a8e29b-9c6b-56fe-bd32-51f25137d9cb	62445afe-3364-5e78-b55e-fb5429807a47	9a22f385-4227-5e99-8f8b-5d66bc7315a3	a7906be2-315f-5b5e-b344-ac119fd04d1a	2026-06-16	00:45:00	Release preparation — Omnichannel Checkout	2026-06-16 09:01:00+00	2026-06-16 09:01:00+00	\N	OC-167	3030e191-44de-5909-b035-5fe3679b482a	Active	Worklog
d08988de-bf32-50b6-8292-fcce03879e53	62445afe-3364-5e78-b55e-fb5429807a47	9a22f385-4227-5e99-8f8b-5d66bc7315a3	1146e928-4d82-581f-84f2-b8c9b6c83378	2026-06-18	02:45:00	Release preparation — Learning Experience	2026-06-18 09:01:00+00	2026-06-18 09:01:00+00	\N	LE-141	a9e0bb14-488c-5643-96ca-5848796322a3	Active	Worklog
dc52ed11-6857-5a0e-9ed9-e9ae82157c8d	62445afe-3364-5e78-b55e-fb5429807a47	9a22f385-4227-5e99-8f8b-5d66bc7315a3	67164958-1bad-5a9c-8d3a-7c4f7dfb7282	2026-06-22	00:45:00	Release preparation — Reporting Sandbox	2026-06-22 09:01:00+00	2026-06-22 09:01:00+00	\N	RS-115	d677a650-2c23-5c0c-9f53-920636bd318e	Active	Worklog
f0685500-df52-5cec-a461-b1c32c5c1b2e	62445afe-3364-5e78-b55e-fb5429807a47	9a22f385-4227-5e99-8f8b-5d66bc7315a3	a7906be2-315f-5b5e-b344-ac119fd04d1a	2026-06-24	02:45:00	Release preparation — Omnichannel Checkout	2026-06-24 09:01:00+00	2026-06-24 09:01:00+00	\N	OC-162	3030e191-44de-5909-b035-5fe3679b482a	Active	Worklog
d7a7c30f-cddc-54a5-8817-d9d37c0cf6e8	62445afe-3364-5e78-b55e-fb5429807a47	9a22f385-4227-5e99-8f8b-5d66bc7315a3	a7906be2-315f-5b5e-b344-ac119fd04d1a	2026-06-25	00:00:00	Client feedback added to the next iteration — Omnichannel Checkout	2026-06-25 09:01:00+00	2026-06-25 09:01:00+00	\N	\N	3030e191-44de-5909-b035-5fe3679b482a	Active	Note
1c3f66c2-444c-540d-a968-5e6e488c7f68	62445afe-3364-5e78-b55e-fb5429807a47	9a22f385-4227-5e99-8f8b-5d66bc7315a3	1146e928-4d82-581f-84f2-b8c9b6c83378	2026-06-26	00:45:00	Release preparation — Learning Experience	2026-06-26 09:01:00+00	2026-06-26 09:01:00+00	\N	LE-136	a9e0bb14-488c-5643-96ca-5848796322a3	Active	Worklog
4396b0f1-68c1-59da-9905-86abb3f650b7	62445afe-3364-5e78-b55e-fb5429807a47	9a22f385-4227-5e99-8f8b-5d66bc7315a3	67164958-1bad-5a9c-8d3a-7c4f7dfb7282	2026-06-29	02:45:00	Release preparation — Reporting Sandbox	2026-06-29 09:01:00+00	2026-06-29 09:01:00+00	\N	RS-110	d677a650-2c23-5c0c-9f53-920636bd318e	Active	Worklog
07ac60ce-76c2-57b7-89d8-88ca5c57f14b	62445afe-3364-5e78-b55e-fb5429807a47	9a22f385-4227-5e99-8f8b-5d66bc7315a3	3d5d3faf-2bbd-5bca-ac00-1c6056bf7ca6	2026-06-29	02:00:00	Historical delivery wrap-up — Dispatch Optimizer	2026-06-29 09:02:00+00	2026-06-29 09:02:00+00	2026-07-13 00:00:00+00	DOP-901	141122b1-9a71-570d-a44c-efc88209be99	Archived	Worklog
1127a6b1-2570-5d25-8f52-3e83e29be9c0	62445afe-3364-5e78-b55e-fb5429807a47	9a22f385-4227-5e99-8f8b-5d66bc7315a3	a7906be2-315f-5b5e-b344-ac119fd04d1a	2026-07-01	00:45:00	Release preparation — Omnichannel Checkout	2026-07-01 09:01:00+00	2026-07-01 09:01:00+00	\N	OC-157	3030e191-44de-5909-b035-5fe3679b482a	Active	Worklog
9dff82e1-0104-5952-9841-7bb61f497b25	62445afe-3364-5e78-b55e-fb5429807a47	9a22f385-4227-5e99-8f8b-5d66bc7315a3	67164958-1bad-5a9c-8d3a-7c4f7dfb7282	2026-07-02	01:15:00	Release preparation — Reporting Sandbox	2026-07-02 09:01:00+00	2026-07-02 09:01:00+00	\N	RS-103	d677a650-2c23-5c0c-9f53-920636bd318e	Active	Worklog
d173feb5-962d-5dcb-963e-e9c2210a79cf	62445afe-3364-5e78-b55e-fb5429807a47	9a22f385-4227-5e99-8f8b-5d66bc7315a3	3d5d3faf-2bbd-5bca-ac00-1c6056bf7ca6	2026-07-02	01:30:00	Historical delivery wrap-up — Dispatch Optimizer	2026-07-02 09:02:00+00	2026-07-02 09:02:00+00	2026-07-13 00:00:00+00	DOP-919	141122b1-9a71-570d-a44c-efc88209be99	Archived	Worklog
f86872ec-91fa-5726-bcdf-55014e47e65b	62445afe-3364-5e78-b55e-fb5429807a47	9a22f385-4227-5e99-8f8b-5d66bc7315a3	1146e928-4d82-581f-84f2-b8c9b6c83378	2026-07-03	02:45:00	Release preparation — Learning Experience	2026-07-03 09:01:00+00	2026-07-03 09:01:00+00	\N	LE-131	a9e0bb14-488c-5643-96ca-5848796322a3	Active	Worklog
5010acbe-5d8e-5523-9dcd-dc130e0cb807	62445afe-3364-5e78-b55e-fb5429807a47	9a22f385-4227-5e99-8f8b-5d66bc7315a3	3d5d3faf-2bbd-5bca-ac00-1c6056bf7ca6	2026-07-05	01:00:00	Historical delivery wrap-up — Dispatch Optimizer	2026-07-05 09:01:00+00	2026-07-05 09:01:00+00	2026-07-13 00:00:00+00	DOP-937	141122b1-9a71-570d-a44c-efc88209be99	Archived	Worklog
49d4554e-38c9-58e7-937d-320ef2b7413c	62445afe-3364-5e78-b55e-fb5429807a47	9a22f385-4227-5e99-8f8b-5d66bc7315a3	a7906be2-315f-5b5e-b344-ac119fd04d1a	2026-07-06	03:15:00	Release preparation — Omnichannel Checkout	2026-07-06 09:01:00+00	2026-07-06 09:01:00+00	\N	OC-150	3030e191-44de-5909-b035-5fe3679b482a	Active	Worklog
1278d79f-71b0-5123-a051-6f5a145df19b	62445afe-3364-5e78-b55e-fb5429807a47	9a22f385-4227-5e99-8f8b-5d66bc7315a3	1146e928-4d82-581f-84f2-b8c9b6c83378	2026-07-08	01:15:00	Release preparation — Learning Experience	2026-07-08 09:01:00+00	2026-07-08 09:01:00+00	\N	LE-124	a9e0bb14-488c-5643-96ca-5848796322a3	Active	Worklog
d2b9ce21-eb6a-5609-8508-d57781adf41c	62445afe-3364-5e78-b55e-fb5429807a47	9a22f385-4227-5e99-8f8b-5d66bc7315a3	3d5d3faf-2bbd-5bca-ac00-1c6056bf7ca6	2026-07-08	00:30:00	Historical delivery wrap-up — Dispatch Optimizer	2026-07-08 09:02:00+00	2026-07-08 09:02:00+00	2026-07-13 00:00:00+00	DOP-955	141122b1-9a71-570d-a44c-efc88209be99	Archived	Worklog
b2695f0f-b6d6-577d-9b8b-1df9157b5c7b	62445afe-3364-5e78-b55e-fb5429807a47	9a22f385-4227-5e99-8f8b-5d66bc7315a3	67164958-1bad-5a9c-8d3a-7c4f7dfb7282	2026-07-10	03:15:00	Release preparation — Reporting Sandbox	2026-07-10 09:01:00+00	2026-07-10 09:01:00+00	\N	RS-171	d677a650-2c23-5c0c-9f53-920636bd318e	Active	Worklog
32048e4b-3d76-5d8e-880b-4ca22ccc7022	62445afe-3364-5e78-b55e-fb5429807a47	9a22f385-4227-5e99-8f8b-5d66bc7315a3	a7906be2-315f-5b5e-b344-ac119fd04d1a	2026-07-13	01:15:00	Release preparation — Omnichannel Checkout	2026-07-13 09:01:00+00	2026-07-13 09:01:00+00	\N	OC-145	3030e191-44de-5909-b035-5fe3679b482a	Active	Worklog
2604c508-04bf-5677-8107-93d8a3241f4b	62445afe-3364-5e78-b55e-fb5429807a47	9a22f385-4227-5e99-8f8b-5d66bc7315a3	1146e928-4d82-581f-84f2-b8c9b6c83378	2026-07-15	03:15:00	Release preparation — Learning Experience	2026-07-15 09:01:00+00	2026-07-15 09:01:00+00	\N	LE-119	a9e0bb14-488c-5643-96ca-5848796322a3	Active	Worklog
5b6c5e5b-da37-59ca-91cc-19edcc540055	62445afe-3364-5e78-b55e-fb5429807a47	9a22f385-4227-5e99-8f8b-5d66bc7315a3	1146e928-4d82-581f-84f2-b8c9b6c83378	2026-07-16	00:00:00	Client feedback added to the next iteration — Learning Experience	2026-07-16 09:01:00+00	2026-07-16 09:01:00+00	\N	\N	a9e0bb14-488c-5643-96ca-5848796322a3	Active	Note
a00aa68e-342c-5684-9911-eb6930915c96	62445afe-3364-5e78-b55e-fb5429807a47	9a22f385-4227-5e99-8f8b-5d66bc7315a3	67164958-1bad-5a9c-8d3a-7c4f7dfb7282	2026-07-17	01:15:00	Release preparation — Reporting Sandbox	2026-07-17 09:01:00+00	2026-07-17 09:01:00+00	\N	RS-166	d677a650-2c23-5c0c-9f53-920636bd318e	Active	Worklog
9be70c5f-85d4-5313-894e-530c2d3650e1	62445afe-3364-5e78-b55e-fb5429807a47	9a22f385-4227-5e99-8f8b-5d66bc7315a3	a7906be2-315f-5b5e-b344-ac119fd04d1a	2026-07-21	03:15:00	Release preparation — Omnichannel Checkout	2026-07-21 09:01:00+00	2026-07-21 09:01:00+00	\N	OC-140	3030e191-44de-5909-b035-5fe3679b482a	Active	Worklog
97ae8b4a-5777-5630-8187-28335c74d825	62445afe-3364-5e78-b55e-fb5429807a47	9a22f385-4227-5e99-8f8b-5d66bc7315a3	1146e928-4d82-581f-84f2-b8c9b6c83378	2026-07-23	01:15:00	Release preparation — Learning Experience	2026-07-23 09:01:00+00	2026-07-23 09:01:00+00	\N	LE-114	a9e0bb14-488c-5643-96ca-5848796322a3	Active	Worklog
26427c7f-f009-5e76-a7f1-041144eae351	62445afe-3364-5e78-b55e-fb5429807a47	9a22f385-4227-5e99-8f8b-5d66bc7315a3	a7906be2-315f-5b5e-b344-ac119fd04d1a	2026-07-24	01:45:00	Release preparation — Omnichannel Checkout	2026-07-24 09:01:00+00	2026-07-24 09:01:00+00	\N	OC-133	3030e191-44de-5909-b035-5fe3679b482a	Active	Worklog
b7484c03-7587-5d3d-b3da-2bc0fd3392a0	62445afe-3364-5e78-b55e-fb5429807a47	9a22f385-4227-5e99-8f8b-5d66bc7315a3	67164958-1bad-5a9c-8d3a-7c4f7dfb7282	2026-07-26	03:15:00	Release preparation — Reporting Sandbox	2026-07-26 09:01:00+00	2026-07-26 09:01:00+00	\N	RS-161	d677a650-2c23-5c0c-9f53-920636bd318e	Active	Worklog
17571166-ae9c-5d8f-923d-d14c24abf98d	62445afe-3364-5e78-b55e-fb5429807a47	9a22f385-4227-5e99-8f8b-5d66bc7315a3	1146e928-4d82-581f-84f2-b8c9b6c83378	2026-07-27	03:45:00	Release preparation — Learning Experience	2026-07-27 09:01:00+00	2026-07-27 09:01:00+00	\N	LE-107	a9e0bb14-488c-5643-96ca-5848796322a3	Active	Worklog
a6b416cb-4ea9-5910-86df-1e8d72b3054e	62445afe-3364-5e78-b55e-fb5429807a47	9a22f385-4227-5e99-8f8b-5d66bc7315a3	67164958-1bad-5a9c-8d3a-7c4f7dfb7282	2026-07-29	01:45:00	Release preparation — Reporting Sandbox	2026-07-29 09:01:00+00	2026-07-29 09:01:00+00	\N	RS-154	d677a650-2c23-5c0c-9f53-920636bd318e	Active	Worklog
90fe9793-e5a2-5aec-86ef-570e6d31e309	62445afe-3364-5e78-b55e-fb5429807a47	9a22f385-4227-5e99-8f8b-5d66bc7315a3	a7906be2-315f-5b5e-b344-ac119fd04d1a	2026-07-31	03:45:00	Release preparation — Omnichannel Checkout	2026-07-31 09:01:00+00	2026-07-31 09:01:00+00	\N	OC-128	3030e191-44de-5909-b035-5fe3679b482a	Active	Worklog
12469146-f31a-50b0-8b12-338ae38f8ea8	62445afe-3364-5e78-b55e-fb5429807a47	9a22f385-4227-5e99-8f8b-5d66bc7315a3	1146e928-4d82-581f-84f2-b8c9b6c83378	2026-08-04	01:45:00	Release preparation — Learning Experience	2026-08-04 09:01:00+00	2026-08-04 09:01:00+00	\N	LE-102	a9e0bb14-488c-5643-96ca-5848796322a3	Active	Worklog
022182ef-2908-5f83-93f2-13037d746080	62445afe-3364-5e78-b55e-fb5429807a47	9a22f385-4227-5e99-8f8b-5d66bc7315a3	67164958-1bad-5a9c-8d3a-7c4f7dfb7282	2026-08-06	03:45:00	Release preparation — Reporting Sandbox	2026-08-06 09:01:00+00	2026-08-06 09:01:00+00	\N	RS-149	d677a650-2c23-5c0c-9f53-920636bd318e	Active	Worklog
b11a73fb-7b77-50fb-a98a-d2f5be9db6b0	62445afe-3364-5e78-b55e-fb5429807a47	9a22f385-4227-5e99-8f8b-5d66bc7315a3	67164958-1bad-5a9c-8d3a-7c4f7dfb7282	2026-08-07	00:00:00	Client feedback added to the next iteration — Reporting Sandbox	2026-08-07 09:01:00+00	2026-08-07 09:01:00+00	\N	\N	d677a650-2c23-5c0c-9f53-920636bd318e	Active	Note
dbcae390-10eb-5016-96bc-4ab726066f46	62445afe-3364-5e78-b55e-fb5429807a47	9a22f385-4227-5e99-8f8b-5d66bc7315a3	a7906be2-315f-5b5e-b344-ac119fd04d1a	2026-08-09	01:45:00	Release preparation — Omnichannel Checkout	2026-08-09 09:01:00+00	2026-08-09 09:01:00+00	\N	OC-123	3030e191-44de-5909-b035-5fe3679b482a	Active	Worklog
0fe51803-fc31-50ca-a013-dc2ddf0f5553	62445afe-3364-5e78-b55e-fb5429807a47	9a22f385-4227-5e99-8f8b-5d66bc7315a3	1146e928-4d82-581f-84f2-b8c9b6c83378	2026-08-11	03:45:00	Release preparation — Learning Experience	2026-08-11 09:01:00+00	2026-08-11 09:01:00+00	\N	LE-170	a9e0bb14-488c-5643-96ca-5848796322a3	Active	Worklog
4dcaf36f-8da8-5968-acbf-db56d8d4fafa	62445afe-3364-5e78-b55e-fb5429807a47	6503790e-ec8d-5c9c-a6f9-20766eed6fb4	b8cd683c-fe4d-538c-bdaf-68c28e1e14ef	2026-05-20	03:45:00	Code review — Time Intelligence	2026-05-20 09:01:00+00	2026-05-20 09:01:00+00	\N	TI-102	d677a650-2c23-5c0c-9f53-920636bd318e	Active	Worklog
49835321-2b6b-5dec-ac64-3884c7118973	62445afe-3364-5e78-b55e-fb5429807a47	6503790e-ec8d-5c9c-a6f9-20766eed6fb4	b8cd683c-fe4d-538c-bdaf-68c28e1e14ef	2026-05-21	01:15:00	Code review — Time Intelligence	2026-05-21 09:01:00+00	2026-05-21 09:01:00+00	\N	TI-130	d677a650-2c23-5c0c-9f53-920636bd318e	Active	Worklog
6bfa3e13-df03-59fe-b1eb-c3d0f2d74026	62445afe-3364-5e78-b55e-fb5429807a47	6503790e-ec8d-5c9c-a6f9-20766eed6fb4	b8cd683c-fe4d-538c-bdaf-68c28e1e14ef	2026-05-22	01:45:00	Code review — Time Intelligence	2026-05-22 09:01:00+00	2026-05-22 09:01:00+00	\N	TI-149	d677a650-2c23-5c0c-9f53-920636bd318e	Active	Worklog
ead38a7c-cfc5-5740-97cb-8a6cb1d37825	62445afe-3364-5e78-b55e-fb5429807a47	6503790e-ec8d-5c9c-a6f9-20766eed6fb4	b8cd683c-fe4d-538c-bdaf-68c28e1e14ef	2026-05-25	03:15:00	Code review — Time Intelligence	2026-05-25 09:01:00+00	2026-05-25 09:01:00+00	\N	TI-104	d677a650-2c23-5c0c-9f53-920636bd318e	Active	Worklog
6565d0d3-f100-5da2-8f12-2ac3a571b86a	62445afe-3364-5e78-b55e-fb5429807a47	6503790e-ec8d-5c9c-a6f9-20766eed6fb4	b8cd683c-fe4d-538c-bdaf-68c28e1e14ef	2026-05-26	03:45:00	Code review — Time Intelligence	2026-05-26 09:01:00+00	2026-05-26 09:01:00+00	\N	TI-123	d677a650-2c23-5c0c-9f53-920636bd318e	Active	Worklog
a9884c50-14b4-5a42-8e9d-a9bf78d313fc	62445afe-3364-5e78-b55e-fb5429807a47	6503790e-ec8d-5c9c-a6f9-20766eed6fb4	b8cd683c-fe4d-538c-bdaf-68c28e1e14ef	2026-05-28	01:45:00	Code review — Time Intelligence	2026-05-28 09:01:00+00	2026-05-28 09:01:00+00	\N	TI-170	d677a650-2c23-5c0c-9f53-920636bd318e	Active	Worklog
0ad96ecd-2e32-5f7b-bb3b-cc73e0aefda3	62445afe-3364-5e78-b55e-fb5429807a47	6503790e-ec8d-5c9c-a6f9-20766eed6fb4	b8cd683c-fe4d-538c-bdaf-68c28e1e14ef	2026-05-31	03:45:00	Code review — Time Intelligence	2026-05-31 09:01:00+00	2026-05-31 09:01:00+00	\N	TI-144	d677a650-2c23-5c0c-9f53-920636bd318e	Active	Worklog
4341ff19-648f-50c3-b826-76af0f9a7964	62445afe-3364-5e78-b55e-fb5429807a47	6503790e-ec8d-5c9c-a6f9-20766eed6fb4	b8cd683c-fe4d-538c-bdaf-68c28e1e14ef	2026-06-02	01:45:00	Code review — Time Intelligence	2026-06-02 09:01:00+00	2026-06-02 09:01:00+00	\N	TI-118	d677a650-2c23-5c0c-9f53-920636bd318e	Active	Worklog
825f8aa9-85fe-597b-9a06-8960b37182a7	62445afe-3364-5e78-b55e-fb5429807a47	6503790e-ec8d-5c9c-a6f9-20766eed6fb4	b8cd683c-fe4d-538c-bdaf-68c28e1e14ef	2026-06-03	00:00:00	Blocker integracji wymaga odpowiedzi partnera — Time Intelligence	2026-06-03 09:01:00+00	2026-06-03 09:01:00+00	\N	\N	d677a650-2c23-5c0c-9f53-920636bd318e	Active	Note
eb4486a9-4433-5551-8d39-5d25701247d7	62445afe-3364-5e78-b55e-fb5429807a47	6503790e-ec8d-5c9c-a6f9-20766eed6fb4	b8cd683c-fe4d-538c-bdaf-68c28e1e14ef	2026-06-04	03:45:00	Code review — Time Intelligence	2026-06-04 09:01:00+00	2026-06-04 09:01:00+00	\N	TI-165	d677a650-2c23-5c0c-9f53-920636bd318e	Active	Worklog
f0251175-7495-56d7-8e36-001efd956cd5	62445afe-3364-5e78-b55e-fb5429807a47	6503790e-ec8d-5c9c-a6f9-20766eed6fb4	b8cd683c-fe4d-538c-bdaf-68c28e1e14ef	2026-06-08	01:45:00	Code review — Time Intelligence	2026-06-08 09:01:00+00	2026-06-08 09:01:00+00	\N	TI-139	d677a650-2c23-5c0c-9f53-920636bd318e	Active	Worklog
40165a4d-9fe4-52ed-ac66-95470d7c50fe	62445afe-3364-5e78-b55e-fb5429807a47	6503790e-ec8d-5c9c-a6f9-20766eed6fb4	b8cd683c-fe4d-538c-bdaf-68c28e1e14ef	2026-06-10	03:45:00	Code review — Time Intelligence	2026-06-10 09:01:00+00	2026-06-10 09:01:00+00	\N	TI-113	d677a650-2c23-5c0c-9f53-920636bd318e	Active	Worklog
f7401e00-0242-5fb2-b306-d441dd4a2b25	62445afe-3364-5e78-b55e-fb5429807a47	6503790e-ec8d-5c9c-a6f9-20766eed6fb4	b8cd683c-fe4d-538c-bdaf-68c28e1e14ef	2026-06-11	00:15:00	Code review — Time Intelligence	2026-06-11 09:01:00+00	2026-06-11 09:01:00+00	\N	TI-132	d677a650-2c23-5c0c-9f53-920636bd318e	Active	Worklog
2d720a59-8e54-5093-812a-7d596a06eb96	62445afe-3364-5e78-b55e-fb5429807a47	6503790e-ec8d-5c9c-a6f9-20766eed6fb4	b8cd683c-fe4d-538c-bdaf-68c28e1e14ef	2026-06-12	01:45:00	Code review — Time Intelligence	2026-06-12 09:01:00+00	2026-06-12 09:01:00+00	\N	TI-160	d677a650-2c23-5c0c-9f53-920636bd318e	Active	Worklog
dba8e6e6-f93d-538d-b783-ea50cfc36a2d	62445afe-3364-5e78-b55e-fb5429807a47	6503790e-ec8d-5c9c-a6f9-20766eed6fb4	b8cd683c-fe4d-538c-bdaf-68c28e1e14ef	2026-06-14	02:15:00	Code review — Time Intelligence	2026-06-14 09:01:00+00	2026-06-14 09:01:00+00	\N	TI-106	d677a650-2c23-5c0c-9f53-920636bd318e	Active	Worklog
466ed598-32c3-585b-a5c7-a4ea4b3c9e22	62445afe-3364-5e78-b55e-fb5429807a47	6503790e-ec8d-5c9c-a6f9-20766eed6fb4	b8cd683c-fe4d-538c-bdaf-68c28e1e14ef	2026-06-16	00:15:00	Code review — Time Intelligence	2026-06-16 09:01:00+00	2026-06-16 09:01:00+00	\N	TI-153	d677a650-2c23-5c0c-9f53-920636bd318e	Active	Worklog
91ae6185-4916-5807-a698-2fc1963d149c	62445afe-3364-5e78-b55e-fb5429807a47	6503790e-ec8d-5c9c-a6f9-20766eed6fb4	b8cd683c-fe4d-538c-bdaf-68c28e1e14ef	2026-06-18	02:15:00	Code review — Time Intelligence	2026-06-18 09:01:00+00	2026-06-18 09:01:00+00	\N	TI-127	d677a650-2c23-5c0c-9f53-920636bd318e	Active	Worklog
75403c32-33ba-52b8-bb22-3de009faffe0	62445afe-3364-5e78-b55e-fb5429807a47	6503790e-ec8d-5c9c-a6f9-20766eed6fb4	b8cd683c-fe4d-538c-bdaf-68c28e1e14ef	2026-06-22	00:15:00	Code review — Time Intelligence	2026-06-22 09:01:00+00	2026-06-22 09:01:00+00	\N	TI-101	d677a650-2c23-5c0c-9f53-920636bd318e	Active	Worklog
4ed29ce5-ad97-5b4b-ac37-4a0f9c1fa075	62445afe-3364-5e78-b55e-fb5429807a47	6503790e-ec8d-5c9c-a6f9-20766eed6fb4	b8cd683c-fe4d-538c-bdaf-68c28e1e14ef	2026-06-24	02:15:00	Code review — Time Intelligence	2026-06-24 09:01:00+00	2026-06-24 09:01:00+00	\N	TI-148	d677a650-2c23-5c0c-9f53-920636bd318e	Active	Worklog
4e0c0850-2132-577e-bbe1-791004f373cf	62445afe-3364-5e78-b55e-fb5429807a47	6503790e-ec8d-5c9c-a6f9-20766eed6fb4	b8cd683c-fe4d-538c-bdaf-68c28e1e14ef	2026-06-25	00:00:00	Blocker integracji wymaga odpowiedzi partnera — Time Intelligence	2026-06-25 09:01:00+00	2026-06-25 09:01:00+00	\N	\N	d677a650-2c23-5c0c-9f53-920636bd318e	Active	Note
892824ce-2294-51b5-85e5-563c72223fbe	62445afe-3364-5e78-b55e-fb5429807a47	6503790e-ec8d-5c9c-a6f9-20766eed6fb4	b8cd683c-fe4d-538c-bdaf-68c28e1e14ef	2026-06-26	00:15:00	Code review — Time Intelligence	2026-06-26 09:01:00+00	2026-06-26 09:01:00+00	\N	TI-122	d677a650-2c23-5c0c-9f53-920636bd318e	Active	Worklog
4e5d473d-5726-59a5-a830-521ee1d6f9d8	62445afe-3364-5e78-b55e-fb5429807a47	6503790e-ec8d-5c9c-a6f9-20766eed6fb4	b8cd683c-fe4d-538c-bdaf-68c28e1e14ef	2026-06-29	02:15:00	Code review — Time Intelligence	2026-06-29 09:01:00+00	2026-06-29 09:01:00+00	\N	TI-169	d677a650-2c23-5c0c-9f53-920636bd318e	Active	Worklog
b61fd4e2-39ab-5c8b-a43f-e75ac3a8a753	62445afe-3364-5e78-b55e-fb5429807a47	6503790e-ec8d-5c9c-a6f9-20766eed6fb4	b8cd683c-fe4d-538c-bdaf-68c28e1e14ef	2026-07-01	00:15:00	Code review — Time Intelligence	2026-07-01 09:01:00+00	2026-07-01 09:01:00+00	\N	TI-143	d677a650-2c23-5c0c-9f53-920636bd318e	Active	Worklog
be072151-47ab-51e9-9443-293a40b0f058	62445afe-3364-5e78-b55e-fb5429807a47	6503790e-ec8d-5c9c-a6f9-20766eed6fb4	b8cd683c-fe4d-538c-bdaf-68c28e1e14ef	2026-07-02	00:45:00	Code review — Time Intelligence	2026-07-02 09:01:00+00	2026-07-02 09:01:00+00	\N	TI-162	d677a650-2c23-5c0c-9f53-920636bd318e	Active	Worklog
d3fb8b34-637e-58fa-bd1c-88a30aa859b0	62445afe-3364-5e78-b55e-fb5429807a47	6503790e-ec8d-5c9c-a6f9-20766eed6fb4	b8cd683c-fe4d-538c-bdaf-68c28e1e14ef	2026-07-03	02:15:00	Code review — Time Intelligence	2026-07-03 09:01:00+00	2026-07-03 09:01:00+00	\N	TI-117	d677a650-2c23-5c0c-9f53-920636bd318e	Active	Worklog
d3fc45a3-5131-500e-9139-2a8fa7927bc2	62445afe-3364-5e78-b55e-fb5429807a47	6503790e-ec8d-5c9c-a6f9-20766eed6fb4	b8cd683c-fe4d-538c-bdaf-68c28e1e14ef	2026-07-06	02:45:00	Code review — Time Intelligence	2026-07-06 09:01:00+00	2026-07-06 09:01:00+00	\N	TI-136	d677a650-2c23-5c0c-9f53-920636bd318e	Active	Worklog
451ec55c-1fc5-57c7-949b-a598ba9d253b	62445afe-3364-5e78-b55e-fb5429807a47	6503790e-ec8d-5c9c-a6f9-20766eed6fb4	b8cd683c-fe4d-538c-bdaf-68c28e1e14ef	2026-07-08	00:45:00	Code review — Time Intelligence	2026-07-08 09:01:00+00	2026-07-08 09:01:00+00	\N	TI-110	d677a650-2c23-5c0c-9f53-920636bd318e	Active	Worklog
813640f4-f559-5ef7-ad9d-125b83630f55	62445afe-3364-5e78-b55e-fb5429807a47	6503790e-ec8d-5c9c-a6f9-20766eed6fb4	b8cd683c-fe4d-538c-bdaf-68c28e1e14ef	2026-07-10	02:45:00	Code review — Time Intelligence	2026-07-10 09:01:00+00	2026-07-10 09:01:00+00	\N	TI-157	d677a650-2c23-5c0c-9f53-920636bd318e	Active	Worklog
92f3ee9b-3142-5cea-8a07-119e1ec27263	62445afe-3364-5e78-b55e-fb5429807a47	6503790e-ec8d-5c9c-a6f9-20766eed6fb4	b8cd683c-fe4d-538c-bdaf-68c28e1e14ef	2026-07-13	00:45:00	Code review — Time Intelligence	2026-07-13 09:01:00+00	2026-07-13 09:01:00+00	\N	TI-131	d677a650-2c23-5c0c-9f53-920636bd318e	Active	Worklog
32043815-5c6d-54e9-a5d4-0e7d95626ff5	62445afe-3364-5e78-b55e-fb5429807a47	6503790e-ec8d-5c9c-a6f9-20766eed6fb4	b8cd683c-fe4d-538c-bdaf-68c28e1e14ef	2026-07-15	02:45:00	Code review — Time Intelligence	2026-07-15 09:01:00+00	2026-07-15 09:01:00+00	\N	TI-105	d677a650-2c23-5c0c-9f53-920636bd318e	Active	Worklog
20b448a7-8f73-5fa0-a873-2f30451d43ed	62445afe-3364-5e78-b55e-fb5429807a47	6503790e-ec8d-5c9c-a6f9-20766eed6fb4	b8cd683c-fe4d-538c-bdaf-68c28e1e14ef	2026-07-16	00:00:00	Blocker integracji wymaga odpowiedzi partnera — Time Intelligence	2026-07-16 09:01:00+00	2026-07-16 09:01:00+00	\N	\N	d677a650-2c23-5c0c-9f53-920636bd318e	Active	Note
74b08633-fbd2-53e4-b98f-c86fd3a662d6	62445afe-3364-5e78-b55e-fb5429807a47	6503790e-ec8d-5c9c-a6f9-20766eed6fb4	b8cd683c-fe4d-538c-bdaf-68c28e1e14ef	2026-07-17	00:45:00	Code review — Time Intelligence	2026-07-17 09:01:00+00	2026-07-17 09:01:00+00	\N	TI-152	d677a650-2c23-5c0c-9f53-920636bd318e	Active	Worklog
924b1ecf-02f6-59bd-b766-4dd886bc9bff	62445afe-3364-5e78-b55e-fb5429807a47	6503790e-ec8d-5c9c-a6f9-20766eed6fb4	b8cd683c-fe4d-538c-bdaf-68c28e1e14ef	2026-07-21	02:45:00	Code review — Time Intelligence	2026-07-21 09:01:00+00	2026-07-21 09:01:00+00	\N	TI-126	d677a650-2c23-5c0c-9f53-920636bd318e	Active	Worklog
65c4e01b-01de-5210-9613-ad1d0b985a63	62445afe-3364-5e78-b55e-fb5429807a47	6503790e-ec8d-5c9c-a6f9-20766eed6fb4	b8cd683c-fe4d-538c-bdaf-68c28e1e14ef	2026-07-23	00:45:00	Code review — Time Intelligence	2026-07-23 09:01:00+00	2026-07-23 09:01:00+00	\N	TI-100	d677a650-2c23-5c0c-9f53-920636bd318e	Active	Worklog
43c8cdf1-ef21-5366-9e9f-08450445dc53	62445afe-3364-5e78-b55e-fb5429807a47	6503790e-ec8d-5c9c-a6f9-20766eed6fb4	b8cd683c-fe4d-538c-bdaf-68c28e1e14ef	2026-07-24	01:15:00	Code review — Time Intelligence	2026-07-24 09:01:00+00	2026-07-24 09:01:00+00	\N	TI-119	d677a650-2c23-5c0c-9f53-920636bd318e	Active	Worklog
91e2a79a-81f2-5cb4-803f-c797e709b839	62445afe-3364-5e78-b55e-fb5429807a47	6503790e-ec8d-5c9c-a6f9-20766eed6fb4	b8cd683c-fe4d-538c-bdaf-68c28e1e14ef	2026-07-26	02:45:00	Code review — Time Intelligence	2026-07-26 09:01:00+00	2026-07-26 09:01:00+00	\N	TI-147	d677a650-2c23-5c0c-9f53-920636bd318e	Active	Worklog
9c2c7e55-1f26-5dde-9cb6-0a565f4d3ece	62445afe-3364-5e78-b55e-fb5429807a47	6503790e-ec8d-5c9c-a6f9-20766eed6fb4	b8cd683c-fe4d-538c-bdaf-68c28e1e14ef	2026-07-27	03:15:00	Code review — Time Intelligence	2026-07-27 09:01:00+00	2026-07-27 09:01:00+00	\N	TI-166	d677a650-2c23-5c0c-9f53-920636bd318e	Active	Worklog
8fa3bb1d-3512-5f58-8258-d69b41da567d	62445afe-3364-5e78-b55e-fb5429807a47	6503790e-ec8d-5c9c-a6f9-20766eed6fb4	b8cd683c-fe4d-538c-bdaf-68c28e1e14ef	2026-07-29	01:15:00	Code review — Time Intelligence	2026-07-29 09:01:00+00	2026-07-29 09:01:00+00	\N	TI-140	d677a650-2c23-5c0c-9f53-920636bd318e	Active	Worklog
f03db1c3-0d4c-58c7-a966-f7efabb92fe4	62445afe-3364-5e78-b55e-fb5429807a47	6503790e-ec8d-5c9c-a6f9-20766eed6fb4	b8cd683c-fe4d-538c-bdaf-68c28e1e14ef	2026-07-31	03:15:00	Code review — Time Intelligence	2026-07-31 09:01:00+00	2026-07-31 09:01:00+00	\N	TI-114	d677a650-2c23-5c0c-9f53-920636bd318e	Active	Worklog
2d2041be-20b8-526f-a211-7a9eb9e3c0db	62445afe-3364-5e78-b55e-fb5429807a47	6503790e-ec8d-5c9c-a6f9-20766eed6fb4	b8cd683c-fe4d-538c-bdaf-68c28e1e14ef	2026-08-04	01:15:00	Code review — Time Intelligence	2026-08-04 09:01:00+00	2026-08-04 09:01:00+00	\N	TI-161	d677a650-2c23-5c0c-9f53-920636bd318e	Active	Worklog
a040ec89-dc8c-5a40-8619-a721143e9045	62445afe-3364-5e78-b55e-fb5429807a47	6503790e-ec8d-5c9c-a6f9-20766eed6fb4	b8cd683c-fe4d-538c-bdaf-68c28e1e14ef	2026-08-06	03:15:00	Code review — Time Intelligence	2026-08-06 09:01:00+00	2026-08-06 09:01:00+00	\N	TI-135	d677a650-2c23-5c0c-9f53-920636bd318e	Active	Worklog
4779410b-b1ac-5a5d-9f80-533801149f9a	62445afe-3364-5e78-b55e-fb5429807a47	6503790e-ec8d-5c9c-a6f9-20766eed6fb4	b8cd683c-fe4d-538c-bdaf-68c28e1e14ef	2026-08-09	01:15:00	Code review — Time Intelligence	2026-08-09 09:01:00+00	2026-08-09 09:01:00+00	\N	TI-109	d677a650-2c23-5c0c-9f53-920636bd318e	Active	Worklog
b73ed2af-ab47-5137-9281-80691aab6ec0	62445afe-3364-5e78-b55e-fb5429807a47	6503790e-ec8d-5c9c-a6f9-20766eed6fb4	b8cd683c-fe4d-538c-bdaf-68c28e1e14ef	2026-08-11	03:15:00	Code review — Time Intelligence	2026-08-11 09:01:00+00	2026-08-11 09:01:00+00	\N	TI-156	d677a650-2c23-5c0c-9f53-920636bd318e	Active	Worklog
c8e3f548-bb7b-5362-a537-7a14462469d1	62445afe-3364-5e78-b55e-fb5429807a47	f3048101-4480-533e-896e-9295fb7f01d5	06f6bf38-0173-52de-aa5b-77d565741cb1	2026-05-20	03:00:00	Performance improvements — Retail Insights	2026-05-20 09:01:00+00	2026-05-20 09:01:00+00	\N	RI-129	3030e191-44de-5909-b035-5fe3679b482a	Active	Worklog
987a7dac-1078-5996-b1b5-848bf5cf2c2e	62445afe-3364-5e78-b55e-fb5429807a47	f3048101-4480-533e-896e-9295fb7f01d5	06f6bf38-0173-52de-aa5b-77d565741cb1	2026-05-21	00:30:00	Performance improvements — Retail Insights	2026-05-21 09:01:00+00	2026-05-21 09:01:00+00	\N	RI-157	3030e191-44de-5909-b035-5fe3679b482a	Active	Worklog
72348cf4-1601-557c-a56c-e520d1582e1f	62445afe-3364-5e78-b55e-fb5429807a47	f3048101-4480-533e-896e-9295fb7f01d5	06f6bf38-0173-52de-aa5b-77d565741cb1	2026-05-22	01:00:00	Performance improvements — Retail Insights	2026-05-22 09:01:00+00	2026-05-22 09:01:00+00	\N	RI-103	3030e191-44de-5909-b035-5fe3679b482a	Active	Worklog
dc0e5d16-e427-5539-a1f7-8d6f43c67ecc	62445afe-3364-5e78-b55e-fb5429807a47	f3048101-4480-533e-896e-9295fb7f01d5	06f6bf38-0173-52de-aa5b-77d565741cb1	2026-05-25	02:30:00	Performance improvements — Retail Insights	2026-05-25 09:01:00+00	2026-05-25 09:01:00+00	\N	RI-131	3030e191-44de-5909-b035-5fe3679b482a	Active	Worklog
1ba79d30-e75f-502d-a317-cc965454b0f7	62445afe-3364-5e78-b55e-fb5429807a47	f3048101-4480-533e-896e-9295fb7f01d5	06f6bf38-0173-52de-aa5b-77d565741cb1	2026-05-26	03:00:00	Performance improvements — Retail Insights	2026-05-26 09:01:00+00	2026-05-26 09:01:00+00	\N	RI-150	3030e191-44de-5909-b035-5fe3679b482a	Active	Worklog
13825c0a-dd0f-5471-880d-478c3f43f29d	62445afe-3364-5e78-b55e-fb5429807a47	f3048101-4480-533e-896e-9295fb7f01d5	06f6bf38-0173-52de-aa5b-77d565741cb1	2026-05-28	01:00:00	Performance improvements — Retail Insights	2026-05-28 09:01:00+00	2026-05-28 09:01:00+00	\N	RI-124	3030e191-44de-5909-b035-5fe3679b482a	Active	Worklog
26c63086-5628-5ce4-a8bf-8287a82c0b93	62445afe-3364-5e78-b55e-fb5429807a47	f3048101-4480-533e-896e-9295fb7f01d5	06f6bf38-0173-52de-aa5b-77d565741cb1	2026-05-31	03:00:00	Performance improvements — Retail Insights	2026-05-31 09:01:00+00	2026-05-31 09:01:00+00	\N	RI-171	3030e191-44de-5909-b035-5fe3679b482a	Active	Worklog
8557905a-5b4f-55ea-a869-9bb3ef24ea28	62445afe-3364-5e78-b55e-fb5429807a47	f3048101-4480-533e-896e-9295fb7f01d5	06f6bf38-0173-52de-aa5b-77d565741cb1	2026-06-02	01:00:00	Performance improvements — Retail Insights	2026-06-02 09:01:00+00	2026-06-02 09:01:00+00	\N	RI-145	3030e191-44de-5909-b035-5fe3679b482a	Active	Worklog
5c925e7d-9d08-5099-8125-80ba430ef573	62445afe-3364-5e78-b55e-fb5429807a47	f3048101-4480-533e-896e-9295fb7f01d5	06f6bf38-0173-52de-aa5b-77d565741cb1	2026-06-03	00:00:00	Ryzyko release omówione i przypisane — Retail Insights	2026-06-03 09:01:00+00	2026-06-03 09:01:00+00	\N	\N	3030e191-44de-5909-b035-5fe3679b482a	Active	Note
8b06d70f-174f-56f8-b9c2-ff1d6a4b5f87	62445afe-3364-5e78-b55e-fb5429807a47	f3048101-4480-533e-896e-9295fb7f01d5	06f6bf38-0173-52de-aa5b-77d565741cb1	2026-06-04	03:00:00	Performance improvements — Retail Insights	2026-06-04 09:01:00+00	2026-06-04 09:01:00+00	\N	RI-119	3030e191-44de-5909-b035-5fe3679b482a	Active	Worklog
5922a2de-08af-58c1-bd97-cad95d56be00	62445afe-3364-5e78-b55e-fb5429807a47	f3048101-4480-533e-896e-9295fb7f01d5	06f6bf38-0173-52de-aa5b-77d565741cb1	2026-06-08	01:00:00	Performance improvements — Retail Insights	2026-06-08 09:01:00+00	2026-06-08 09:01:00+00	\N	RI-166	3030e191-44de-5909-b035-5fe3679b482a	Active	Worklog
0f70e603-6a6f-52d1-9773-fce7e5dfbfbd	62445afe-3364-5e78-b55e-fb5429807a47	f3048101-4480-533e-896e-9295fb7f01d5	06f6bf38-0173-52de-aa5b-77d565741cb1	2026-06-10	03:00:00	Performance improvements — Retail Insights	2026-06-10 09:01:00+00	2026-06-10 09:01:00+00	\N	RI-140	3030e191-44de-5909-b035-5fe3679b482a	Active	Worklog
941ff04c-c34e-53b9-b180-3f3ae6a4268e	62445afe-3364-5e78-b55e-fb5429807a47	f3048101-4480-533e-896e-9295fb7f01d5	06f6bf38-0173-52de-aa5b-77d565741cb1	2026-06-11	03:30:00	Performance improvements — Retail Insights	2026-06-11 09:01:00+00	2026-06-11 09:01:00+00	\N	RI-159	3030e191-44de-5909-b035-5fe3679b482a	Active	Worklog
527906c7-8348-5819-bcf6-228739e17fce	62445afe-3364-5e78-b55e-fb5429807a47	f3048101-4480-533e-896e-9295fb7f01d5	06f6bf38-0173-52de-aa5b-77d565741cb1	2026-06-12	01:00:00	Performance improvements — Retail Insights	2026-06-12 09:01:00+00	2026-06-12 09:01:00+00	\N	RI-114	3030e191-44de-5909-b035-5fe3679b482a	Active	Worklog
788d0769-ab55-5bda-bbe1-6620426f7c97	62445afe-3364-5e78-b55e-fb5429807a47	f3048101-4480-533e-896e-9295fb7f01d5	06f6bf38-0173-52de-aa5b-77d565741cb1	2026-06-14	01:30:00	Performance improvements — Retail Insights	2026-06-14 09:01:00+00	2026-06-14 09:01:00+00	\N	RI-133	3030e191-44de-5909-b035-5fe3679b482a	Active	Worklog
2988cea2-9f6c-5610-aeb2-80153efc96b8	62445afe-3364-5e78-b55e-fb5429807a47	f3048101-4480-533e-896e-9295fb7f01d5	06f6bf38-0173-52de-aa5b-77d565741cb1	2026-06-16	03:30:00	Performance improvements — Retail Insights	2026-06-16 09:01:00+00	2026-06-16 09:01:00+00	\N	RI-107	3030e191-44de-5909-b035-5fe3679b482a	Active	Worklog
ec4fc342-e5df-5c54-9b92-ab69f5b421f7	62445afe-3364-5e78-b55e-fb5429807a47	f3048101-4480-533e-896e-9295fb7f01d5	06f6bf38-0173-52de-aa5b-77d565741cb1	2026-06-18	01:30:00	Performance improvements — Retail Insights	2026-06-18 09:01:00+00	2026-06-18 09:01:00+00	\N	RI-154	3030e191-44de-5909-b035-5fe3679b482a	Active	Worklog
a2fa9392-42d6-58f5-82c1-74e6b61caa8a	62445afe-3364-5e78-b55e-fb5429807a47	f3048101-4480-533e-896e-9295fb7f01d5	06f6bf38-0173-52de-aa5b-77d565741cb1	2026-06-22	03:30:00	Performance improvements — Retail Insights	2026-06-22 09:01:00+00	2026-06-22 09:01:00+00	\N	RI-128	3030e191-44de-5909-b035-5fe3679b482a	Active	Worklog
cd362028-81c1-5234-b6d6-7f13cd206207	62445afe-3364-5e78-b55e-fb5429807a47	f3048101-4480-533e-896e-9295fb7f01d5	06f6bf38-0173-52de-aa5b-77d565741cb1	2026-06-24	01:30:00	Performance improvements — Retail Insights	2026-06-24 09:01:00+00	2026-06-24 09:01:00+00	\N	RI-102	3030e191-44de-5909-b035-5fe3679b482a	Active	Worklog
58082da8-de55-5528-92c4-c0f15efc0979	62445afe-3364-5e78-b55e-fb5429807a47	f3048101-4480-533e-896e-9295fb7f01d5	06f6bf38-0173-52de-aa5b-77d565741cb1	2026-06-25	00:00:00	Ryzyko release omówione i przypisane — Retail Insights	2026-06-25 09:01:00+00	2026-06-25 09:01:00+00	\N	\N	3030e191-44de-5909-b035-5fe3679b482a	Active	Note
28670caa-6b9e-56d4-92d5-129f22e0c56c	62445afe-3364-5e78-b55e-fb5429807a47	f3048101-4480-533e-896e-9295fb7f01d5	06f6bf38-0173-52de-aa5b-77d565741cb1	2026-06-26	03:30:00	Performance improvements — Retail Insights	2026-06-26 09:01:00+00	2026-06-26 09:01:00+00	\N	RI-149	3030e191-44de-5909-b035-5fe3679b482a	Active	Worklog
aa9550c6-b808-57aa-b56a-c20b40d530ec	62445afe-3364-5e78-b55e-fb5429807a47	f3048101-4480-533e-896e-9295fb7f01d5	06f6bf38-0173-52de-aa5b-77d565741cb1	2026-06-29	01:30:00	Performance improvements — Retail Insights	2026-06-29 09:01:00+00	2026-06-29 09:01:00+00	\N	RI-123	3030e191-44de-5909-b035-5fe3679b482a	Active	Worklog
071c1602-b2f8-580f-8e62-5248302e551d	62445afe-3364-5e78-b55e-fb5429807a47	f3048101-4480-533e-896e-9295fb7f01d5	06f6bf38-0173-52de-aa5b-77d565741cb1	2026-07-01	03:30:00	Performance improvements — Retail Insights	2026-07-01 09:01:00+00	2026-07-01 09:01:00+00	\N	RI-170	3030e191-44de-5909-b035-5fe3679b482a	Active	Worklog
9238cbb0-d95f-5554-8be0-4cc5f674b273	62445afe-3364-5e78-b55e-fb5429807a47	f3048101-4480-533e-896e-9295fb7f01d5	06f6bf38-0173-52de-aa5b-77d565741cb1	2026-07-02	04:00:00	Performance improvements — Retail Insights	2026-07-02 09:01:00+00	2026-07-02 09:01:00+00	\N	RI-116	3030e191-44de-5909-b035-5fe3679b482a	Active	Worklog
5429d0e6-7467-565f-8124-fc3418e8a37d	62445afe-3364-5e78-b55e-fb5429807a47	f3048101-4480-533e-896e-9295fb7f01d5	06f6bf38-0173-52de-aa5b-77d565741cb1	2026-07-03	01:30:00	Performance improvements — Retail Insights	2026-07-03 09:01:00+00	2026-07-03 09:01:00+00	\N	RI-144	3030e191-44de-5909-b035-5fe3679b482a	Active	Worklog
2fc02f16-0515-5ef6-9ddf-1d9cd4a72d1e	62445afe-3364-5e78-b55e-fb5429807a47	f3048101-4480-533e-896e-9295fb7f01d5	06f6bf38-0173-52de-aa5b-77d565741cb1	2026-07-06	02:00:00	Performance improvements — Retail Insights	2026-07-06 09:01:00+00	2026-07-06 09:01:00+00	\N	RI-163	3030e191-44de-5909-b035-5fe3679b482a	Active	Worklog
a95d588c-4fb0-59b3-8efd-d6892753c3d9	62445afe-3364-5e78-b55e-fb5429807a47	f3048101-4480-533e-896e-9295fb7f01d5	06f6bf38-0173-52de-aa5b-77d565741cb1	2026-07-08	04:00:00	Performance improvements — Retail Insights	2026-07-08 09:01:00+00	2026-07-08 09:01:00+00	\N	RI-137	3030e191-44de-5909-b035-5fe3679b482a	Active	Worklog
818e935a-1b83-57eb-9b5f-4d47f5af022f	62445afe-3364-5e78-b55e-fb5429807a47	f3048101-4480-533e-896e-9295fb7f01d5	06f6bf38-0173-52de-aa5b-77d565741cb1	2026-07-10	02:00:00	Performance improvements — Retail Insights	2026-07-10 09:01:00+00	2026-07-10 09:01:00+00	\N	RI-111	3030e191-44de-5909-b035-5fe3679b482a	Active	Worklog
5e007db8-9dc5-585b-abc5-13ed0d2594d8	62445afe-3364-5e78-b55e-fb5429807a47	f3048101-4480-533e-896e-9295fb7f01d5	06f6bf38-0173-52de-aa5b-77d565741cb1	2026-07-13	04:00:00	Performance improvements — Retail Insights	2026-07-13 09:01:00+00	2026-07-13 09:01:00+00	\N	RI-158	3030e191-44de-5909-b035-5fe3679b482a	Active	Worklog
237a7314-812c-5d97-9cc5-6b1dac366901	62445afe-3364-5e78-b55e-fb5429807a47	f3048101-4480-533e-896e-9295fb7f01d5	06f6bf38-0173-52de-aa5b-77d565741cb1	2026-07-15	02:00:00	Performance improvements — Retail Insights	2026-07-15 09:01:00+00	2026-07-15 09:01:00+00	\N	RI-132	3030e191-44de-5909-b035-5fe3679b482a	Active	Worklog
b15ccc73-cd9a-580b-837c-021d09dfc88d	62445afe-3364-5e78-b55e-fb5429807a47	f3048101-4480-533e-896e-9295fb7f01d5	06f6bf38-0173-52de-aa5b-77d565741cb1	2026-07-16	00:00:00	Ryzyko release omówione i przypisane — Retail Insights	2026-07-16 09:01:00+00	2026-07-16 09:01:00+00	\N	\N	3030e191-44de-5909-b035-5fe3679b482a	Active	Note
9a231a99-1e9c-57ca-9c70-c2c3398b6db5	62445afe-3364-5e78-b55e-fb5429807a47	f3048101-4480-533e-896e-9295fb7f01d5	06f6bf38-0173-52de-aa5b-77d565741cb1	2026-07-17	04:00:00	Performance improvements — Retail Insights	2026-07-17 09:01:00+00	2026-07-17 09:01:00+00	\N	RI-106	3030e191-44de-5909-b035-5fe3679b482a	Active	Worklog
8d383c17-122a-5655-9b4e-6a63bbe16a47	62445afe-3364-5e78-b55e-fb5429807a47	f3048101-4480-533e-896e-9295fb7f01d5	06f6bf38-0173-52de-aa5b-77d565741cb1	2026-07-21	02:00:00	Performance improvements — Retail Insights	2026-07-21 09:01:00+00	2026-07-21 09:01:00+00	\N	RI-153	3030e191-44de-5909-b035-5fe3679b482a	Active	Worklog
4589ce7e-1961-5788-a5fd-a21c8e86c87b	62445afe-3364-5e78-b55e-fb5429807a47	f3048101-4480-533e-896e-9295fb7f01d5	06f6bf38-0173-52de-aa5b-77d565741cb1	2026-07-23	04:00:00	Performance improvements — Retail Insights	2026-07-23 09:01:00+00	2026-07-23 09:01:00+00	\N	RI-127	3030e191-44de-5909-b035-5fe3679b482a	Active	Worklog
2a272244-40a7-5664-9d48-5e666411cd5b	62445afe-3364-5e78-b55e-fb5429807a47	f3048101-4480-533e-896e-9295fb7f01d5	06f6bf38-0173-52de-aa5b-77d565741cb1	2026-07-24	00:30:00	Performance improvements — Retail Insights	2026-07-24 09:01:00+00	2026-07-24 09:01:00+00	\N	RI-146	3030e191-44de-5909-b035-5fe3679b482a	Active	Worklog
b1d4346e-c281-5b04-bd26-67e90614d9ce	62445afe-3364-5e78-b55e-fb5429807a47	f3048101-4480-533e-896e-9295fb7f01d5	06f6bf38-0173-52de-aa5b-77d565741cb1	2026-07-26	02:00:00	Performance improvements — Retail Insights	2026-07-26 09:01:00+00	2026-07-26 09:01:00+00	\N	RI-101	3030e191-44de-5909-b035-5fe3679b482a	Active	Worklog
7d5f98fb-88a1-5489-8b7e-7562e3b19d5f	62445afe-3364-5e78-b55e-fb5429807a47	f3048101-4480-533e-896e-9295fb7f01d5	06f6bf38-0173-52de-aa5b-77d565741cb1	2026-07-27	02:30:00	Performance improvements — Retail Insights	2026-07-27 09:01:00+00	2026-07-27 09:01:00+00	\N	RI-120	3030e191-44de-5909-b035-5fe3679b482a	Active	Worklog
08abdf8f-0113-5803-863b-aff679210f80	62445afe-3364-5e78-b55e-fb5429807a47	f3048101-4480-533e-896e-9295fb7f01d5	06f6bf38-0173-52de-aa5b-77d565741cb1	2026-07-29	00:30:00	Performance improvements — Retail Insights	2026-07-29 09:01:00+00	2026-07-29 09:01:00+00	\N	RI-167	3030e191-44de-5909-b035-5fe3679b482a	Active	Worklog
0fdacaff-a22c-5793-8de8-e661f6f8c23a	62445afe-3364-5e78-b55e-fb5429807a47	f3048101-4480-533e-896e-9295fb7f01d5	06f6bf38-0173-52de-aa5b-77d565741cb1	2026-07-31	02:30:00	Performance improvements — Retail Insights	2026-07-31 09:01:00+00	2026-07-31 09:01:00+00	\N	RI-141	3030e191-44de-5909-b035-5fe3679b482a	Active	Worklog
1d9499bb-760a-5370-87bc-b6533fe00421	62445afe-3364-5e78-b55e-fb5429807a47	f3048101-4480-533e-896e-9295fb7f01d5	06f6bf38-0173-52de-aa5b-77d565741cb1	2026-08-04	00:30:00	Performance improvements — Retail Insights	2026-08-04 09:01:00+00	2026-08-04 09:01:00+00	\N	RI-115	3030e191-44de-5909-b035-5fe3679b482a	Active	Worklog
47215f22-a155-512a-aa0e-e33f5ece163a	62445afe-3364-5e78-b55e-fb5429807a47	f3048101-4480-533e-896e-9295fb7f01d5	06f6bf38-0173-52de-aa5b-77d565741cb1	2026-08-06	02:30:00	Performance improvements — Retail Insights	2026-08-06 09:01:00+00	2026-08-06 09:01:00+00	\N	RI-162	3030e191-44de-5909-b035-5fe3679b482a	Active	Worklog
131f4373-3260-5174-8be4-edf1123db8ba	62445afe-3364-5e78-b55e-fb5429807a47	f3048101-4480-533e-896e-9295fb7f01d5	06f6bf38-0173-52de-aa5b-77d565741cb1	2026-08-09	00:30:00	Performance improvements — Retail Insights	2026-08-09 09:01:00+00	2026-08-09 09:01:00+00	\N	RI-136	3030e191-44de-5909-b035-5fe3679b482a	Active	Worklog
135949e2-bede-58e9-9632-a79852cb4565	62445afe-3364-5e78-b55e-fb5429807a47	f3048101-4480-533e-896e-9295fb7f01d5	06f6bf38-0173-52de-aa5b-77d565741cb1	2026-08-11	02:30:00	Performance improvements — Retail Insights	2026-08-11 09:01:00+00	2026-08-11 09:01:00+00	\N	RI-110	3030e191-44de-5909-b035-5fe3679b482a	Active	Worklog
298df797-7918-5ffb-b45a-6bc57cd898cd	62445afe-3364-5e78-b55e-fb5429807a47	44d6afb5-6765-5cc4-b4c9-a8877761b0ca	e7ea37c3-9fe3-5010-bb38-8c7330ef5bdc	2026-05-20	00:30:00	Architecture notes — Care Analytics	2026-05-20 09:01:00+00	2026-05-20 09:01:00+00	\N	CA-107	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
1ec37915-e533-5ec6-a699-a9d9aed84710	62445afe-3364-5e78-b55e-fb5429807a47	44d6afb5-6765-5cc4-b4c9-a8877761b0ca	e7ea37c3-9fe3-5010-bb38-8c7330ef5bdc	2026-05-21	02:00:00	Architecture notes — Care Analytics	2026-05-21 09:01:00+00	2026-05-21 09:01:00+00	\N	CA-135	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
ee1f628c-b7df-5cc6-91d1-c7b0977a69a1	62445afe-3364-5e78-b55e-fb5429807a47	44d6afb5-6765-5cc4-b4c9-a8877761b0ca	9406b74a-6b7a-578b-8fbd-958684d93780	2026-05-22	02:30:00	Architecture notes — Patient Portal	2026-05-22 09:01:00+00	2026-05-22 09:01:00+00	\N	PP-154	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
debe9772-7135-566f-a107-640d960a65c5	62445afe-3364-5e78-b55e-fb5429807a47	44d6afb5-6765-5cc4-b4c9-a8877761b0ca	9406b74a-6b7a-578b-8fbd-958684d93780	2026-05-25	04:00:00	Architecture notes — Patient Portal	2026-05-25 09:01:00+00	2026-05-25 09:01:00+00	\N	PP-109	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
fd402a9e-a6f9-5eab-9805-f8e8a077aa08	62445afe-3364-5e78-b55e-fb5429807a47	44d6afb5-6765-5cc4-b4c9-a8877761b0ca	b8cd683c-fe4d-538c-bdaf-68c28e1e14ef	2026-05-26	00:30:00	Architecture notes — Time Intelligence	2026-05-26 09:01:00+00	2026-05-26 09:01:00+00	\N	TI-128	d677a650-2c23-5c0c-9f53-920636bd318e	Active	Worklog
6623be07-22da-5645-937e-58e696d39929	62445afe-3364-5e78-b55e-fb5429807a47	44d6afb5-6765-5cc4-b4c9-a8877761b0ca	f07ee933-bae1-5f0f-9e95-6c303aba6f5d	2026-05-28	02:30:00	Architecture notes — Open Banking Integration	2026-05-28 09:01:00+00	2026-05-28 09:01:00+00	\N	OBI-102	f4c5b0e8-5503-5a50-8487-4ae103b885f2	Active	Worklog
ac99353f-b293-5627-8413-3d23d6a9bf3d	62445afe-3364-5e78-b55e-fb5429807a47	44d6afb5-6765-5cc4-b4c9-a8877761b0ca	06f6bf38-0173-52de-aa5b-77d565741cb1	2026-05-31	00:30:00	Architecture notes — Retail Insights	2026-05-31 09:01:00+00	2026-05-31 09:01:00+00	\N	RI-149	3030e191-44de-5909-b035-5fe3679b482a	Active	Worklog
00ffcfd7-bffd-5a87-b8ad-ae68392ae2be	62445afe-3364-5e78-b55e-fb5429807a47	44d6afb5-6765-5cc4-b4c9-a8877761b0ca	e7ea37c3-9fe3-5010-bb38-8c7330ef5bdc	2026-06-02	02:30:00	Architecture notes — Care Analytics	2026-06-02 09:01:00+00	2026-06-02 09:01:00+00	\N	CA-123	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
c91aa18f-f1dd-56c4-b370-518f5a61d82d	62445afe-3364-5e78-b55e-fb5429807a47	44d6afb5-6765-5cc4-b4c9-a8877761b0ca	06f6bf38-0173-52de-aa5b-77d565741cb1	2026-06-03	00:00:00	Decyzja zakresowa potwierdzona z zespołem — Retail Insights	2026-06-03 09:01:00+00	2026-06-03 09:01:00+00	\N	\N	3030e191-44de-5909-b035-5fe3679b482a	Active	Note
175528f6-e04a-5b8a-a91e-f4dfe5e0d087	62445afe-3364-5e78-b55e-fb5429807a47	44d6afb5-6765-5cc4-b4c9-a8877761b0ca	9406b74a-6b7a-578b-8fbd-958684d93780	2026-06-04	00:30:00	Architecture notes — Patient Portal	2026-06-04 09:01:00+00	2026-06-04 09:01:00+00	\N	PP-170	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
6fec6368-7be8-5f49-856b-1f1823b95310	62445afe-3364-5e78-b55e-fb5429807a47	44d6afb5-6765-5cc4-b4c9-a8877761b0ca	b8cd683c-fe4d-538c-bdaf-68c28e1e14ef	2026-06-08	02:30:00	Architecture notes — Time Intelligence	2026-06-08 09:01:00+00	2026-06-08 09:01:00+00	\N	TI-144	d677a650-2c23-5c0c-9f53-920636bd318e	Active	Worklog
24bedc49-77eb-5e0d-b02e-c27e1a74d618	62445afe-3364-5e78-b55e-fb5429807a47	44d6afb5-6765-5cc4-b4c9-a8877761b0ca	f07ee933-bae1-5f0f-9e95-6c303aba6f5d	2026-06-10	00:30:00	Architecture notes — Open Banking Integration	2026-06-10 09:01:00+00	2026-06-10 09:01:00+00	\N	OBI-118	f4c5b0e8-5503-5a50-8487-4ae103b885f2	Active	Worklog
b456f440-a7ab-5b27-b291-f8839fc36caf	62445afe-3364-5e78-b55e-fb5429807a47	44d6afb5-6765-5cc4-b4c9-a8877761b0ca	06f6bf38-0173-52de-aa5b-77d565741cb1	2026-06-11	01:00:00	Architecture notes — Retail Insights	2026-06-11 09:01:00+00	2026-06-11 09:01:00+00	\N	RI-137	3030e191-44de-5909-b035-5fe3679b482a	Active	Worklog
9847199d-1d27-5851-b662-11546eea9c7f	62445afe-3364-5e78-b55e-fb5429807a47	44d6afb5-6765-5cc4-b4c9-a8877761b0ca	06f6bf38-0173-52de-aa5b-77d565741cb1	2026-06-12	02:30:00	Architecture notes — Retail Insights	2026-06-12 09:01:00+00	2026-06-12 09:01:00+00	\N	RI-165	3030e191-44de-5909-b035-5fe3679b482a	Active	Worklog
c697481b-524f-53b8-890f-b019e55184a3	62445afe-3364-5e78-b55e-fb5429807a47	44d6afb5-6765-5cc4-b4c9-a8877761b0ca	e7ea37c3-9fe3-5010-bb38-8c7330ef5bdc	2026-06-14	03:00:00	Architecture notes — Care Analytics	2026-06-14 09:01:00+00	2026-06-14 09:01:00+00	\N	CA-111	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
c73daaff-7784-5e43-aa07-808b09e9b316	62445afe-3364-5e78-b55e-fb5429807a47	44d6afb5-6765-5cc4-b4c9-a8877761b0ca	9406b74a-6b7a-578b-8fbd-958684d93780	2026-06-16	01:00:00	Architecture notes — Patient Portal	2026-06-16 09:01:00+00	2026-06-16 09:01:00+00	\N	PP-158	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
c4062be9-8d13-5054-8209-797b7497b4c9	62445afe-3364-5e78-b55e-fb5429807a47	44d6afb5-6765-5cc4-b4c9-a8877761b0ca	b8cd683c-fe4d-538c-bdaf-68c28e1e14ef	2026-06-18	03:00:00	Architecture notes — Time Intelligence	2026-06-18 09:01:00+00	2026-06-18 09:01:00+00	\N	TI-132	d677a650-2c23-5c0c-9f53-920636bd318e	Active	Worklog
e072d978-7739-5910-a769-473378fc3ea8	62445afe-3364-5e78-b55e-fb5429807a47	44d6afb5-6765-5cc4-b4c9-a8877761b0ca	f07ee933-bae1-5f0f-9e95-6c303aba6f5d	2026-06-22	01:00:00	Architecture notes — Open Banking Integration	2026-06-22 09:01:00+00	2026-06-22 09:01:00+00	\N	OBI-106	f4c5b0e8-5503-5a50-8487-4ae103b885f2	Active	Worklog
b3770a78-bd53-5f7a-8a3a-effcb3979566	62445afe-3364-5e78-b55e-fb5429807a47	44d6afb5-6765-5cc4-b4c9-a8877761b0ca	06f6bf38-0173-52de-aa5b-77d565741cb1	2026-06-24	03:00:00	Architecture notes — Retail Insights	2026-06-24 09:01:00+00	2026-06-24 09:01:00+00	\N	RI-153	3030e191-44de-5909-b035-5fe3679b482a	Active	Worklog
a41f454b-7e4a-56c2-ba0a-aaea3c73cbf0	62445afe-3364-5e78-b55e-fb5429807a47	44d6afb5-6765-5cc4-b4c9-a8877761b0ca	f07ee933-bae1-5f0f-9e95-6c303aba6f5d	2026-06-25	00:00:00	Decyzja zakresowa potwierdzona z zespołem — Open Banking Integration	2026-06-25 09:01:00+00	2026-06-25 09:01:00+00	\N	\N	f4c5b0e8-5503-5a50-8487-4ae103b885f2	Active	Note
e841badc-fad6-528e-9d4f-26076354a804	62445afe-3364-5e78-b55e-fb5429807a47	44d6afb5-6765-5cc4-b4c9-a8877761b0ca	e7ea37c3-9fe3-5010-bb38-8c7330ef5bdc	2026-06-26	01:00:00	Architecture notes — Care Analytics	2026-06-26 09:01:00+00	2026-06-26 09:01:00+00	\N	CA-127	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
e8a05c6f-dba8-511f-bd5d-edfd49b04cc5	62445afe-3364-5e78-b55e-fb5429807a47	44d6afb5-6765-5cc4-b4c9-a8877761b0ca	9406b74a-6b7a-578b-8fbd-958684d93780	2026-06-29	03:00:00	Architecture notes — Patient Portal	2026-06-29 09:01:00+00	2026-06-29 09:01:00+00	\N	PP-101	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
cceb0e25-b54c-57e8-b1dc-65dbb20d0580	62445afe-3364-5e78-b55e-fb5429807a47	44d6afb5-6765-5cc4-b4c9-a8877761b0ca	b8cd683c-fe4d-538c-bdaf-68c28e1e14ef	2026-07-01	01:00:00	Architecture notes — Time Intelligence	2026-07-01 09:01:00+00	2026-07-01 09:01:00+00	\N	TI-148	d677a650-2c23-5c0c-9f53-920636bd318e	Active	Worklog
e5f598cf-aefc-5a4c-9b45-3735e02cbccc	62445afe-3364-5e78-b55e-fb5429807a47	44d6afb5-6765-5cc4-b4c9-a8877761b0ca	f07ee933-bae1-5f0f-9e95-6c303aba6f5d	2026-07-02	01:30:00	Architecture notes — Open Banking Integration	2026-07-02 09:01:00+00	2026-07-02 09:01:00+00	\N	OBI-167	f4c5b0e8-5503-5a50-8487-4ae103b885f2	Active	Worklog
fdd781f3-386f-5e75-b0fe-db5d758035f2	62445afe-3364-5e78-b55e-fb5429807a47	44d6afb5-6765-5cc4-b4c9-a8877761b0ca	f07ee933-bae1-5f0f-9e95-6c303aba6f5d	2026-07-03	03:00:00	Architecture notes — Open Banking Integration	2026-07-03 09:01:00+00	2026-07-03 09:01:00+00	\N	OBI-122	f4c5b0e8-5503-5a50-8487-4ae103b885f2	Active	Worklog
49de91b2-547e-531c-a383-813ab8bab88c	62445afe-3364-5e78-b55e-fb5429807a47	44d6afb5-6765-5cc4-b4c9-a8877761b0ca	06f6bf38-0173-52de-aa5b-77d565741cb1	2026-07-06	03:30:00	Architecture notes — Retail Insights	2026-07-06 09:01:00+00	2026-07-06 09:01:00+00	\N	RI-141	3030e191-44de-5909-b035-5fe3679b482a	Active	Worklog
331ca54e-1426-5709-85d9-ae8e35751e71	62445afe-3364-5e78-b55e-fb5429807a47	44d6afb5-6765-5cc4-b4c9-a8877761b0ca	e7ea37c3-9fe3-5010-bb38-8c7330ef5bdc	2026-07-08	01:30:00	Architecture notes — Care Analytics	2026-07-08 09:01:00+00	2026-07-08 09:01:00+00	\N	CA-115	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
1cad9e2e-d28e-5674-861b-abcb5ac3b38c	62445afe-3364-5e78-b55e-fb5429807a47	44d6afb5-6765-5cc4-b4c9-a8877761b0ca	9406b74a-6b7a-578b-8fbd-958684d93780	2026-07-10	03:30:00	Architecture notes — Patient Portal	2026-07-10 09:01:00+00	2026-07-10 09:01:00+00	\N	PP-162	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
737b7edc-3989-5198-86fd-5055c81ea755	62445afe-3364-5e78-b55e-fb5429807a47	44d6afb5-6765-5cc4-b4c9-a8877761b0ca	b8cd683c-fe4d-538c-bdaf-68c28e1e14ef	2026-07-13	01:30:00	Architecture notes — Time Intelligence	2026-07-13 09:01:00+00	2026-07-13 09:01:00+00	\N	TI-136	d677a650-2c23-5c0c-9f53-920636bd318e	Active	Worklog
0b3ce87e-01cc-5cd4-bead-a681553ffd10	62445afe-3364-5e78-b55e-fb5429807a47	44d6afb5-6765-5cc4-b4c9-a8877761b0ca	f07ee933-bae1-5f0f-9e95-6c303aba6f5d	2026-07-15	03:30:00	Architecture notes — Open Banking Integration	2026-07-15 09:01:00+00	2026-07-15 09:01:00+00	\N	OBI-110	f4c5b0e8-5503-5a50-8487-4ae103b885f2	Active	Worklog
867135b3-155f-5150-9617-f6aa8f32ba7e	62445afe-3364-5e78-b55e-fb5429807a47	44d6afb5-6765-5cc4-b4c9-a8877761b0ca	b8cd683c-fe4d-538c-bdaf-68c28e1e14ef	2026-07-16	00:00:00	Decyzja zakresowa potwierdzona z zespołem — Time Intelligence	2026-07-16 09:01:00+00	2026-07-16 09:01:00+00	\N	\N	d677a650-2c23-5c0c-9f53-920636bd318e	Active	Note
bab0782f-9d9a-5d2b-8e49-32a6daac717a	62445afe-3364-5e78-b55e-fb5429807a47	44d6afb5-6765-5cc4-b4c9-a8877761b0ca	06f6bf38-0173-52de-aa5b-77d565741cb1	2026-07-17	01:30:00	Architecture notes — Retail Insights	2026-07-17 09:01:00+00	2026-07-17 09:01:00+00	\N	RI-157	3030e191-44de-5909-b035-5fe3679b482a	Active	Worklog
2711b405-6cb6-599e-ae3d-e5af653ed12b	62445afe-3364-5e78-b55e-fb5429807a47	44d6afb5-6765-5cc4-b4c9-a8877761b0ca	e7ea37c3-9fe3-5010-bb38-8c7330ef5bdc	2026-07-21	03:30:00	Architecture notes — Care Analytics	2026-07-21 09:01:00+00	2026-07-21 09:01:00+00	\N	CA-131	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
f8f89f9c-608e-509f-ad35-855e6091d16c	62445afe-3364-5e78-b55e-fb5429807a47	44d6afb5-6765-5cc4-b4c9-a8877761b0ca	9406b74a-6b7a-578b-8fbd-958684d93780	2026-07-23	01:30:00	Architecture notes — Patient Portal	2026-07-23 09:01:00+00	2026-07-23 09:01:00+00	\N	PP-105	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
e3473d70-5cc5-5bb8-8442-f11b0c78b68d	62445afe-3364-5e78-b55e-fb5429807a47	44d6afb5-6765-5cc4-b4c9-a8877761b0ca	b8cd683c-fe4d-538c-bdaf-68c28e1e14ef	2026-07-24	02:00:00	Architecture notes — Time Intelligence	2026-07-24 09:01:00+00	2026-07-24 09:01:00+00	\N	TI-124	d677a650-2c23-5c0c-9f53-920636bd318e	Active	Worklog
7263a4cb-64bf-5929-8e81-f1f6f9b3c495	62445afe-3364-5e78-b55e-fb5429807a47	44d6afb5-6765-5cc4-b4c9-a8877761b0ca	b8cd683c-fe4d-538c-bdaf-68c28e1e14ef	2026-07-26	03:30:00	Architecture notes — Time Intelligence	2026-07-26 09:01:00+00	2026-07-26 09:01:00+00	\N	TI-152	d677a650-2c23-5c0c-9f53-920636bd318e	Active	Worklog
fdd686ec-2958-50d1-bc17-658978ccef59	62445afe-3364-5e78-b55e-fb5429807a47	44d6afb5-6765-5cc4-b4c9-a8877761b0ca	f07ee933-bae1-5f0f-9e95-6c303aba6f5d	2026-07-27	04:00:00	Architecture notes — Open Banking Integration	2026-07-27 09:01:00+00	2026-07-27 09:01:00+00	\N	OBI-171	f4c5b0e8-5503-5a50-8487-4ae103b885f2	Active	Worklog
fc610dd4-a3a0-524b-b8e0-7dda61af0237	62445afe-3364-5e78-b55e-fb5429807a47	44d6afb5-6765-5cc4-b4c9-a8877761b0ca	06f6bf38-0173-52de-aa5b-77d565741cb1	2026-07-29	02:00:00	Architecture notes — Retail Insights	2026-07-29 09:01:00+00	2026-07-29 09:01:00+00	\N	RI-145	3030e191-44de-5909-b035-5fe3679b482a	Active	Worklog
aa3f2bb7-e5e8-561d-8a72-dd530c43add2	62445afe-3364-5e78-b55e-fb5429807a47	44d6afb5-6765-5cc4-b4c9-a8877761b0ca	e7ea37c3-9fe3-5010-bb38-8c7330ef5bdc	2026-07-31	04:00:00	Architecture notes — Care Analytics	2026-07-31 09:01:00+00	2026-07-31 09:01:00+00	\N	CA-119	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
2d742c1f-0ecc-5ddd-8747-d205708f8c9e	62445afe-3364-5e78-b55e-fb5429807a47	44d6afb5-6765-5cc4-b4c9-a8877761b0ca	9406b74a-6b7a-578b-8fbd-958684d93780	2026-08-04	02:00:00	Architecture notes — Patient Portal	2026-08-04 09:01:00+00	2026-08-04 09:01:00+00	\N	PP-166	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
4b2e244e-464b-5404-85b1-75f79adc2650	62445afe-3364-5e78-b55e-fb5429807a47	44d6afb5-6765-5cc4-b4c9-a8877761b0ca	b8cd683c-fe4d-538c-bdaf-68c28e1e14ef	2026-08-06	04:00:00	Architecture notes — Time Intelligence	2026-08-06 09:01:00+00	2026-08-06 09:01:00+00	\N	TI-140	d677a650-2c23-5c0c-9f53-920636bd318e	Active	Worklog
b0b4722f-4701-54fc-b259-a3ef7dd8e19f	62445afe-3364-5e78-b55e-fb5429807a47	44d6afb5-6765-5cc4-b4c9-a8877761b0ca	9406b74a-6b7a-578b-8fbd-958684d93780	2026-08-07	00:00:00	Decyzja zakresowa potwierdzona z zespołem — Patient Portal	2026-08-07 09:01:00+00	2026-08-07 09:01:00+00	\N	\N	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Note
aa530e26-2b19-5ad0-9d9b-4a43c1a0d532	62445afe-3364-5e78-b55e-fb5429807a47	44d6afb5-6765-5cc4-b4c9-a8877761b0ca	f07ee933-bae1-5f0f-9e95-6c303aba6f5d	2026-08-09	02:00:00	Architecture notes — Open Banking Integration	2026-08-09 09:01:00+00	2026-08-09 09:01:00+00	\N	OBI-114	f4c5b0e8-5503-5a50-8487-4ae103b885f2	Active	Worklog
ab548f68-e103-5dc9-8af1-b21d26ea4f51	62445afe-3364-5e78-b55e-fb5429807a47	44d6afb5-6765-5cc4-b4c9-a8877761b0ca	06f6bf38-0173-52de-aa5b-77d565741cb1	2026-08-11	04:00:00	Architecture notes — Retail Insights	2026-08-11 09:01:00+00	2026-08-11 09:01:00+00	\N	RI-161	3030e191-44de-5909-b035-5fe3679b482a	Active	Worklog
fed06a48-3f1e-57b0-b845-4b9eef806319	62445afe-3364-5e78-b55e-fb5429807a47	b47a0c61-e4a8-5afd-b215-61150a1e3066	9406b74a-6b7a-578b-8fbd-958684d93780	2026-05-20	01:15:00	Code review — Patient Portal	2026-05-20 09:01:00+00	2026-05-20 09:01:00+00	\N	PP-112	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
05600a1b-c8c1-5c1f-8e71-64e84487a8c5	62445afe-3364-5e78-b55e-fb5429807a47	b47a0c61-e4a8-5afd-b215-61150a1e3066	04500693-9e94-55cd-a8ad-c3627d2dac80	2026-05-21	02:45:00	Code review — Commerce Growth	2026-05-21 09:01:00+00	2026-05-21 09:01:00+00	\N	CG-140	e7e99ce4-232e-5ade-abb1-0966c94d952e	Active	Worklog
758f5ead-0fb9-546a-8fae-56a1985f768a	62445afe-3364-5e78-b55e-fb5429807a47	b47a0c61-e4a8-5afd-b215-61150a1e3066	9406b74a-6b7a-578b-8fbd-958684d93780	2026-05-22	03:15:00	Code review — Patient Portal	2026-05-22 09:01:00+00	2026-05-22 09:01:00+00	\N	PP-159	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
201b07e0-5579-5eba-8faf-e46f62c41ed3	62445afe-3364-5e78-b55e-fb5429807a47	b47a0c61-e4a8-5afd-b215-61150a1e3066	04500693-9e94-55cd-a8ad-c3627d2dac80	2026-05-25	00:45:00	Code review — Commerce Growth	2026-05-25 09:01:00+00	2026-05-25 09:01:00+00	\N	CG-114	e7e99ce4-232e-5ade-abb1-0966c94d952e	Active	Worklog
fa84a6ff-f121-527c-9908-502bd86f88eb	62445afe-3364-5e78-b55e-fb5429807a47	b47a0c61-e4a8-5afd-b215-61150a1e3066	9406b74a-6b7a-578b-8fbd-958684d93780	2026-05-26	01:15:00	Code review — Patient Portal	2026-05-26 09:01:00+00	2026-05-26 09:01:00+00	\N	PP-133	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
65b9a376-ef1a-53c8-960d-b0aaaff02fe5	62445afe-3364-5e78-b55e-fb5429807a47	b47a0c61-e4a8-5afd-b215-61150a1e3066	9406b74a-6b7a-578b-8fbd-958684d93780	2026-05-28	03:15:00	Code review — Patient Portal	2026-05-28 09:01:00+00	2026-05-28 09:01:00+00	\N	PP-107	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
d1880626-97cc-5706-a693-bc810d17ab00	62445afe-3364-5e78-b55e-fb5429807a47	b47a0c61-e4a8-5afd-b215-61150a1e3066	9406b74a-6b7a-578b-8fbd-958684d93780	2026-05-31	01:15:00	Code review — Patient Portal	2026-05-31 09:01:00+00	2026-05-31 09:01:00+00	\N	PP-154	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
48ff18c0-0b79-5c0e-8255-d25e73893b45	62445afe-3364-5e78-b55e-fb5429807a47	b47a0c61-e4a8-5afd-b215-61150a1e3066	9406b74a-6b7a-578b-8fbd-958684d93780	2026-06-02	03:15:00	Code review — Patient Portal	2026-06-02 09:01:00+00	2026-06-02 09:01:00+00	\N	PP-128	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
0b2118a3-431e-5531-a273-a492532a3eb8	62445afe-3364-5e78-b55e-fb5429807a47	b47a0c61-e4a8-5afd-b215-61150a1e3066	04500693-9e94-55cd-a8ad-c3627d2dac80	2026-06-03	00:00:00	Discovery follow-up zaplanowany na kolejny tydzień — Commerce Growth	2026-06-03 09:01:00+00	2026-06-03 09:01:00+00	\N	\N	e7e99ce4-232e-5ade-abb1-0966c94d952e	Active	Note
f3ba239c-1b3f-5536-80d1-743f3adc5e68	62445afe-3364-5e78-b55e-fb5429807a47	b47a0c61-e4a8-5afd-b215-61150a1e3066	9406b74a-6b7a-578b-8fbd-958684d93780	2026-06-04	01:15:00	Code review — Patient Portal	2026-06-04 09:01:00+00	2026-06-04 09:01:00+00	\N	PP-102	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
3b7c479a-ed2d-541c-954b-34a1ba45db8d	62445afe-3364-5e78-b55e-fb5429807a47	b47a0c61-e4a8-5afd-b215-61150a1e3066	9406b74a-6b7a-578b-8fbd-958684d93780	2026-06-08	03:15:00	Code review — Patient Portal	2026-06-08 09:01:00+00	2026-06-08 09:01:00+00	\N	PP-149	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
c7b897c0-f118-51db-8d2b-323fc7891666	62445afe-3364-5e78-b55e-fb5429807a47	b47a0c61-e4a8-5afd-b215-61150a1e3066	9406b74a-6b7a-578b-8fbd-958684d93780	2026-06-10	01:15:00	Code review — Patient Portal	2026-06-10 09:01:00+00	2026-06-10 09:01:00+00	\N	PP-123	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
3b913a98-edf2-5d0c-b2d3-cb56e6eafdb1	62445afe-3364-5e78-b55e-fb5429807a47	b47a0c61-e4a8-5afd-b215-61150a1e3066	35f8aab0-9932-515e-80cc-e8fa82f9c650	2026-06-11	01:45:00	Code review — Risk Dashboard	2026-06-11 09:01:00+00	2026-06-11 09:01:00+00	\N	RD-142	f4c5b0e8-5503-5a50-8487-4ae103b885f2	Active	Worklog
d63a80ce-8336-5044-90ad-0472138b1bfc	62445afe-3364-5e78-b55e-fb5429807a47	b47a0c61-e4a8-5afd-b215-61150a1e3066	9406b74a-6b7a-578b-8fbd-958684d93780	2026-06-12	03:15:00	Code review — Patient Portal	2026-06-12 09:01:00+00	2026-06-12 09:01:00+00	\N	PP-170	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
f53fabb8-7777-5c2c-8e6b-6264a9890201	62445afe-3364-5e78-b55e-fb5429807a47	b47a0c61-e4a8-5afd-b215-61150a1e3066	35f8aab0-9932-515e-80cc-e8fa82f9c650	2026-06-14	03:45:00	Code review — Risk Dashboard	2026-06-14 09:01:00+00	2026-06-14 09:01:00+00	\N	RD-116	f4c5b0e8-5503-5a50-8487-4ae103b885f2	Active	Worklog
5e74d462-737b-51e1-9c40-165442f5a6b0	62445afe-3364-5e78-b55e-fb5429807a47	b47a0c61-e4a8-5afd-b215-61150a1e3066	35f8aab0-9932-515e-80cc-e8fa82f9c650	2026-06-16	01:45:00	Code review — Risk Dashboard	2026-06-16 09:01:00+00	2026-06-16 09:01:00+00	\N	RD-163	f4c5b0e8-5503-5a50-8487-4ae103b885f2	Active	Worklog
ec36836b-6f6f-5e90-94a5-362a450056bc	62445afe-3364-5e78-b55e-fb5429807a47	b47a0c61-e4a8-5afd-b215-61150a1e3066	35f8aab0-9932-515e-80cc-e8fa82f9c650	2026-06-18	03:45:00	Code review — Risk Dashboard	2026-06-18 09:01:00+00	2026-06-18 09:01:00+00	\N	RD-137	f4c5b0e8-5503-5a50-8487-4ae103b885f2	Active	Worklog
ba92b0d1-d5e2-5b2d-8a7b-0f32f7dd5763	62445afe-3364-5e78-b55e-fb5429807a47	b47a0c61-e4a8-5afd-b215-61150a1e3066	35f8aab0-9932-515e-80cc-e8fa82f9c650	2026-06-22	01:45:00	Code review — Risk Dashboard	2026-06-22 09:01:00+00	2026-06-22 09:01:00+00	\N	RD-111	f4c5b0e8-5503-5a50-8487-4ae103b885f2	Active	Worklog
6af4298c-dec5-5c48-866a-f60aff2b07ca	62445afe-3364-5e78-b55e-fb5429807a47	b47a0c61-e4a8-5afd-b215-61150a1e3066	35f8aab0-9932-515e-80cc-e8fa82f9c650	2026-06-24	03:45:00	Code review — Risk Dashboard	2026-06-24 09:01:00+00	2026-06-24 09:01:00+00	\N	RD-158	f4c5b0e8-5503-5a50-8487-4ae103b885f2	Active	Worklog
f8c8c93f-6267-5d53-913e-ea4707368b3e	62445afe-3364-5e78-b55e-fb5429807a47	b47a0c61-e4a8-5afd-b215-61150a1e3066	9406b74a-6b7a-578b-8fbd-958684d93780	2026-06-25	00:00:00	Discovery follow-up zaplanowany na kolejny tydzień — Patient Portal	2026-06-25 09:01:00+00	2026-06-25 09:01:00+00	\N	\N	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Note
8213cfc1-5b1d-581c-ab63-778ea91bd32f	62445afe-3364-5e78-b55e-fb5429807a47	b47a0c61-e4a8-5afd-b215-61150a1e3066	35f8aab0-9932-515e-80cc-e8fa82f9c650	2026-06-26	01:45:00	Code review — Risk Dashboard	2026-06-26 09:01:00+00	2026-06-26 09:01:00+00	\N	RD-132	f4c5b0e8-5503-5a50-8487-4ae103b885f2	Active	Worklog
9bb056e9-8058-56ba-997c-7342d2ec5c54	62445afe-3364-5e78-b55e-fb5429807a47	b47a0c61-e4a8-5afd-b215-61150a1e3066	35f8aab0-9932-515e-80cc-e8fa82f9c650	2026-06-29	03:45:00	Code review — Risk Dashboard	2026-06-29 09:01:00+00	2026-06-29 09:01:00+00	\N	RD-106	f4c5b0e8-5503-5a50-8487-4ae103b885f2	Active	Worklog
49f840d3-7eff-5496-94ee-ece238eddc82	62445afe-3364-5e78-b55e-fb5429807a47	b47a0c61-e4a8-5afd-b215-61150a1e3066	35f8aab0-9932-515e-80cc-e8fa82f9c650	2026-07-01	01:45:00	Code review — Risk Dashboard	2026-07-01 09:01:00+00	2026-07-01 09:01:00+00	\N	RD-153	f4c5b0e8-5503-5a50-8487-4ae103b885f2	Active	Worklog
d1af6f73-092e-591a-a141-169f3f69d507	62445afe-3364-5e78-b55e-fb5429807a47	b47a0c61-e4a8-5afd-b215-61150a1e3066	1146e928-4d82-581f-84f2-b8c9b6c83378	2026-07-02	02:15:00	Code review — Learning Experience	2026-07-02 09:01:00+00	2026-07-02 09:01:00+00	\N	LE-172	a9e0bb14-488c-5643-96ca-5848796322a3	Active	Worklog
f290c2b3-6fa2-5d50-bb6b-95b1a4626b67	62445afe-3364-5e78-b55e-fb5429807a47	b47a0c61-e4a8-5afd-b215-61150a1e3066	35f8aab0-9932-515e-80cc-e8fa82f9c650	2026-07-03	03:45:00	Code review — Risk Dashboard	2026-07-03 09:01:00+00	2026-07-03 09:01:00+00	\N	RD-127	f4c5b0e8-5503-5a50-8487-4ae103b885f2	Active	Worklog
2c6a6d06-fee0-5504-9939-4b21115fbd93	62445afe-3364-5e78-b55e-fb5429807a47	b47a0c61-e4a8-5afd-b215-61150a1e3066	1146e928-4d82-581f-84f2-b8c9b6c83378	2026-07-06	00:15:00	Code review — Learning Experience	2026-07-06 09:01:00+00	2026-07-06 09:01:00+00	\N	LE-146	a9e0bb14-488c-5643-96ca-5848796322a3	Active	Worklog
40ddb3cd-8aea-5128-81c9-c02ff39d35b8	62445afe-3364-5e78-b55e-fb5429807a47	b47a0c61-e4a8-5afd-b215-61150a1e3066	1146e928-4d82-581f-84f2-b8c9b6c83378	2026-07-08	02:15:00	Code review — Learning Experience	2026-07-08 09:01:00+00	2026-07-08 09:01:00+00	\N	LE-120	a9e0bb14-488c-5643-96ca-5848796322a3	Active	Worklog
1fa28bf1-4af2-5f7a-8eba-d8470198778e	62445afe-3364-5e78-b55e-fb5429807a47	b47a0c61-e4a8-5afd-b215-61150a1e3066	1146e928-4d82-581f-84f2-b8c9b6c83378	2026-07-10	00:15:00	Code review — Learning Experience	2026-07-10 09:01:00+00	2026-07-10 09:01:00+00	\N	LE-167	a9e0bb14-488c-5643-96ca-5848796322a3	Active	Worklog
a5c19337-1545-5976-b29b-b5173ca1bae6	62445afe-3364-5e78-b55e-fb5429807a47	b47a0c61-e4a8-5afd-b215-61150a1e3066	1146e928-4d82-581f-84f2-b8c9b6c83378	2026-07-13	02:15:00	Code review — Learning Experience	2026-07-13 09:01:00+00	2026-07-13 09:01:00+00	\N	LE-141	a9e0bb14-488c-5643-96ca-5848796322a3	Active	Worklog
47273115-630d-5032-9c82-be6024391c37	62445afe-3364-5e78-b55e-fb5429807a47	b47a0c61-e4a8-5afd-b215-61150a1e3066	1146e928-4d82-581f-84f2-b8c9b6c83378	2026-07-15	00:15:00	Code review — Learning Experience	2026-07-15 09:01:00+00	2026-07-15 09:01:00+00	\N	LE-115	a9e0bb14-488c-5643-96ca-5848796322a3	Active	Worklog
46cccec1-6541-5796-8e83-3ad4069c462c	62445afe-3364-5e78-b55e-fb5429807a47	b47a0c61-e4a8-5afd-b215-61150a1e3066	35f8aab0-9932-515e-80cc-e8fa82f9c650	2026-07-16	00:00:00	Discovery follow-up zaplanowany na kolejny tydzień — Risk Dashboard	2026-07-16 09:01:00+00	2026-07-16 09:01:00+00	\N	\N	f4c5b0e8-5503-5a50-8487-4ae103b885f2	Active	Note
9e298066-477e-56d7-a408-fc5e374aed92	62445afe-3364-5e78-b55e-fb5429807a47	b47a0c61-e4a8-5afd-b215-61150a1e3066	1146e928-4d82-581f-84f2-b8c9b6c83378	2026-07-17	02:15:00	Code review — Learning Experience	2026-07-17 09:01:00+00	2026-07-17 09:01:00+00	\N	LE-162	a9e0bb14-488c-5643-96ca-5848796322a3	Active	Worklog
719c2615-a2e7-5a23-8cef-65d233f914e3	62445afe-3364-5e78-b55e-fb5429807a47	b47a0c61-e4a8-5afd-b215-61150a1e3066	1146e928-4d82-581f-84f2-b8c9b6c83378	2026-07-21	00:15:00	Code review — Learning Experience	2026-07-21 09:01:00+00	2026-07-21 09:01:00+00	\N	LE-136	a9e0bb14-488c-5643-96ca-5848796322a3	Active	Worklog
0c10e48f-7736-515c-87ae-b9842f4b79ff	62445afe-3364-5e78-b55e-fb5429807a47	b47a0c61-e4a8-5afd-b215-61150a1e3066	1146e928-4d82-581f-84f2-b8c9b6c83378	2026-07-23	02:15:00	Code review — Learning Experience	2026-07-23 09:01:00+00	2026-07-23 09:01:00+00	\N	LE-110	a9e0bb14-488c-5643-96ca-5848796322a3	Active	Worklog
c6d579ee-011c-51a6-9a18-fd71d04c0efa	62445afe-3364-5e78-b55e-fb5429807a47	b47a0c61-e4a8-5afd-b215-61150a1e3066	04500693-9e94-55cd-a8ad-c3627d2dac80	2026-07-24	02:45:00	Code review — Commerce Growth	2026-07-24 09:01:00+00	2026-07-24 09:01:00+00	\N	CG-129	e7e99ce4-232e-5ade-abb1-0966c94d952e	Active	Worklog
914d3baf-65bd-5eeb-81a0-8cd741224f2a	62445afe-3364-5e78-b55e-fb5429807a47	b47a0c61-e4a8-5afd-b215-61150a1e3066	1146e928-4d82-581f-84f2-b8c9b6c83378	2026-07-26	00:15:00	Code review — Learning Experience	2026-07-26 09:01:00+00	2026-07-26 09:01:00+00	\N	LE-157	a9e0bb14-488c-5643-96ca-5848796322a3	Active	Worklog
88ee6e6a-d229-587e-84d8-cb4ad256fe11	62445afe-3364-5e78-b55e-fb5429807a47	b47a0c61-e4a8-5afd-b215-61150a1e3066	04500693-9e94-55cd-a8ad-c3627d2dac80	2026-07-27	00:45:00	Code review — Commerce Growth	2026-07-27 09:01:00+00	2026-07-27 09:01:00+00	\N	CG-103	e7e99ce4-232e-5ade-abb1-0966c94d952e	Active	Worklog
74bb4222-b904-597f-92d0-391c2f25644a	62445afe-3364-5e78-b55e-fb5429807a47	b47a0c61-e4a8-5afd-b215-61150a1e3066	04500693-9e94-55cd-a8ad-c3627d2dac80	2026-07-29	02:45:00	Code review — Commerce Growth	2026-07-29 09:01:00+00	2026-07-29 09:01:00+00	\N	CG-150	e7e99ce4-232e-5ade-abb1-0966c94d952e	Active	Worklog
25885f86-ccb8-58ac-a799-8795c3a9798d	62445afe-3364-5e78-b55e-fb5429807a47	b47a0c61-e4a8-5afd-b215-61150a1e3066	04500693-9e94-55cd-a8ad-c3627d2dac80	2026-07-31	00:45:00	Code review — Commerce Growth	2026-07-31 09:01:00+00	2026-07-31 09:01:00+00	\N	CG-124	e7e99ce4-232e-5ade-abb1-0966c94d952e	Active	Worklog
9beb5e7c-e433-5ac5-90c0-0901a01f3841	62445afe-3364-5e78-b55e-fb5429807a47	b47a0c61-e4a8-5afd-b215-61150a1e3066	04500693-9e94-55cd-a8ad-c3627d2dac80	2026-08-04	02:45:00	Code review — Commerce Growth	2026-08-04 09:01:00+00	2026-08-04 09:01:00+00	\N	CG-171	e7e99ce4-232e-5ade-abb1-0966c94d952e	Active	Worklog
0c5c1c2f-33c7-5fcc-a128-ec81366852d3	62445afe-3364-5e78-b55e-fb5429807a47	b47a0c61-e4a8-5afd-b215-61150a1e3066	04500693-9e94-55cd-a8ad-c3627d2dac80	2026-08-06	00:45:00	Code review — Commerce Growth	2026-08-06 09:01:00+00	2026-08-06 09:01:00+00	\N	CG-145	e7e99ce4-232e-5ade-abb1-0966c94d952e	Active	Worklog
f3df504c-8e75-52bb-a4d6-071d9f012c68	62445afe-3364-5e78-b55e-fb5429807a47	b47a0c61-e4a8-5afd-b215-61150a1e3066	1146e928-4d82-581f-84f2-b8c9b6c83378	2026-08-07	00:00:00	Discovery follow-up zaplanowany na kolejny tydzień — Learning Experience	2026-08-07 09:01:00+00	2026-08-07 09:01:00+00	\N	\N	a9e0bb14-488c-5643-96ca-5848796322a3	Active	Note
192ce54b-5f44-5593-b694-08acb9bad970	62445afe-3364-5e78-b55e-fb5429807a47	b47a0c61-e4a8-5afd-b215-61150a1e3066	04500693-9e94-55cd-a8ad-c3627d2dac80	2026-08-09	02:45:00	Code review — Commerce Growth	2026-08-09 09:01:00+00	2026-08-09 09:01:00+00	\N	CG-119	e7e99ce4-232e-5ade-abb1-0966c94d952e	Active	Worklog
7f298735-4715-593e-8229-4dfda2dca248	62445afe-3364-5e78-b55e-fb5429807a47	b47a0c61-e4a8-5afd-b215-61150a1e3066	04500693-9e94-55cd-a8ad-c3627d2dac80	2026-08-11	00:45:00	Code review — Commerce Growth	2026-08-11 09:01:00+00	2026-08-11 09:01:00+00	\N	CG-166	e7e99ce4-232e-5ade-abb1-0966c94d952e	Active	Worklog
38cc5ba3-54f4-56a5-b5ac-1f9213c7c9cd	62445afe-3364-5e78-b55e-fb5429807a47	1bfc7228-78d0-5a5c-8562-deb1f1a7b28f	a7906be2-315f-5b5e-b344-ac119fd04d1a	2026-05-20	01:15:00	Accessibility review — Omnichannel Checkout	2026-05-20 09:01:00+00	2026-05-20 09:01:00+00	\N	OC-128	3030e191-44de-5909-b035-5fe3679b482a	Active	Worklog
bba5ddcc-683b-5abe-8c05-4e2ab31a7c8a	62445afe-3364-5e78-b55e-fb5429807a47	1bfc7228-78d0-5a5c-8562-deb1f1a7b28f	a7906be2-315f-5b5e-b344-ac119fd04d1a	2026-05-21	02:45:00	Accessibility review — Omnichannel Checkout	2026-05-21 09:01:00+00	2026-05-21 09:01:00+00	\N	OC-156	3030e191-44de-5909-b035-5fe3679b482a	Active	Worklog
24a7952e-d823-549e-8161-735d8e8180a6	62445afe-3364-5e78-b55e-fb5429807a47	1bfc7228-78d0-5a5c-8562-deb1f1a7b28f	a7906be2-315f-5b5e-b344-ac119fd04d1a	2026-05-22	03:15:00	Accessibility review — Omnichannel Checkout	2026-05-22 09:01:00+00	2026-05-22 09:01:00+00	\N	OC-102	3030e191-44de-5909-b035-5fe3679b482a	Active	Worklog
12a53c29-e78f-5e57-8030-27e984c574b5	62445afe-3364-5e78-b55e-fb5429807a47	1bfc7228-78d0-5a5c-8562-deb1f1a7b28f	a7906be2-315f-5b5e-b344-ac119fd04d1a	2026-05-25	00:45:00	Accessibility review — Omnichannel Checkout	2026-05-25 09:01:00+00	2026-05-25 09:01:00+00	\N	OC-130	3030e191-44de-5909-b035-5fe3679b482a	Active	Worklog
ce815df8-6bbc-599a-8e67-0c9c2c37711f	62445afe-3364-5e78-b55e-fb5429807a47	1bfc7228-78d0-5a5c-8562-deb1f1a7b28f	a7906be2-315f-5b5e-b344-ac119fd04d1a	2026-05-26	01:15:00	Accessibility review — Omnichannel Checkout	2026-05-26 09:01:00+00	2026-05-26 09:01:00+00	\N	OC-149	3030e191-44de-5909-b035-5fe3679b482a	Active	Worklog
51e5fcbe-f65b-50aa-9453-060e0ec6f99d	62445afe-3364-5e78-b55e-fb5429807a47	1bfc7228-78d0-5a5c-8562-deb1f1a7b28f	a7906be2-315f-5b5e-b344-ac119fd04d1a	2026-05-28	03:15:00	Accessibility review — Omnichannel Checkout	2026-05-28 09:01:00+00	2026-05-28 09:01:00+00	\N	OC-123	3030e191-44de-5909-b035-5fe3679b482a	Active	Worklog
a09a6ded-8621-5af4-bf01-9b7090497d3e	62445afe-3364-5e78-b55e-fb5429807a47	1bfc7228-78d0-5a5c-8562-deb1f1a7b28f	a7906be2-315f-5b5e-b344-ac119fd04d1a	2026-05-31	01:15:00	Accessibility review — Omnichannel Checkout	2026-05-31 09:01:00+00	2026-05-31 09:01:00+00	\N	OC-170	3030e191-44de-5909-b035-5fe3679b482a	Active	Worklog
0483e8d2-77de-5e40-8d10-0836fc11b907	62445afe-3364-5e78-b55e-fb5429807a47	1bfc7228-78d0-5a5c-8562-deb1f1a7b28f	a7906be2-315f-5b5e-b344-ac119fd04d1a	2026-06-02	03:15:00	Accessibility review — Omnichannel Checkout	2026-06-02 09:01:00+00	2026-06-02 09:01:00+00	\N	OC-144	3030e191-44de-5909-b035-5fe3679b482a	Active	Worklog
ff31c38e-44c8-5c05-9e44-6572fb6d5887	62445afe-3364-5e78-b55e-fb5429807a47	1bfc7228-78d0-5a5c-8562-deb1f1a7b28f	a7906be2-315f-5b5e-b344-ac119fd04d1a	2026-06-03	00:00:00	Client feedback added to the next iteration — Omnichannel Checkout	2026-06-03 09:01:00+00	2026-06-03 09:01:00+00	\N	\N	3030e191-44de-5909-b035-5fe3679b482a	Active	Note
333758db-c5aa-5901-aeb3-876f60b54cf6	62445afe-3364-5e78-b55e-fb5429807a47	1bfc7228-78d0-5a5c-8562-deb1f1a7b28f	a7906be2-315f-5b5e-b344-ac119fd04d1a	2026-06-04	01:15:00	Accessibility review — Omnichannel Checkout	2026-06-04 09:01:00+00	2026-06-04 09:01:00+00	\N	OC-118	3030e191-44de-5909-b035-5fe3679b482a	Active	Worklog
22794a7b-2da7-505a-a6cd-695b0eda3984	62445afe-3364-5e78-b55e-fb5429807a47	1bfc7228-78d0-5a5c-8562-deb1f1a7b28f	a7906be2-315f-5b5e-b344-ac119fd04d1a	2026-06-08	03:15:00	Accessibility review — Omnichannel Checkout	2026-06-08 09:01:00+00	2026-06-08 09:01:00+00	\N	OC-165	3030e191-44de-5909-b035-5fe3679b482a	Active	Worklog
c4a90696-68ab-5155-b397-539d0a48d0a9	62445afe-3364-5e78-b55e-fb5429807a47	1bfc7228-78d0-5a5c-8562-deb1f1a7b28f	a7906be2-315f-5b5e-b344-ac119fd04d1a	2026-06-10	01:15:00	Accessibility review — Omnichannel Checkout	2026-06-10 09:01:00+00	2026-06-10 09:01:00+00	\N	OC-139	3030e191-44de-5909-b035-5fe3679b482a	Active	Worklog
c6df7f4c-10ae-52ce-b600-766d5e3b01a3	62445afe-3364-5e78-b55e-fb5429807a47	1bfc7228-78d0-5a5c-8562-deb1f1a7b28f	a7906be2-315f-5b5e-b344-ac119fd04d1a	2026-06-11	01:45:00	Accessibility review — Omnichannel Checkout	2026-06-11 09:01:00+00	2026-06-11 09:01:00+00	\N	OC-158	3030e191-44de-5909-b035-5fe3679b482a	Active	Worklog
7f2be277-45d3-5ca8-b1cc-b42eef9378c9	62445afe-3364-5e78-b55e-fb5429807a47	1bfc7228-78d0-5a5c-8562-deb1f1a7b28f	a7906be2-315f-5b5e-b344-ac119fd04d1a	2026-06-12	03:15:00	Accessibility review — Omnichannel Checkout	2026-06-12 09:01:00+00	2026-06-12 09:01:00+00	\N	OC-113	3030e191-44de-5909-b035-5fe3679b482a	Active	Worklog
36da70c7-9caf-5063-a98a-04a90c82e039	62445afe-3364-5e78-b55e-fb5429807a47	1bfc7228-78d0-5a5c-8562-deb1f1a7b28f	a7906be2-315f-5b5e-b344-ac119fd04d1a	2026-06-14	03:45:00	Accessibility review — Omnichannel Checkout	2026-06-14 09:01:00+00	2026-06-14 09:01:00+00	\N	OC-132	3030e191-44de-5909-b035-5fe3679b482a	Active	Worklog
3cc4c58c-c713-51bb-bedc-9179ae7d335c	62445afe-3364-5e78-b55e-fb5429807a47	1bfc7228-78d0-5a5c-8562-deb1f1a7b28f	a7906be2-315f-5b5e-b344-ac119fd04d1a	2026-06-16	01:45:00	Accessibility review — Omnichannel Checkout	2026-06-16 09:01:00+00	2026-06-16 09:01:00+00	\N	OC-106	3030e191-44de-5909-b035-5fe3679b482a	Active	Worklog
541749d4-9ab3-5e4f-80e7-1ea70c611f9a	62445afe-3364-5e78-b55e-fb5429807a47	1bfc7228-78d0-5a5c-8562-deb1f1a7b28f	a7906be2-315f-5b5e-b344-ac119fd04d1a	2026-06-18	03:45:00	Accessibility review — Omnichannel Checkout	2026-06-18 09:01:00+00	2026-06-18 09:01:00+00	\N	OC-153	3030e191-44de-5909-b035-5fe3679b482a	Active	Worklog
fe09dfe7-295e-575c-b621-badb8f6baa7a	62445afe-3364-5e78-b55e-fb5429807a47	1bfc7228-78d0-5a5c-8562-deb1f1a7b28f	a7906be2-315f-5b5e-b344-ac119fd04d1a	2026-06-22	01:45:00	Accessibility review — Omnichannel Checkout	2026-06-22 09:01:00+00	2026-06-22 09:01:00+00	\N	OC-127	3030e191-44de-5909-b035-5fe3679b482a	Active	Worklog
0b053ea5-ec56-5978-9cf2-96dc2003fd91	62445afe-3364-5e78-b55e-fb5429807a47	1bfc7228-78d0-5a5c-8562-deb1f1a7b28f	a7906be2-315f-5b5e-b344-ac119fd04d1a	2026-06-24	03:45:00	Accessibility review — Omnichannel Checkout	2026-06-24 09:01:00+00	2026-06-24 09:01:00+00	\N	OC-101	3030e191-44de-5909-b035-5fe3679b482a	Active	Worklog
8ea628d4-4374-5463-8e85-e0d5814e25b2	62445afe-3364-5e78-b55e-fb5429807a47	1bfc7228-78d0-5a5c-8562-deb1f1a7b28f	a7906be2-315f-5b5e-b344-ac119fd04d1a	2026-06-25	00:00:00	Client feedback added to the next iteration — Omnichannel Checkout	2026-06-25 09:01:00+00	2026-06-25 09:01:00+00	\N	\N	3030e191-44de-5909-b035-5fe3679b482a	Active	Note
13b18604-6ecf-53ec-8b86-97ffcdabae8e	62445afe-3364-5e78-b55e-fb5429807a47	1bfc7228-78d0-5a5c-8562-deb1f1a7b28f	a7906be2-315f-5b5e-b344-ac119fd04d1a	2026-06-26	01:45:00	Accessibility review — Omnichannel Checkout	2026-06-26 09:01:00+00	2026-06-26 09:01:00+00	\N	OC-148	3030e191-44de-5909-b035-5fe3679b482a	Active	Worklog
9006d9bc-0d1b-57af-8d4b-f20f01f0b777	62445afe-3364-5e78-b55e-fb5429807a47	1bfc7228-78d0-5a5c-8562-deb1f1a7b28f	a7906be2-315f-5b5e-b344-ac119fd04d1a	2026-06-29	03:45:00	Accessibility review — Omnichannel Checkout	2026-06-29 09:01:00+00	2026-06-29 09:01:00+00	\N	OC-122	3030e191-44de-5909-b035-5fe3679b482a	Active	Worklog
68989664-641c-5fb3-9455-fc4433c42d04	62445afe-3364-5e78-b55e-fb5429807a47	1bfc7228-78d0-5a5c-8562-deb1f1a7b28f	a7906be2-315f-5b5e-b344-ac119fd04d1a	2026-07-01	01:45:00	Accessibility review — Omnichannel Checkout	2026-07-01 09:01:00+00	2026-07-01 09:01:00+00	\N	OC-169	3030e191-44de-5909-b035-5fe3679b482a	Active	Worklog
2e604b1f-0e00-53a4-94c0-fb6623e08112	62445afe-3364-5e78-b55e-fb5429807a47	1bfc7228-78d0-5a5c-8562-deb1f1a7b28f	a7906be2-315f-5b5e-b344-ac119fd04d1a	2026-07-02	02:15:00	Accessibility review — Omnichannel Checkout	2026-07-02 09:01:00+00	2026-07-02 09:01:00+00	\N	OC-115	3030e191-44de-5909-b035-5fe3679b482a	Active	Worklog
6523f5f6-693b-5e04-afa8-9866f01fec9a	62445afe-3364-5e78-b55e-fb5429807a47	1bfc7228-78d0-5a5c-8562-deb1f1a7b28f	a7906be2-315f-5b5e-b344-ac119fd04d1a	2026-07-03	03:45:00	Accessibility review — Omnichannel Checkout	2026-07-03 09:01:00+00	2026-07-03 09:01:00+00	\N	OC-143	3030e191-44de-5909-b035-5fe3679b482a	Active	Worklog
5a744345-db11-5c9c-88aa-a1503ca86636	62445afe-3364-5e78-b55e-fb5429807a47	1bfc7228-78d0-5a5c-8562-deb1f1a7b28f	a7906be2-315f-5b5e-b344-ac119fd04d1a	2026-07-06	00:15:00	Accessibility review — Omnichannel Checkout	2026-07-06 09:01:00+00	2026-07-06 09:01:00+00	\N	OC-162	3030e191-44de-5909-b035-5fe3679b482a	Active	Worklog
0da85707-1dad-58ba-9263-1e5f30521419	62445afe-3364-5e78-b55e-fb5429807a47	1bfc7228-78d0-5a5c-8562-deb1f1a7b28f	a7906be2-315f-5b5e-b344-ac119fd04d1a	2026-07-08	02:15:00	Accessibility review — Omnichannel Checkout	2026-07-08 09:01:00+00	2026-07-08 09:01:00+00	\N	OC-136	3030e191-44de-5909-b035-5fe3679b482a	Active	Worklog
f770df6f-0cad-599b-b59f-9b4bc3c0e5e4	62445afe-3364-5e78-b55e-fb5429807a47	1bfc7228-78d0-5a5c-8562-deb1f1a7b28f	a7906be2-315f-5b5e-b344-ac119fd04d1a	2026-07-10	00:15:00	Accessibility review — Omnichannel Checkout	2026-07-10 09:01:00+00	2026-07-10 09:01:00+00	\N	OC-110	3030e191-44de-5909-b035-5fe3679b482a	Active	Worklog
f59e06a2-acc6-5cd6-8cfb-1fecc109f804	62445afe-3364-5e78-b55e-fb5429807a47	1bfc7228-78d0-5a5c-8562-deb1f1a7b28f	a7906be2-315f-5b5e-b344-ac119fd04d1a	2026-07-13	02:15:00	Accessibility review — Omnichannel Checkout	2026-07-13 09:01:00+00	2026-07-13 09:01:00+00	\N	OC-157	3030e191-44de-5909-b035-5fe3679b482a	Active	Worklog
a4c319cb-c9ca-5519-ac0d-22449900034e	62445afe-3364-5e78-b55e-fb5429807a47	1bfc7228-78d0-5a5c-8562-deb1f1a7b28f	a7906be2-315f-5b5e-b344-ac119fd04d1a	2026-07-15	00:15:00	Accessibility review — Omnichannel Checkout	2026-07-15 09:01:00+00	2026-07-15 09:01:00+00	\N	OC-131	3030e191-44de-5909-b035-5fe3679b482a	Active	Worklog
d4bac039-3e55-599b-9cec-9b0abbfbbf24	62445afe-3364-5e78-b55e-fb5429807a47	1bfc7228-78d0-5a5c-8562-deb1f1a7b28f	a7906be2-315f-5b5e-b344-ac119fd04d1a	2026-07-16	00:00:00	Client feedback added to the next iteration — Omnichannel Checkout	2026-07-16 09:01:00+00	2026-07-16 09:01:00+00	\N	\N	3030e191-44de-5909-b035-5fe3679b482a	Active	Note
e144a118-7a5c-5f86-8c12-2412ce1a234b	62445afe-3364-5e78-b55e-fb5429807a47	1bfc7228-78d0-5a5c-8562-deb1f1a7b28f	a7906be2-315f-5b5e-b344-ac119fd04d1a	2026-07-17	02:15:00	Accessibility review — Omnichannel Checkout	2026-07-17 09:01:00+00	2026-07-17 09:01:00+00	\N	OC-105	3030e191-44de-5909-b035-5fe3679b482a	Active	Worklog
1f6e0c01-7d5e-5554-a395-13761fd32343	62445afe-3364-5e78-b55e-fb5429807a47	1bfc7228-78d0-5a5c-8562-deb1f1a7b28f	a7906be2-315f-5b5e-b344-ac119fd04d1a	2026-07-21	00:15:00	Accessibility review — Omnichannel Checkout	2026-07-21 09:01:00+00	2026-07-21 09:01:00+00	\N	OC-152	3030e191-44de-5909-b035-5fe3679b482a	Active	Worklog
42b0cac3-b4bf-5f4b-8023-a5dd92bacaba	62445afe-3364-5e78-b55e-fb5429807a47	1bfc7228-78d0-5a5c-8562-deb1f1a7b28f	a7906be2-315f-5b5e-b344-ac119fd04d1a	2026-07-23	02:15:00	Accessibility review — Omnichannel Checkout	2026-07-23 09:01:00+00	2026-07-23 09:01:00+00	\N	OC-126	3030e191-44de-5909-b035-5fe3679b482a	Active	Worklog
5231dc81-cbd6-579f-9aac-0bb32bc8cb70	62445afe-3364-5e78-b55e-fb5429807a47	1bfc7228-78d0-5a5c-8562-deb1f1a7b28f	a7906be2-315f-5b5e-b344-ac119fd04d1a	2026-07-24	02:45:00	Accessibility review — Omnichannel Checkout	2026-07-24 09:01:00+00	2026-07-24 09:01:00+00	\N	OC-145	3030e191-44de-5909-b035-5fe3679b482a	Active	Worklog
a334519a-e2ff-56d0-9e52-66e77c46eb5c	62445afe-3364-5e78-b55e-fb5429807a47	1bfc7228-78d0-5a5c-8562-deb1f1a7b28f	a7906be2-315f-5b5e-b344-ac119fd04d1a	2026-07-26	00:15:00	Accessibility review — Omnichannel Checkout	2026-07-26 09:01:00+00	2026-07-26 09:01:00+00	\N	OC-100	3030e191-44de-5909-b035-5fe3679b482a	Active	Worklog
74c64617-6eea-5c7e-a437-404550acb6b5	62445afe-3364-5e78-b55e-fb5429807a47	1bfc7228-78d0-5a5c-8562-deb1f1a7b28f	a7906be2-315f-5b5e-b344-ac119fd04d1a	2026-07-27	00:45:00	Accessibility review — Omnichannel Checkout	2026-07-27 09:01:00+00	2026-07-27 09:01:00+00	\N	OC-119	3030e191-44de-5909-b035-5fe3679b482a	Active	Worklog
11a2b8ce-d2a4-5b01-9699-638eaf128924	62445afe-3364-5e78-b55e-fb5429807a47	1bfc7228-78d0-5a5c-8562-deb1f1a7b28f	a7906be2-315f-5b5e-b344-ac119fd04d1a	2026-07-29	02:45:00	Accessibility review — Omnichannel Checkout	2026-07-29 09:01:00+00	2026-07-29 09:01:00+00	\N	OC-166	3030e191-44de-5909-b035-5fe3679b482a	Active	Worklog
2763bf79-2e3d-5ab2-99f7-734781cb5550	62445afe-3364-5e78-b55e-fb5429807a47	1bfc7228-78d0-5a5c-8562-deb1f1a7b28f	a7906be2-315f-5b5e-b344-ac119fd04d1a	2026-07-31	00:45:00	Accessibility review — Omnichannel Checkout	2026-07-31 09:01:00+00	2026-07-31 09:01:00+00	\N	OC-140	3030e191-44de-5909-b035-5fe3679b482a	Active	Worklog
ae4dedcb-a109-5841-8443-1e4231edbf93	62445afe-3364-5e78-b55e-fb5429807a47	1bfc7228-78d0-5a5c-8562-deb1f1a7b28f	a7906be2-315f-5b5e-b344-ac119fd04d1a	2026-08-04	02:45:00	Accessibility review — Omnichannel Checkout	2026-08-04 09:01:00+00	2026-08-04 09:01:00+00	\N	OC-114	3030e191-44de-5909-b035-5fe3679b482a	Active	Worklog
f4b46706-4db6-584a-8852-094998fdfcf5	62445afe-3364-5e78-b55e-fb5429807a47	1bfc7228-78d0-5a5c-8562-deb1f1a7b28f	a7906be2-315f-5b5e-b344-ac119fd04d1a	2026-08-06	00:45:00	Accessibility review — Omnichannel Checkout	2026-08-06 09:01:00+00	2026-08-06 09:01:00+00	\N	OC-161	3030e191-44de-5909-b035-5fe3679b482a	Active	Worklog
3f6da922-4326-5f33-8fbd-e92abf09580c	62445afe-3364-5e78-b55e-fb5429807a47	1bfc7228-78d0-5a5c-8562-deb1f1a7b28f	a7906be2-315f-5b5e-b344-ac119fd04d1a	2026-08-09	02:45:00	Accessibility review — Omnichannel Checkout	2026-08-09 09:01:00+00	2026-08-09 09:01:00+00	\N	OC-135	3030e191-44de-5909-b035-5fe3679b482a	Active	Worklog
9af8c2ee-2646-5e90-b81c-7b5d800fd525	62445afe-3364-5e78-b55e-fb5429807a47	1bfc7228-78d0-5a5c-8562-deb1f1a7b28f	a7906be2-315f-5b5e-b344-ac119fd04d1a	2026-08-11	00:45:00	Accessibility review — Omnichannel Checkout	2026-08-11 09:01:00+00	2026-08-11 09:01:00+00	\N	OC-109	3030e191-44de-5909-b035-5fe3679b482a	Active	Worklog
06c5f353-6058-5603-91c2-412dc5828f84	62445afe-3364-5e78-b55e-fb5429807a47	18664d65-3906-58e7-91fd-d67ffedd1b64	06f6bf38-0173-52de-aa5b-77d565741cb1	2026-05-20	03:15:00	Discovery workshop — Retail Insights	2026-05-20 09:01:00+00	2026-05-20 09:01:00+00	\N	RI-120	3030e191-44de-5909-b035-5fe3679b482a	Active	Worklog
0c942bb4-e479-5bb4-8cd9-97a3b89616af	62445afe-3364-5e78-b55e-fb5429807a47	18664d65-3906-58e7-91fd-d67ffedd1b64	a7906be2-315f-5b5e-b344-ac119fd04d1a	2026-05-21	00:45:00	Discovery workshop — Omnichannel Checkout	2026-05-21 09:01:00+00	2026-05-21 09:01:00+00	\N	OC-148	3030e191-44de-5909-b035-5fe3679b482a	Active	Worklog
04bcdede-94f0-59c3-bec8-2d73bd7bc3c1	62445afe-3364-5e78-b55e-fb5429807a47	18664d65-3906-58e7-91fd-d67ffedd1b64	f04245fa-9e0e-5905-80fa-524e9f1e172f	2026-05-22	01:15:00	Discovery workshop — Delivery Operations Hub	2026-05-22 09:01:00+00	2026-05-22 09:01:00+00	\N	DOH-167	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
19ce1448-d970-5c6f-8f32-10d6f53b8c0b	62445afe-3364-5e78-b55e-fb5429807a47	18664d65-3906-58e7-91fd-d67ffedd1b64	06f6bf38-0173-52de-aa5b-77d565741cb1	2026-05-25	02:45:00	Discovery workshop — Retail Insights	2026-05-25 09:01:00+00	2026-05-25 09:01:00+00	\N	RI-122	3030e191-44de-5909-b035-5fe3679b482a	Active	Worklog
f77b5a77-b006-511b-8613-88523e02908b	62445afe-3364-5e78-b55e-fb5429807a47	18664d65-3906-58e7-91fd-d67ffedd1b64	a7906be2-315f-5b5e-b344-ac119fd04d1a	2026-05-26	03:15:00	Discovery workshop — Omnichannel Checkout	2026-05-26 09:01:00+00	2026-05-26 09:01:00+00	\N	OC-141	3030e191-44de-5909-b035-5fe3679b482a	Active	Worklog
ef17ba6a-1072-5e99-b5a6-9ecf8229f6f7	62445afe-3364-5e78-b55e-fb5429807a47	18664d65-3906-58e7-91fd-d67ffedd1b64	06f6bf38-0173-52de-aa5b-77d565741cb1	2026-05-28	01:15:00	Discovery workshop — Retail Insights	2026-05-28 09:01:00+00	2026-05-28 09:01:00+00	\N	RI-115	3030e191-44de-5909-b035-5fe3679b482a	Active	Worklog
03386330-3ebf-5406-a3de-0106998b9c1e	62445afe-3364-5e78-b55e-fb5429807a47	18664d65-3906-58e7-91fd-d67ffedd1b64	f04245fa-9e0e-5905-80fa-524e9f1e172f	2026-05-31	03:15:00	Discovery workshop — Delivery Operations Hub	2026-05-31 09:01:00+00	2026-05-31 09:01:00+00	\N	DOH-162	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
0221cc76-7cfb-5851-89f6-7b53d29d6e0c	62445afe-3364-5e78-b55e-fb5429807a47	18664d65-3906-58e7-91fd-d67ffedd1b64	a7906be2-315f-5b5e-b344-ac119fd04d1a	2026-06-02	01:15:00	Discovery workshop — Omnichannel Checkout	2026-06-02 09:01:00+00	2026-06-02 09:01:00+00	\N	OC-136	3030e191-44de-5909-b035-5fe3679b482a	Active	Worklog
09532851-dc62-56a2-aeed-4d69d873595a	62445afe-3364-5e78-b55e-fb5429807a47	18664d65-3906-58e7-91fd-d67ffedd1b64	a7906be2-315f-5b5e-b344-ac119fd04d1a	2026-06-03	00:00:00	Blocker integracji wymaga odpowiedzi partnera — Omnichannel Checkout	2026-06-03 09:01:00+00	2026-06-03 09:01:00+00	\N	\N	3030e191-44de-5909-b035-5fe3679b482a	Active	Note
1a29b5c2-7da1-5be2-b0b5-dd173bf3f127	62445afe-3364-5e78-b55e-fb5429807a47	18664d65-3906-58e7-91fd-d67ffedd1b64	06f6bf38-0173-52de-aa5b-77d565741cb1	2026-06-04	03:15:00	Discovery workshop — Retail Insights	2026-06-04 09:01:00+00	2026-06-04 09:01:00+00	\N	RI-110	3030e191-44de-5909-b035-5fe3679b482a	Active	Worklog
6fd66dd8-2d1a-5ba1-afd1-4041a047500c	62445afe-3364-5e78-b55e-fb5429807a47	18664d65-3906-58e7-91fd-d67ffedd1b64	f04245fa-9e0e-5905-80fa-524e9f1e172f	2026-06-08	01:15:00	Discovery workshop — Delivery Operations Hub	2026-06-08 09:01:00+00	2026-06-08 09:01:00+00	\N	DOH-157	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
4f8ecf68-ea8c-5b99-8865-a669dc6199bc	62445afe-3364-5e78-b55e-fb5429807a47	18664d65-3906-58e7-91fd-d67ffedd1b64	a7906be2-315f-5b5e-b344-ac119fd04d1a	2026-06-10	03:15:00	Discovery workshop — Omnichannel Checkout	2026-06-10 09:01:00+00	2026-06-10 09:01:00+00	\N	OC-131	3030e191-44de-5909-b035-5fe3679b482a	Active	Worklog
b33f3269-aebb-5e40-9c60-63ca25626523	62445afe-3364-5e78-b55e-fb5429807a47	18664d65-3906-58e7-91fd-d67ffedd1b64	f04245fa-9e0e-5905-80fa-524e9f1e172f	2026-06-11	03:45:00	Discovery workshop — Delivery Operations Hub	2026-06-11 09:01:00+00	2026-06-11 09:01:00+00	\N	DOH-150	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
b6bcce6d-6f51-5ce4-9196-6e47ffa76b60	62445afe-3364-5e78-b55e-fb5429807a47	18664d65-3906-58e7-91fd-d67ffedd1b64	06f6bf38-0173-52de-aa5b-77d565741cb1	2026-06-12	01:15:00	Discovery workshop — Retail Insights	2026-06-12 09:01:00+00	2026-06-12 09:01:00+00	\N	RI-105	3030e191-44de-5909-b035-5fe3679b482a	Active	Worklog
3eb20950-fc15-559d-8005-8bf0065dc4f5	62445afe-3364-5e78-b55e-fb5429807a47	18664d65-3906-58e7-91fd-d67ffedd1b64	a7906be2-315f-5b5e-b344-ac119fd04d1a	2026-06-14	01:45:00	Discovery workshop — Omnichannel Checkout	2026-06-14 09:01:00+00	2026-06-14 09:01:00+00	\N	OC-124	3030e191-44de-5909-b035-5fe3679b482a	Active	Worklog
da6374b4-21a8-59c9-8a1a-db5da255b10f	62445afe-3364-5e78-b55e-fb5429807a47	18664d65-3906-58e7-91fd-d67ffedd1b64	06f6bf38-0173-52de-aa5b-77d565741cb1	2026-06-16	03:45:00	Discovery workshop — Retail Insights	2026-06-16 09:01:00+00	2026-06-16 09:01:00+00	\N	RI-171	3030e191-44de-5909-b035-5fe3679b482a	Active	Worklog
77f7400e-d129-5cf5-aefd-ede996506f68	62445afe-3364-5e78-b55e-fb5429807a47	18664d65-3906-58e7-91fd-d67ffedd1b64	f04245fa-9e0e-5905-80fa-524e9f1e172f	2026-06-18	01:45:00	Discovery workshop — Delivery Operations Hub	2026-06-18 09:01:00+00	2026-06-18 09:01:00+00	\N	DOH-145	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
ee6144a9-b98f-558d-9d9a-0c6dc8576106	62445afe-3364-5e78-b55e-fb5429807a47	18664d65-3906-58e7-91fd-d67ffedd1b64	a7906be2-315f-5b5e-b344-ac119fd04d1a	2026-06-22	03:45:00	Discovery workshop — Omnichannel Checkout	2026-06-22 09:01:00+00	2026-06-22 09:01:00+00	\N	OC-119	3030e191-44de-5909-b035-5fe3679b482a	Active	Worklog
085c9037-b729-5ffc-a741-83805cb3f9d4	62445afe-3364-5e78-b55e-fb5429807a47	18664d65-3906-58e7-91fd-d67ffedd1b64	06f6bf38-0173-52de-aa5b-77d565741cb1	2026-06-24	01:45:00	Discovery workshop — Retail Insights	2026-06-24 09:01:00+00	2026-06-24 09:01:00+00	\N	RI-166	3030e191-44de-5909-b035-5fe3679b482a	Active	Worklog
69da7fe7-4b57-588c-9c4d-62a08698ada1	62445afe-3364-5e78-b55e-fb5429807a47	18664d65-3906-58e7-91fd-d67ffedd1b64	06f6bf38-0173-52de-aa5b-77d565741cb1	2026-06-25	00:00:00	Blocker integracji wymaga odpowiedzi partnera — Retail Insights	2026-06-25 09:01:00+00	2026-06-25 09:01:00+00	\N	\N	3030e191-44de-5909-b035-5fe3679b482a	Active	Note
8330a241-43a2-5611-bef9-d6a5bdd76702	62445afe-3364-5e78-b55e-fb5429807a47	18664d65-3906-58e7-91fd-d67ffedd1b64	f04245fa-9e0e-5905-80fa-524e9f1e172f	2026-06-26	03:45:00	Discovery workshop — Delivery Operations Hub	2026-06-26 09:01:00+00	2026-06-26 09:01:00+00	\N	DOH-140	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
a2575f80-e1e4-50a7-8013-8d596e172be2	62445afe-3364-5e78-b55e-fb5429807a47	18664d65-3906-58e7-91fd-d67ffedd1b64	a7906be2-315f-5b5e-b344-ac119fd04d1a	2026-06-29	01:45:00	Discovery workshop — Omnichannel Checkout	2026-06-29 09:01:00+00	2026-06-29 09:01:00+00	\N	OC-114	3030e191-44de-5909-b035-5fe3679b482a	Active	Worklog
412f0972-6658-5416-9fe1-60bf78d76d4f	62445afe-3364-5e78-b55e-fb5429807a47	18664d65-3906-58e7-91fd-d67ffedd1b64	06f6bf38-0173-52de-aa5b-77d565741cb1	2026-07-01	03:45:00	Discovery workshop — Retail Insights	2026-07-01 09:01:00+00	2026-07-01 09:01:00+00	\N	RI-161	3030e191-44de-5909-b035-5fe3679b482a	Active	Worklog
3426994e-1df0-5e75-b867-63f4fdea26e6	62445afe-3364-5e78-b55e-fb5429807a47	18664d65-3906-58e7-91fd-d67ffedd1b64	a7906be2-315f-5b5e-b344-ac119fd04d1a	2026-07-02	00:15:00	Discovery workshop — Omnichannel Checkout	2026-07-02 09:01:00+00	2026-07-02 09:01:00+00	\N	OC-107	3030e191-44de-5909-b035-5fe3679b482a	Active	Worklog
d5fa3a05-e085-5d7f-8d89-8634ee9b66dc	62445afe-3364-5e78-b55e-fb5429807a47	18664d65-3906-58e7-91fd-d67ffedd1b64	3d5d3faf-2bbd-5bca-ac00-1c6056bf7ca6	2026-07-02	03:15:00	Historical delivery wrap-up — Dispatch Optimizer	2026-07-02 09:02:00+00	2026-07-02 09:02:00+00	2026-07-13 00:00:00+00	DOP-904	141122b1-9a71-570d-a44c-efc88209be99	Archived	Worklog
562e9e0a-9a24-5be2-9f2b-8592c4534e78	62445afe-3364-5e78-b55e-fb5429807a47	18664d65-3906-58e7-91fd-d67ffedd1b64	f04245fa-9e0e-5905-80fa-524e9f1e172f	2026-07-03	01:45:00	Discovery workshop — Delivery Operations Hub	2026-07-03 09:01:00+00	2026-07-03 09:01:00+00	\N	DOH-135	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
0d4ca68a-a9fb-535a-9d1d-f2d284be50a1	62445afe-3364-5e78-b55e-fb5429807a47	18664d65-3906-58e7-91fd-d67ffedd1b64	3d5d3faf-2bbd-5bca-ac00-1c6056bf7ca6	2026-07-05	02:45:00	Historical delivery wrap-up — Dispatch Optimizer	2026-07-05 09:01:00+00	2026-07-05 09:01:00+00	2026-07-13 00:00:00+00	DOP-922	141122b1-9a71-570d-a44c-efc88209be99	Archived	Worklog
c28370f4-7233-50c2-a78f-b94a5c682cd9	62445afe-3364-5e78-b55e-fb5429807a47	18664d65-3906-58e7-91fd-d67ffedd1b64	06f6bf38-0173-52de-aa5b-77d565741cb1	2026-07-06	02:15:00	Discovery workshop — Retail Insights	2026-07-06 09:01:00+00	2026-07-06 09:01:00+00	\N	RI-154	3030e191-44de-5909-b035-5fe3679b482a	Active	Worklog
8a48dc86-5581-5425-b7f3-9c09851d8c4f	62445afe-3364-5e78-b55e-fb5429807a47	18664d65-3906-58e7-91fd-d67ffedd1b64	f04245fa-9e0e-5905-80fa-524e9f1e172f	2026-07-08	00:15:00	Discovery workshop — Delivery Operations Hub	2026-07-08 09:01:00+00	2026-07-08 09:01:00+00	\N	DOH-128	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
dc98cdba-ba89-5057-8d2e-efb8c4816e1a	62445afe-3364-5e78-b55e-fb5429807a47	18664d65-3906-58e7-91fd-d67ffedd1b64	3d5d3faf-2bbd-5bca-ac00-1c6056bf7ca6	2026-07-08	02:15:00	Historical delivery wrap-up — Dispatch Optimizer	2026-07-08 09:02:00+00	2026-07-08 09:02:00+00	2026-07-13 00:00:00+00	DOP-940	141122b1-9a71-570d-a44c-efc88209be99	Archived	Worklog
d312e8eb-2012-5c13-8878-d35485fadd8b	62445afe-3364-5e78-b55e-fb5429807a47	18664d65-3906-58e7-91fd-d67ffedd1b64	a7906be2-315f-5b5e-b344-ac119fd04d1a	2026-07-10	02:15:00	Discovery workshop — Omnichannel Checkout	2026-07-10 09:01:00+00	2026-07-10 09:01:00+00	\N	OC-102	3030e191-44de-5909-b035-5fe3679b482a	Active	Worklog
c492fc45-34dd-5b4d-8d80-1d1d011ae791	62445afe-3364-5e78-b55e-fb5429807a47	18664d65-3906-58e7-91fd-d67ffedd1b64	3d5d3faf-2bbd-5bca-ac00-1c6056bf7ca6	2026-07-11	01:45:00	Historical delivery wrap-up — Dispatch Optimizer	2026-07-11 09:01:00+00	2026-07-11 09:01:00+00	2026-07-13 00:00:00+00	DOP-958	141122b1-9a71-570d-a44c-efc88209be99	Archived	Worklog
490a6197-10de-5217-b587-6cb43566f0cd	62445afe-3364-5e78-b55e-fb5429807a47	18664d65-3906-58e7-91fd-d67ffedd1b64	06f6bf38-0173-52de-aa5b-77d565741cb1	2026-07-13	00:15:00	Discovery workshop — Retail Insights	2026-07-13 09:01:00+00	2026-07-13 09:01:00+00	\N	RI-149	3030e191-44de-5909-b035-5fe3679b482a	Active	Worklog
a6350682-ceb7-5aa3-9855-3233da1fd1f9	62445afe-3364-5e78-b55e-fb5429807a47	18664d65-3906-58e7-91fd-d67ffedd1b64	f04245fa-9e0e-5905-80fa-524e9f1e172f	2026-07-15	02:15:00	Discovery workshop — Delivery Operations Hub	2026-07-15 09:01:00+00	2026-07-15 09:01:00+00	\N	DOH-123	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
9ee6c2db-f114-544c-9368-e0a7342ca67d	62445afe-3364-5e78-b55e-fb5429807a47	18664d65-3906-58e7-91fd-d67ffedd1b64	f04245fa-9e0e-5905-80fa-524e9f1e172f	2026-07-16	00:00:00	Blocker integracji wymaga odpowiedzi partnera — Delivery Operations Hub	2026-07-16 09:01:00+00	2026-07-16 09:01:00+00	\N	\N	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Note
684d39c6-0ce7-5ae7-8303-85ea7bbe8bfb	62445afe-3364-5e78-b55e-fb5429807a47	18664d65-3906-58e7-91fd-d67ffedd1b64	a7906be2-315f-5b5e-b344-ac119fd04d1a	2026-07-17	00:15:00	Discovery workshop — Omnichannel Checkout	2026-07-17 09:01:00+00	2026-07-17 09:01:00+00	\N	OC-170	3030e191-44de-5909-b035-5fe3679b482a	Active	Worklog
9c849b30-ffe1-57e2-a581-3929d1eb46d9	62445afe-3364-5e78-b55e-fb5429807a47	18664d65-3906-58e7-91fd-d67ffedd1b64	06f6bf38-0173-52de-aa5b-77d565741cb1	2026-07-21	02:15:00	Discovery workshop — Retail Insights	2026-07-21 09:01:00+00	2026-07-21 09:01:00+00	\N	RI-144	3030e191-44de-5909-b035-5fe3679b482a	Active	Worklog
6dfcd25a-baf6-5e29-b37c-fe2b08070966	62445afe-3364-5e78-b55e-fb5429807a47	18664d65-3906-58e7-91fd-d67ffedd1b64	f04245fa-9e0e-5905-80fa-524e9f1e172f	2026-07-23	00:15:00	Discovery workshop — Delivery Operations Hub	2026-07-23 09:01:00+00	2026-07-23 09:01:00+00	\N	DOH-118	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
6add695c-614d-5704-8cba-f56cf08c8f6f	62445afe-3364-5e78-b55e-fb5429807a47	18664d65-3906-58e7-91fd-d67ffedd1b64	06f6bf38-0173-52de-aa5b-77d565741cb1	2026-07-24	00:45:00	Discovery workshop — Retail Insights	2026-07-24 09:01:00+00	2026-07-24 09:01:00+00	\N	RI-137	3030e191-44de-5909-b035-5fe3679b482a	Active	Worklog
cfed74c7-3920-5810-8ea6-7b29fc16654a	62445afe-3364-5e78-b55e-fb5429807a47	18664d65-3906-58e7-91fd-d67ffedd1b64	a7906be2-315f-5b5e-b344-ac119fd04d1a	2026-07-26	02:15:00	Discovery workshop — Omnichannel Checkout	2026-07-26 09:01:00+00	2026-07-26 09:01:00+00	\N	OC-165	3030e191-44de-5909-b035-5fe3679b482a	Active	Worklog
9227260a-7e87-5443-bbc4-d188151628e2	62445afe-3364-5e78-b55e-fb5429807a47	18664d65-3906-58e7-91fd-d67ffedd1b64	f04245fa-9e0e-5905-80fa-524e9f1e172f	2026-07-27	02:45:00	Discovery workshop — Delivery Operations Hub	2026-07-27 09:01:00+00	2026-07-27 09:01:00+00	\N	DOH-111	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
fec37584-9ed6-56ef-b0d4-6f39d2e89b33	62445afe-3364-5e78-b55e-fb5429807a47	18664d65-3906-58e7-91fd-d67ffedd1b64	a7906be2-315f-5b5e-b344-ac119fd04d1a	2026-07-29	00:45:00	Discovery workshop — Omnichannel Checkout	2026-07-29 09:01:00+00	2026-07-29 09:01:00+00	\N	OC-158	3030e191-44de-5909-b035-5fe3679b482a	Active	Worklog
61965cf9-33fe-5d74-8ba0-0fb3e434cfeb	62445afe-3364-5e78-b55e-fb5429807a47	18664d65-3906-58e7-91fd-d67ffedd1b64	06f6bf38-0173-52de-aa5b-77d565741cb1	2026-07-31	02:45:00	Discovery workshop — Retail Insights	2026-07-31 09:01:00+00	2026-07-31 09:01:00+00	\N	RI-132	3030e191-44de-5909-b035-5fe3679b482a	Active	Worklog
3eb40b7e-cf2c-5ff8-b0eb-e47ea88ff411	62445afe-3364-5e78-b55e-fb5429807a47	18664d65-3906-58e7-91fd-d67ffedd1b64	f04245fa-9e0e-5905-80fa-524e9f1e172f	2026-08-04	00:45:00	Discovery workshop — Delivery Operations Hub	2026-08-04 09:01:00+00	2026-08-04 09:01:00+00	\N	DOH-106	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
aea26d65-661a-5adc-9fdc-d51c855a0e3f	62445afe-3364-5e78-b55e-fb5429807a47	18664d65-3906-58e7-91fd-d67ffedd1b64	a7906be2-315f-5b5e-b344-ac119fd04d1a	2026-08-06	02:45:00	Discovery workshop — Omnichannel Checkout	2026-08-06 09:01:00+00	2026-08-06 09:01:00+00	\N	OC-153	3030e191-44de-5909-b035-5fe3679b482a	Active	Worklog
ae2f0058-cef8-5db7-91ea-18719e641b86	62445afe-3364-5e78-b55e-fb5429807a47	18664d65-3906-58e7-91fd-d67ffedd1b64	06f6bf38-0173-52de-aa5b-77d565741cb1	2026-08-09	00:45:00	Discovery workshop — Retail Insights	2026-08-09 09:01:00+00	2026-08-09 09:01:00+00	\N	RI-127	3030e191-44de-5909-b035-5fe3679b482a	Active	Worklog
b4b09a44-a716-52b2-bf73-bcb33633712f	62445afe-3364-5e78-b55e-fb5429807a47	18664d65-3906-58e7-91fd-d67ffedd1b64	f04245fa-9e0e-5905-80fa-524e9f1e172f	2026-08-11	02:45:00	Discovery workshop — Delivery Operations Hub	2026-08-11 09:01:00+00	2026-08-11 09:01:00+00	\N	DOH-101	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
9db876ae-0040-5644-990b-19ffdcdccb28	62445afe-3364-5e78-b55e-fb5429807a47	68e81bc4-dc44-5a60-b522-6f6909339289	1146e928-4d82-581f-84f2-b8c9b6c83378	2026-05-20	03:30:00	Implementation and pairing — Learning Experience	2026-05-20 09:01:00+00	2026-05-20 09:01:00+00	\N	LE-111	a9e0bb14-488c-5643-96ca-5848796322a3	Active	Worklog
ed38d3c0-8afc-58b5-9802-5d3b59b9d3f5	62445afe-3364-5e78-b55e-fb5429807a47	68e81bc4-dc44-5a60-b522-6f6909339289	9406b74a-6b7a-578b-8fbd-958684d93780	2026-05-21	01:00:00	Implementation and pairing — Patient Portal	2026-05-21 09:01:00+00	2026-05-21 09:01:00+00	\N	PP-139	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
72127fc5-3481-5f36-88e8-59bddfd27791	62445afe-3364-5e78-b55e-fb5429807a47	68e81bc4-dc44-5a60-b522-6f6909339289	b8cd683c-fe4d-538c-bdaf-68c28e1e14ef	2026-05-22	01:30:00	Implementation and pairing — Time Intelligence	2026-05-22 09:01:00+00	2026-05-22 09:01:00+00	\N	TI-158	d677a650-2c23-5c0c-9f53-920636bd318e	Active	Worklog
9d468068-9069-5f98-a049-efdb68fa9619	62445afe-3364-5e78-b55e-fb5429807a47	68e81bc4-dc44-5a60-b522-6f6909339289	1146e928-4d82-581f-84f2-b8c9b6c83378	2026-05-25	03:00:00	Implementation and pairing — Learning Experience	2026-05-25 09:01:00+00	2026-05-25 09:01:00+00	\N	LE-113	a9e0bb14-488c-5643-96ca-5848796322a3	Active	Worklog
10136166-ccd3-5695-a017-9b0d4614694f	62445afe-3364-5e78-b55e-fb5429807a47	68e81bc4-dc44-5a60-b522-6f6909339289	9406b74a-6b7a-578b-8fbd-958684d93780	2026-05-26	03:30:00	Implementation and pairing — Patient Portal	2026-05-26 09:01:00+00	2026-05-26 09:01:00+00	\N	PP-132	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
b9bef059-b547-5655-ac88-c900225a1c87	62445afe-3364-5e78-b55e-fb5429807a47	68e81bc4-dc44-5a60-b522-6f6909339289	1146e928-4d82-581f-84f2-b8c9b6c83378	2026-05-28	01:30:00	Implementation and pairing — Learning Experience	2026-05-28 09:01:00+00	2026-05-28 09:01:00+00	\N	LE-106	a9e0bb14-488c-5643-96ca-5848796322a3	Active	Worklog
edb860b7-ce98-53cc-be7f-b94e6cf81141	62445afe-3364-5e78-b55e-fb5429807a47	68e81bc4-dc44-5a60-b522-6f6909339289	b8cd683c-fe4d-538c-bdaf-68c28e1e14ef	2026-05-31	03:30:00	Implementation and pairing — Time Intelligence	2026-05-31 09:01:00+00	2026-05-31 09:01:00+00	\N	TI-153	d677a650-2c23-5c0c-9f53-920636bd318e	Active	Worklog
d1994200-7dfe-5869-9bea-45d1031722d7	62445afe-3364-5e78-b55e-fb5429807a47	68e81bc4-dc44-5a60-b522-6f6909339289	9406b74a-6b7a-578b-8fbd-958684d93780	2026-06-02	01:30:00	Implementation and pairing — Patient Portal	2026-06-02 09:01:00+00	2026-06-02 09:01:00+00	\N	PP-127	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
8185e7a3-932d-5822-9d34-a99879ab714d	62445afe-3364-5e78-b55e-fb5429807a47	68e81bc4-dc44-5a60-b522-6f6909339289	9406b74a-6b7a-578b-8fbd-958684d93780	2026-06-03	00:00:00	Ryzyko release omówione i przypisane — Patient Portal	2026-06-03 09:01:00+00	2026-06-03 09:01:00+00	\N	\N	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Note
9d0771bc-9b08-55af-8855-e1cd16e7206d	62445afe-3364-5e78-b55e-fb5429807a47	68e81bc4-dc44-5a60-b522-6f6909339289	1146e928-4d82-581f-84f2-b8c9b6c83378	2026-06-04	03:30:00	Implementation and pairing — Learning Experience	2026-06-04 09:01:00+00	2026-06-04 09:01:00+00	\N	LE-101	a9e0bb14-488c-5643-96ca-5848796322a3	Active	Worklog
90c754b2-147c-5e6a-a3d6-1269f3b06891	62445afe-3364-5e78-b55e-fb5429807a47	68e81bc4-dc44-5a60-b522-6f6909339289	b8cd683c-fe4d-538c-bdaf-68c28e1e14ef	2026-06-08	01:30:00	Implementation and pairing — Time Intelligence	2026-06-08 09:01:00+00	2026-06-08 09:01:00+00	\N	TI-148	d677a650-2c23-5c0c-9f53-920636bd318e	Active	Worklog
dca37756-fb92-526f-a0e6-4d92dfe38bb3	62445afe-3364-5e78-b55e-fb5429807a47	68e81bc4-dc44-5a60-b522-6f6909339289	9406b74a-6b7a-578b-8fbd-958684d93780	2026-06-10	03:30:00	Implementation and pairing — Patient Portal	2026-06-10 09:01:00+00	2026-06-10 09:01:00+00	\N	PP-122	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
0e44c031-cf40-5d5e-ad4f-596718a61379	62445afe-3364-5e78-b55e-fb5429807a47	68e81bc4-dc44-5a60-b522-6f6909339289	b8cd683c-fe4d-538c-bdaf-68c28e1e14ef	2026-06-11	04:00:00	Implementation and pairing — Time Intelligence	2026-06-11 09:01:00+00	2026-06-11 09:01:00+00	\N	TI-141	d677a650-2c23-5c0c-9f53-920636bd318e	Active	Worklog
729f3791-a412-5bfe-85e2-a7b5b1dbf406	62445afe-3364-5e78-b55e-fb5429807a47	68e81bc4-dc44-5a60-b522-6f6909339289	1146e928-4d82-581f-84f2-b8c9b6c83378	2026-06-12	01:30:00	Implementation and pairing — Learning Experience	2026-06-12 09:01:00+00	2026-06-12 09:01:00+00	\N	LE-169	a9e0bb14-488c-5643-96ca-5848796322a3	Active	Worklog
263e4e20-1463-5c5c-9d48-551119269dc9	62445afe-3364-5e78-b55e-fb5429807a47	68e81bc4-dc44-5a60-b522-6f6909339289	9406b74a-6b7a-578b-8fbd-958684d93780	2026-06-14	02:00:00	Implementation and pairing — Patient Portal	2026-06-14 09:01:00+00	2026-06-14 09:01:00+00	\N	PP-115	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
f4621ef8-b73e-5dca-9c63-43865b102f53	62445afe-3364-5e78-b55e-fb5429807a47	68e81bc4-dc44-5a60-b522-6f6909339289	1146e928-4d82-581f-84f2-b8c9b6c83378	2026-06-16	04:00:00	Implementation and pairing — Learning Experience	2026-06-16 09:01:00+00	2026-06-16 09:01:00+00	\N	LE-162	a9e0bb14-488c-5643-96ca-5848796322a3	Active	Worklog
088d27d9-2c1e-521e-9655-4ddc7e042fa2	62445afe-3364-5e78-b55e-fb5429807a47	68e81bc4-dc44-5a60-b522-6f6909339289	b8cd683c-fe4d-538c-bdaf-68c28e1e14ef	2026-06-18	02:00:00	Implementation and pairing — Time Intelligence	2026-06-18 09:01:00+00	2026-06-18 09:01:00+00	\N	TI-136	d677a650-2c23-5c0c-9f53-920636bd318e	Active	Worklog
8635dc37-0d9f-5df8-badd-f3772bd8c701	62445afe-3364-5e78-b55e-fb5429807a47	68e81bc4-dc44-5a60-b522-6f6909339289	9406b74a-6b7a-578b-8fbd-958684d93780	2026-06-22	04:00:00	Implementation and pairing — Patient Portal	2026-06-22 09:01:00+00	2026-06-22 09:01:00+00	\N	PP-110	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
2317f14b-48d0-541a-8b63-65f9fa00b0c6	62445afe-3364-5e78-b55e-fb5429807a47	68e81bc4-dc44-5a60-b522-6f6909339289	1146e928-4d82-581f-84f2-b8c9b6c83378	2026-06-24	02:00:00	Implementation and pairing — Learning Experience	2026-06-24 09:01:00+00	2026-06-24 09:01:00+00	\N	LE-157	a9e0bb14-488c-5643-96ca-5848796322a3	Active	Worklog
963e997d-d18e-5b38-a182-93e1f262a452	62445afe-3364-5e78-b55e-fb5429807a47	68e81bc4-dc44-5a60-b522-6f6909339289	1146e928-4d82-581f-84f2-b8c9b6c83378	2026-06-25	00:00:00	Ryzyko release omówione i przypisane — Learning Experience	2026-06-25 09:01:00+00	2026-06-25 09:01:00+00	\N	\N	a9e0bb14-488c-5643-96ca-5848796322a3	Active	Note
6c7d6d1e-0994-5a12-a3d6-9616cab5c60e	62445afe-3364-5e78-b55e-fb5429807a47	68e81bc4-dc44-5a60-b522-6f6909339289	b8cd683c-fe4d-538c-bdaf-68c28e1e14ef	2026-06-26	04:00:00	Implementation and pairing — Time Intelligence	2026-06-26 09:01:00+00	2026-06-26 09:01:00+00	\N	TI-131	d677a650-2c23-5c0c-9f53-920636bd318e	Active	Worklog
8847a859-d4bd-5d89-b109-ec40166fa35e	62445afe-3364-5e78-b55e-fb5429807a47	68e81bc4-dc44-5a60-b522-6f6909339289	613fe369-ab85-5812-9136-0d147b91706d	2026-06-28	00:15:00	Historical delivery wrap-up — Mobility Discovery	2026-06-28 09:01:00+00	2026-06-28 09:01:00+00	2026-07-13 00:00:00+00	MD-900	eba17d28-b076-534c-918a-dca0a5be8fab	Archived	Worklog
61ecb758-3e7c-5e0e-b340-8f5a00eb2f60	62445afe-3364-5e78-b55e-fb5429807a47	68e81bc4-dc44-5a60-b522-6f6909339289	9406b74a-6b7a-578b-8fbd-958684d93780	2026-06-29	02:00:00	Implementation and pairing — Patient Portal	2026-06-29 09:01:00+00	2026-06-29 09:01:00+00	\N	PP-105	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
e15886b4-1865-5f8b-b867-a6255745d9de	62445afe-3364-5e78-b55e-fb5429807a47	68e81bc4-dc44-5a60-b522-6f6909339289	1146e928-4d82-581f-84f2-b8c9b6c83378	2026-07-01	04:00:00	Implementation and pairing — Learning Experience	2026-07-01 09:01:00+00	2026-07-01 09:01:00+00	\N	LE-152	a9e0bb14-488c-5643-96ca-5848796322a3	Active	Worklog
2dde6c66-2781-5f8a-85fe-a9c50e2f4e76	62445afe-3364-5e78-b55e-fb5429807a47	68e81bc4-dc44-5a60-b522-6f6909339289	613fe369-ab85-5812-9136-0d147b91706d	2026-07-01	00:15:00	Historical delivery wrap-up — Mobility Discovery	2026-07-01 09:02:00+00	2026-07-01 09:02:00+00	2026-07-13 00:00:00+00	MD-948	eba17d28-b076-534c-918a-dca0a5be8fab	Archived	Worklog
0a0927a0-c740-58d8-8226-52c9581a1cea	62445afe-3364-5e78-b55e-fb5429807a47	68e81bc4-dc44-5a60-b522-6f6909339289	9406b74a-6b7a-578b-8fbd-958684d93780	2026-07-02	00:30:00	Implementation and pairing — Patient Portal	2026-07-02 09:01:00+00	2026-07-02 09:01:00+00	\N	PP-171	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
2564223e-8422-591f-98bf-0da77d4bb433	62445afe-3364-5e78-b55e-fb5429807a47	68e81bc4-dc44-5a60-b522-6f6909339289	b8cd683c-fe4d-538c-bdaf-68c28e1e14ef	2026-07-03	02:00:00	Implementation and pairing — Time Intelligence	2026-07-03 09:01:00+00	2026-07-03 09:01:00+00	\N	TI-126	d677a650-2c23-5c0c-9f53-920636bd318e	Active	Worklog
a363a1a2-b539-5f0c-b3c3-1dbaa5a255d3	62445afe-3364-5e78-b55e-fb5429807a47	68e81bc4-dc44-5a60-b522-6f6909339289	613fe369-ab85-5812-9136-0d147b91706d	2026-07-04	03:15:00	Historical delivery wrap-up — Mobility Discovery	2026-07-04 09:01:00+00	2026-07-04 09:01:00+00	2026-07-13 00:00:00+00	MD-936	eba17d28-b076-534c-918a-dca0a5be8fab	Archived	Worklog
15487839-081a-598a-b9d8-f5bd159cb78d	62445afe-3364-5e78-b55e-fb5429807a47	68e81bc4-dc44-5a60-b522-6f6909339289	1146e928-4d82-581f-84f2-b8c9b6c83378	2026-07-06	02:30:00	Implementation and pairing — Learning Experience	2026-07-06 09:01:00+00	2026-07-06 09:01:00+00	\N	LE-145	a9e0bb14-488c-5643-96ca-5848796322a3	Active	Worklog
cbaa11ab-deb6-5b2e-9820-ca805f1e7ccc	62445afe-3364-5e78-b55e-fb5429807a47	68e81bc4-dc44-5a60-b522-6f6909339289	613fe369-ab85-5812-9136-0d147b91706d	2026-07-07	02:15:00	Historical delivery wrap-up — Mobility Discovery	2026-07-07 09:01:00+00	2026-07-07 09:01:00+00	2026-07-13 00:00:00+00	MD-924	eba17d28-b076-534c-918a-dca0a5be8fab	Archived	Worklog
0acbd692-eb16-5443-8118-a9c9be173156	62445afe-3364-5e78-b55e-fb5429807a47	68e81bc4-dc44-5a60-b522-6f6909339289	b8cd683c-fe4d-538c-bdaf-68c28e1e14ef	2026-07-08	00:30:00	Implementation and pairing — Time Intelligence	2026-07-08 09:01:00+00	2026-07-08 09:01:00+00	\N	TI-119	d677a650-2c23-5c0c-9f53-920636bd318e	Active	Worklog
21282ceb-dad9-5628-8ea4-2044e6a3d37f	62445afe-3364-5e78-b55e-fb5429807a47	68e81bc4-dc44-5a60-b522-6f6909339289	9406b74a-6b7a-578b-8fbd-958684d93780	2026-07-10	02:30:00	Implementation and pairing — Patient Portal	2026-07-10 09:01:00+00	2026-07-10 09:01:00+00	\N	PP-166	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
1b930de7-c594-50fc-94eb-ba8cd8998898	62445afe-3364-5e78-b55e-fb5429807a47	68e81bc4-dc44-5a60-b522-6f6909339289	613fe369-ab85-5812-9136-0d147b91706d	2026-07-10	01:15:00	Historical delivery wrap-up — Mobility Discovery	2026-07-10 09:02:00+00	2026-07-10 09:02:00+00	2026-07-13 00:00:00+00	MD-912	eba17d28-b076-534c-918a-dca0a5be8fab	Archived	Worklog
2e5bafc6-4d8e-5e10-afd7-5bf969dcc458	62445afe-3364-5e78-b55e-fb5429807a47	68e81bc4-dc44-5a60-b522-6f6909339289	1146e928-4d82-581f-84f2-b8c9b6c83378	2026-07-13	00:30:00	Implementation and pairing — Learning Experience	2026-07-13 09:01:00+00	2026-07-13 09:01:00+00	\N	LE-140	a9e0bb14-488c-5643-96ca-5848796322a3	Active	Worklog
7b72d1cb-ef05-574a-abb2-e05fff64eb21	62445afe-3364-5e78-b55e-fb5429807a47	68e81bc4-dc44-5a60-b522-6f6909339289	b8cd683c-fe4d-538c-bdaf-68c28e1e14ef	2026-07-15	02:30:00	Implementation and pairing — Time Intelligence	2026-07-15 09:01:00+00	2026-07-15 09:01:00+00	\N	TI-114	d677a650-2c23-5c0c-9f53-920636bd318e	Active	Worklog
b09a9457-27b4-592f-8c48-1be390fd532a	62445afe-3364-5e78-b55e-fb5429807a47	68e81bc4-dc44-5a60-b522-6f6909339289	b8cd683c-fe4d-538c-bdaf-68c28e1e14ef	2026-07-16	00:00:00	Ryzyko release omówione i przypisane — Time Intelligence	2026-07-16 09:01:00+00	2026-07-16 09:01:00+00	\N	\N	d677a650-2c23-5c0c-9f53-920636bd318e	Active	Note
39205a91-ad06-502c-ae60-ef3dd97bb4a1	62445afe-3364-5e78-b55e-fb5429807a47	68e81bc4-dc44-5a60-b522-6f6909339289	9406b74a-6b7a-578b-8fbd-958684d93780	2026-07-17	00:30:00	Implementation and pairing — Patient Portal	2026-07-17 09:01:00+00	2026-07-17 09:01:00+00	\N	PP-161	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
36ade524-ce02-50d0-9486-fcba53689b28	62445afe-3364-5e78-b55e-fb5429807a47	68e81bc4-dc44-5a60-b522-6f6909339289	1146e928-4d82-581f-84f2-b8c9b6c83378	2026-07-21	02:30:00	Implementation and pairing — Learning Experience	2026-07-21 09:01:00+00	2026-07-21 09:01:00+00	\N	LE-135	a9e0bb14-488c-5643-96ca-5848796322a3	Active	Worklog
38d020e1-28ef-5e89-8437-f2d4e7a7b806	62445afe-3364-5e78-b55e-fb5429807a47	68e81bc4-dc44-5a60-b522-6f6909339289	b8cd683c-fe4d-538c-bdaf-68c28e1e14ef	2026-07-23	00:30:00	Implementation and pairing — Time Intelligence	2026-07-23 09:01:00+00	2026-07-23 09:01:00+00	\N	TI-109	d677a650-2c23-5c0c-9f53-920636bd318e	Active	Worklog
933c9f10-9e45-5159-9abc-d823765cd439	62445afe-3364-5e78-b55e-fb5429807a47	68e81bc4-dc44-5a60-b522-6f6909339289	1146e928-4d82-581f-84f2-b8c9b6c83378	2026-07-24	01:00:00	Implementation and pairing — Learning Experience	2026-07-24 09:01:00+00	2026-07-24 09:01:00+00	\N	LE-128	a9e0bb14-488c-5643-96ca-5848796322a3	Active	Worklog
f4387f6e-7025-5408-8485-cc4adaaa4132	62445afe-3364-5e78-b55e-fb5429807a47	68e81bc4-dc44-5a60-b522-6f6909339289	9406b74a-6b7a-578b-8fbd-958684d93780	2026-07-26	02:30:00	Implementation and pairing — Patient Portal	2026-07-26 09:01:00+00	2026-07-26 09:01:00+00	\N	PP-156	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
949255ca-f867-54c7-bf91-e97dbf664917	62445afe-3364-5e78-b55e-fb5429807a47	68e81bc4-dc44-5a60-b522-6f6909339289	b8cd683c-fe4d-538c-bdaf-68c28e1e14ef	2026-07-27	03:00:00	Implementation and pairing — Time Intelligence	2026-07-27 09:01:00+00	2026-07-27 09:01:00+00	\N	TI-102	d677a650-2c23-5c0c-9f53-920636bd318e	Active	Worklog
1ee8af81-bf22-504d-bbe2-87b4f181ef49	62445afe-3364-5e78-b55e-fb5429807a47	68e81bc4-dc44-5a60-b522-6f6909339289	9406b74a-6b7a-578b-8fbd-958684d93780	2026-07-29	01:00:00	Implementation and pairing — Patient Portal	2026-07-29 09:01:00+00	2026-07-29 09:01:00+00	\N	PP-149	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
95e5b1ee-7f9e-5ad5-9958-3d3facc1deb8	62445afe-3364-5e78-b55e-fb5429807a47	68e81bc4-dc44-5a60-b522-6f6909339289	1146e928-4d82-581f-84f2-b8c9b6c83378	2026-07-31	03:00:00	Implementation and pairing — Learning Experience	2026-07-31 09:01:00+00	2026-07-31 09:01:00+00	\N	LE-123	a9e0bb14-488c-5643-96ca-5848796322a3	Active	Worklog
89ee994a-bfbe-5691-bd34-a2ab8ece2c5b	62445afe-3364-5e78-b55e-fb5429807a47	68e81bc4-dc44-5a60-b522-6f6909339289	b8cd683c-fe4d-538c-bdaf-68c28e1e14ef	2026-08-04	01:00:00	Implementation and pairing — Time Intelligence	2026-08-04 09:01:00+00	2026-08-04 09:01:00+00	\N	TI-170	d677a650-2c23-5c0c-9f53-920636bd318e	Active	Worklog
882a81f4-0957-59a8-ae38-7543b44a95d0	62445afe-3364-5e78-b55e-fb5429807a47	68e81bc4-dc44-5a60-b522-6f6909339289	9406b74a-6b7a-578b-8fbd-958684d93780	2026-08-06	03:00:00	Implementation and pairing — Patient Portal	2026-08-06 09:01:00+00	2026-08-06 09:01:00+00	\N	PP-144	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
e405871e-48f1-52af-bf13-198c73648885	62445afe-3364-5e78-b55e-fb5429807a47	68e81bc4-dc44-5a60-b522-6f6909339289	9406b74a-6b7a-578b-8fbd-958684d93780	2026-08-07	00:00:00	Ryzyko release omówione i przypisane — Patient Portal	2026-08-07 09:01:00+00	2026-08-07 09:01:00+00	\N	\N	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Note
1622ef71-805f-5457-bb52-7f5fc1cfc971	62445afe-3364-5e78-b55e-fb5429807a47	68e81bc4-dc44-5a60-b522-6f6909339289	1146e928-4d82-581f-84f2-b8c9b6c83378	2026-08-09	01:00:00	Implementation and pairing — Learning Experience	2026-08-09 09:01:00+00	2026-08-09 09:01:00+00	\N	LE-118	a9e0bb14-488c-5643-96ca-5848796322a3	Active	Worklog
62c39198-132a-5965-9cb3-1f46d0f7295b	62445afe-3364-5e78-b55e-fb5429807a47	68e81bc4-dc44-5a60-b522-6f6909339289	b8cd683c-fe4d-538c-bdaf-68c28e1e14ef	2026-08-11	03:00:00	Implementation and pairing — Time Intelligence	2026-08-11 09:01:00+00	2026-08-11 09:01:00+00	\N	TI-165	d677a650-2c23-5c0c-9f53-920636bd318e	Active	Worklog
80bc2fe8-6bed-5e33-aa01-b5ea912a1134	62445afe-3364-5e78-b55e-fb5429807a47	de529b34-39ac-5368-86e8-1d1076117642	67164958-1bad-5a9c-8d3a-7c4f7dfb7282	2026-05-20	01:30:00	Regression testing — Reporting Sandbox	2026-05-20 09:01:00+00	2026-05-20 09:01:00+00	\N	RS-103	d677a650-2c23-5c0c-9f53-920636bd318e	Active	Worklog
cdd59fbc-0910-591a-9e26-9dd7afb2dcb8	62445afe-3364-5e78-b55e-fb5429807a47	de529b34-39ac-5368-86e8-1d1076117642	eb73aa6c-87aa-532d-8b94-109b8b863733	2026-05-21	03:00:00	Regression testing — Design System Evolution	2026-05-21 09:01:00+00	2026-05-21 09:01:00+00	\N	DSE-131	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
f8406440-f8fa-5610-bb30-6ecc3930e00c	62445afe-3364-5e78-b55e-fb5429807a47	de529b34-39ac-5368-86e8-1d1076117642	67164958-1bad-5a9c-8d3a-7c4f7dfb7282	2026-05-22	03:30:00	Regression testing — Reporting Sandbox	2026-05-22 09:01:00+00	2026-05-22 09:01:00+00	\N	RS-150	d677a650-2c23-5c0c-9f53-920636bd318e	Active	Worklog
ff45e1e4-41f7-5dc7-88e0-b52655fbc518	62445afe-3364-5e78-b55e-fb5429807a47	de529b34-39ac-5368-86e8-1d1076117642	eb73aa6c-87aa-532d-8b94-109b8b863733	2026-05-25	01:00:00	Regression testing — Design System Evolution	2026-05-25 09:01:00+00	2026-05-25 09:01:00+00	\N	DSE-105	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
2cac6f75-a4a3-5379-a16b-9cd829cd6b70	62445afe-3364-5e78-b55e-fb5429807a47	de529b34-39ac-5368-86e8-1d1076117642	67164958-1bad-5a9c-8d3a-7c4f7dfb7282	2026-05-26	01:30:00	Regression testing — Reporting Sandbox	2026-05-26 09:01:00+00	2026-05-26 09:01:00+00	\N	RS-124	d677a650-2c23-5c0c-9f53-920636bd318e	Active	Worklog
ec411673-f73a-57db-a235-e1a191bc4d3b	62445afe-3364-5e78-b55e-fb5429807a47	de529b34-39ac-5368-86e8-1d1076117642	67164958-1bad-5a9c-8d3a-7c4f7dfb7282	2026-05-28	03:30:00	Regression testing — Reporting Sandbox	2026-05-28 09:01:00+00	2026-05-28 09:01:00+00	\N	RS-171	d677a650-2c23-5c0c-9f53-920636bd318e	Active	Worklog
c9556ce4-7ff7-53f5-b501-700bcaf85699	62445afe-3364-5e78-b55e-fb5429807a47	de529b34-39ac-5368-86e8-1d1076117642	67164958-1bad-5a9c-8d3a-7c4f7dfb7282	2026-05-31	01:30:00	Regression testing — Reporting Sandbox	2026-05-31 09:01:00+00	2026-05-31 09:01:00+00	\N	RS-145	d677a650-2c23-5c0c-9f53-920636bd318e	Active	Worklog
3ded46b1-c9aa-515d-9cef-08c683a0180e	62445afe-3364-5e78-b55e-fb5429807a47	de529b34-39ac-5368-86e8-1d1076117642	67164958-1bad-5a9c-8d3a-7c4f7dfb7282	2026-06-02	03:30:00	Regression testing — Reporting Sandbox	2026-06-02 09:01:00+00	2026-06-02 09:01:00+00	\N	RS-119	d677a650-2c23-5c0c-9f53-920636bd318e	Active	Worklog
ee85959e-fbe2-515b-ad28-b324a4770924	62445afe-3364-5e78-b55e-fb5429807a47	de529b34-39ac-5368-86e8-1d1076117642	eb73aa6c-87aa-532d-8b94-109b8b863733	2026-06-03	00:00:00	Planowana nieobecność uwzględniona w harmonogramie — Design System Evolution	2026-06-03 09:01:00+00	2026-06-03 09:01:00+00	\N	\N	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Note
dfeda888-eb28-5f60-b1ad-9d8c5552b16b	62445afe-3364-5e78-b55e-fb5429807a47	de529b34-39ac-5368-86e8-1d1076117642	67164958-1bad-5a9c-8d3a-7c4f7dfb7282	2026-06-04	01:30:00	Regression testing — Reporting Sandbox	2026-06-04 09:01:00+00	2026-06-04 09:01:00+00	\N	RS-166	d677a650-2c23-5c0c-9f53-920636bd318e	Active	Worklog
8fd67675-d219-5502-a2ec-4d5e71f0d5e5	62445afe-3364-5e78-b55e-fb5429807a47	de529b34-39ac-5368-86e8-1d1076117642	67164958-1bad-5a9c-8d3a-7c4f7dfb7282	2026-06-08	03:30:00	Regression testing — Reporting Sandbox	2026-06-08 09:01:00+00	2026-06-08 09:01:00+00	\N	RS-140	d677a650-2c23-5c0c-9f53-920636bd318e	Active	Worklog
40732eba-ce70-5241-af11-bff065783662	62445afe-3364-5e78-b55e-fb5429807a47	de529b34-39ac-5368-86e8-1d1076117642	67164958-1bad-5a9c-8d3a-7c4f7dfb7282	2026-06-10	01:30:00	Regression testing — Reporting Sandbox	2026-06-10 09:01:00+00	2026-06-10 09:01:00+00	\N	RS-114	d677a650-2c23-5c0c-9f53-920636bd318e	Active	Worklog
f5cdb2f7-6fc2-5a76-90de-3b6b66adc024	62445afe-3364-5e78-b55e-fb5429807a47	de529b34-39ac-5368-86e8-1d1076117642	eb73aa6c-87aa-532d-8b94-109b8b863733	2026-06-11	02:00:00	Regression testing — Design System Evolution	2026-06-11 09:01:00+00	2026-06-11 09:01:00+00	\N	DSE-133	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
63b24a48-4a1b-582e-99ef-32d5e405311b	62445afe-3364-5e78-b55e-fb5429807a47	de529b34-39ac-5368-86e8-1d1076117642	67164958-1bad-5a9c-8d3a-7c4f7dfb7282	2026-06-12	03:30:00	Regression testing — Reporting Sandbox	2026-06-12 09:01:00+00	2026-06-12 09:01:00+00	\N	RS-161	d677a650-2c23-5c0c-9f53-920636bd318e	Active	Worklog
fdfc09c4-5918-56de-b00f-66f6e302d4ba	62445afe-3364-5e78-b55e-fb5429807a47	de529b34-39ac-5368-86e8-1d1076117642	eb73aa6c-87aa-532d-8b94-109b8b863733	2026-06-14	04:00:00	Regression testing — Design System Evolution	2026-06-14 09:01:00+00	2026-06-14 09:01:00+00	\N	DSE-107	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
520ffd1f-32a6-5410-b971-a6d5ffd0599c	62445afe-3364-5e78-b55e-fb5429807a47	de529b34-39ac-5368-86e8-1d1076117642	eb73aa6c-87aa-532d-8b94-109b8b863733	2026-06-16	02:00:00	Regression testing — Design System Evolution	2026-06-16 09:01:00+00	2026-06-16 09:01:00+00	\N	DSE-154	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
85646032-49e6-5654-bf70-2e48d4122bce	62445afe-3364-5e78-b55e-fb5429807a47	de529b34-39ac-5368-86e8-1d1076117642	eb73aa6c-87aa-532d-8b94-109b8b863733	2026-06-18	04:00:00	Regression testing — Design System Evolution	2026-06-18 09:01:00+00	2026-06-18 09:01:00+00	\N	DSE-128	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
5dc21412-4af4-560d-b020-76dbaf1cba62	62445afe-3364-5e78-b55e-fb5429807a47	de529b34-39ac-5368-86e8-1d1076117642	eb73aa6c-87aa-532d-8b94-109b8b863733	2026-06-22	02:00:00	Regression testing — Design System Evolution	2026-06-22 09:01:00+00	2026-06-22 09:01:00+00	\N	DSE-102	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
c831bbcd-d799-563c-9114-21af5f5a7c03	62445afe-3364-5e78-b55e-fb5429807a47	de529b34-39ac-5368-86e8-1d1076117642	eb73aa6c-87aa-532d-8b94-109b8b863733	2026-06-24	04:00:00	Regression testing — Design System Evolution	2026-06-24 09:01:00+00	2026-06-24 09:01:00+00	\N	DSE-149	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
f5322f86-5035-5fd8-a7ed-a2a0ba0a19c7	62445afe-3364-5e78-b55e-fb5429807a47	de529b34-39ac-5368-86e8-1d1076117642	67164958-1bad-5a9c-8d3a-7c4f7dfb7282	2026-06-25	00:00:00	Planowana nieobecność uwzględniona w harmonogramie — Reporting Sandbox	2026-06-25 09:01:00+00	2026-06-25 09:01:00+00	\N	\N	d677a650-2c23-5c0c-9f53-920636bd318e	Active	Note
560b4b6b-9bf2-50ba-8248-714ebc9f75a7	62445afe-3364-5e78-b55e-fb5429807a47	de529b34-39ac-5368-86e8-1d1076117642	eb73aa6c-87aa-532d-8b94-109b8b863733	2026-06-26	02:00:00	Regression testing — Design System Evolution	2026-06-26 09:01:00+00	2026-06-26 09:01:00+00	\N	DSE-123	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
5404cf26-f6b9-58d4-821a-876d9384e2a7	62445afe-3364-5e78-b55e-fb5429807a47	de529b34-39ac-5368-86e8-1d1076117642	eb73aa6c-87aa-532d-8b94-109b8b863733	2026-06-29	04:00:00	Regression testing — Design System Evolution	2026-06-29 09:01:00+00	2026-06-29 09:01:00+00	\N	DSE-170	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
6359f631-6ecf-5ba9-ae21-61994e498443	62445afe-3364-5e78-b55e-fb5429807a47	de529b34-39ac-5368-86e8-1d1076117642	eb73aa6c-87aa-532d-8b94-109b8b863733	2026-07-01	02:00:00	Regression testing — Design System Evolution	2026-07-01 09:01:00+00	2026-07-01 09:01:00+00	\N	DSE-144	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
231e529a-7dc9-536c-9301-d14e63185073	62445afe-3364-5e78-b55e-fb5429807a47	de529b34-39ac-5368-86e8-1d1076117642	67164958-1bad-5a9c-8d3a-7c4f7dfb7282	2026-07-02	02:30:00	Regression testing — Reporting Sandbox	2026-07-02 09:01:00+00	2026-07-02 09:01:00+00	\N	RS-163	d677a650-2c23-5c0c-9f53-920636bd318e	Active	Worklog
c2b0ccad-e007-5912-8cbd-31a4bffd1f39	62445afe-3364-5e78-b55e-fb5429807a47	de529b34-39ac-5368-86e8-1d1076117642	eb73aa6c-87aa-532d-8b94-109b8b863733	2026-07-03	04:00:00	Regression testing — Design System Evolution	2026-07-03 09:01:00+00	2026-07-03 09:01:00+00	\N	DSE-118	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
2eb7d0fd-ba34-5f1e-9b6b-49798ba3ebd1	62445afe-3364-5e78-b55e-fb5429807a47	de529b34-39ac-5368-86e8-1d1076117642	67164958-1bad-5a9c-8d3a-7c4f7dfb7282	2026-07-06	00:30:00	Regression testing — Reporting Sandbox	2026-07-06 09:01:00+00	2026-07-06 09:01:00+00	\N	RS-137	d677a650-2c23-5c0c-9f53-920636bd318e	Active	Worklog
8dcb7012-f2aa-50e5-acd4-b6a189be01ac	62445afe-3364-5e78-b55e-fb5429807a47	de529b34-39ac-5368-86e8-1d1076117642	67164958-1bad-5a9c-8d3a-7c4f7dfb7282	2026-07-08	02:30:00	Regression testing — Reporting Sandbox	2026-07-08 09:01:00+00	2026-07-08 09:01:00+00	\N	RS-111	d677a650-2c23-5c0c-9f53-920636bd318e	Active	Worklog
a04479ac-908d-5f91-9304-3fe33f224420	62445afe-3364-5e78-b55e-fb5429807a47	de529b34-39ac-5368-86e8-1d1076117642	67164958-1bad-5a9c-8d3a-7c4f7dfb7282	2026-07-10	00:30:00	Regression testing — Reporting Sandbox	2026-07-10 09:01:00+00	2026-07-10 09:01:00+00	\N	RS-158	d677a650-2c23-5c0c-9f53-920636bd318e	Active	Worklog
f19726cd-cb48-5373-981b-8ea9b11a206e	62445afe-3364-5e78-b55e-fb5429807a47	de529b34-39ac-5368-86e8-1d1076117642	67164958-1bad-5a9c-8d3a-7c4f7dfb7282	2026-07-13	02:30:00	Regression testing — Reporting Sandbox	2026-07-13 09:01:00+00	2026-07-13 09:01:00+00	\N	RS-132	d677a650-2c23-5c0c-9f53-920636bd318e	Active	Worklog
0bece3f1-2b15-528a-b7ab-f3c77a5cfb73	62445afe-3364-5e78-b55e-fb5429807a47	de529b34-39ac-5368-86e8-1d1076117642	67164958-1bad-5a9c-8d3a-7c4f7dfb7282	2026-07-15	00:30:00	Regression testing — Reporting Sandbox	2026-07-15 09:01:00+00	2026-07-15 09:01:00+00	\N	RS-106	d677a650-2c23-5c0c-9f53-920636bd318e	Active	Worklog
debebed8-1efb-58c2-8f9a-be11cf9939bb	62445afe-3364-5e78-b55e-fb5429807a47	de529b34-39ac-5368-86e8-1d1076117642	eb73aa6c-87aa-532d-8b94-109b8b863733	2026-07-16	00:00:00	Planowana nieobecność uwzględniona w harmonogramie — Design System Evolution	2026-07-16 09:01:00+00	2026-07-16 09:01:00+00	\N	\N	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Note
26d381b1-c40e-5791-9502-e5a780f50597	62445afe-3364-5e78-b55e-fb5429807a47	de529b34-39ac-5368-86e8-1d1076117642	67164958-1bad-5a9c-8d3a-7c4f7dfb7282	2026-07-17	02:30:00	Regression testing — Reporting Sandbox	2026-07-17 09:01:00+00	2026-07-17 09:01:00+00	\N	RS-153	d677a650-2c23-5c0c-9f53-920636bd318e	Active	Worklog
3af95955-60bc-552e-a255-67bd23f130e5	62445afe-3364-5e78-b55e-fb5429807a47	de529b34-39ac-5368-86e8-1d1076117642	67164958-1bad-5a9c-8d3a-7c4f7dfb7282	2026-07-21	00:30:00	Regression testing — Reporting Sandbox	2026-07-21 09:01:00+00	2026-07-21 09:01:00+00	\N	RS-127	d677a650-2c23-5c0c-9f53-920636bd318e	Active	Worklog
74e30575-abcf-503f-bd95-84c6c93b6e3f	62445afe-3364-5e78-b55e-fb5429807a47	de529b34-39ac-5368-86e8-1d1076117642	67164958-1bad-5a9c-8d3a-7c4f7dfb7282	2026-07-23	02:30:00	Regression testing — Reporting Sandbox	2026-07-23 09:01:00+00	2026-07-23 09:01:00+00	\N	RS-101	d677a650-2c23-5c0c-9f53-920636bd318e	Active	Worklog
04ac5bbe-3769-53ec-a5cc-adbad261d6fd	62445afe-3364-5e78-b55e-fb5429807a47	de529b34-39ac-5368-86e8-1d1076117642	eb73aa6c-87aa-532d-8b94-109b8b863733	2026-07-24	03:00:00	Regression testing — Design System Evolution	2026-07-24 09:01:00+00	2026-07-24 09:01:00+00	\N	DSE-120	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
ef492bfa-2ec9-5690-aeb1-f221f4121d52	62445afe-3364-5e78-b55e-fb5429807a47	de529b34-39ac-5368-86e8-1d1076117642	67164958-1bad-5a9c-8d3a-7c4f7dfb7282	2026-07-26	00:30:00	Regression testing — Reporting Sandbox	2026-07-26 09:01:00+00	2026-07-26 09:01:00+00	\N	RS-148	d677a650-2c23-5c0c-9f53-920636bd318e	Active	Worklog
1b59c470-dcfa-50f0-a29a-9ec61e4d4113	62445afe-3364-5e78-b55e-fb5429807a47	de529b34-39ac-5368-86e8-1d1076117642	eb73aa6c-87aa-532d-8b94-109b8b863733	2026-07-27	01:00:00	Regression testing — Design System Evolution	2026-07-27 09:01:00+00	2026-07-27 09:01:00+00	\N	DSE-167	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
f10abb46-62fb-55a5-a6ba-66a7ae140a4e	62445afe-3364-5e78-b55e-fb5429807a47	de529b34-39ac-5368-86e8-1d1076117642	eb73aa6c-87aa-532d-8b94-109b8b863733	2026-07-29	03:00:00	Regression testing — Design System Evolution	2026-07-29 09:01:00+00	2026-07-29 09:01:00+00	\N	DSE-141	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
f9593629-9af8-5b31-950c-f560480d2a44	62445afe-3364-5e78-b55e-fb5429807a47	de529b34-39ac-5368-86e8-1d1076117642	eb73aa6c-87aa-532d-8b94-109b8b863733	2026-07-31	01:00:00	Regression testing — Design System Evolution	2026-07-31 09:01:00+00	2026-07-31 09:01:00+00	\N	DSE-115	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
94868831-607c-535a-a15d-33265c8c6bff	62445afe-3364-5e78-b55e-fb5429807a47	de529b34-39ac-5368-86e8-1d1076117642	eb73aa6c-87aa-532d-8b94-109b8b863733	2026-08-04	03:00:00	Regression testing — Design System Evolution	2026-08-04 09:01:00+00	2026-08-04 09:01:00+00	\N	DSE-162	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
c83db1ef-31be-51f8-9d24-ec413b9938ad	62445afe-3364-5e78-b55e-fb5429807a47	de529b34-39ac-5368-86e8-1d1076117642	eb73aa6c-87aa-532d-8b94-109b8b863733	2026-08-06	01:00:00	Regression testing — Design System Evolution	2026-08-06 09:01:00+00	2026-08-06 09:01:00+00	\N	DSE-136	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
9d928f6c-fadf-5be6-bdd9-7bd38731c43e	62445afe-3364-5e78-b55e-fb5429807a47	de529b34-39ac-5368-86e8-1d1076117642	eb73aa6c-87aa-532d-8b94-109b8b863733	2026-08-09	03:00:00	Regression testing — Design System Evolution	2026-08-09 09:01:00+00	2026-08-09 09:01:00+00	\N	DSE-110	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
065aaf14-51a6-5eb2-baee-8fb2db35f42d	62445afe-3364-5e78-b55e-fb5429807a47	de529b34-39ac-5368-86e8-1d1076117642	eb73aa6c-87aa-532d-8b94-109b8b863733	2026-08-11	01:00:00	Regression testing — Design System Evolution	2026-08-11 09:01:00+00	2026-08-11 09:01:00+00	\N	DSE-157	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
d6a6451e-e30d-56ed-bb28-f771753f1cff	62445afe-3364-5e78-b55e-fb5429807a47	8205f025-5eee-5f16-9e8e-b6a44f2a90e7	9406b74a-6b7a-578b-8fbd-958684d93780	2026-05-20	01:45:00	Release preparation — Patient Portal	2026-05-20 09:01:00+00	2026-05-20 09:01:00+00	\N	PP-126	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
a929a4eb-615e-51b7-a552-d8ca0bd4118a	62445afe-3364-5e78-b55e-fb5429807a47	8205f025-5eee-5f16-9e8e-b6a44f2a90e7	9406b74a-6b7a-578b-8fbd-958684d93780	2026-05-21	03:15:00	Release preparation — Patient Portal	2026-05-21 09:01:00+00	2026-05-21 09:01:00+00	\N	PP-154	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
3da680f2-4a26-5a42-a78f-e7be291b1b30	62445afe-3364-5e78-b55e-fb5429807a47	8205f025-5eee-5f16-9e8e-b6a44f2a90e7	9406b74a-6b7a-578b-8fbd-958684d93780	2026-05-22	03:45:00	Release preparation — Patient Portal	2026-05-22 09:01:00+00	2026-05-22 09:01:00+00	\N	PP-100	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
f2dbc9cc-0d24-5503-a9f1-a3afb10ec8c5	62445afe-3364-5e78-b55e-fb5429807a47	8205f025-5eee-5f16-9e8e-b6a44f2a90e7	9406b74a-6b7a-578b-8fbd-958684d93780	2026-05-25	01:15:00	Release preparation — Patient Portal	2026-05-25 09:01:00+00	2026-05-25 09:01:00+00	\N	PP-128	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
0b1f2f03-0383-5c45-8621-d78fbce20d1b	62445afe-3364-5e78-b55e-fb5429807a47	8205f025-5eee-5f16-9e8e-b6a44f2a90e7	9406b74a-6b7a-578b-8fbd-958684d93780	2026-05-26	01:45:00	Release preparation — Patient Portal	2026-05-26 09:01:00+00	2026-05-26 09:01:00+00	\N	PP-147	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
23f29c1c-5a44-55ea-9d37-277234c26f5c	62445afe-3364-5e78-b55e-fb5429807a47	8205f025-5eee-5f16-9e8e-b6a44f2a90e7	9406b74a-6b7a-578b-8fbd-958684d93780	2026-05-28	03:45:00	Release preparation — Patient Portal	2026-05-28 09:01:00+00	2026-05-28 09:01:00+00	\N	PP-121	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
5fe5cf96-b881-5e3f-b4e5-32e171cfe904	62445afe-3364-5e78-b55e-fb5429807a47	8205f025-5eee-5f16-9e8e-b6a44f2a90e7	9406b74a-6b7a-578b-8fbd-958684d93780	2026-05-31	01:45:00	Release preparation — Patient Portal	2026-05-31 09:01:00+00	2026-05-31 09:01:00+00	\N	PP-168	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
b5d7b2e0-f70a-5d58-9c3c-96ce11b47881	62445afe-3364-5e78-b55e-fb5429807a47	8205f025-5eee-5f16-9e8e-b6a44f2a90e7	9406b74a-6b7a-578b-8fbd-958684d93780	2026-06-02	03:45:00	Release preparation — Patient Portal	2026-06-02 09:01:00+00	2026-06-02 09:01:00+00	\N	PP-142	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
206db642-4dd8-50d9-bd31-a4f24bfc60dc	62445afe-3364-5e78-b55e-fb5429807a47	8205f025-5eee-5f16-9e8e-b6a44f2a90e7	9406b74a-6b7a-578b-8fbd-958684d93780	2026-06-03	00:00:00	Blocker integracji wymaga odpowiedzi partnera — Patient Portal	2026-06-03 09:01:00+00	2026-06-03 09:01:00+00	\N	\N	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Note
349bd6ad-0a8c-5d77-93ba-5acfb46f0418	62445afe-3364-5e78-b55e-fb5429807a47	8205f025-5eee-5f16-9e8e-b6a44f2a90e7	9406b74a-6b7a-578b-8fbd-958684d93780	2026-06-04	01:45:00	Release preparation — Patient Portal	2026-06-04 09:01:00+00	2026-06-04 09:01:00+00	\N	PP-116	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
9d7a561c-aece-5b04-bf9b-cbf81f9dd216	62445afe-3364-5e78-b55e-fb5429807a47	8205f025-5eee-5f16-9e8e-b6a44f2a90e7	9406b74a-6b7a-578b-8fbd-958684d93780	2026-06-08	03:45:00	Release preparation — Patient Portal	2026-06-08 09:01:00+00	2026-06-08 09:01:00+00	\N	PP-163	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
c46e9f8d-7833-5752-b014-3440bec198d4	62445afe-3364-5e78-b55e-fb5429807a47	8205f025-5eee-5f16-9e8e-b6a44f2a90e7	9406b74a-6b7a-578b-8fbd-958684d93780	2026-06-10	01:45:00	Release preparation — Patient Portal	2026-06-10 09:01:00+00	2026-06-10 09:01:00+00	\N	PP-137	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
f99747ea-1968-57cb-b788-2e9b03e560ee	62445afe-3364-5e78-b55e-fb5429807a47	8205f025-5eee-5f16-9e8e-b6a44f2a90e7	9406b74a-6b7a-578b-8fbd-958684d93780	2026-06-11	02:15:00	Release preparation — Patient Portal	2026-06-11 09:01:00+00	2026-06-11 09:01:00+00	\N	PP-156	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
7f8f1b31-9ea9-5a76-98d5-879cecb52aa8	62445afe-3364-5e78-b55e-fb5429807a47	8205f025-5eee-5f16-9e8e-b6a44f2a90e7	9406b74a-6b7a-578b-8fbd-958684d93780	2026-06-12	03:45:00	Release preparation — Patient Portal	2026-06-12 09:01:00+00	2026-06-12 09:01:00+00	\N	PP-111	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
7d499bbc-dd62-513b-9f39-da18b1930be1	62445afe-3364-5e78-b55e-fb5429807a47	8205f025-5eee-5f16-9e8e-b6a44f2a90e7	9406b74a-6b7a-578b-8fbd-958684d93780	2026-06-14	00:15:00	Release preparation — Patient Portal	2026-06-14 09:01:00+00	2026-06-14 09:01:00+00	\N	PP-130	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
1ad5f093-a55e-5d41-9ae4-8dd87687bc0d	62445afe-3364-5e78-b55e-fb5429807a47	8205f025-5eee-5f16-9e8e-b6a44f2a90e7	9406b74a-6b7a-578b-8fbd-958684d93780	2026-06-16	02:15:00	Release preparation — Patient Portal	2026-06-16 09:01:00+00	2026-06-16 09:01:00+00	\N	PP-104	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
2dbb6038-082e-53ce-b875-645ce7da718a	62445afe-3364-5e78-b55e-fb5429807a47	8205f025-5eee-5f16-9e8e-b6a44f2a90e7	9406b74a-6b7a-578b-8fbd-958684d93780	2026-06-18	00:15:00	Release preparation — Patient Portal	2026-06-18 09:01:00+00	2026-06-18 09:01:00+00	\N	PP-151	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
cfff7c52-7e0d-5104-af7e-b316d8b8e761	62445afe-3364-5e78-b55e-fb5429807a47	8205f025-5eee-5f16-9e8e-b6a44f2a90e7	9406b74a-6b7a-578b-8fbd-958684d93780	2026-06-22	02:15:00	Release preparation — Patient Portal	2026-06-22 09:01:00+00	2026-06-22 09:01:00+00	\N	PP-125	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
74d680c1-2f4c-5209-93a3-90dec8e8f7ae	62445afe-3364-5e78-b55e-fb5429807a47	8205f025-5eee-5f16-9e8e-b6a44f2a90e7	9406b74a-6b7a-578b-8fbd-958684d93780	2026-06-24	00:15:00	Release preparation — Patient Portal	2026-06-24 09:01:00+00	2026-06-24 09:01:00+00	\N	PP-172	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
33672de0-1e12-5ea7-aeb5-c08401d52cb0	62445afe-3364-5e78-b55e-fb5429807a47	8205f025-5eee-5f16-9e8e-b6a44f2a90e7	9406b74a-6b7a-578b-8fbd-958684d93780	2026-06-25	00:00:00	Blocker integracji wymaga odpowiedzi partnera — Patient Portal	2026-06-25 09:01:00+00	2026-06-25 09:01:00+00	\N	\N	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Note
9ea9bb56-4289-5ab4-a10e-fdf4ad6cab7c	62445afe-3364-5e78-b55e-fb5429807a47	8205f025-5eee-5f16-9e8e-b6a44f2a90e7	9406b74a-6b7a-578b-8fbd-958684d93780	2026-06-26	02:15:00	Release preparation — Patient Portal	2026-06-26 09:01:00+00	2026-06-26 09:01:00+00	\N	PP-146	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
fa588b90-40d2-5606-a482-d856fa21820e	62445afe-3364-5e78-b55e-fb5429807a47	8205f025-5eee-5f16-9e8e-b6a44f2a90e7	9406b74a-6b7a-578b-8fbd-958684d93780	2026-06-29	00:15:00	Release preparation — Patient Portal	2026-06-29 09:01:00+00	2026-06-29 09:01:00+00	\N	PP-120	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
276a523d-7ec5-5e74-ba6b-32dddea78b5d	62445afe-3364-5e78-b55e-fb5429807a47	8205f025-5eee-5f16-9e8e-b6a44f2a90e7	9406b74a-6b7a-578b-8fbd-958684d93780	2026-07-01	02:15:00	Release preparation — Patient Portal	2026-07-01 09:01:00+00	2026-07-01 09:01:00+00	\N	PP-167	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
ebcd01cd-692b-5f35-a90e-2422caebb62c	62445afe-3364-5e78-b55e-fb5429807a47	8205f025-5eee-5f16-9e8e-b6a44f2a90e7	9406b74a-6b7a-578b-8fbd-958684d93780	2026-07-02	02:45:00	Release preparation — Patient Portal	2026-07-02 09:01:00+00	2026-07-02 09:01:00+00	\N	PP-113	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
81b24c5e-b633-5806-9cc6-a0c7a52634ca	62445afe-3364-5e78-b55e-fb5429807a47	8205f025-5eee-5f16-9e8e-b6a44f2a90e7	9406b74a-6b7a-578b-8fbd-958684d93780	2026-07-03	00:15:00	Release preparation — Patient Portal	2026-07-03 09:01:00+00	2026-07-03 09:01:00+00	\N	PP-141	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
2b5814d3-9b19-556a-be4f-0ddf773cd56e	62445afe-3364-5e78-b55e-fb5429807a47	8205f025-5eee-5f16-9e8e-b6a44f2a90e7	9406b74a-6b7a-578b-8fbd-958684d93780	2026-07-06	00:45:00	Release preparation — Patient Portal	2026-07-06 09:01:00+00	2026-07-06 09:01:00+00	\N	PP-160	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
89064910-a203-56ed-a0f2-e84570393886	62445afe-3364-5e78-b55e-fb5429807a47	8205f025-5eee-5f16-9e8e-b6a44f2a90e7	9406b74a-6b7a-578b-8fbd-958684d93780	2026-07-08	02:45:00	Release preparation — Patient Portal	2026-07-08 09:01:00+00	2026-07-08 09:01:00+00	\N	PP-134	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
b71fc61e-6b35-54ed-8af9-789fa3947118	62445afe-3364-5e78-b55e-fb5429807a47	8205f025-5eee-5f16-9e8e-b6a44f2a90e7	9406b74a-6b7a-578b-8fbd-958684d93780	2026-07-10	00:45:00	Release preparation — Patient Portal	2026-07-10 09:01:00+00	2026-07-10 09:01:00+00	\N	PP-108	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
21514751-bc1f-5eac-b2bb-2d357f145876	62445afe-3364-5e78-b55e-fb5429807a47	8205f025-5eee-5f16-9e8e-b6a44f2a90e7	9406b74a-6b7a-578b-8fbd-958684d93780	2026-07-13	02:45:00	Release preparation — Patient Portal	2026-07-13 09:01:00+00	2026-07-13 09:01:00+00	\N	PP-155	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
4f21dd7a-e746-57f2-befd-a29c2ceefd5d	62445afe-3364-5e78-b55e-fb5429807a47	8205f025-5eee-5f16-9e8e-b6a44f2a90e7	9406b74a-6b7a-578b-8fbd-958684d93780	2026-07-15	00:45:00	Release preparation — Patient Portal	2026-07-15 09:01:00+00	2026-07-15 09:01:00+00	\N	PP-129	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
a27f9e6e-e4ea-5e7c-9ff1-aa2a2c9e825a	62445afe-3364-5e78-b55e-fb5429807a47	8205f025-5eee-5f16-9e8e-b6a44f2a90e7	9406b74a-6b7a-578b-8fbd-958684d93780	2026-07-16	00:00:00	Blocker integracji wymaga odpowiedzi partnera — Patient Portal	2026-07-16 09:01:00+00	2026-07-16 09:01:00+00	\N	\N	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Note
3b568c4a-c273-5ccd-9c2a-9da02b849979	62445afe-3364-5e78-b55e-fb5429807a47	8205f025-5eee-5f16-9e8e-b6a44f2a90e7	9406b74a-6b7a-578b-8fbd-958684d93780	2026-07-17	02:45:00	Release preparation — Patient Portal	2026-07-17 09:01:00+00	2026-07-17 09:01:00+00	\N	PP-103	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
ea0e4e24-4bed-521f-ac17-8752796acb3a	62445afe-3364-5e78-b55e-fb5429807a47	8205f025-5eee-5f16-9e8e-b6a44f2a90e7	9406b74a-6b7a-578b-8fbd-958684d93780	2026-07-21	00:45:00	Release preparation — Patient Portal	2026-07-21 09:01:00+00	2026-07-21 09:01:00+00	\N	PP-150	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
4cfa3aae-102f-5584-b09a-06e2da2c6827	62445afe-3364-5e78-b55e-fb5429807a47	8205f025-5eee-5f16-9e8e-b6a44f2a90e7	9406b74a-6b7a-578b-8fbd-958684d93780	2026-07-23	02:45:00	Release preparation — Patient Portal	2026-07-23 09:01:00+00	2026-07-23 09:01:00+00	\N	PP-124	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
2883d445-782d-5d17-9172-2937db3c4dac	62445afe-3364-5e78-b55e-fb5429807a47	8205f025-5eee-5f16-9e8e-b6a44f2a90e7	9406b74a-6b7a-578b-8fbd-958684d93780	2026-07-24	03:15:00	Release preparation — Patient Portal	2026-07-24 09:01:00+00	2026-07-24 09:01:00+00	\N	PP-143	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
70e4e7d8-dabb-514b-954a-b3f2172f5ae1	62445afe-3364-5e78-b55e-fb5429807a47	8205f025-5eee-5f16-9e8e-b6a44f2a90e7	9406b74a-6b7a-578b-8fbd-958684d93780	2026-07-26	00:45:00	Release preparation — Patient Portal	2026-07-26 09:01:00+00	2026-07-26 09:01:00+00	\N	PP-171	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
d0fed691-69fa-578c-8e1c-ac821fa8b3da	62445afe-3364-5e78-b55e-fb5429807a47	8205f025-5eee-5f16-9e8e-b6a44f2a90e7	9406b74a-6b7a-578b-8fbd-958684d93780	2026-07-27	01:15:00	Release preparation — Patient Portal	2026-07-27 09:01:00+00	2026-07-27 09:01:00+00	\N	PP-117	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
947827e0-12ba-5c45-aee6-9a505fd1636d	62445afe-3364-5e78-b55e-fb5429807a47	8205f025-5eee-5f16-9e8e-b6a44f2a90e7	9406b74a-6b7a-578b-8fbd-958684d93780	2026-07-29	03:15:00	Release preparation — Patient Portal	2026-07-29 09:01:00+00	2026-07-29 09:01:00+00	\N	PP-164	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
f51e4d62-d002-5217-900b-d79deafa69b1	62445afe-3364-5e78-b55e-fb5429807a47	8205f025-5eee-5f16-9e8e-b6a44f2a90e7	9406b74a-6b7a-578b-8fbd-958684d93780	2026-07-31	01:15:00	Release preparation — Patient Portal	2026-07-31 09:01:00+00	2026-07-31 09:01:00+00	\N	PP-138	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
9f4fa1f3-a430-54c2-83ac-149159634b4b	62445afe-3364-5e78-b55e-fb5429807a47	8205f025-5eee-5f16-9e8e-b6a44f2a90e7	9406b74a-6b7a-578b-8fbd-958684d93780	2026-08-04	03:15:00	Release preparation — Patient Portal	2026-08-04 09:01:00+00	2026-08-04 09:01:00+00	\N	PP-112	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
6eb38328-5aa2-5a9f-82ea-a049067ea6ef	62445afe-3364-5e78-b55e-fb5429807a47	8205f025-5eee-5f16-9e8e-b6a44f2a90e7	9406b74a-6b7a-578b-8fbd-958684d93780	2026-08-06	01:15:00	Release preparation — Patient Portal	2026-08-06 09:01:00+00	2026-08-06 09:01:00+00	\N	PP-159	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
8b507593-3119-5476-9407-8430419492f6	62445afe-3364-5e78-b55e-fb5429807a47	8205f025-5eee-5f16-9e8e-b6a44f2a90e7	9406b74a-6b7a-578b-8fbd-958684d93780	2026-08-09	03:15:00	Release preparation — Patient Portal	2026-08-09 09:01:00+00	2026-08-09 09:01:00+00	\N	PP-133	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
ba82ae1d-13f5-5795-9894-48afb485431d	62445afe-3364-5e78-b55e-fb5429807a47	8205f025-5eee-5f16-9e8e-b6a44f2a90e7	9406b74a-6b7a-578b-8fbd-958684d93780	2026-08-11	01:15:00	Release preparation — Patient Portal	2026-08-11 09:01:00+00	2026-08-11 09:01:00+00	\N	PP-107	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
5d63d07e-738f-5137-b163-09eeb8dd7e5f	62445afe-3364-5e78-b55e-fb5429807a47	2d40ec7a-98f2-5e42-84d6-c8bafec1e0b2	6dfe9630-59ce-507d-81a0-2f94cb54247f	2026-05-20	01:00:00	Implementation and pairing — Fleet Companion	2026-05-20 09:01:00+00	2026-05-20 09:01:00+00	\N	FC-121	eba17d28-b076-534c-918a-dca0a5be8fab	Active	Worklog
3a91e774-7074-5bd5-81d2-009afc2f7223	62445afe-3364-5e78-b55e-fb5429807a47	2d40ec7a-98f2-5e42-84d6-c8bafec1e0b2	f04245fa-9e0e-5905-80fa-524e9f1e172f	2026-05-21	02:30:00	Implementation and pairing — Delivery Operations Hub	2026-05-21 09:01:00+00	2026-05-21 09:01:00+00	\N	DOH-149	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
4da23de9-1fa7-52e3-9009-1fdf781a759c	62445afe-3364-5e78-b55e-fb5429807a47	2d40ec7a-98f2-5e42-84d6-c8bafec1e0b2	6dfe9630-59ce-507d-81a0-2f94cb54247f	2026-05-22	03:00:00	Implementation and pairing — Fleet Companion	2026-05-22 09:01:00+00	2026-05-22 09:01:00+00	\N	FC-168	eba17d28-b076-534c-918a-dca0a5be8fab	Active	Worklog
462272d6-86fa-5d93-95f0-1ab99993c6e0	62445afe-3364-5e78-b55e-fb5429807a47	2d40ec7a-98f2-5e42-84d6-c8bafec1e0b2	f04245fa-9e0e-5905-80fa-524e9f1e172f	2026-05-25	00:30:00	Implementation and pairing — Delivery Operations Hub	2026-05-25 09:01:00+00	2026-05-25 09:01:00+00	\N	DOH-123	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
b21f6a0c-f043-5603-9339-73618398be8c	62445afe-3364-5e78-b55e-fb5429807a47	2d40ec7a-98f2-5e42-84d6-c8bafec1e0b2	6dfe9630-59ce-507d-81a0-2f94cb54247f	2026-05-26	01:00:00	Implementation and pairing — Fleet Companion	2026-05-26 09:01:00+00	2026-05-26 09:01:00+00	\N	FC-142	eba17d28-b076-534c-918a-dca0a5be8fab	Active	Worklog
7512c2a1-1549-553b-afe3-6d29d751cde3	62445afe-3364-5e78-b55e-fb5429807a47	2d40ec7a-98f2-5e42-84d6-c8bafec1e0b2	6dfe9630-59ce-507d-81a0-2f94cb54247f	2026-05-28	03:00:00	Implementation and pairing — Fleet Companion	2026-05-28 09:01:00+00	2026-05-28 09:01:00+00	\N	FC-116	eba17d28-b076-534c-918a-dca0a5be8fab	Active	Worklog
7ceb7b51-92ea-5552-81a4-5a1bcf6a0171	62445afe-3364-5e78-b55e-fb5429807a47	2d40ec7a-98f2-5e42-84d6-c8bafec1e0b2	6dfe9630-59ce-507d-81a0-2f94cb54247f	2026-05-31	01:00:00	Implementation and pairing — Fleet Companion	2026-05-31 09:01:00+00	2026-05-31 09:01:00+00	\N	FC-163	eba17d28-b076-534c-918a-dca0a5be8fab	Active	Worklog
2efe4266-ade6-525e-a7c4-7653a5718124	62445afe-3364-5e78-b55e-fb5429807a47	2d40ec7a-98f2-5e42-84d6-c8bafec1e0b2	6dfe9630-59ce-507d-81a0-2f94cb54247f	2026-06-02	03:00:00	Implementation and pairing — Fleet Companion	2026-06-02 09:01:00+00	2026-06-02 09:01:00+00	\N	FC-137	eba17d28-b076-534c-918a-dca0a5be8fab	Active	Worklog
8898b422-09e1-5767-a3eb-fd16cea1a1d4	62445afe-3364-5e78-b55e-fb5429807a47	2d40ec7a-98f2-5e42-84d6-c8bafec1e0b2	f04245fa-9e0e-5905-80fa-524e9f1e172f	2026-06-03	00:00:00	Planowana nieobecność uwzględniona w harmonogramie — Delivery Operations Hub	2026-06-03 09:01:00+00	2026-06-03 09:01:00+00	\N	\N	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Note
82cae027-ccbc-582e-b62a-3fc3f01d6a85	62445afe-3364-5e78-b55e-fb5429807a47	2d40ec7a-98f2-5e42-84d6-c8bafec1e0b2	6dfe9630-59ce-507d-81a0-2f94cb54247f	2026-06-04	01:00:00	Implementation and pairing — Fleet Companion	2026-06-04 09:01:00+00	2026-06-04 09:01:00+00	\N	FC-111	eba17d28-b076-534c-918a-dca0a5be8fab	Active	Worklog
42e1d87c-cacd-541d-9957-334a70ab8410	62445afe-3364-5e78-b55e-fb5429807a47	2d40ec7a-98f2-5e42-84d6-c8bafec1e0b2	6dfe9630-59ce-507d-81a0-2f94cb54247f	2026-06-08	03:00:00	Implementation and pairing — Fleet Companion	2026-06-08 09:01:00+00	2026-06-08 09:01:00+00	\N	FC-158	eba17d28-b076-534c-918a-dca0a5be8fab	Active	Worklog
2a213d07-9abb-5fa1-b40f-2906e185b038	62445afe-3364-5e78-b55e-fb5429807a47	2d40ec7a-98f2-5e42-84d6-c8bafec1e0b2	6dfe9630-59ce-507d-81a0-2f94cb54247f	2026-06-10	01:00:00	Implementation and pairing — Fleet Companion	2026-06-10 09:01:00+00	2026-06-10 09:01:00+00	\N	FC-132	eba17d28-b076-534c-918a-dca0a5be8fab	Active	Worklog
e37b2e33-2d9f-50e5-8353-ee08facda2b5	62445afe-3364-5e78-b55e-fb5429807a47	2d40ec7a-98f2-5e42-84d6-c8bafec1e0b2	f04245fa-9e0e-5905-80fa-524e9f1e172f	2026-06-11	01:30:00	Implementation and pairing — Delivery Operations Hub	2026-06-11 09:01:00+00	2026-06-11 09:01:00+00	\N	DOH-151	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
e306d7cb-0bda-52cd-8a2f-cb1269a9e45d	62445afe-3364-5e78-b55e-fb5429807a47	2d40ec7a-98f2-5e42-84d6-c8bafec1e0b2	6dfe9630-59ce-507d-81a0-2f94cb54247f	2026-06-12	03:00:00	Implementation and pairing — Fleet Companion	2026-06-12 09:01:00+00	2026-06-12 09:01:00+00	\N	FC-106	eba17d28-b076-534c-918a-dca0a5be8fab	Active	Worklog
f896283a-15df-5730-91fa-f89a53164c00	62445afe-3364-5e78-b55e-fb5429807a47	2d40ec7a-98f2-5e42-84d6-c8bafec1e0b2	f04245fa-9e0e-5905-80fa-524e9f1e172f	2026-06-14	03:30:00	Implementation and pairing — Delivery Operations Hub	2026-06-14 09:01:00+00	2026-06-14 09:01:00+00	\N	DOH-125	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
6b25ebdb-ba92-5921-94ed-4b6011484f1b	62445afe-3364-5e78-b55e-fb5429807a47	2d40ec7a-98f2-5e42-84d6-c8bafec1e0b2	f04245fa-9e0e-5905-80fa-524e9f1e172f	2026-06-16	01:30:00	Implementation and pairing — Delivery Operations Hub	2026-06-16 09:01:00+00	2026-06-16 09:01:00+00	\N	DOH-172	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
f8b96e54-7e04-53a2-a2fc-d4e0a0ab0ede	62445afe-3364-5e78-b55e-fb5429807a47	2d40ec7a-98f2-5e42-84d6-c8bafec1e0b2	f04245fa-9e0e-5905-80fa-524e9f1e172f	2026-06-18	03:30:00	Implementation and pairing — Delivery Operations Hub	2026-06-18 09:01:00+00	2026-06-18 09:01:00+00	\N	DOH-146	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
babb2840-86c3-515b-a19f-024e5df65794	62445afe-3364-5e78-b55e-fb5429807a47	2d40ec7a-98f2-5e42-84d6-c8bafec1e0b2	f04245fa-9e0e-5905-80fa-524e9f1e172f	2026-06-22	01:30:00	Implementation and pairing — Delivery Operations Hub	2026-06-22 09:01:00+00	2026-06-22 09:01:00+00	\N	DOH-120	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
1143571e-c5cb-5bb2-b34c-714434b6cce2	62445afe-3364-5e78-b55e-fb5429807a47	2d40ec7a-98f2-5e42-84d6-c8bafec1e0b2	f04245fa-9e0e-5905-80fa-524e9f1e172f	2026-06-24	03:30:00	Implementation and pairing — Delivery Operations Hub	2026-06-24 09:01:00+00	2026-06-24 09:01:00+00	\N	DOH-167	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
c1785467-0876-5519-85b1-8fcf9ba8ef00	62445afe-3364-5e78-b55e-fb5429807a47	2d40ec7a-98f2-5e42-84d6-c8bafec1e0b2	6dfe9630-59ce-507d-81a0-2f94cb54247f	2026-06-25	00:00:00	Planowana nieobecność uwzględniona w harmonogramie — Fleet Companion	2026-06-25 09:01:00+00	2026-06-25 09:01:00+00	\N	\N	eba17d28-b076-534c-918a-dca0a5be8fab	Active	Note
82b08070-453d-5589-a75e-e67538ba1ca0	62445afe-3364-5e78-b55e-fb5429807a47	2d40ec7a-98f2-5e42-84d6-c8bafec1e0b2	f04245fa-9e0e-5905-80fa-524e9f1e172f	2026-06-26	01:30:00	Implementation and pairing — Delivery Operations Hub	2026-06-26 09:01:00+00	2026-06-26 09:01:00+00	\N	DOH-141	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
d87b05d2-cbd3-5810-8106-093acba4e3a0	62445afe-3364-5e78-b55e-fb5429807a47	2d40ec7a-98f2-5e42-84d6-c8bafec1e0b2	f04245fa-9e0e-5905-80fa-524e9f1e172f	2026-06-29	03:30:00	Implementation and pairing — Delivery Operations Hub	2026-06-29 09:01:00+00	2026-06-29 09:01:00+00	\N	DOH-115	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
f3fcfb9c-fabd-5045-87de-0894b259618d	62445afe-3364-5e78-b55e-fb5429807a47	2d40ec7a-98f2-5e42-84d6-c8bafec1e0b2	f04245fa-9e0e-5905-80fa-524e9f1e172f	2026-07-01	01:30:00	Implementation and pairing — Delivery Operations Hub	2026-07-01 09:01:00+00	2026-07-01 09:01:00+00	\N	DOH-162	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
efa5eef2-2e22-59fe-90e3-ffa5eed60318	62445afe-3364-5e78-b55e-fb5429807a47	2d40ec7a-98f2-5e42-84d6-c8bafec1e0b2	6dfe9630-59ce-507d-81a0-2f94cb54247f	2026-07-02	02:00:00	Implementation and pairing — Fleet Companion	2026-07-02 09:01:00+00	2026-07-02 09:01:00+00	\N	FC-108	eba17d28-b076-534c-918a-dca0a5be8fab	Active	Worklog
a72b856f-ab1e-5144-83d6-eff1ea2e3615	62445afe-3364-5e78-b55e-fb5429807a47	2d40ec7a-98f2-5e42-84d6-c8bafec1e0b2	f04245fa-9e0e-5905-80fa-524e9f1e172f	2026-07-03	03:30:00	Implementation and pairing — Delivery Operations Hub	2026-07-03 09:01:00+00	2026-07-03 09:01:00+00	\N	DOH-136	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
3f4a0888-652f-5f4a-9ec6-7cc8ede0e7fd	62445afe-3364-5e78-b55e-fb5429807a47	2d40ec7a-98f2-5e42-84d6-c8bafec1e0b2	3d5d3faf-2bbd-5bca-ac00-1c6056bf7ca6	2026-07-05	00:30:00	Historical delivery wrap-up — Dispatch Optimizer	2026-07-05 09:01:00+00	2026-07-05 09:01:00+00	2026-07-13 00:00:00+00	DOP-907	141122b1-9a71-570d-a44c-efc88209be99	Archived	Worklog
8ca57d9b-3faa-5961-b22f-a679d6f9c94a	62445afe-3364-5e78-b55e-fb5429807a47	2d40ec7a-98f2-5e42-84d6-c8bafec1e0b2	6dfe9630-59ce-507d-81a0-2f94cb54247f	2026-07-06	04:00:00	Implementation and pairing — Fleet Companion	2026-07-06 09:01:00+00	2026-07-06 09:01:00+00	\N	FC-155	eba17d28-b076-534c-918a-dca0a5be8fab	Active	Worklog
9e8d9699-fbf4-594a-a21b-5615dea5fd69	62445afe-3364-5e78-b55e-fb5429807a47	2d40ec7a-98f2-5e42-84d6-c8bafec1e0b2	6dfe9630-59ce-507d-81a0-2f94cb54247f	2026-07-08	02:00:00	Implementation and pairing — Fleet Companion	2026-07-08 09:01:00+00	2026-07-08 09:01:00+00	\N	FC-129	eba17d28-b076-534c-918a-dca0a5be8fab	Active	Worklog
32e0c5eb-81cf-5acd-8044-c329b785ff33	62445afe-3364-5e78-b55e-fb5429807a47	2d40ec7a-98f2-5e42-84d6-c8bafec1e0b2	3d5d3faf-2bbd-5bca-ac00-1c6056bf7ca6	2026-07-08	04:00:00	Historical delivery wrap-up — Dispatch Optimizer	2026-07-08 09:02:00+00	2026-07-08 09:02:00+00	2026-07-13 00:00:00+00	DOP-925	141122b1-9a71-570d-a44c-efc88209be99	Archived	Worklog
647848a4-b870-5fad-8846-b8a64e669cd7	62445afe-3364-5e78-b55e-fb5429807a47	2d40ec7a-98f2-5e42-84d6-c8bafec1e0b2	6dfe9630-59ce-507d-81a0-2f94cb54247f	2026-07-10	04:00:00	Implementation and pairing — Fleet Companion	2026-07-10 09:01:00+00	2026-07-10 09:01:00+00	\N	FC-103	eba17d28-b076-534c-918a-dca0a5be8fab	Active	Worklog
c835fb9a-9fd3-53cb-bfd6-ce8ba7dcc3d3	62445afe-3364-5e78-b55e-fb5429807a47	2d40ec7a-98f2-5e42-84d6-c8bafec1e0b2	3d5d3faf-2bbd-5bca-ac00-1c6056bf7ca6	2026-07-11	03:30:00	Historical delivery wrap-up — Dispatch Optimizer	2026-07-11 09:01:00+00	2026-07-11 09:01:00+00	2026-07-13 00:00:00+00	DOP-943	141122b1-9a71-570d-a44c-efc88209be99	Archived	Worklog
d375d377-c3de-5569-a856-cfed0cbbe768	62445afe-3364-5e78-b55e-fb5429807a47	2d40ec7a-98f2-5e42-84d6-c8bafec1e0b2	6dfe9630-59ce-507d-81a0-2f94cb54247f	2026-07-13	02:00:00	Implementation and pairing — Fleet Companion	2026-07-13 09:01:00+00	2026-07-13 09:01:00+00	\N	FC-150	eba17d28-b076-534c-918a-dca0a5be8fab	Active	Worklog
1f5f95cc-3724-52ea-8d13-5381e2b39488	62445afe-3364-5e78-b55e-fb5429807a47	2d40ec7a-98f2-5e42-84d6-c8bafec1e0b2	6dfe9630-59ce-507d-81a0-2f94cb54247f	2026-07-15	04:00:00	Implementation and pairing — Fleet Companion	2026-07-15 09:01:00+00	2026-07-15 09:01:00+00	\N	FC-124	eba17d28-b076-534c-918a-dca0a5be8fab	Active	Worklog
39d57ecb-5a0f-5ed0-90f3-d94bfccd094f	62445afe-3364-5e78-b55e-fb5429807a47	2d40ec7a-98f2-5e42-84d6-c8bafec1e0b2	f04245fa-9e0e-5905-80fa-524e9f1e172f	2026-07-16	00:00:00	Planowana nieobecność uwzględniona w harmonogramie — Delivery Operations Hub	2026-07-16 09:01:00+00	2026-07-16 09:01:00+00	\N	\N	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Note
794da314-7c85-5b7e-b8cb-6a98a00354fa	62445afe-3364-5e78-b55e-fb5429807a47	2d40ec7a-98f2-5e42-84d6-c8bafec1e0b2	6dfe9630-59ce-507d-81a0-2f94cb54247f	2026-07-17	02:00:00	Implementation and pairing — Fleet Companion	2026-07-17 09:01:00+00	2026-07-17 09:01:00+00	\N	FC-171	eba17d28-b076-534c-918a-dca0a5be8fab	Active	Worklog
e6cc7b82-86ee-5f2d-a644-ecb1fe014967	62445afe-3364-5e78-b55e-fb5429807a47	2d40ec7a-98f2-5e42-84d6-c8bafec1e0b2	6dfe9630-59ce-507d-81a0-2f94cb54247f	2026-07-21	04:00:00	Implementation and pairing — Fleet Companion	2026-07-21 09:01:00+00	2026-07-21 09:01:00+00	\N	FC-145	eba17d28-b076-534c-918a-dca0a5be8fab	Active	Worklog
dffec381-f08f-554e-8ad3-bf493a999d68	62445afe-3364-5e78-b55e-fb5429807a47	2d40ec7a-98f2-5e42-84d6-c8bafec1e0b2	6dfe9630-59ce-507d-81a0-2f94cb54247f	2026-07-23	02:00:00	Implementation and pairing — Fleet Companion	2026-07-23 09:01:00+00	2026-07-23 09:01:00+00	\N	FC-119	eba17d28-b076-534c-918a-dca0a5be8fab	Active	Worklog
ca004ed0-d422-5617-adfa-e35ad9da6acc	62445afe-3364-5e78-b55e-fb5429807a47	2d40ec7a-98f2-5e42-84d6-c8bafec1e0b2	f04245fa-9e0e-5905-80fa-524e9f1e172f	2026-07-24	02:30:00	Implementation and pairing — Delivery Operations Hub	2026-07-24 09:01:00+00	2026-07-24 09:01:00+00	\N	DOH-138	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
66576f09-986f-5b95-b69d-c7c60351c035	62445afe-3364-5e78-b55e-fb5429807a47	2d40ec7a-98f2-5e42-84d6-c8bafec1e0b2	6dfe9630-59ce-507d-81a0-2f94cb54247f	2026-07-26	04:00:00	Implementation and pairing — Fleet Companion	2026-07-26 09:01:00+00	2026-07-26 09:01:00+00	\N	FC-166	eba17d28-b076-534c-918a-dca0a5be8fab	Active	Worklog
4c5dde2e-345d-55cf-accc-73b5b955f06e	62445afe-3364-5e78-b55e-fb5429807a47	2d40ec7a-98f2-5e42-84d6-c8bafec1e0b2	f04245fa-9e0e-5905-80fa-524e9f1e172f	2026-07-27	00:30:00	Implementation and pairing — Delivery Operations Hub	2026-07-27 09:01:00+00	2026-07-27 09:01:00+00	\N	DOH-112	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
2483b853-ea96-57ae-b1da-f948c441823b	62445afe-3364-5e78-b55e-fb5429807a47	2d40ec7a-98f2-5e42-84d6-c8bafec1e0b2	f04245fa-9e0e-5905-80fa-524e9f1e172f	2026-07-29	02:30:00	Implementation and pairing — Delivery Operations Hub	2026-07-29 09:01:00+00	2026-07-29 09:01:00+00	\N	DOH-159	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
3a7e1cf7-e5a3-5865-96fa-0f1868fcf60b	62445afe-3364-5e78-b55e-fb5429807a47	2d40ec7a-98f2-5e42-84d6-c8bafec1e0b2	f04245fa-9e0e-5905-80fa-524e9f1e172f	2026-07-31	00:30:00	Implementation and pairing — Delivery Operations Hub	2026-07-31 09:01:00+00	2026-07-31 09:01:00+00	\N	DOH-133	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
835a53a6-df42-5265-aec4-1b1dcd4591e0	62445afe-3364-5e78-b55e-fb5429807a47	2d40ec7a-98f2-5e42-84d6-c8bafec1e0b2	f04245fa-9e0e-5905-80fa-524e9f1e172f	2026-08-04	02:30:00	Implementation and pairing — Delivery Operations Hub	2026-08-04 09:01:00+00	2026-08-04 09:01:00+00	\N	DOH-107	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
cfaf6bd6-7ace-5132-9961-e4ce27558e83	62445afe-3364-5e78-b55e-fb5429807a47	2d40ec7a-98f2-5e42-84d6-c8bafec1e0b2	f04245fa-9e0e-5905-80fa-524e9f1e172f	2026-08-06	00:30:00	Implementation and pairing — Delivery Operations Hub	2026-08-06 09:01:00+00	2026-08-06 09:01:00+00	\N	DOH-154	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
dad3ef05-fff2-5375-a6f4-0cf798e51dab	62445afe-3364-5e78-b55e-fb5429807a47	2d40ec7a-98f2-5e42-84d6-c8bafec1e0b2	f04245fa-9e0e-5905-80fa-524e9f1e172f	2026-08-09	02:30:00	Implementation and pairing — Delivery Operations Hub	2026-08-09 09:01:00+00	2026-08-09 09:01:00+00	\N	DOH-128	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
7ef70689-813f-53f7-8342-f9db799e3f2c	62445afe-3364-5e78-b55e-fb5429807a47	2d40ec7a-98f2-5e42-84d6-c8bafec1e0b2	f04245fa-9e0e-5905-80fa-524e9f1e172f	2026-08-11	00:30:00	Implementation and pairing — Delivery Operations Hub	2026-08-11 09:01:00+00	2026-08-11 09:01:00+00	\N	DOH-102	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
20ebff2f-37b1-5954-89f6-f55cdd4fdb51	62445afe-3364-5e78-b55e-fb5429807a47	cbe7100e-7e0b-5f30-9fec-aca7c60cad25	35f8aab0-9932-515e-80cc-e8fa82f9c650	2026-05-20	04:00:00	Performance improvements — Risk Dashboard	2026-05-20 09:01:00+00	2026-05-20 09:01:00+00	\N	RD-109	f4c5b0e8-5503-5a50-8487-4ae103b885f2	Active	Worklog
b8dba98b-cc8f-5553-af48-f6755317fe2c	62445afe-3364-5e78-b55e-fb5429807a47	cbe7100e-7e0b-5f30-9fec-aca7c60cad25	35f8aab0-9932-515e-80cc-e8fa82f9c650	2026-05-21	01:30:00	Performance improvements — Risk Dashboard	2026-05-21 09:01:00+00	2026-05-21 09:01:00+00	\N	RD-137	f4c5b0e8-5503-5a50-8487-4ae103b885f2	Active	Worklog
2f7bb43b-fd1b-5d00-bd96-f13ac5045566	62445afe-3364-5e78-b55e-fb5429807a47	cbe7100e-7e0b-5f30-9fec-aca7c60cad25	06f6bf38-0173-52de-aa5b-77d565741cb1	2026-05-22	02:00:00	Performance improvements — Retail Insights	2026-05-22 09:01:00+00	2026-05-22 09:01:00+00	\N	RI-156	3030e191-44de-5909-b035-5fe3679b482a	Active	Worklog
058b495a-de68-52e4-8874-c785caea7d2e	62445afe-3364-5e78-b55e-fb5429807a47	cbe7100e-7e0b-5f30-9fec-aca7c60cad25	06f6bf38-0173-52de-aa5b-77d565741cb1	2026-05-25	03:30:00	Performance improvements — Retail Insights	2026-05-25 09:01:00+00	2026-05-25 09:01:00+00	\N	RI-111	3030e191-44de-5909-b035-5fe3679b482a	Active	Worklog
db0376dd-26f3-5eee-aaae-755d0d05b8c4	62445afe-3364-5e78-b55e-fb5429807a47	cbe7100e-7e0b-5f30-9fec-aca7c60cad25	9406b74a-6b7a-578b-8fbd-958684d93780	2026-05-26	04:00:00	Performance improvements — Patient Portal	2026-05-26 09:01:00+00	2026-05-26 09:01:00+00	\N	PP-130	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
e229952f-d914-5d34-b441-4e32fb14af3b	62445afe-3364-5e78-b55e-fb5429807a47	cbe7100e-7e0b-5f30-9fec-aca7c60cad25	b8cd683c-fe4d-538c-bdaf-68c28e1e14ef	2026-05-28	02:00:00	Performance improvements — Time Intelligence	2026-05-28 09:01:00+00	2026-05-28 09:01:00+00	\N	TI-104	d677a650-2c23-5c0c-9f53-920636bd318e	Active	Worklog
90230624-253e-5d82-8cfd-f92e170b58e5	62445afe-3364-5e78-b55e-fb5429807a47	cbe7100e-7e0b-5f30-9fec-aca7c60cad25	eb73aa6c-87aa-532d-8b94-109b8b863733	2026-05-31	04:00:00	Performance improvements — Design System Evolution	2026-05-31 09:01:00+00	2026-05-31 09:01:00+00	\N	DSE-151	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
b4440188-fae1-56dc-b8aa-8d8c4e730b01	62445afe-3364-5e78-b55e-fb5429807a47	cbe7100e-7e0b-5f30-9fec-aca7c60cad25	35f8aab0-9932-515e-80cc-e8fa82f9c650	2026-06-02	02:00:00	Performance improvements — Risk Dashboard	2026-06-02 09:01:00+00	2026-06-02 09:01:00+00	\N	RD-125	f4c5b0e8-5503-5a50-8487-4ae103b885f2	Active	Worklog
300b020a-131a-5dcb-8f81-671aea49ce6b	62445afe-3364-5e78-b55e-fb5429807a47	cbe7100e-7e0b-5f30-9fec-aca7c60cad25	eb73aa6c-87aa-532d-8b94-109b8b863733	2026-06-03	00:00:00	Planowana nieobecność uwzględniona w harmonogramie — Design System Evolution	2026-06-03 09:01:00+00	2026-06-03 09:01:00+00	\N	\N	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Note
470ab113-682f-5b62-a6a6-ebb5a5909b5f	62445afe-3364-5e78-b55e-fb5429807a47	cbe7100e-7e0b-5f30-9fec-aca7c60cad25	06f6bf38-0173-52de-aa5b-77d565741cb1	2026-06-04	04:00:00	Performance improvements — Retail Insights	2026-06-04 09:01:00+00	2026-06-04 09:01:00+00	\N	RI-172	3030e191-44de-5909-b035-5fe3679b482a	Active	Worklog
dad2f32b-06ee-5396-9736-70dbe8b43594	62445afe-3364-5e78-b55e-fb5429807a47	cbe7100e-7e0b-5f30-9fec-aca7c60cad25	9406b74a-6b7a-578b-8fbd-958684d93780	2026-06-08	02:00:00	Performance improvements — Patient Portal	2026-06-08 09:01:00+00	2026-06-08 09:01:00+00	\N	PP-146	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
d04914fa-eb66-5d31-97a6-bc9b1cef9569	62445afe-3364-5e78-b55e-fb5429807a47	cbe7100e-7e0b-5f30-9fec-aca7c60cad25	b8cd683c-fe4d-538c-bdaf-68c28e1e14ef	2026-06-10	04:00:00	Performance improvements — Time Intelligence	2026-06-10 09:01:00+00	2026-06-10 09:01:00+00	\N	TI-120	d677a650-2c23-5c0c-9f53-920636bd318e	Active	Worklog
6efe52a0-b856-51f5-8334-d32a29cdd72a	62445afe-3364-5e78-b55e-fb5429807a47	cbe7100e-7e0b-5f30-9fec-aca7c60cad25	eb73aa6c-87aa-532d-8b94-109b8b863733	2026-06-11	00:30:00	Performance improvements — Design System Evolution	2026-06-11 09:01:00+00	2026-06-11 09:01:00+00	\N	DSE-139	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
ee59c6c4-ea61-57f2-9ab5-a76653d6521b	62445afe-3364-5e78-b55e-fb5429807a47	cbe7100e-7e0b-5f30-9fec-aca7c60cad25	eb73aa6c-87aa-532d-8b94-109b8b863733	2026-06-12	02:00:00	Performance improvements — Design System Evolution	2026-06-12 09:01:00+00	2026-06-12 09:01:00+00	\N	DSE-167	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
090012bd-6682-5644-8cd2-0bbdc7670eed	62445afe-3364-5e78-b55e-fb5429807a47	cbe7100e-7e0b-5f30-9fec-aca7c60cad25	35f8aab0-9932-515e-80cc-e8fa82f9c650	2026-06-14	02:30:00	Performance improvements — Risk Dashboard	2026-06-14 09:01:00+00	2026-06-14 09:01:00+00	\N	RD-113	f4c5b0e8-5503-5a50-8487-4ae103b885f2	Active	Worklog
b634118a-01de-5933-9398-7cd90727291c	62445afe-3364-5e78-b55e-fb5429807a47	cbe7100e-7e0b-5f30-9fec-aca7c60cad25	06f6bf38-0173-52de-aa5b-77d565741cb1	2026-06-16	00:30:00	Performance improvements — Retail Insights	2026-06-16 09:01:00+00	2026-06-16 09:01:00+00	\N	RI-160	3030e191-44de-5909-b035-5fe3679b482a	Active	Worklog
6f79b217-57e0-5165-b54e-b4c71a5dec2e	62445afe-3364-5e78-b55e-fb5429807a47	cbe7100e-7e0b-5f30-9fec-aca7c60cad25	9406b74a-6b7a-578b-8fbd-958684d93780	2026-06-18	02:30:00	Performance improvements — Patient Portal	2026-06-18 09:01:00+00	2026-06-18 09:01:00+00	\N	PP-134	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
ef0b6bb9-edb7-5c5f-a258-60018a029a79	62445afe-3364-5e78-b55e-fb5429807a47	cbe7100e-7e0b-5f30-9fec-aca7c60cad25	b8cd683c-fe4d-538c-bdaf-68c28e1e14ef	2026-06-22	00:30:00	Performance improvements — Time Intelligence	2026-06-22 09:01:00+00	2026-06-22 09:01:00+00	\N	TI-108	d677a650-2c23-5c0c-9f53-920636bd318e	Active	Worklog
15554770-0abe-551c-bcfe-475fbdfcfd84	62445afe-3364-5e78-b55e-fb5429807a47	cbe7100e-7e0b-5f30-9fec-aca7c60cad25	eb73aa6c-87aa-532d-8b94-109b8b863733	2026-06-24	02:30:00	Performance improvements — Design System Evolution	2026-06-24 09:01:00+00	2026-06-24 09:01:00+00	\N	DSE-155	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
48cd63c2-a94d-5c6a-97d9-74115381d3d6	62445afe-3364-5e78-b55e-fb5429807a47	cbe7100e-7e0b-5f30-9fec-aca7c60cad25	b8cd683c-fe4d-538c-bdaf-68c28e1e14ef	2026-06-25	00:00:00	Planowana nieobecność uwzględniona w harmonogramie — Time Intelligence	2026-06-25 09:01:00+00	2026-06-25 09:01:00+00	\N	\N	d677a650-2c23-5c0c-9f53-920636bd318e	Active	Note
078b4dee-5e70-59c9-ad50-24850b1c7590	62445afe-3364-5e78-b55e-fb5429807a47	cbe7100e-7e0b-5f30-9fec-aca7c60cad25	35f8aab0-9932-515e-80cc-e8fa82f9c650	2026-06-26	00:30:00	Performance improvements — Risk Dashboard	2026-06-26 09:01:00+00	2026-06-26 09:01:00+00	\N	RD-129	f4c5b0e8-5503-5a50-8487-4ae103b885f2	Active	Worklog
3fcdd0b5-b477-56c7-903c-986effa9f58c	62445afe-3364-5e78-b55e-fb5429807a47	cbe7100e-7e0b-5f30-9fec-aca7c60cad25	06f6bf38-0173-52de-aa5b-77d565741cb1	2026-06-29	02:30:00	Performance improvements — Retail Insights	2026-06-29 09:01:00+00	2026-06-29 09:01:00+00	\N	RI-103	3030e191-44de-5909-b035-5fe3679b482a	Active	Worklog
e222640b-03be-50aa-84c6-5c7994387e1e	62445afe-3364-5e78-b55e-fb5429807a47	cbe7100e-7e0b-5f30-9fec-aca7c60cad25	6f343524-7197-5868-bc07-4ca1a311dc9e	2026-06-30	03:45:00	Historical delivery wrap-up — Guest Journey	2026-06-30 09:01:00+00	2026-06-30 09:01:00+00	2026-07-13 00:00:00+00	GJ-902	498db7da-8df6-5797-90f5-e34933a83972	Archived	Worklog
f8bb6d8e-8691-5eb7-8b1d-ef577ced6ee6	62445afe-3364-5e78-b55e-fb5429807a47	3681b9d5-7732-52da-b97e-97efdcf08fd9	67164958-1bad-5a9c-8d3a-7c4f7dfb7282	2026-05-22	04:00:00	Architecture notes — Reporting Sandbox	2026-05-22 09:01:00+00	2026-05-22 09:01:00+00	\N	RS-164	d677a650-2c23-5c0c-9f53-920636bd318e	Active	Worklog
ab5ec11c-39c4-5828-90f0-abc74ee46407	62445afe-3364-5e78-b55e-fb5429807a47	cbe7100e-7e0b-5f30-9fec-aca7c60cad25	6f343524-7197-5868-bc07-4ca1a311dc9e	2026-06-30	02:30:00	Historical delivery wrap-up — Guest Journey	2026-06-30 09:02:00+00	2026-06-30 09:02:00+00	2026-07-13 00:00:00+00	GJ-947	498db7da-8df6-5797-90f5-e34933a83972	Archived	Worklog
fd8225bb-a3e3-5d8c-bcef-76d09df5fda8	62445afe-3364-5e78-b55e-fb5429807a47	cbe7100e-7e0b-5f30-9fec-aca7c60cad25	9406b74a-6b7a-578b-8fbd-958684d93780	2026-07-01	00:30:00	Performance improvements — Patient Portal	2026-07-01 09:01:00+00	2026-07-01 09:01:00+00	\N	PP-150	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
964d9b89-bb0c-5a29-9b67-726a4465b7db	62445afe-3364-5e78-b55e-fb5429807a47	cbe7100e-7e0b-5f30-9fec-aca7c60cad25	b8cd683c-fe4d-538c-bdaf-68c28e1e14ef	2026-07-02	01:00:00	Performance improvements — Time Intelligence	2026-07-02 09:01:00+00	2026-07-02 09:01:00+00	\N	TI-169	d677a650-2c23-5c0c-9f53-920636bd318e	Active	Worklog
7300685a-7c92-5343-95a2-244f9fb8a274	62445afe-3364-5e78-b55e-fb5429807a47	cbe7100e-7e0b-5f30-9fec-aca7c60cad25	b8cd683c-fe4d-538c-bdaf-68c28e1e14ef	2026-07-03	02:30:00	Performance improvements — Time Intelligence	2026-07-03 09:01:00+00	2026-07-03 09:01:00+00	\N	TI-124	d677a650-2c23-5c0c-9f53-920636bd318e	Active	Worklog
e2e9df02-6129-5123-896f-87ec48fc61d3	62445afe-3364-5e78-b55e-fb5429807a47	cbe7100e-7e0b-5f30-9fec-aca7c60cad25	6f343524-7197-5868-bc07-4ca1a311dc9e	2026-07-03	03:15:00	Historical delivery wrap-up — Guest Journey	2026-07-03 09:02:00+00	2026-07-03 09:02:00+00	2026-07-13 00:00:00+00	GJ-920	498db7da-8df6-5797-90f5-e34933a83972	Archived	Worklog
026e1b44-4ac7-5388-ada3-6437995c4e56	62445afe-3364-5e78-b55e-fb5429807a47	cbe7100e-7e0b-5f30-9fec-aca7c60cad25	eb73aa6c-87aa-532d-8b94-109b8b863733	2026-07-06	03:00:00	Performance improvements — Design System Evolution	2026-07-06 09:01:00+00	2026-07-06 09:01:00+00	\N	DSE-143	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
2eb4841f-079f-5b5c-af3e-fc09c1becff1	62445afe-3364-5e78-b55e-fb5429807a47	cbe7100e-7e0b-5f30-9fec-aca7c60cad25	6f343524-7197-5868-bc07-4ca1a311dc9e	2026-07-06	02:45:00	Historical delivery wrap-up — Guest Journey	2026-07-06 09:02:00+00	2026-07-06 09:02:00+00	2026-07-13 00:00:00+00	GJ-938	498db7da-8df6-5797-90f5-e34933a83972	Archived	Worklog
8cd5d18d-e7e9-565d-a320-f7f7cd5fedbf	62445afe-3364-5e78-b55e-fb5429807a47	cbe7100e-7e0b-5f30-9fec-aca7c60cad25	35f8aab0-9932-515e-80cc-e8fa82f9c650	2026-07-08	01:00:00	Performance improvements — Risk Dashboard	2026-07-08 09:01:00+00	2026-07-08 09:01:00+00	\N	RD-117	f4c5b0e8-5503-5a50-8487-4ae103b885f2	Active	Worklog
38740756-b16d-5545-800a-800c4cc120dd	62445afe-3364-5e78-b55e-fb5429807a47	cbe7100e-7e0b-5f30-9fec-aca7c60cad25	6f343524-7197-5868-bc07-4ca1a311dc9e	2026-07-09	03:30:00	Historical delivery wrap-up — Guest Journey	2026-07-09 09:01:00+00	2026-07-09 09:01:00+00	2026-07-13 00:00:00+00	GJ-911	498db7da-8df6-5797-90f5-e34933a83972	Archived	Worklog
e89dbb7b-151b-5bd8-a809-2aa423330c92	62445afe-3364-5e78-b55e-fb5429807a47	cbe7100e-7e0b-5f30-9fec-aca7c60cad25	6f343524-7197-5868-bc07-4ca1a311dc9e	2026-07-09	02:15:00	Historical delivery wrap-up — Guest Journey	2026-07-09 09:02:00+00	2026-07-09 09:02:00+00	2026-07-13 00:00:00+00	GJ-956	498db7da-8df6-5797-90f5-e34933a83972	Archived	Worklog
e73d8b37-23fd-55d8-9c54-64781e7a4eb6	62445afe-3364-5e78-b55e-fb5429807a47	cbe7100e-7e0b-5f30-9fec-aca7c60cad25	06f6bf38-0173-52de-aa5b-77d565741cb1	2026-07-10	03:00:00	Performance improvements — Retail Insights	2026-07-10 09:01:00+00	2026-07-10 09:01:00+00	\N	RI-164	3030e191-44de-5909-b035-5fe3679b482a	Active	Worklog
f864dee5-0b4c-5f3c-a137-196eb2bcff4d	62445afe-3364-5e78-b55e-fb5429807a47	cbe7100e-7e0b-5f30-9fec-aca7c60cad25	6f343524-7197-5868-bc07-4ca1a311dc9e	2026-07-12	03:00:00	Historical delivery wrap-up — Guest Journey	2026-07-12 09:01:00+00	2026-07-12 09:01:00+00	2026-07-13 00:00:00+00	GJ-929	498db7da-8df6-5797-90f5-e34933a83972	Archived	Worklog
38bf75e8-3b72-54fb-a8fc-b2100181b198	62445afe-3364-5e78-b55e-fb5429807a47	cbe7100e-7e0b-5f30-9fec-aca7c60cad25	9406b74a-6b7a-578b-8fbd-958684d93780	2026-07-13	01:00:00	Performance improvements — Patient Portal	2026-07-13 09:01:00+00	2026-07-13 09:01:00+00	\N	PP-138	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
accfacc8-3d9f-5056-8899-7ddfd47e8aa0	62445afe-3364-5e78-b55e-fb5429807a47	cbe7100e-7e0b-5f30-9fec-aca7c60cad25	b8cd683c-fe4d-538c-bdaf-68c28e1e14ef	2026-07-15	03:00:00	Performance improvements — Time Intelligence	2026-07-15 09:01:00+00	2026-07-15 09:01:00+00	\N	TI-112	d677a650-2c23-5c0c-9f53-920636bd318e	Active	Worklog
1e919595-3622-535a-a062-ae61cc3c00bd	62445afe-3364-5e78-b55e-fb5429807a47	cbe7100e-7e0b-5f30-9fec-aca7c60cad25	9406b74a-6b7a-578b-8fbd-958684d93780	2026-07-16	00:00:00	Planowana nieobecność uwzględniona w harmonogramie — Patient Portal	2026-07-16 09:01:00+00	2026-07-16 09:01:00+00	\N	\N	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Note
df43729a-345e-5ed0-9799-e270d5c6fc7e	62445afe-3364-5e78-b55e-fb5429807a47	cbe7100e-7e0b-5f30-9fec-aca7c60cad25	eb73aa6c-87aa-532d-8b94-109b8b863733	2026-07-17	01:00:00	Performance improvements — Design System Evolution	2026-07-17 09:01:00+00	2026-07-17 09:01:00+00	\N	DSE-159	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
b7efa21e-db38-5956-98ff-817697faab9d	62445afe-3364-5e78-b55e-fb5429807a47	cbe7100e-7e0b-5f30-9fec-aca7c60cad25	35f8aab0-9932-515e-80cc-e8fa82f9c650	2026-07-21	03:00:00	Performance improvements — Risk Dashboard	2026-07-21 09:01:00+00	2026-07-21 09:01:00+00	\N	RD-133	f4c5b0e8-5503-5a50-8487-4ae103b885f2	Active	Worklog
d433995d-b58b-5f5c-b18e-3592d198a475	62445afe-3364-5e78-b55e-fb5429807a47	cbe7100e-7e0b-5f30-9fec-aca7c60cad25	06f6bf38-0173-52de-aa5b-77d565741cb1	2026-07-23	01:00:00	Performance improvements — Retail Insights	2026-07-23 09:01:00+00	2026-07-23 09:01:00+00	\N	RI-107	3030e191-44de-5909-b035-5fe3679b482a	Active	Worklog
156d9e29-1584-5bf0-98d2-19841830f9c1	62445afe-3364-5e78-b55e-fb5429807a47	cbe7100e-7e0b-5f30-9fec-aca7c60cad25	9406b74a-6b7a-578b-8fbd-958684d93780	2026-07-24	01:30:00	Performance improvements — Patient Portal	2026-07-24 09:01:00+00	2026-07-24 09:01:00+00	\N	PP-126	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
368914eb-8bd4-5aae-841b-037880c16723	62445afe-3364-5e78-b55e-fb5429807a47	cbe7100e-7e0b-5f30-9fec-aca7c60cad25	9406b74a-6b7a-578b-8fbd-958684d93780	2026-07-26	03:00:00	Performance improvements — Patient Portal	2026-07-26 09:01:00+00	2026-07-26 09:01:00+00	\N	PP-154	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
c465810b-801f-54d0-b886-2c78b97c8b0b	62445afe-3364-5e78-b55e-fb5429807a47	cbe7100e-7e0b-5f30-9fec-aca7c60cad25	b8cd683c-fe4d-538c-bdaf-68c28e1e14ef	2026-07-27	03:30:00	Performance improvements — Time Intelligence	2026-07-27 09:01:00+00	2026-07-27 09:01:00+00	\N	TI-100	d677a650-2c23-5c0c-9f53-920636bd318e	Active	Worklog
9d2e8b8b-2955-59ee-95f7-ae9ffff66af6	62445afe-3364-5e78-b55e-fb5429807a47	cbe7100e-7e0b-5f30-9fec-aca7c60cad25	eb73aa6c-87aa-532d-8b94-109b8b863733	2026-07-29	01:30:00	Performance improvements — Design System Evolution	2026-07-29 09:01:00+00	2026-07-29 09:01:00+00	\N	DSE-147	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
4cf2244b-9359-5ea7-8617-9a67b5fc77c5	62445afe-3364-5e78-b55e-fb5429807a47	cbe7100e-7e0b-5f30-9fec-aca7c60cad25	35f8aab0-9932-515e-80cc-e8fa82f9c650	2026-07-31	03:30:00	Performance improvements — Risk Dashboard	2026-07-31 09:01:00+00	2026-07-31 09:01:00+00	\N	RD-121	f4c5b0e8-5503-5a50-8487-4ae103b885f2	Active	Worklog
95fdd411-0619-5e25-8b7b-15fbc2f2b055	62445afe-3364-5e78-b55e-fb5429807a47	cbe7100e-7e0b-5f30-9fec-aca7c60cad25	06f6bf38-0173-52de-aa5b-77d565741cb1	2026-08-04	01:30:00	Performance improvements — Retail Insights	2026-08-04 09:01:00+00	2026-08-04 09:01:00+00	\N	RI-168	3030e191-44de-5909-b035-5fe3679b482a	Active	Worklog
0cd639e7-ab06-5417-84f2-907afb8a3385	62445afe-3364-5e78-b55e-fb5429807a47	cbe7100e-7e0b-5f30-9fec-aca7c60cad25	9406b74a-6b7a-578b-8fbd-958684d93780	2026-08-06	03:30:00	Performance improvements — Patient Portal	2026-08-06 09:01:00+00	2026-08-06 09:01:00+00	\N	PP-142	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
5aa831f2-0daf-5d67-8ad4-6090d3cb0ca4	62445afe-3364-5e78-b55e-fb5429807a47	cbe7100e-7e0b-5f30-9fec-aca7c60cad25	06f6bf38-0173-52de-aa5b-77d565741cb1	2026-08-07	00:00:00	Planowana nieobecność uwzględniona w harmonogramie — Retail Insights	2026-08-07 09:01:00+00	2026-08-07 09:01:00+00	\N	\N	3030e191-44de-5909-b035-5fe3679b482a	Active	Note
9c6ed273-1b33-5879-b0ff-bc55238b1b07	62445afe-3364-5e78-b55e-fb5429807a47	cbe7100e-7e0b-5f30-9fec-aca7c60cad25	b8cd683c-fe4d-538c-bdaf-68c28e1e14ef	2026-08-09	01:30:00	Performance improvements — Time Intelligence	2026-08-09 09:01:00+00	2026-08-09 09:01:00+00	\N	TI-116	d677a650-2c23-5c0c-9f53-920636bd318e	Active	Worklog
c59d5a77-8194-55fb-be96-dc833d440003	62445afe-3364-5e78-b55e-fb5429807a47	cbe7100e-7e0b-5f30-9fec-aca7c60cad25	eb73aa6c-87aa-532d-8b94-109b8b863733	2026-08-11	03:30:00	Performance improvements — Design System Evolution	2026-08-11 09:01:00+00	2026-08-11 09:01:00+00	\N	DSE-163	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
a52cfc85-a8ae-5847-b1ff-a0d5eb45a943	62445afe-3364-5e78-b55e-fb5429807a47	3681b9d5-7732-52da-b97e-97efdcf08fd9	a7906be2-315f-5b5e-b344-ac119fd04d1a	2026-05-20	02:00:00	Architecture notes — Omnichannel Checkout	2026-05-20 09:01:00+00	2026-05-20 09:01:00+00	\N	OC-117	3030e191-44de-5909-b035-5fe3679b482a	Active	Worklog
5b5bfeed-e2c1-57f0-b9f5-591ec4a33357	62445afe-3364-5e78-b55e-fb5429807a47	3681b9d5-7732-52da-b97e-97efdcf08fd9	9406b74a-6b7a-578b-8fbd-958684d93780	2026-05-21	03:30:00	Architecture notes — Patient Portal	2026-05-21 09:01:00+00	2026-05-21 09:01:00+00	\N	PP-145	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
ea68f4ed-e06e-5058-a06e-8ab36d380001	62445afe-3364-5e78-b55e-fb5429807a47	3681b9d5-7732-52da-b97e-97efdcf08fd9	a7906be2-315f-5b5e-b344-ac119fd04d1a	2026-05-25	01:30:00	Architecture notes — Omnichannel Checkout	2026-05-25 09:01:00+00	2026-05-25 09:01:00+00	\N	OC-119	3030e191-44de-5909-b035-5fe3679b482a	Active	Worklog
c54bf510-734f-5872-9ee1-1d9bba40a656	62445afe-3364-5e78-b55e-fb5429807a47	3681b9d5-7732-52da-b97e-97efdcf08fd9	9406b74a-6b7a-578b-8fbd-958684d93780	2026-05-26	02:00:00	Architecture notes — Patient Portal	2026-05-26 09:01:00+00	2026-05-26 09:01:00+00	\N	PP-138	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
d2b289ba-e481-5658-a22a-b23d3d8201a5	62445afe-3364-5e78-b55e-fb5429807a47	3681b9d5-7732-52da-b97e-97efdcf08fd9	a7906be2-315f-5b5e-b344-ac119fd04d1a	2026-05-28	04:00:00	Architecture notes — Omnichannel Checkout	2026-05-28 09:01:00+00	2026-05-28 09:01:00+00	\N	OC-112	3030e191-44de-5909-b035-5fe3679b482a	Active	Worklog
497fbbba-4765-51fc-b101-ce6b1d5be155	62445afe-3364-5e78-b55e-fb5429807a47	3681b9d5-7732-52da-b97e-97efdcf08fd9	67164958-1bad-5a9c-8d3a-7c4f7dfb7282	2026-05-31	02:00:00	Architecture notes — Reporting Sandbox	2026-05-31 09:01:00+00	2026-05-31 09:01:00+00	\N	RS-159	d677a650-2c23-5c0c-9f53-920636bd318e	Active	Worklog
9f573129-ae70-5127-8fa5-b1ef0705c722	62445afe-3364-5e78-b55e-fb5429807a47	3681b9d5-7732-52da-b97e-97efdcf08fd9	9406b74a-6b7a-578b-8fbd-958684d93780	2026-06-02	04:00:00	Architecture notes — Patient Portal	2026-06-02 09:01:00+00	2026-06-02 09:01:00+00	\N	PP-133	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
52d1c5fe-8e5d-5af8-8f98-8b86c056fde2	62445afe-3364-5e78-b55e-fb5429807a47	3681b9d5-7732-52da-b97e-97efdcf08fd9	9406b74a-6b7a-578b-8fbd-958684d93780	2026-06-03	00:00:00	Ryzyko release omówione i przypisane — Patient Portal	2026-06-03 09:01:00+00	2026-06-03 09:01:00+00	\N	\N	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Note
305e885b-2bae-59bc-8e64-f0000ff3d689	62445afe-3364-5e78-b55e-fb5429807a47	3681b9d5-7732-52da-b97e-97efdcf08fd9	a7906be2-315f-5b5e-b344-ac119fd04d1a	2026-06-04	02:00:00	Architecture notes — Omnichannel Checkout	2026-06-04 09:01:00+00	2026-06-04 09:01:00+00	\N	OC-107	3030e191-44de-5909-b035-5fe3679b482a	Active	Worklog
9df1b201-51c7-5dd7-8121-7015b8bc2982	62445afe-3364-5e78-b55e-fb5429807a47	3681b9d5-7732-52da-b97e-97efdcf08fd9	67164958-1bad-5a9c-8d3a-7c4f7dfb7282	2026-06-08	04:00:00	Architecture notes — Reporting Sandbox	2026-06-08 09:01:00+00	2026-06-08 09:01:00+00	\N	RS-154	d677a650-2c23-5c0c-9f53-920636bd318e	Active	Worklog
a53f77ea-2468-5897-b7fe-c091b33956cd	62445afe-3364-5e78-b55e-fb5429807a47	3681b9d5-7732-52da-b97e-97efdcf08fd9	9406b74a-6b7a-578b-8fbd-958684d93780	2026-06-10	02:00:00	Architecture notes — Patient Portal	2026-06-10 09:01:00+00	2026-06-10 09:01:00+00	\N	PP-128	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
950317db-125e-58e3-b076-f141d3cbed81	62445afe-3364-5e78-b55e-fb5429807a47	3681b9d5-7732-52da-b97e-97efdcf08fd9	67164958-1bad-5a9c-8d3a-7c4f7dfb7282	2026-06-11	02:30:00	Architecture notes — Reporting Sandbox	2026-06-11 09:01:00+00	2026-06-11 09:01:00+00	\N	RS-147	d677a650-2c23-5c0c-9f53-920636bd318e	Active	Worklog
43808357-80d7-5465-9529-49cd4051122b	62445afe-3364-5e78-b55e-fb5429807a47	3681b9d5-7732-52da-b97e-97efdcf08fd9	a7906be2-315f-5b5e-b344-ac119fd04d1a	2026-06-12	04:00:00	Architecture notes — Omnichannel Checkout	2026-06-12 09:01:00+00	2026-06-12 09:01:00+00	\N	OC-102	3030e191-44de-5909-b035-5fe3679b482a	Active	Worklog
8200f549-7b51-52a5-abef-5fe3e917376c	62445afe-3364-5e78-b55e-fb5429807a47	3681b9d5-7732-52da-b97e-97efdcf08fd9	9406b74a-6b7a-578b-8fbd-958684d93780	2026-06-14	00:30:00	Architecture notes — Patient Portal	2026-06-14 09:01:00+00	2026-06-14 09:01:00+00	\N	PP-121	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
7b6c5df5-adb6-52f5-aab1-fa819f58c441	62445afe-3364-5e78-b55e-fb5429807a47	3681b9d5-7732-52da-b97e-97efdcf08fd9	a7906be2-315f-5b5e-b344-ac119fd04d1a	2026-06-16	02:30:00	Architecture notes — Omnichannel Checkout	2026-06-16 09:01:00+00	2026-06-16 09:01:00+00	\N	OC-168	3030e191-44de-5909-b035-5fe3679b482a	Active	Worklog
717311c9-859f-54b1-9209-2c20ea8f3a21	62445afe-3364-5e78-b55e-fb5429807a47	3681b9d5-7732-52da-b97e-97efdcf08fd9	67164958-1bad-5a9c-8d3a-7c4f7dfb7282	2026-06-18	00:30:00	Architecture notes — Reporting Sandbox	2026-06-18 09:01:00+00	2026-06-18 09:01:00+00	\N	RS-142	d677a650-2c23-5c0c-9f53-920636bd318e	Active	Worklog
b7659045-6be3-5ce1-bb89-3c4e07331b77	62445afe-3364-5e78-b55e-fb5429807a47	3681b9d5-7732-52da-b97e-97efdcf08fd9	9406b74a-6b7a-578b-8fbd-958684d93780	2026-06-22	02:30:00	Architecture notes — Patient Portal	2026-06-22 09:01:00+00	2026-06-22 09:01:00+00	\N	PP-116	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
55ac812d-b05e-56a1-9e0a-94b3cd75d036	62445afe-3364-5e78-b55e-fb5429807a47	3681b9d5-7732-52da-b97e-97efdcf08fd9	a7906be2-315f-5b5e-b344-ac119fd04d1a	2026-06-24	00:30:00	Architecture notes — Omnichannel Checkout	2026-06-24 09:01:00+00	2026-06-24 09:01:00+00	\N	OC-163	3030e191-44de-5909-b035-5fe3679b482a	Active	Worklog
49317f4c-4e2d-56d5-a007-92703bce7943	62445afe-3364-5e78-b55e-fb5429807a47	3681b9d5-7732-52da-b97e-97efdcf08fd9	a7906be2-315f-5b5e-b344-ac119fd04d1a	2026-06-25	00:00:00	Ryzyko release omówione i przypisane — Omnichannel Checkout	2026-06-25 09:01:00+00	2026-06-25 09:01:00+00	\N	\N	3030e191-44de-5909-b035-5fe3679b482a	Active	Note
77e57790-f441-5bdf-87b8-be5edefb17e9	62445afe-3364-5e78-b55e-fb5429807a47	3681b9d5-7732-52da-b97e-97efdcf08fd9	67164958-1bad-5a9c-8d3a-7c4f7dfb7282	2026-06-26	02:30:00	Architecture notes — Reporting Sandbox	2026-06-26 09:01:00+00	2026-06-26 09:01:00+00	\N	RS-137	d677a650-2c23-5c0c-9f53-920636bd318e	Active	Worklog
090fd0b4-290a-5da9-9a1c-76e915b288a6	62445afe-3364-5e78-b55e-fb5429807a47	3681b9d5-7732-52da-b97e-97efdcf08fd9	9406b74a-6b7a-578b-8fbd-958684d93780	2026-06-29	00:30:00	Architecture notes — Patient Portal	2026-06-29 09:01:00+00	2026-06-29 09:01:00+00	\N	PP-111	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
07a03a51-eec0-5d32-855b-193406b2c344	62445afe-3364-5e78-b55e-fb5429807a47	3681b9d5-7732-52da-b97e-97efdcf08fd9	6f343524-7197-5868-bc07-4ca1a311dc9e	2026-06-30	02:00:00	Historical delivery wrap-up — Guest Journey	2026-06-30 09:01:00+00	2026-06-30 09:01:00+00	2026-07-13 00:00:00+00	GJ-917	498db7da-8df6-5797-90f5-e34933a83972	Archived	Worklog
61e59226-a8fa-5040-ab8d-bf17c30813c8	62445afe-3364-5e78-b55e-fb5429807a47	3681b9d5-7732-52da-b97e-97efdcf08fd9	a7906be2-315f-5b5e-b344-ac119fd04d1a	2026-07-01	02:30:00	Architecture notes — Omnichannel Checkout	2026-07-01 09:01:00+00	2026-07-01 09:01:00+00	\N	OC-158	3030e191-44de-5909-b035-5fe3679b482a	Active	Worklog
8c6d3563-938a-56a4-a938-b42c135d3f15	62445afe-3364-5e78-b55e-fb5429807a47	3681b9d5-7732-52da-b97e-97efdcf08fd9	9406b74a-6b7a-578b-8fbd-958684d93780	2026-07-02	03:00:00	Architecture notes — Patient Portal	2026-07-02 09:01:00+00	2026-07-02 09:01:00+00	\N	PP-104	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
c8c90ffd-65ef-5b3a-b82c-834f75e21ed1	62445afe-3364-5e78-b55e-fb5429807a47	3681b9d5-7732-52da-b97e-97efdcf08fd9	67164958-1bad-5a9c-8d3a-7c4f7dfb7282	2026-07-03	00:30:00	Architecture notes — Reporting Sandbox	2026-07-03 09:01:00+00	2026-07-03 09:01:00+00	\N	RS-132	d677a650-2c23-5c0c-9f53-920636bd318e	Active	Worklog
4befb81f-e981-5663-a4d6-73f379f9970d	62445afe-3364-5e78-b55e-fb5429807a47	3681b9d5-7732-52da-b97e-97efdcf08fd9	6f343524-7197-5868-bc07-4ca1a311dc9e	2026-07-03	01:30:00	Historical delivery wrap-up — Guest Journey	2026-07-03 09:02:00+00	2026-07-03 09:02:00+00	2026-07-13 00:00:00+00	GJ-935	498db7da-8df6-5797-90f5-e34933a83972	Archived	Worklog
698d3517-8ed5-544c-9986-45490c003446	62445afe-3364-5e78-b55e-fb5429807a47	3681b9d5-7732-52da-b97e-97efdcf08fd9	a7906be2-315f-5b5e-b344-ac119fd04d1a	2026-07-06	01:00:00	Architecture notes — Omnichannel Checkout	2026-07-06 09:01:00+00	2026-07-06 09:01:00+00	\N	OC-151	3030e191-44de-5909-b035-5fe3679b482a	Active	Worklog
8bfd0032-6239-50b0-9d46-1fb0456af670	62445afe-3364-5e78-b55e-fb5429807a47	3681b9d5-7732-52da-b97e-97efdcf08fd9	6f343524-7197-5868-bc07-4ca1a311dc9e	2026-07-06	02:15:00	Historical delivery wrap-up — Guest Journey	2026-07-06 09:02:00+00	2026-07-06 09:02:00+00	2026-07-13 00:00:00+00	GJ-908	498db7da-8df6-5797-90f5-e34933a83972	Archived	Worklog
02280a7a-79e2-5bed-9161-9a43dc2de3b9	62445afe-3364-5e78-b55e-fb5429807a47	3681b9d5-7732-52da-b97e-97efdcf08fd9	6f343524-7197-5868-bc07-4ca1a311dc9e	2026-07-06	01:00:00	Historical delivery wrap-up — Guest Journey	2026-07-06 09:03:00+00	2026-07-06 09:03:00+00	2026-07-13 00:00:00+00	GJ-953	498db7da-8df6-5797-90f5-e34933a83972	Archived	Worklog
9ae50807-f175-5aad-a487-b2f83e1caac6	62445afe-3364-5e78-b55e-fb5429807a47	3681b9d5-7732-52da-b97e-97efdcf08fd9	67164958-1bad-5a9c-8d3a-7c4f7dfb7282	2026-07-08	03:00:00	Architecture notes — Reporting Sandbox	2026-07-08 09:01:00+00	2026-07-08 09:01:00+00	\N	RS-125	d677a650-2c23-5c0c-9f53-920636bd318e	Active	Worklog
888ca753-85ea-5e37-af5e-aa6630932817	62445afe-3364-5e78-b55e-fb5429807a47	3681b9d5-7732-52da-b97e-97efdcf08fd9	6f343524-7197-5868-bc07-4ca1a311dc9e	2026-07-09	01:45:00	Historical delivery wrap-up — Guest Journey	2026-07-09 09:01:00+00	2026-07-09 09:01:00+00	2026-07-13 00:00:00+00	GJ-926	498db7da-8df6-5797-90f5-e34933a83972	Archived	Worklog
f9b94ce8-0d81-5443-979b-0cb7280f3e1f	62445afe-3364-5e78-b55e-fb5429807a47	3681b9d5-7732-52da-b97e-97efdcf08fd9	9406b74a-6b7a-578b-8fbd-958684d93780	2026-07-10	01:00:00	Architecture notes — Patient Portal	2026-07-10 09:01:00+00	2026-07-10 09:01:00+00	\N	PP-172	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
8c74d660-8b31-5fac-909c-98bf96c2dfb0	62445afe-3364-5e78-b55e-fb5429807a47	3681b9d5-7732-52da-b97e-97efdcf08fd9	6f343524-7197-5868-bc07-4ca1a311dc9e	2026-07-12	01:15:00	Historical delivery wrap-up — Guest Journey	2026-07-12 09:01:00+00	2026-07-12 09:01:00+00	2026-07-13 00:00:00+00	GJ-944	498db7da-8df6-5797-90f5-e34933a83972	Archived	Worklog
f7339911-d6b0-513b-b87b-ce3a6590c973	62445afe-3364-5e78-b55e-fb5429807a47	3681b9d5-7732-52da-b97e-97efdcf08fd9	a7906be2-315f-5b5e-b344-ac119fd04d1a	2026-07-13	03:00:00	Architecture notes — Omnichannel Checkout	2026-07-13 09:01:00+00	2026-07-13 09:01:00+00	\N	OC-146	3030e191-44de-5909-b035-5fe3679b482a	Active	Worklog
9e8bbcad-51bc-5da7-947d-e47c9f7d2635	62445afe-3364-5e78-b55e-fb5429807a47	3681b9d5-7732-52da-b97e-97efdcf08fd9	67164958-1bad-5a9c-8d3a-7c4f7dfb7282	2026-07-15	01:00:00	Architecture notes — Reporting Sandbox	2026-07-15 09:01:00+00	2026-07-15 09:01:00+00	\N	RS-120	d677a650-2c23-5c0c-9f53-920636bd318e	Active	Worklog
2298cbcd-aa81-5c8d-80df-1ca4129e5c3b	62445afe-3364-5e78-b55e-fb5429807a47	3681b9d5-7732-52da-b97e-97efdcf08fd9	67164958-1bad-5a9c-8d3a-7c4f7dfb7282	2026-07-16	00:00:00	Ryzyko release omówione i przypisane — Reporting Sandbox	2026-07-16 09:01:00+00	2026-07-16 09:01:00+00	\N	\N	d677a650-2c23-5c0c-9f53-920636bd318e	Active	Note
1da027f0-3b8d-5c37-b3e1-077f126776e3	62445afe-3364-5e78-b55e-fb5429807a47	3681b9d5-7732-52da-b97e-97efdcf08fd9	9406b74a-6b7a-578b-8fbd-958684d93780	2026-07-17	03:00:00	Architecture notes — Patient Portal	2026-07-17 09:01:00+00	2026-07-17 09:01:00+00	\N	PP-167	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
1749d16e-33d2-574c-a5ea-3628fcbf776b	62445afe-3364-5e78-b55e-fb5429807a47	3681b9d5-7732-52da-b97e-97efdcf08fd9	a7906be2-315f-5b5e-b344-ac119fd04d1a	2026-07-21	01:00:00	Architecture notes — Omnichannel Checkout	2026-07-21 09:01:00+00	2026-07-21 09:01:00+00	\N	OC-141	3030e191-44de-5909-b035-5fe3679b482a	Active	Worklog
2723aead-f8ea-5768-87c9-5cb3b305a3ad	62445afe-3364-5e78-b55e-fb5429807a47	3681b9d5-7732-52da-b97e-97efdcf08fd9	67164958-1bad-5a9c-8d3a-7c4f7dfb7282	2026-07-23	03:00:00	Architecture notes — Reporting Sandbox	2026-07-23 09:01:00+00	2026-07-23 09:01:00+00	\N	RS-115	d677a650-2c23-5c0c-9f53-920636bd318e	Active	Worklog
a5001664-ddef-52c5-8299-c94512b02ece	62445afe-3364-5e78-b55e-fb5429807a47	3681b9d5-7732-52da-b97e-97efdcf08fd9	a7906be2-315f-5b5e-b344-ac119fd04d1a	2026-07-24	03:30:00	Architecture notes — Omnichannel Checkout	2026-07-24 09:01:00+00	2026-07-24 09:01:00+00	\N	OC-134	3030e191-44de-5909-b035-5fe3679b482a	Active	Worklog
27084a32-a133-52fb-8936-6e6a565323df	62445afe-3364-5e78-b55e-fb5429807a47	3681b9d5-7732-52da-b97e-97efdcf08fd9	9406b74a-6b7a-578b-8fbd-958684d93780	2026-07-26	01:00:00	Architecture notes — Patient Portal	2026-07-26 09:01:00+00	2026-07-26 09:01:00+00	\N	PP-162	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
e9f2d7e1-a6d9-5002-a1b2-faf603135a70	62445afe-3364-5e78-b55e-fb5429807a47	3681b9d5-7732-52da-b97e-97efdcf08fd9	67164958-1bad-5a9c-8d3a-7c4f7dfb7282	2026-07-27	01:30:00	Architecture notes — Reporting Sandbox	2026-07-27 09:01:00+00	2026-07-27 09:01:00+00	\N	RS-108	d677a650-2c23-5c0c-9f53-920636bd318e	Active	Worklog
bdaa93cb-6d8f-59f2-a2d4-446dac0508bc	62445afe-3364-5e78-b55e-fb5429807a47	3681b9d5-7732-52da-b97e-97efdcf08fd9	9406b74a-6b7a-578b-8fbd-958684d93780	2026-07-29	03:30:00	Architecture notes — Patient Portal	2026-07-29 09:01:00+00	2026-07-29 09:01:00+00	\N	PP-155	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
2bba30d8-b510-5c29-b1e2-084505d9ba14	62445afe-3364-5e78-b55e-fb5429807a47	3681b9d5-7732-52da-b97e-97efdcf08fd9	a7906be2-315f-5b5e-b344-ac119fd04d1a	2026-07-31	01:30:00	Architecture notes — Omnichannel Checkout	2026-07-31 09:01:00+00	2026-07-31 09:01:00+00	\N	OC-129	3030e191-44de-5909-b035-5fe3679b482a	Active	Worklog
9de28196-42f6-537e-ada1-08cb5f634af0	62445afe-3364-5e78-b55e-fb5429807a47	3681b9d5-7732-52da-b97e-97efdcf08fd9	67164958-1bad-5a9c-8d3a-7c4f7dfb7282	2026-08-04	03:30:00	Architecture notes — Reporting Sandbox	2026-08-04 09:01:00+00	2026-08-04 09:01:00+00	\N	RS-103	d677a650-2c23-5c0c-9f53-920636bd318e	Active	Worklog
bb8a0eb8-3898-5547-8dd7-846583e0e301	62445afe-3364-5e78-b55e-fb5429807a47	3681b9d5-7732-52da-b97e-97efdcf08fd9	9406b74a-6b7a-578b-8fbd-958684d93780	2026-08-06	01:30:00	Architecture notes — Patient Portal	2026-08-06 09:01:00+00	2026-08-06 09:01:00+00	\N	PP-150	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
2aa3d263-0866-57df-8b71-19362bd44d2f	62445afe-3364-5e78-b55e-fb5429807a47	3681b9d5-7732-52da-b97e-97efdcf08fd9	a7906be2-315f-5b5e-b344-ac119fd04d1a	2026-08-09	03:30:00	Architecture notes — Omnichannel Checkout	2026-08-09 09:01:00+00	2026-08-09 09:01:00+00	\N	OC-124	3030e191-44de-5909-b035-5fe3679b482a	Active	Worklog
9de409a7-1e93-5e77-8881-f85fb33a1992	62445afe-3364-5e78-b55e-fb5429807a47	3681b9d5-7732-52da-b97e-97efdcf08fd9	67164958-1bad-5a9c-8d3a-7c4f7dfb7282	2026-08-11	01:30:00	Architecture notes — Reporting Sandbox	2026-08-11 09:01:00+00	2026-08-11 09:01:00+00	\N	RS-171	d677a650-2c23-5c0c-9f53-920636bd318e	Active	Worklog
e143d6b7-2fbe-59d7-a883-db1d080c63ed	62445afe-3364-5e78-b55e-fb5429807a47	636cb5b4-a95e-5d50-b513-6871826ee53f	b8cd683c-fe4d-538c-bdaf-68c28e1e14ef	2026-05-20	02:15:00	Accessibility review — Time Intelligence	2026-05-20 09:01:00+00	2026-05-20 09:01:00+00	\N	TI-108	d677a650-2c23-5c0c-9f53-920636bd318e	Active	Worklog
00fdef7d-c526-58bb-9583-fe0adb56a905	62445afe-3364-5e78-b55e-fb5429807a47	636cb5b4-a95e-5d50-b513-6871826ee53f	b8cd683c-fe4d-538c-bdaf-68c28e1e14ef	2026-05-21	03:45:00	Accessibility review — Time Intelligence	2026-05-21 09:01:00+00	2026-05-21 09:01:00+00	\N	TI-136	d677a650-2c23-5c0c-9f53-920636bd318e	Active	Worklog
784c26d5-bb84-5ffe-8ad4-076d4ae41e19	62445afe-3364-5e78-b55e-fb5429807a47	636cb5b4-a95e-5d50-b513-6871826ee53f	6dfe9630-59ce-507d-81a0-2f94cb54247f	2026-05-22	00:15:00	Accessibility review — Fleet Companion	2026-05-22 09:01:00+00	2026-05-22 09:01:00+00	\N	FC-155	eba17d28-b076-534c-918a-dca0a5be8fab	Active	Worklog
71092887-413a-5d4e-a689-0f81e0c63b50	62445afe-3364-5e78-b55e-fb5429807a47	636cb5b4-a95e-5d50-b513-6871826ee53f	6dfe9630-59ce-507d-81a0-2f94cb54247f	2026-05-25	01:45:00	Accessibility review — Fleet Companion	2026-05-25 09:01:00+00	2026-05-25 09:01:00+00	\N	FC-110	eba17d28-b076-534c-918a-dca0a5be8fab	Active	Worklog
1c37a71f-e7d5-5da1-98da-b799e9a15007	62445afe-3364-5e78-b55e-fb5429807a47	636cb5b4-a95e-5d50-b513-6871826ee53f	9406b74a-6b7a-578b-8fbd-958684d93780	2026-05-26	02:15:00	Accessibility review — Patient Portal	2026-05-26 09:01:00+00	2026-05-26 09:01:00+00	\N	PP-129	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
40d15c5f-5600-5fb8-8eb1-2a7b4d90fab1	62445afe-3364-5e78-b55e-fb5429807a47	636cb5b4-a95e-5d50-b513-6871826ee53f	f07ee933-bae1-5f0f-9e95-6c303aba6f5d	2026-05-28	00:15:00	Accessibility review — Open Banking Integration	2026-05-28 09:01:00+00	2026-05-28 09:01:00+00	\N	OBI-103	f4c5b0e8-5503-5a50-8487-4ae103b885f2	Active	Worklog
d4c23462-3f1c-59ea-89e9-32c697483ed8	62445afe-3364-5e78-b55e-fb5429807a47	636cb5b4-a95e-5d50-b513-6871826ee53f	e7ea37c3-9fe3-5010-bb38-8c7330ef5bdc	2026-05-31	02:15:00	Accessibility review — Care Analytics	2026-05-31 09:01:00+00	2026-05-31 09:01:00+00	\N	CA-150	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
3b1f41e9-f9d2-559a-9976-531a10d04d22	62445afe-3364-5e78-b55e-fb5429807a47	636cb5b4-a95e-5d50-b513-6871826ee53f	eb73aa6c-87aa-532d-8b94-109b8b863733	2026-06-02	00:15:00	Accessibility review — Design System Evolution	2026-06-02 09:01:00+00	2026-06-02 09:01:00+00	\N	DSE-124	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
c0f20bc7-a8a1-58c5-94f5-7906967cb752	62445afe-3364-5e78-b55e-fb5429807a47	636cb5b4-a95e-5d50-b513-6871826ee53f	6dfe9630-59ce-507d-81a0-2f94cb54247f	2026-06-03	00:00:00	Blocker integracji wymaga odpowiedzi partnera — Fleet Companion	2026-06-03 09:01:00+00	2026-06-03 09:01:00+00	\N	\N	eba17d28-b076-534c-918a-dca0a5be8fab	Active	Note
b296098e-39c5-575d-9ec3-efa574188e75	62445afe-3364-5e78-b55e-fb5429807a47	636cb5b4-a95e-5d50-b513-6871826ee53f	a7906be2-315f-5b5e-b344-ac119fd04d1a	2026-06-04	02:15:00	Accessibility review — Omnichannel Checkout	2026-06-04 09:01:00+00	2026-06-04 09:01:00+00	\N	OC-171	3030e191-44de-5909-b035-5fe3679b482a	Active	Worklog
3fae9e1e-082d-5567-97ea-6bff491fe2a9	62445afe-3364-5e78-b55e-fb5429807a47	636cb5b4-a95e-5d50-b513-6871826ee53f	b8cd683c-fe4d-538c-bdaf-68c28e1e14ef	2026-06-08	00:15:00	Accessibility review — Time Intelligence	2026-06-08 09:01:00+00	2026-06-08 09:01:00+00	\N	TI-145	d677a650-2c23-5c0c-9f53-920636bd318e	Active	Worklog
33199f44-13cd-5f6f-855e-511ed6311a28	62445afe-3364-5e78-b55e-fb5429807a47	636cb5b4-a95e-5d50-b513-6871826ee53f	6dfe9630-59ce-507d-81a0-2f94cb54247f	2026-06-10	02:15:00	Accessibility review — Fleet Companion	2026-06-10 09:01:00+00	2026-06-10 09:01:00+00	\N	FC-119	eba17d28-b076-534c-918a-dca0a5be8fab	Active	Worklog
0e6d4cb0-9b68-504a-ac7a-37a9739e4c69	62445afe-3364-5e78-b55e-fb5429807a47	636cb5b4-a95e-5d50-b513-6871826ee53f	9406b74a-6b7a-578b-8fbd-958684d93780	2026-06-11	02:45:00	Accessibility review — Patient Portal	2026-06-11 09:01:00+00	2026-06-11 09:01:00+00	\N	PP-138	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
13b128d1-00f0-5d84-ba69-9e9197d306cd	62445afe-3364-5e78-b55e-fb5429807a47	636cb5b4-a95e-5d50-b513-6871826ee53f	9406b74a-6b7a-578b-8fbd-958684d93780	2026-06-12	00:15:00	Accessibility review — Patient Portal	2026-06-12 09:01:00+00	2026-06-12 09:01:00+00	\N	PP-166	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
b330733e-2700-5d66-b45d-9587bd998337	62445afe-3364-5e78-b55e-fb5429807a47	636cb5b4-a95e-5d50-b513-6871826ee53f	f07ee933-bae1-5f0f-9e95-6c303aba6f5d	2026-06-14	00:45:00	Accessibility review — Open Banking Integration	2026-06-14 09:01:00+00	2026-06-14 09:01:00+00	\N	OBI-112	f4c5b0e8-5503-5a50-8487-4ae103b885f2	Active	Worklog
15f5ad0d-8da2-5531-acda-dcb3f0d0cfd7	62445afe-3364-5e78-b55e-fb5429807a47	636cb5b4-a95e-5d50-b513-6871826ee53f	e7ea37c3-9fe3-5010-bb38-8c7330ef5bdc	2026-06-16	02:45:00	Accessibility review — Care Analytics	2026-06-16 09:01:00+00	2026-06-16 09:01:00+00	\N	CA-159	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
7305b10d-a5d6-5cd0-bee4-e2650b7326cb	62445afe-3364-5e78-b55e-fb5429807a47	636cb5b4-a95e-5d50-b513-6871826ee53f	eb73aa6c-87aa-532d-8b94-109b8b863733	2026-06-18	00:45:00	Accessibility review — Design System Evolution	2026-06-18 09:01:00+00	2026-06-18 09:01:00+00	\N	DSE-133	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
43805b79-fd75-5be9-9b53-3788e71bfb6f	62445afe-3364-5e78-b55e-fb5429807a47	636cb5b4-a95e-5d50-b513-6871826ee53f	a7906be2-315f-5b5e-b344-ac119fd04d1a	2026-06-22	02:45:00	Accessibility review — Omnichannel Checkout	2026-06-22 09:01:00+00	2026-06-22 09:01:00+00	\N	OC-107	3030e191-44de-5909-b035-5fe3679b482a	Active	Worklog
3c2b7297-a460-5c1b-b36e-7967b62757b5	62445afe-3364-5e78-b55e-fb5429807a47	636cb5b4-a95e-5d50-b513-6871826ee53f	b8cd683c-fe4d-538c-bdaf-68c28e1e14ef	2026-06-24	00:45:00	Accessibility review — Time Intelligence	2026-06-24 09:01:00+00	2026-06-24 09:01:00+00	\N	TI-154	d677a650-2c23-5c0c-9f53-920636bd318e	Active	Worklog
e5a1d666-d35a-51bf-93de-0c0024756c37	62445afe-3364-5e78-b55e-fb5429807a47	636cb5b4-a95e-5d50-b513-6871826ee53f	f07ee933-bae1-5f0f-9e95-6c303aba6f5d	2026-06-25	00:00:00	Blocker integracji wymaga odpowiedzi partnera — Open Banking Integration	2026-06-25 09:01:00+00	2026-06-25 09:01:00+00	\N	\N	f4c5b0e8-5503-5a50-8487-4ae103b885f2	Active	Note
e69ab195-6688-58d4-bbb0-cddd467a9042	62445afe-3364-5e78-b55e-fb5429807a47	636cb5b4-a95e-5d50-b513-6871826ee53f	6dfe9630-59ce-507d-81a0-2f94cb54247f	2026-06-26	02:45:00	Accessibility review — Fleet Companion	2026-06-26 09:01:00+00	2026-06-26 09:01:00+00	\N	FC-128	eba17d28-b076-534c-918a-dca0a5be8fab	Active	Worklog
396c3892-f431-5618-8fb3-f99a48641a73	62445afe-3364-5e78-b55e-fb5429807a47	636cb5b4-a95e-5d50-b513-6871826ee53f	9406b74a-6b7a-578b-8fbd-958684d93780	2026-06-29	00:45:00	Accessibility review — Patient Portal	2026-06-29 09:01:00+00	2026-06-29 09:01:00+00	\N	PP-102	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
b9b848e1-9155-5914-9202-0812bc60cdf1	62445afe-3364-5e78-b55e-fb5429807a47	636cb5b4-a95e-5d50-b513-6871826ee53f	f07ee933-bae1-5f0f-9e95-6c303aba6f5d	2026-07-01	02:45:00	Accessibility review — Open Banking Integration	2026-07-01 09:01:00+00	2026-07-01 09:01:00+00	\N	OBI-149	f4c5b0e8-5503-5a50-8487-4ae103b885f2	Active	Worklog
b8858ad2-5543-51d6-9b08-b103728e8853	62445afe-3364-5e78-b55e-fb5429807a47	636cb5b4-a95e-5d50-b513-6871826ee53f	e7ea37c3-9fe3-5010-bb38-8c7330ef5bdc	2026-07-02	03:15:00	Accessibility review — Care Analytics	2026-07-02 09:01:00+00	2026-07-02 09:01:00+00	\N	CA-168	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
091cc0d2-2f7e-5898-8ad9-d94a9e0ce028	62445afe-3364-5e78-b55e-fb5429807a47	636cb5b4-a95e-5d50-b513-6871826ee53f	e7ea37c3-9fe3-5010-bb38-8c7330ef5bdc	2026-07-03	00:45:00	Accessibility review — Care Analytics	2026-07-03 09:01:00+00	2026-07-03 09:01:00+00	\N	CA-123	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
ac2dc421-4100-5a8e-a375-c5c27773d4c5	62445afe-3364-5e78-b55e-fb5429807a47	636cb5b4-a95e-5d50-b513-6871826ee53f	eb73aa6c-87aa-532d-8b94-109b8b863733	2026-07-06	01:15:00	Accessibility review — Design System Evolution	2026-07-06 09:01:00+00	2026-07-06 09:01:00+00	\N	DSE-142	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
f87618d0-aff0-58c9-9684-84aa2a3d4203	62445afe-3364-5e78-b55e-fb5429807a47	636cb5b4-a95e-5d50-b513-6871826ee53f	a7906be2-315f-5b5e-b344-ac119fd04d1a	2026-07-08	03:15:00	Accessibility review — Omnichannel Checkout	2026-07-08 09:01:00+00	2026-07-08 09:01:00+00	\N	OC-116	3030e191-44de-5909-b035-5fe3679b482a	Active	Worklog
d1e2e1cf-0ba4-5fb7-9fa7-e9dac9c6d0cc	62445afe-3364-5e78-b55e-fb5429807a47	636cb5b4-a95e-5d50-b513-6871826ee53f	b8cd683c-fe4d-538c-bdaf-68c28e1e14ef	2026-07-10	01:15:00	Accessibility review — Time Intelligence	2026-07-10 09:01:00+00	2026-07-10 09:01:00+00	\N	TI-163	d677a650-2c23-5c0c-9f53-920636bd318e	Active	Worklog
29b91b9e-239c-5c12-99e9-1089ec607635	62445afe-3364-5e78-b55e-fb5429807a47	636cb5b4-a95e-5d50-b513-6871826ee53f	6dfe9630-59ce-507d-81a0-2f94cb54247f	2026-07-13	03:15:00	Accessibility review — Fleet Companion	2026-07-13 09:01:00+00	2026-07-13 09:01:00+00	\N	FC-137	eba17d28-b076-534c-918a-dca0a5be8fab	Active	Worklog
de674cc3-1ad3-591a-982d-ff85ee0b4007	62445afe-3364-5e78-b55e-fb5429807a47	636cb5b4-a95e-5d50-b513-6871826ee53f	9406b74a-6b7a-578b-8fbd-958684d93780	2026-07-15	01:15:00	Accessibility review — Patient Portal	2026-07-15 09:01:00+00	2026-07-15 09:01:00+00	\N	PP-111	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
d73ea51e-9df1-5b38-ac61-edeee8c593f0	62445afe-3364-5e78-b55e-fb5429807a47	636cb5b4-a95e-5d50-b513-6871826ee53f	eb73aa6c-87aa-532d-8b94-109b8b863733	2026-07-16	00:00:00	Blocker integracji wymaga odpowiedzi partnera — Design System Evolution	2026-07-16 09:01:00+00	2026-07-16 09:01:00+00	\N	\N	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Note
78da6340-710c-535a-a8dd-0aa06d2bd55a	62445afe-3364-5e78-b55e-fb5429807a47	636cb5b4-a95e-5d50-b513-6871826ee53f	f07ee933-bae1-5f0f-9e95-6c303aba6f5d	2026-07-17	03:15:00	Accessibility review — Open Banking Integration	2026-07-17 09:01:00+00	2026-07-17 09:01:00+00	\N	OBI-158	f4c5b0e8-5503-5a50-8487-4ae103b885f2	Active	Worklog
32dc5a96-7f84-5e1a-bfb5-75811165b626	62445afe-3364-5e78-b55e-fb5429807a47	636cb5b4-a95e-5d50-b513-6871826ee53f	e7ea37c3-9fe3-5010-bb38-8c7330ef5bdc	2026-07-21	01:15:00	Accessibility review — Care Analytics	2026-07-21 09:01:00+00	2026-07-21 09:01:00+00	\N	CA-132	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
b32ba53f-555d-5e9e-af9e-844b1bab2eaa	62445afe-3364-5e78-b55e-fb5429807a47	636cb5b4-a95e-5d50-b513-6871826ee53f	eb73aa6c-87aa-532d-8b94-109b8b863733	2026-07-23	03:15:00	Accessibility review — Design System Evolution	2026-07-23 09:01:00+00	2026-07-23 09:01:00+00	\N	DSE-106	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
2582ec0b-b428-5e9c-b6fc-bf4375cce466	62445afe-3364-5e78-b55e-fb5429807a47	636cb5b4-a95e-5d50-b513-6871826ee53f	a7906be2-315f-5b5e-b344-ac119fd04d1a	2026-07-24	03:45:00	Accessibility review — Omnichannel Checkout	2026-07-24 09:01:00+00	2026-07-24 09:01:00+00	\N	OC-125	3030e191-44de-5909-b035-5fe3679b482a	Active	Worklog
9cd3ce8d-2df4-5134-adbf-a267136d0e53	62445afe-3364-5e78-b55e-fb5429807a47	636cb5b4-a95e-5d50-b513-6871826ee53f	a7906be2-315f-5b5e-b344-ac119fd04d1a	2026-07-26	01:15:00	Accessibility review — Omnichannel Checkout	2026-07-26 09:01:00+00	2026-07-26 09:01:00+00	\N	OC-153	3030e191-44de-5909-b035-5fe3679b482a	Active	Worklog
66e43060-b07c-5f02-b1c1-8d1e35edf032	62445afe-3364-5e78-b55e-fb5429807a47	636cb5b4-a95e-5d50-b513-6871826ee53f	b8cd683c-fe4d-538c-bdaf-68c28e1e14ef	2026-07-27	01:45:00	Accessibility review — Time Intelligence	2026-07-27 09:01:00+00	2026-07-27 09:01:00+00	\N	TI-172	d677a650-2c23-5c0c-9f53-920636bd318e	Active	Worklog
d953ea54-85ca-598c-962a-153bebf41970	62445afe-3364-5e78-b55e-fb5429807a47	636cb5b4-a95e-5d50-b513-6871826ee53f	6dfe9630-59ce-507d-81a0-2f94cb54247f	2026-07-29	03:45:00	Accessibility review — Fleet Companion	2026-07-29 09:01:00+00	2026-07-29 09:01:00+00	\N	FC-146	eba17d28-b076-534c-918a-dca0a5be8fab	Active	Worklog
f17c3258-4a01-5018-9f8e-6203b70c2701	62445afe-3364-5e78-b55e-fb5429807a47	636cb5b4-a95e-5d50-b513-6871826ee53f	9406b74a-6b7a-578b-8fbd-958684d93780	2026-07-31	01:45:00	Accessibility review — Patient Portal	2026-07-31 09:01:00+00	2026-07-31 09:01:00+00	\N	PP-120	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
b1c9a634-2f13-546c-b162-b349af57f278	62445afe-3364-5e78-b55e-fb5429807a47	636cb5b4-a95e-5d50-b513-6871826ee53f	f07ee933-bae1-5f0f-9e95-6c303aba6f5d	2026-08-04	03:45:00	Accessibility review — Open Banking Integration	2026-08-04 09:01:00+00	2026-08-04 09:01:00+00	\N	OBI-167	f4c5b0e8-5503-5a50-8487-4ae103b885f2	Active	Worklog
35c934f3-b89e-5d92-9b2a-3e684f30d58d	62445afe-3364-5e78-b55e-fb5429807a47	636cb5b4-a95e-5d50-b513-6871826ee53f	e7ea37c3-9fe3-5010-bb38-8c7330ef5bdc	2026-08-06	01:45:00	Accessibility review — Care Analytics	2026-08-06 09:01:00+00	2026-08-06 09:01:00+00	\N	CA-141	79d55734-27e3-5dd0-bf06-6726f0eba8b3	Active	Worklog
956a84db-fb9c-5d72-92ea-c780273f38ac	62445afe-3364-5e78-b55e-fb5429807a47	636cb5b4-a95e-5d50-b513-6871826ee53f	b8cd683c-fe4d-538c-bdaf-68c28e1e14ef	2026-08-07	00:00:00	Blocker integracji wymaga odpowiedzi partnera — Time Intelligence	2026-08-07 09:01:00+00	2026-08-07 09:01:00+00	\N	\N	d677a650-2c23-5c0c-9f53-920636bd318e	Active	Note
5b9fce09-3ac0-5397-beeb-3c5e358b299f	62445afe-3364-5e78-b55e-fb5429807a47	636cb5b4-a95e-5d50-b513-6871826ee53f	eb73aa6c-87aa-532d-8b94-109b8b863733	2026-08-09	03:45:00	Accessibility review — Design System Evolution	2026-08-09 09:01:00+00	2026-08-09 09:01:00+00	\N	DSE-115	9baaa280-6dca-51c5-85f7-99b7fd05e701	Active	Worklog
b0229585-e524-5939-8960-418184050dc5	62445afe-3364-5e78-b55e-fb5429807a47	636cb5b4-a95e-5d50-b513-6871826ee53f	a7906be2-315f-5b5e-b344-ac119fd04d1a	2026-08-11	01:45:00	Accessibility review — Omnichannel Checkout	2026-08-11 09:01:00+00	2026-08-11 09:01:00+00	\N	OC-162	3030e191-44de-5909-b035-5fe3679b482a	Active	Worklog
\.


--
-- Data for Name: work_unit_idempotency; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.work_unit_idempotency (claim_id, organization_id, actor_id, idempotency_key, operation, target_work_unit_id, fingerprint_version, canonical_request, fingerprint, state, outcome_status, outcome_body, result_work_unit_id, created_at, response_expires_at) FROM stdin;
\.


--
-- Data for Name: work_unit_order; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.work_unit_order (organization_id, user_id, date, work_unit_ids) FROM stdin;
\.


--
-- Data for Name: work_unit_pm_classification; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.work_unit_pm_classification (work_unit_id, pm_project_id, pm_task_id, version, last_changed_by, last_changed_at) FROM stdin;
\.


--
-- Data for Name: work_unit_pm_classification_history; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.work_unit_pm_classification_history (id, work_unit_id, version, operation, actor_id, actor_display_name, changed_at, before_pm_project_id, before_pm_project_name, before_pm_client_id, before_pm_client_name, before_pm_task_id, after_pm_project_id, after_pm_project_name, after_pm_client_id, after_pm_client_name, after_pm_task_id) FROM stdin;
\.


--
-- Name: client client_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client
    ADD CONSTRAINT client_pkey PRIMARY KEY (id);


--
-- Name: flyway_schema_history flyway_schema_history_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.flyway_schema_history
    ADD CONSTRAINT flyway_schema_history_pk PRIMARY KEY (installed_rank);


--
-- Name: invitation invitation_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invitation
    ADD CONSTRAINT invitation_pkey PRIMARY KEY (id);


--
-- Name: mail_history mail_history_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mail_history
    ADD CONSTRAINT mail_history_pkey PRIMARY KEY (mail_uuid);


--
-- Name: organization organization_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.organization
    ADD CONSTRAINT organization_pkey PRIMARY KEY (id);


--
-- Name: organization organization_slug_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.organization
    ADD CONSTRAINT organization_slug_key UNIQUE (slug);


--
-- Name: organization_user organization_user_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.organization_user
    ADD CONSTRAINT organization_user_pkey PRIMARY KEY (id);


--
-- Name: project project_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project
    ADD CONSTRAINT project_pkey PRIMARY KEY (id);


--
-- Name: project_user project_user_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_user
    ADD CONSTRAINT project_user_pkey PRIMARY KEY (id);


--
-- Name: quartz_blob_triggers quartz_blob_triggers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.quartz_blob_triggers
    ADD CONSTRAINT quartz_blob_triggers_pkey PRIMARY KEY (sched_name, trigger_name, trigger_group);


--
-- Name: quartz_calendars quartz_calendars_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.quartz_calendars
    ADD CONSTRAINT quartz_calendars_pkey PRIMARY KEY (sched_name, calendar_name);


--
-- Name: quartz_cron_triggers quartz_cron_triggers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.quartz_cron_triggers
    ADD CONSTRAINT quartz_cron_triggers_pkey PRIMARY KEY (sched_name, trigger_name, trigger_group);


--
-- Name: quartz_fired_triggers quartz_fired_triggers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.quartz_fired_triggers
    ADD CONSTRAINT quartz_fired_triggers_pkey PRIMARY KEY (sched_name, entry_id);


--
-- Name: quartz_job_details quartz_job_details_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.quartz_job_details
    ADD CONSTRAINT quartz_job_details_pkey PRIMARY KEY (sched_name, job_name, job_group);


--
-- Name: quartz_locks quartz_locks_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.quartz_locks
    ADD CONSTRAINT quartz_locks_pkey PRIMARY KEY (sched_name, lock_name);


--
-- Name: quartz_paused_trigger_grps quartz_paused_trigger_grps_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.quartz_paused_trigger_grps
    ADD CONSTRAINT quartz_paused_trigger_grps_pkey PRIMARY KEY (sched_name, trigger_group);


--
-- Name: quartz_scheduler_state quartz_scheduler_state_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.quartz_scheduler_state
    ADD CONSTRAINT quartz_scheduler_state_pkey PRIMARY KEY (sched_name, instance_name);


--
-- Name: quartz_simple_triggers quartz_simple_triggers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.quartz_simple_triggers
    ADD CONSTRAINT quartz_simple_triggers_pkey PRIMARY KEY (sched_name, trigger_name, trigger_group);


--
-- Name: quartz_simprop_triggers quartz_simprop_triggers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.quartz_simprop_triggers
    ADD CONSTRAINT quartz_simprop_triggers_pkey PRIMARY KEY (sched_name, trigger_name, trigger_group);


--
-- Name: quartz_triggers quartz_triggers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.quartz_triggers
    ADD CONSTRAINT quartz_triggers_pkey PRIMARY KEY (sched_name, trigger_name, trigger_group);


--
-- Name: refresh_token refresh_token_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.refresh_token
    ADD CONSTRAINT refresh_token_pkey PRIMARY KEY (user_id, device_id);


--
-- Name: saml_config saml_config_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.saml_config
    ADD CONSTRAINT saml_config_pkey PRIMARY KEY (organization_id);


--
-- Name: saml_request saml_request_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.saml_request
    ADD CONSTRAINT saml_request_pkey PRIMARY KEY (id);


--
-- Name: user_identity user_identity_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_identity
    ADD CONSTRAINT user_identity_pkey PRIMARY KEY (id);


--
-- Name: user_login_token user_login_token_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_login_token
    ADD CONSTRAINT user_login_token_pkey PRIMARY KEY (id);


--
-- Name: user_password user_password_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_password
    ADD CONSTRAINT user_password_pkey PRIMARY KEY (user_identity_id);


--
-- Name: user user_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."user"
    ADD CONSTRAINT user_pkey PRIMARY KEY (id);


--
-- Name: work_unit_idempotency work_unit_idempotency_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.work_unit_idempotency
    ADD CONSTRAINT work_unit_idempotency_pkey PRIMARY KEY (claim_id);


--
-- Name: work_unit_idempotency work_unit_idempotency_scope_key_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.work_unit_idempotency
    ADD CONSTRAINT work_unit_idempotency_scope_key_unique UNIQUE (organization_id, actor_id, idempotency_key);


--
-- Name: work_unit_order work_unit_order_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.work_unit_order
    ADD CONSTRAINT work_unit_order_pkey PRIMARY KEY (organization_id, user_id, date);


--
-- Name: work_unit work_unit_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.work_unit
    ADD CONSTRAINT work_unit_pkey PRIMARY KEY (id);


--
-- Name: work_unit_pm_classification_history work_unit_pm_classification_history_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.work_unit_pm_classification_history
    ADD CONSTRAINT work_unit_pm_classification_history_pkey PRIMARY KEY (id);


--
-- Name: work_unit_pm_classification_history work_unit_pm_classification_history_work_unit_id_version_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.work_unit_pm_classification_history
    ADD CONSTRAINT work_unit_pm_classification_history_work_unit_id_version_key UNIQUE (work_unit_id, version);


--
-- Name: work_unit_pm_classification work_unit_pm_classification_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.work_unit_pm_classification
    ADD CONSTRAINT work_unit_pm_classification_pkey PRIMARY KEY (work_unit_id);


--
-- Name: flyway_schema_history_s_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX flyway_schema_history_s_idx ON public.flyway_schema_history USING btree (success);


--
-- Name: idx_ft_inst_job_req_rcvry; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_ft_inst_job_req_rcvry ON public.quartz_fired_triggers USING btree (sched_name, instance_name, requests_recovery);


--
-- Name: idx_ft_j_g; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_ft_j_g ON public.quartz_fired_triggers USING btree (sched_name, job_name, job_group);


--
-- Name: idx_ft_jg; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_ft_jg ON public.quartz_fired_triggers USING btree (sched_name, job_group);


--
-- Name: idx_ft_t_g; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_ft_t_g ON public.quartz_fired_triggers USING btree (sched_name, trigger_name, trigger_group);


--
-- Name: idx_ft_tg; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_ft_tg ON public.quartz_fired_triggers USING btree (sched_name, trigger_group);


--
-- Name: idx_ft_trig_inst_name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_ft_trig_inst_name ON public.quartz_fired_triggers USING btree (sched_name, instance_name);


--
-- Name: idx_j_grp; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_j_grp ON public.quartz_job_details USING btree (sched_name, job_group);


--
-- Name: idx_j_req_recovery; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_j_req_recovery ON public.quartz_job_details USING btree (sched_name, requests_recovery);


--
-- Name: idx_t_c; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_t_c ON public.quartz_triggers USING btree (sched_name, calendar_name);


--
-- Name: idx_t_g; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_t_g ON public.quartz_triggers USING btree (sched_name, trigger_group);


--
-- Name: idx_t_j; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_t_j ON public.quartz_triggers USING btree (sched_name, job_name, job_group);


--
-- Name: idx_t_jg; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_t_jg ON public.quartz_triggers USING btree (sched_name, job_group);


--
-- Name: idx_t_n_g_state; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_t_n_g_state ON public.quartz_triggers USING btree (sched_name, trigger_group, trigger_state);


--
-- Name: idx_t_n_state; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_t_n_state ON public.quartz_triggers USING btree (sched_name, trigger_name, trigger_group, trigger_state);


--
-- Name: idx_t_next_fire_time; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_t_next_fire_time ON public.quartz_triggers USING btree (sched_name, next_fire_time);


--
-- Name: idx_t_nft_misfire; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_t_nft_misfire ON public.quartz_triggers USING btree (sched_name, misfire_instr, next_fire_time);


--
-- Name: idx_t_nft_st; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_t_nft_st ON public.quartz_triggers USING btree (sched_name, trigger_state, next_fire_time);


--
-- Name: idx_t_nft_st_misfire; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_t_nft_st_misfire ON public.quartz_triggers USING btree (sched_name, misfire_instr, next_fire_time, trigger_state);


--
-- Name: idx_t_nft_st_misfire_grp; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_t_nft_st_misfire_grp ON public.quartz_triggers USING btree (sched_name, misfire_instr, next_fire_time, trigger_group, trigger_state);


--
-- Name: idx_t_state; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_t_state ON public.quartz_triggers USING btree (sched_name, trigger_state);


--
-- Name: project_user_project_id_user_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX project_user_project_id_user_id_idx ON public.project_user USING btree (project_id, user_id);


--
-- Name: saml_request_one_time_token_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX saml_request_one_time_token_idx ON public.saml_request USING btree (one_time_token);


--
-- Name: sendgrid_mail_event_email_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX sendgrid_mail_event_email_idx ON public.sendgrid_mail_event USING btree (email);


--
-- Name: sendgrid_mail_event_mail_uuid_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX sendgrid_mail_event_mail_uuid_idx ON public.sendgrid_mail_event USING btree (mail_uuid);


--
-- Name: user_identity_user_id_type_value_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX user_identity_user_id_type_value_idx ON public.user_identity USING btree (user_id, type, value);


--
-- Name: user_identity_value_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX user_identity_value_idx ON public.user_identity USING btree (value);


--
-- Name: user_login_token_login_token_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX user_login_token_login_token_idx ON public.user_login_token USING btree (login_token);


--
-- Name: user_login_token_user_identity_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX user_login_token_user_identity_id_idx ON public.user_login_token USING btree (user_identity_id);


--
-- Name: user_password_user_identity_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX user_password_user_identity_id_idx ON public.user_password USING btree (user_identity_id);


--
-- Name: work_unit_idempotency_expired_response_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX work_unit_idempotency_expired_response_idx ON public.work_unit_idempotency USING btree (response_expires_at) WHERE (state = 'Completed'::text);


--
-- Name: work_unit_pm_classification_history_version_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX work_unit_pm_classification_history_version_idx ON public.work_unit_pm_classification_history USING btree (work_unit_id, version DESC);


--
-- Name: work_unit_pm_classification_project_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX work_unit_pm_classification_project_idx ON public.work_unit_pm_classification USING btree (pm_project_id);


--
-- Name: work_unit_user_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX work_unit_user_id_idx ON public.work_unit USING btree (user_id);


--
-- Name: work_unit work_unit_client_id_from_project; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER work_unit_client_id_from_project BEFORE INSERT OR UPDATE ON public.work_unit FOR EACH ROW EXECUTE FUNCTION public.set_work_unit_client_id_from_project();


--
-- Name: client client_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client
    ADD CONSTRAINT client_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organization(id);


--
-- Name: invitation invitation_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invitation
    ADD CONSTRAINT invitation_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organization(id);


--
-- Name: organization_user organization_user_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.organization_user
    ADD CONSTRAINT organization_user_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organization(id);


--
-- Name: organization_user organization_user_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.organization_user
    ADD CONSTRAINT organization_user_user_id_fkey FOREIGN KEY (user_id) REFERENCES public."user"(id);


--
-- Name: project project_client_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project
    ADD CONSTRAINT project_client_id_fkey FOREIGN KEY (client_id) REFERENCES public.client(id);


--
-- Name: project project_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project
    ADD CONSTRAINT project_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organization(id);


--
-- Name: project_user project_user_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_user
    ADD CONSTRAINT project_user_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.project(id);


--
-- Name: project_user project_user_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_user
    ADD CONSTRAINT project_user_user_id_fkey FOREIGN KEY (user_id) REFERENCES public."user"(id);


--
-- Name: quartz_blob_triggers quartz_blob_triggers_sched_name_trigger_name_trigger_group_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.quartz_blob_triggers
    ADD CONSTRAINT quartz_blob_triggers_sched_name_trigger_name_trigger_group_fkey FOREIGN KEY (sched_name, trigger_name, trigger_group) REFERENCES public.quartz_triggers(sched_name, trigger_name, trigger_group);


--
-- Name: quartz_cron_triggers quartz_cron_triggers_sched_name_trigger_name_trigger_group_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.quartz_cron_triggers
    ADD CONSTRAINT quartz_cron_triggers_sched_name_trigger_name_trigger_group_fkey FOREIGN KEY (sched_name, trigger_name, trigger_group) REFERENCES public.quartz_triggers(sched_name, trigger_name, trigger_group);


--
-- Name: quartz_simple_triggers quartz_simple_triggers_sched_name_trigger_name_trigger_gro_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.quartz_simple_triggers
    ADD CONSTRAINT quartz_simple_triggers_sched_name_trigger_name_trigger_gro_fkey FOREIGN KEY (sched_name, trigger_name, trigger_group) REFERENCES public.quartz_triggers(sched_name, trigger_name, trigger_group);


--
-- Name: quartz_simprop_triggers quartz_simprop_triggers_sched_name_trigger_name_trigger_gr_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.quartz_simprop_triggers
    ADD CONSTRAINT quartz_simprop_triggers_sched_name_trigger_name_trigger_gr_fkey FOREIGN KEY (sched_name, trigger_name, trigger_group) REFERENCES public.quartz_triggers(sched_name, trigger_name, trigger_group);


--
-- Name: quartz_triggers quartz_triggers_sched_name_job_name_job_group_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.quartz_triggers
    ADD CONSTRAINT quartz_triggers_sched_name_job_name_job_group_fkey FOREIGN KEY (sched_name, job_name, job_group) REFERENCES public.quartz_job_details(sched_name, job_name, job_group);


--
-- Name: refresh_token refresh_token_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.refresh_token
    ADD CONSTRAINT refresh_token_user_id_fkey FOREIGN KEY (user_id) REFERENCES public."user"(id);


--
-- Name: saml_config saml_config_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.saml_config
    ADD CONSTRAINT saml_config_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organization(id);


--
-- Name: saml_request saml_request_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.saml_request
    ADD CONSTRAINT saml_request_user_id_fkey FOREIGN KEY (user_id) REFERENCES public."user"(id);


--
-- Name: sendgrid_mail_event sendgrid_mail_event_mail_uuid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sendgrid_mail_event
    ADD CONSTRAINT sendgrid_mail_event_mail_uuid_fkey FOREIGN KEY (mail_uuid) REFERENCES public.mail_history(mail_uuid);


--
-- Name: user_identity user_identity_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_identity
    ADD CONSTRAINT user_identity_user_id_fkey FOREIGN KEY (user_id) REFERENCES public."user"(id);


--
-- Name: user_login_token user_login_token_user_identity_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_login_token
    ADD CONSTRAINT user_login_token_user_identity_id_fkey FOREIGN KEY (user_identity_id) REFERENCES public.user_identity(id) ON DELETE CASCADE;


--
-- Name: user_password user_password_user_identity_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_password
    ADD CONSTRAINT user_password_user_identity_id_fkey FOREIGN KEY (user_identity_id) REFERENCES public.user_identity(id) ON DELETE CASCADE;


--
-- Name: work_unit work_unit_client_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.work_unit
    ADD CONSTRAINT work_unit_client_id_fkey FOREIGN KEY (client_id) REFERENCES public.client(id);


--
-- Name: work_unit_idempotency work_unit_idempotency_actor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.work_unit_idempotency
    ADD CONSTRAINT work_unit_idempotency_actor_id_fkey FOREIGN KEY (actor_id) REFERENCES public."user"(id);


--
-- Name: work_unit_idempotency work_unit_idempotency_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.work_unit_idempotency
    ADD CONSTRAINT work_unit_idempotency_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organization(id);


--
-- Name: work_unit_order work_unit_order_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.work_unit_order
    ADD CONSTRAINT work_unit_order_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organization(id);


--
-- Name: work_unit_order work_unit_order_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.work_unit_order
    ADD CONSTRAINT work_unit_order_user_id_fkey FOREIGN KEY (user_id) REFERENCES public."user"(id);


--
-- Name: work_unit work_unit_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.work_unit
    ADD CONSTRAINT work_unit_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organization(id);


--
-- Name: work_unit_pm_classification_history work_unit_pm_classification_history_actor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.work_unit_pm_classification_history
    ADD CONSTRAINT work_unit_pm_classification_history_actor_id_fkey FOREIGN KEY (actor_id) REFERENCES public."user"(id);


--
-- Name: work_unit_pm_classification_history work_unit_pm_classification_history_work_unit_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.work_unit_pm_classification_history
    ADD CONSTRAINT work_unit_pm_classification_history_work_unit_id_fkey FOREIGN KEY (work_unit_id) REFERENCES public.work_unit(id);


--
-- Name: work_unit_pm_classification work_unit_pm_classification_last_changed_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.work_unit_pm_classification
    ADD CONSTRAINT work_unit_pm_classification_last_changed_by_fkey FOREIGN KEY (last_changed_by) REFERENCES public."user"(id);


--
-- Name: work_unit_pm_classification work_unit_pm_classification_pm_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.work_unit_pm_classification
    ADD CONSTRAINT work_unit_pm_classification_pm_project_id_fkey FOREIGN KEY (pm_project_id) REFERENCES public.project(id);


--
-- Name: work_unit_pm_classification work_unit_pm_classification_work_unit_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.work_unit_pm_classification
    ADD CONSTRAINT work_unit_pm_classification_work_unit_id_fkey FOREIGN KEY (work_unit_id) REFERENCES public.work_unit(id);


--
-- Name: work_unit work_unit_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.work_unit
    ADD CONSTRAINT work_unit_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.project(id);


--
-- Name: work_unit work_unit_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.work_unit
    ADD CONSTRAINT work_unit_user_id_fkey FOREIGN KEY (user_id) REFERENCES public."user"(id);


--
-- PostgreSQL database dump complete
--

